import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter);

const routes = [
    {
        path: '/home',
        name: 'home',
        component: () => import('../views/home')
    },
    {
        path: '/classroom',
        name: 'classroom',
        component: () => import('../views/classroom')
    },
    {
        path: '/login',
        name: 'login',
        component: () => import('../views/login')
    },
    {
        path: '/',
        redirect: '/home'
    },
];

const router = new VueRouter({
    mode: 'history',
    base: '/masters-admin-web/',
    routes
});

export default router
