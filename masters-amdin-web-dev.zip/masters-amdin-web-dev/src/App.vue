<template>
    <div id="app">
        <router-view/>
    </div>
</template>

<style lang="less">
    @import "./assets/style/public.less";
</style>
