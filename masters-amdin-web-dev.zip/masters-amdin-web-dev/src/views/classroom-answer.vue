<!--suppress RequiredAttributes -->
<template>
    <div class="classroom-answer">
        <div class="answer-machine">
            <div class="set-subject">
                <div class="item-subject-title">设置答题器</div>
                <div class="setting">
                    <el-select v-model="subject.answerTime" style="width: 90px" :disabled="status.answering">
                        <el-option label="30秒" :value="30"></el-option>
                        <el-option label="45秒" :value="45"></el-option>
                        <el-option label="1分钟" :value="60"></el-option>
                        <el-option label="2分钟" :value="120"></el-option>
                    </el-select>
                    <template v-if="answerType === constData.ANSWER_TYPE_PRIMARY">
                        <el-select v-model="subject.subjectType" style="width: 90px;margin-left: 10px" :disabled="status.answering">
                            <el-option label="选择题" :value="constData.SUBJECT_TYPE_CHOICE"></el-option>
                            <el-option label="填空题" :value="constData.SUBJECT_TYPE_Completion"></el-option>
                            <el-option label="解答题" :value="constData.SUBJECT_TYPE_SOLVING"></el-option>
                        </el-select>
                        <div style="height: 10px"></div>
                        <el-input type="textarea" :readonly="status.answering" v-model="subject.subjectTitle" maxlength="200"
                                  placeholder="在此处输入题目"></el-input>
                        <div style="height: 10px"></div>
                        <template v-if="subject.subjectType === constData.SUBJECT_TYPE_CHOICE">
                            <div class="option-list">
                                <div class="option-item" v-for="(item,index) in subject.optionList" :key="index">
                                    <span>{{item.label}}:</span>
                                    <el-input class="value-input" :readonly="status.answering" maxlength="100" size="mini"
                                              v-model="item.value"></el-input>
                                    <el-button size="mini" :type="subject.rightAnswer === item.label ? 'primary':''"
                                               @click="choseRightAnswer(item.label)">设为正确答案
                                    </el-button>
                                </div>
                            </div>
                        </template>
                        <div style="height: 20px"></div>
                    </template>
                    <template v-if="answerType === constData.ANSWER_TYPE_CLASS">
                        <div class="class-answer">
                            <div :class="subject.rightAnswer === item.label ? 'class-answer-item class-answer-item-active':'class-answer-item'"
                                 v-for="(item,index) in subject.optionList"
                                 :key="index"
                                 @click="choseRightAnswer(item.label)">{{item.label}}</div>
                        </div>
                    </template>
                    <div class="operate-bar">
                        <el-button type="primary" style="margin-left: 10px" @click="answerStart" :disabled="status.answering"
                                   :loading="status.answerStartLoading">开始答题
                        </el-button>
                        <el-button @click="answerCancel">关闭答题</el-button>
                    </div>
                </div>
            </div>
            <div class="look-subject">
                <div class="item-subject-title">查看答题结果</div>
                <div class="result">
                    <div class="result-total">
                        <span v-if="subject.subjectType === constData.SUBJECT_TYPE_CHOICE">正确答案: {{subject.rightAnswer}}</span>
                        <span>已答题人数: {{studentAnsweringList.length}}</span>
                        <span v-if="subject.subjectType === constData.SUBJECT_TYPE_CHOICE">正确率: {{accuracy}}%</span>
                    </div>
                    <div style="height: 10px"></div>
                    <el-table v-if="subject.subjectType === constData.SUBJECT_TYPE_CHOICE && subject.optionList.length > 0" :data="choiceResultData">
                        <el-table-column align="center" v-for="(item,index) in subject.optionList" :key="index" :label="item.label">
                            <template slot-scope="scope">
                                {{scope.row[item.label] || 0}}
                            </template>
                        </el-table-column>
                    </el-table>
                    <div style="height: 10px"></div>
                    <el-table :data="studentAnsweringList">
                        <el-table-column align="center" label="学生名称" prop="studentName"></el-table-column>
                        <el-table-column align="center" label="答题用时(秒)" prop="time"></el-table-column>
                        <el-table-column align="center" label="所答答案" prop="answer"></el-table-column>
                    </el-table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {mapState} from 'vuex'
    import constData from './../assets/javascript/const-data'

    export default {
        name: "classroom-answer",
        computed: {
            ...mapState({
                studentAnsweringList: state => state.classroomAnswer.studentAnsweringList,
                accuracy: state => state.classroomAnswer.accuracy,
                choiceResultData: state => state.classroomAnswer.choiceResultData,
                tic: state => state.tic
            })
        },
        data() {
            return {
                constData: constData,
                subject: {
                    //题目
                    subjectTitle: "",
                    //题目类型
                    subjectType: constData.SUBJECT_TYPE_CHOICE,
                    //答案
                    rightAnswer: "",
                    //答题时间
                    answerTime: 45,
                    //选项列表
                    optionList: [
                        {
                            label: "A",
                            value: ""
                        },
                        {
                            label: "B",
                            value: ""
                        },
                        {
                            label: "C",
                            value: ""
                        },
                        {
                            label: "D",
                            value: ""
                        },
                        {
                            label: "E",
                            value: ""
                        }
                    ],
                },
                status: {
                    answerStartLoading: false,
                    answering: false
                }
            }
        },
        methods: {
            addOption() {
                if (this.status.answering) {
                    return;
                }
                if (this.subject.optionList.length >= 6) {
                    this.$message.warning("最多6个选项");
                    return;
                }
                this.$prompt('请输入选项值', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    inputPattern: /^.{1,100}$/,
                    inputErrorMessage: '答案长度为1-100'
                }).then(({value}) => {
                    if (this.subject.optionList.includes(value)) {
                        this.$message.warning("不能有一样的答案");
                        return;
                    }
                    this.subject.optionList.push(value);
                }).catch(() => {
                });
            },
            getABCDEF(index) {
                let ABCDEF = ["A", "B", "C", "D", "E", "F"];
                return ABCDEF[index]
            },
            choseRightAnswer(label) {
                if(this.status.answering){
                    return;
                }
                this.subject.rightAnswer = label;
                this.$store.commit("setRightAnswer", label);
            },
            removeAnswer(item, index) {
                if (this.status.answering) {
                    return;
                }
                this.subject.optionList.splice(index, 1);
                if (this.subject.rightAnswer === item) {
                    this.subject.rightAnswer = "";
                    this.$store.commit("setRightAnswer", "");
                }
            },
            //开始答题
            answerStart() {
                if (this.$util.isEmpty(this.subject.subjectTitle) && this.answerType === constData.ANSWER_TYPE_PRIMARY) {
                    this.$message.warning("请输入题目");
                    return;
                }
                let params = JSON.parse(JSON.stringify(this.subject));
                params.answerType = this.answerType;
                if (this.subject.subjectType === constData.SUBJECT_TYPE_CHOICE) {
                    if (this.$util.isEmpty(this.subject.rightAnswer)) {
                        this.$message.warning("请选择一个正确答案");
                        return;
                    }
                    let optionList = [];
                    params.optionList.map(item => {
                        let option = {};
                        option.label = item.label;
                        option.value = item.value;
                        optionList.push(option);
                    });
                    params.optionList = optionList;
                }
                if (this.subject.subjectType !== constData.SUBJECT_TYPE_CHOICE) {
                    params.rightAnswer = "";
                    params.optionList = [];
                }
                let message = {};
                message.type = constData.MESSAGE_TYPE_BEGIN_QUESTION;
                message.data = params;
                this.status.answerStartLoading = true;
                this.tic.sendGroupTextMessage(JSON.stringify(message), res => {
                    if (res.code !== 0) {
                        this.status.answerStartLoading = false;
                        this.$message.warning("推送题目失败,请重试");
                    } else {
                        this.status.answerStartLoading = false;
                        this.status.answering = true;
                        this.$message.success("推送题目成功");
                    }
                });
            },
            answerCancel() {
                if (this.status.answering) {
                    this.$confirm('学生们可能正在答题,是否要终止答题?', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(() => {
                        let message = {};
                        message.type = constData.MESSAGE_TYPE_OVER_QUESTION;
                        this.tic.sendGroupTextMessage(JSON.stringify(message));
                        this.$store.commit("setAnswering", false);
                        this.$store.commit("clearStudentAnsweringList");
                        this.$store.commit("setAnswering", "");
                        this.$store.commit("clearChoiceResultData");
                        this.status.answering = false;
                    }).catch(() => {
                    });
                } else {
                    this.$store.commit("setAnswering", false);
                    this.$store.commit("clearStudentAnsweringList");
                    this.$store.commit("setAnswering", "");
                    this.$store.commit("clearChoiceResultData");
                    this.status.answering = false;
                }
            }
        },
        props: {
            answerType: {
                type: String,
                default: () => {
                    return constData.ANSWER_TYPE_PRIMARY
                }
            }
        }
    }
</script>

<style lang="less" scoped>
    .classroom-answer {
        position: fixed;
        z-index: 100;
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        .answer-machine {
            width: 633px;
            .set-subject, .look-subject {
                background-color: white;
                width: calc(100% - 34px);
                padding: 17px;
                border-radius: 5px;
                .item-subject-title {
                    font-size: 14px;
                    color: #303133;
                }
            }
            .set-subject {
                .setting {
                    width: calc(100% - 30px);
                    padding-left: 30px;
                    margin-top: 37px;
                    .option-list {
                        display: flex;
                        flex-direction: column;
                        align-items: flex-start;
                        .option-item {
                            min-height: 24px;
                            color: #101010;
                            font-size: 14px;
                            margin-top: 5px;
                            display: flex;
                            align-items: center;
                            .value-input {
                                width: 300px;
                                margin: 0 10px;
                            }
                        }
                        .option-item-active {
                            color: white;
                            background-color: #5D2385;
                        }
                    }
                    .operate-bar {
                        display: flex;
                        flex-direction: row-reverse;
                    }
                }
                .class-answer{
                    display: flex;
                    align-items: center;
                    justify-content: space-around;
                    margin: 10px 0;
                    .class-answer-item{
                        cursor: pointer;
                        height: 50px;
                        width: 50px;
                        border: 1px solid #5D2385;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        &:hover{
                            background-color: #5D2385;
                            color: white;
                        }
                    }
                    .class-answer-item-active{
                        background-color: #5D2385;
                        color: white;
                    }
                }
            }
            .look-subject {
                margin-top: 35px;
                .result {

                }
                .result-total {
                    margin-top: 10px;
                    font-size: 12px;
                    color: #101010;
                    span {
                        margin-right: 10px;
                    }
                }
            }
        }
    }
</style>