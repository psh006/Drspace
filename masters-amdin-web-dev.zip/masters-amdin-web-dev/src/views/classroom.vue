<!--suppress RequiredAttributes -->
<template>
    <div class="classroom">
        <div class="class-title">
            <div class="title">名师荟教育：{{courseName}}</div>
            <div class="button-box">
                <i class="el-icon-switch-button" @click="outRoom"></i>
                <i class="el-icon-user-solid" @click="openStudentList"></i>
                <i v-if="!isPushing" class="el-icon-video-camera" @click="startRTC"></i>
                <i v-else class="el-icon-video-pause" @click="stopPush"></i>
                <el-button size="mini" style="margin-left: 10px" type="success" @click="createClassroom"
                           :disabled="ticUserStatus < constData.USER_STATUS_LOGINED || ticUserStatus === constData.USER_STATUS_INCLASS">上课
                </el-button>
                <el-button size="mini" type="success" @click="beginVideotape"
                           :disabled="ticUserStatus < constData.USER_STATUS_INCLASS || status.videotapeStatus === constData.VIDEOTAPE_STATUS_ON">开始录像
                </el-button>
                <el-button size="mini" type="success" @click="stopVideotape"
                           :disabled="ticUserStatus < constData.USER_STATUS_INCLASS || status.videotapeStatus < constData.VIDEOTAPE_STATUS_PAUSE">停止录像
                </el-button>
                <el-button size="mini" type="success" @click="pauseVideotape"
                           :disabled="ticUserStatus < constData.USER_STATUS_INCLASS || status.videotapeStatus < constData.VIDEOTAPE_STATUS_ON">暂停
                </el-button>
                <el-button size="mini" type="success" :disabled="ticUserStatus < constData.USER_STATUS_INCLASS"
                           @click="answerStart(constData.ANSWER_TYPE_PRIMARY)">自定义答题
                </el-button>
                <el-button size="mini" type="success" :disabled="ticUserStatus < constData.USER_STATUS_INCLASS"
                           @click="answerStart(constData.ANSWER_TYPE_CLASS)">课件答题
                </el-button>
                <el-button size="mini" type="success" @click="toolShow = !toolShow">显示/隐藏白板工具</el-button>
            </div>
        </div>
        <div class="video-box" id="video-box"></div>
        <div class="watch-box">
            <div class="whiteboard">
                <el-main>
                    <el-container>
                        <el-header style="height: 42px;">
                            <el-tabs size="mini" v-model="currentFileId" closable type="card" @tab-remove="onDeleteFileById"
                                     @tab-click="onClickBoardTab">
                                <el-tab-pane size="mini" :key="file.fid" v-for="file in fileInfoList" :label="file.title" :name="file.fid">
                                </el-tab-pane>
                            </el-tabs>
                        </el-header>
                        <el-main style="position: relative">
                            <div id="whiteboard" style="background-color: rgb(240, 240, 240);"></div>
                            <div class="tool-box" v-if="ticUserStatus === constData.USER_STATUS_INCLASS && toolShow">
                                <div class="tool-head">
                                    <div :class="toolHead === '涂鸦' ? 'tool-head-item tool-head-item-active':'tool-head-item'"
                                         @click="setToolHead('涂鸦')">涂鸦
                                    </div>
                                    <div :class="toolHead === '白板' ? 'tool-head-item tool-head-item-active':'tool-head-item'"
                                         @click="setToolHead('白板')">白板
                                    </div>
                                    <div :class="toolHead === '文件' ? 'tool-head-item tool-head-item-active':'tool-head-item'"
                                         @click="setToolHead('文件')">文件
                                    </div>
                                </div>
                                <div class="tool-content" v-if="toolHead === '涂鸦'">
                                    <div class="bar">
                                        <el-button @click="onclearDraws">清空涂鸦</el-button>
                                        <el-button @click="onClear">清空白板</el-button>
                                        <div class="bar-item">
                                            <div class="bar-item-label">涂鸦颜色</div>
                                            <div class="bar-item-label-content color-box">
                                                <div v-for="(color,index) in colorList"
                                                     :key="index"
                                                     :style={backgroundColor:color}
                                                     :class="brushColor === color ? 'color-item color-active':'color-item'"
                                                     @click="onSetBrushColor(color)">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">背景颜色</div>
                                            <div class="bar-item-label-content color-box">
                                                <div v-for="(color,index) in colorList"
                                                     :key="index"
                                                     :style={backgroundColor:color}
                                                     :class="backgroundColor === color ? 'color-item color-active':'color-item'"
                                                     @click="onSetBackgroudColor(color)">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">字体颜色</div>
                                            <div class="bar-item-label-content color-box">
                                                <div v-for="(color,index) in colorList"
                                                     :key="index"
                                                     :style={backgroundColor:color}
                                                     :class="textColor === color ? 'color-item color-active':'color-item'"
                                                     @click="onSetTextColor(color)">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">画笔粗细</div>
                                            <div class="bar-item-label-content">
                                                <el-slider style="width: 100%" @change="onSetThin" v-model="brushThin" :max='500'></el-slider>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">字体大小</div>
                                            <div class="bar-item-label-content">
                                                <el-slider style="width: 100%" @change="onSetTextSize" v-model="textSize" :max='500'></el-slider>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">白板缩放</div>
                                            <div class="bar-item-label-content">
                                                <el-slider style="width: 100%" @change="onSetScale" v-model="scaleSize" :max='300'></el-slider>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="button-list">
                                        <div :class="toolType === item.value ? 'button-list-item button-list-item-active':'button-list-item'"
                                             v-for="(item,index) in toolTypeList"
                                             :key="index"
                                             @click="onSetToolType(item.value)">
                                            <img :src="item.icon"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="tool-content" v-else-if="toolHead === '白板'">
                                    <div class="bar">
                                        <div class="bar-item">
                                            <div class="bar-item-label">白板信息</div>
                                            <div class="bar-item-label-content">
                                                总页数：{{boardData.total}}, 当前页：{{boardData.current}}
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">跳转页面</div>
                                            <div class="bar-item-label-content">
                                                <el-input v-model="setCurrent" style="width: 68px;margin-right: 10px"
                                                          @change="setCurrentInput"></el-input>
                                                <el-button @click="onThumbClick(setCurrent - 1)" v-text="'跳转'"></el-button>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">前后翻页</div>
                                            <div class="bar-item-label-content">
                                                <el-button @click="prevBoard" v-text="'前一页'"></el-button>
                                                <el-button @click="nextBoard" v-text="'后一页'"></el-button>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">上下一步</div>
                                            <div class="bar-item-label-content">
                                                <el-button @click="prevStep" v-text="'上一步'"></el-button>
                                                <el-button @click="nextStep" v-text="'下一步'"></el-button>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">新增白板</div>
                                            <div class="bar-item-label-content">
                                                <el-button @click="addBoard" v-text="'新增白板'"></el-button>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">跳转白板</div>
                                            <div class="bar-item-label-content">
                                                <el-select @change="onGotoBoard" placeholder="跳转">
                                                    <el-option v-for="item in boardData.boardIdlist" :key="item" :label="item" :value="item"/>
                                                </el-select>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">删除白板</div>
                                            <div class="bar-item-label-content">
                                                <el-select @change="onDeleteBoard" placeholder="删除">
                                                    <el-option v-for="item in boardData.boardIdlist" :key="item" :label="item" :value="item"/>
                                                </el-select>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">删除说明</div>
                                            <div class="bar-item-label-content">
                                                缺省白板页和PPT白板页不能删除
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tool-content" v-else>
                                    <div class="bar">
                                        <div class="bar-item">
                                            <div class="bar-item-label">新增文件</div>
                                            <div class="bar-item-label-content">
                                                <input id="file_input" type="file" @change="uploadFile"
                                                       accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/vnd.openxmlformats-officedocument.presentationml.presentation, application/vnd.ms-powerpoint, application/vnd.ms-excel">
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">切换文件</div>
                                            <div class="bar-item-label-content">
                                                <el-select @change="onSwitchFile" placeholder="切换">
                                                    <el-option v-for="file in fileInfoList" :key="file.fid" :label="file.title" :value="file"/>
                                                </el-select>
                                            </div>
                                        </div>
                                        <div class="bar-item">
                                            <div class="bar-item-label">删除文件</div>
                                            <div class="bar-item-label-content">
                                                <el-select @change="onDeleteFile" placeholder="删除">
                                                    <el-option v-for="file in fileInfoList" :key="file.fid" :label="file.title" :value="file"/>
                                                </el-select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <template v-if="ticUserStatus === constData.USER_STATUS_INCLASS">
                                <div :class="toolType === 1 ?'tool-box-left tool-box-left-active':'tool-box-left'" style="top:0"
                                     @click="onSetToolType(1)">
                                    <img src="./../assets/toolImg/huabi.png"/>
                                </div>
                                <div :class="toolType === 2 ?'tool-box-left tool-box-left-active':'tool-box-left'" style="top:55px"
                                     @click="onSetToolType(2)">
                                    <img src="./../assets/toolImg/xiangpicha.png"/>
                                </div>
                                <div :class="toolType === 4 ?'tool-box-left tool-box-left-active':'tool-box-left'" style="top:110px"
                                     @click="onSetToolType(4)">
                                    <img src="./../assets/toolImg/zhixian.png"/>
                                </div>
                                <div :class="toolType === 11 ?'tool-box-left tool-box-left-active':'tool-box-left'" style="top:165px"
                                     @click="onSetToolType(11)">
                                    <img src="./../assets/toolImg/wenzi.png"/>
                                </div>
                                <div class="tool-box-left" style="top:220px" @click="onclearDraws">
                                    清空
                                </div>
                                <div class="tool-box-left" style="top:275px" @click="prevStep">
                                    上一步
                                </div>
                                <div class="tool-box-left" style="top:330px" @click="nextStep">
                                    下一步
                                </div>
                            </template>
                        </el-main>
                        <el-footer style="height: 80px;">
                            <div style="text-align: center; padding-top: 30px; color: gray;" v-if="thumbUrls.length === 0">此文件不支持缩略图
                            </div>
                            <!--suppress CssInvalidPropertyValue -->
                            <div style="overflow-x: scroll visible; overflow-y:hidden; white-space:nowrap; height:inherit; ">
                                <img style="height: 100%; margin-right: 3px;" v-for="(item, index) in thumbUrls" :name="index" :src="item"
                                     :key="index" @click="onThumbClick(index)"/>
                            </div>
                        </el-footer>
                    </el-container>
                </el-main>
            </div>
            <div class="msg-box">
                <div class="msgs">
                    <div class="msgs-title">
                        讨论区
                    </div>
                    <div class="msgs-content">
                        <div v-for="(msg,index) in groupMsg" :key="index">
                            <span class="msg-tim">{{msg.time}}</span>
                            <span class="msg-source">{{msg.send}}</span>
                            <span class="msg-content">{{msg.content}}</span>
                        </div>
                    </div>
                </div>
                <div class="send-msg">
                    <el-input placeholder="发送群消息..." v-model="imMsg.common.data" maxlength="30"></el-input>
                    <el-button type="success" style="margin-left: 10px" @click="sendMsg(constData.MESSAGE_TYPE_GROUP)">发送</el-button>
                </div>
            </div>
        </div>
        <!--答题-->
        <classroomAnswer v-if="answering" :answer-type="answerType"></classroomAnswer>
        <!--学生列表-->
        <classroomStudentList></classroomStudentList>
    </div>
</template>

<script>
    import TIC from "./../assets/TX_api/TIC.min"
    import {mapState} from 'vuex'
    import constData from './../assets/javascript/const-data'
    import classroomAnswer from "./classroom-answer"
    import classroomStudentList from "./classroom-student-list"

    export default {
        name: 'classroom',
        components: {
            classroomAnswer,
            classroomStudentList
        },
        data() {
            return {
                answerType: constData.ANSWER_TYPE_PRIMARY,
                taskId: "",
                teduBoard: null,
                //当前房间号
                roomID: "",
                courseHourId: "",
                courseName: "",
                courseId: "",
                courseTimeId: "",
                //状态
                status: {
                    //当前录像状态
                    videotapeStatus: 0,
                    toolBoxShow: false,
                    questionDialog: false
                },
                //常量
                constData: constData,
                //board(涂鸦)
                drawEnable: true, //是否可以涂鸦
                synDrawEnable: true, //是否将你画的涂鸦同步给其他人
                toolShow: false,
                toolType: 1,
                toolHead: "涂鸦",
                brushThin: 100,
                backgroundImage: "背景图",
                backgroundImageH5: "背景图H5",
                backgroundColor: "#FFFFFF",
                globalBackgroundColor: "#ff0000",
                brushColor: "#FF2121",
                textColor: "#FF2121",
                textStyle: "#ff0000",
                textFamily: "sans-serif,serif,monospace",
                textSize: 320,
                scaleSize: 100,
                fitMode: 1,
                ration: "16:9",
                canRedo: 0,
                canUndo: 0,
                //画笔工具
                toolTypeList: [
                    {
                        value: 0,
                        label: "鼠标",
                        icon: require("./../assets/toolImg/shubiao.png")
                    },
                    {
                        value: 1,
                        label: "画笔",
                        icon: require("./../assets/toolImg/huabi.png")
                    },
                    {
                        value: 4,
                        label: "直线",
                        icon: require("./../assets/toolImg/zhixian.png")
                    },
                    {
                        value: 7,
                        label: "实心(椭)圆",
                        icon: require("./../assets/toolImg/tuoyuanshi.png")
                    },
                    {
                        value: 5,
                        label: "空心(椭)圆",
                        icon: require("./../assets/toolImg/tuoyuankong.png")
                    },
                    {
                        value: 8,
                        label: "实心矩形",
                        icon: require("./../assets/toolImg/juxingshi.png")
                    },
                    {
                        value: 6,
                        label: "空心矩形",
                        icon: require("./../assets/toolImg/juxingkong.png")
                    },
                    {
                        value: 11,
                        label: "文字输入",
                        icon: require("./../assets/toolImg/wenzi.png")
                    },
                    {
                        value: 2,
                        label: "橡皮擦",
                        icon: require("./../assets/toolImg/xiangpicha.png")
                    },
                    {
                        value: 3,
                        label: "激光笔",
                        icon: require("./../assets/toolImg/jiguangbi.png")
                    },
                    {
                        value: 10,
                        label: "框选",
                        icon: require("./../assets/toolImg/kuangxuan.png")
                    },
                    {
                        value: 9,
                        label: "点选",
                        icon: require("./../assets/toolImg/dianxuan.png")
                    },
                    {
                        value: 12,
                        label: "移动",
                        icon: require("./../assets/toolImg/yidong.png")
                    }
                ],
                colorList: ["#000000", "#FFFFFF", "#FF2121", "#FFF143", "#44CEF6"],
                //board(白板操作)
                setCurrent: 1,
                boardData: {
                    currentBoardId: null, //当前白板ID
                    boardIdlist: [], //白板ID列表
                    current: 0, //当前白板index
                    total: 0 //总页数
                },
                //board(文件操作)
                currentFileId: null, // 当前文件Id
                fileInfoList: [], // 所有文件信息
                thumbUrls: [], // 缩略图

                //音视频及设备
                enableCamera: true,
                enableMic: true,
                cameraIndex: 0,
                micIndex: 0,
                devices: {
                    camera: [],
                    mic: []
                },

                imMsg: {
                    common: {
                        data: "",
                        toUser: ""
                    },
                    custom: {}
                },
                //
                isShow: false,
                isPushing: false, // 是否正在推流
                isPushCamera: false, // 是否推摄像头流
                remoteVideos: {},
                localStream: null,//本地流
                willDeleteFile: null,
                willSwitchFile: null,
                willAddVideoFile: null,
                willDeleteBoard: null,
                willAddH5File: null,

                //业务相关-答题相关
                questionAllInfo: {
                    //当前选中问题类型 1选择 2判断
                    selectQuestionType: 1,
                    //问题回答时间
                    questionTime: 0,
                    //正确答案
                    rightAnswer: "A",
                    //选项
                    option: ["A", "B", "C", "D"]
                }
            }
        },
        computed: {
            ...mapState({
                ticUserStatus: state => state.ticUserStatus,
                tic: state => state.tic,
                groupMsg: state => state.groupMsg,
                ticUserInfo: state => state.ticUserInfo,
                answering: state => state.classroomAnswer.answering,
                studentList: state => state.classroomStudentModules.studentList
            })
        },
        created() {
            let roomID = this.$route.query.roomID;
            let courseHourId = this.$route.query.courseHourId;
            let courseName = this.$route.query.courseName;
            let courseId = this.$route.query.courseId;
            let courseTimeId = this.$route.query.courseTimeId;
            if (this.$util.isEmpty(roomID)) {
                this.$router.push("/home");
                return;
            }
            if (this.$util.isEmpty(this.tic)) {
                this.$router.push("/home");
                return;
            }
            this.roomID = roomID;
            this.courseHourId = courseHourId;
            this.courseName = courseName;
            this.courseId = courseId;
            this.courseTimeId = courseTimeId;
        },
        mounted() {
            window.addEventListener('beforeunload', this.updateHandler);
        },
        methods: {
            showMessageInBox(messageType, text) {
                let d = new Date();
                let time = `${('0' + d.getHours()).substr(-2)}:${('0' + d.getMinutes()).substr(-2)}:${('0' + d.getSeconds()).substr(-2)}`;
                let msgs = {
                    time: time + ' ',
                    send: messageType + ' ',
                    content: text
                };
                this.$store.commit("insertGroupMsg", msgs)
            },
            outRoom() {
                this.$confirm('确定要结束这节课吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    if (this.ticUserStatus < this.constData.USER_STATUS_INCLASS) {
                        this.$router.push("/");
                        return;
                    }
                    this.destroyClassroom();
                }).catch(() => {
                });
            },
            initData() {
                this.$store.commit("clearGroupMsg");
                this.devices = {
                    camera: [],
                    mic: []
                };

                this.cameraIndex = 0;
                this.micIndex = 0;

                this.imMsg = {
                    common: {
                        data: '',
                        toUser: ''
                    },
                    custom: {
                        data: '',
                        toUser: ''
                    }
                };

                this.drawEnable = true; //是否可以涂鸦
                this.synDrawEnable = true; //是否将你画的涂鸦同步给其他人
                this.toolType = 1;
                this.brushThin = 100;
                this.backgroundImage = "背景图";
                this.backgroundImageH5 = "背景图H5";
                this.backgroundColor = "#FFFFFF";
                this.globalBackgroundColor = "#ff0000";
                this.brushColor = "#FF2121";
                this.textColor = "#FF2121";
                this.textStyle = "#ff0000";
                this.textFamily = "sans-serif,serif,monospace";
                this.textSize = 320;
                this.scaleSize = 100;
                this.fitMode = 1;
                this.ration = "16:9";
                this.canRedo = 0;
                this.canUndo = 0;
            },
            clearClassInfo() {
                //设备信息
                this.remoteVideos = {};
                this.enableCamera = true;
                this.enableMic = true;
                this.isPushing = false;
                this.isPushCamera = false;

                //白板信息
                this.boardData.currentBoardId = null;
                this.boardData.boardIdlist = [];
                this.boardData.current = 0;
                this.boardData.total = 0;

                document.getElementById("whiteboard").innerHTML = "";

                let divvideo = document.querySelector("#video-box");
                while (divvideo.hasChildNodes())
                    divvideo.removeChild(divvideo.firstChild);

                this.fileInfoList = [];
                this.currentFileId = null;
            },
            // 创建房间
            createClassroom() {
                if (!this.roomID) {
                    this.$message.warning('房间号不能为空');
                    return;
                }
                this.tic.createClassroom({
                    classId: this.roomID,
                    classScene: TIC.CONSTANT.TICClassScene.TIC_CLASS_SCENE_VIDEO_CALL // 1：直播模式 0: 实时模式
                }, (res) => {
                    if (res.code) {
                        if (res.code === 10021) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "该课堂已被他人创建，请直接加入");
                        } else if (res.code === 10025) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "您已经创建过这个课堂，请直接加入");
                        } else {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "创建课堂失败,错误码" + res.code + "失败原因:" + res.desc);
                        }
                    } else {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "创建课堂成功");
                        this.joinClassroom();
                    }
                });
            },
            // 销毁课堂
            destroyClassroom() {
                if (!this.roomID) {
                    this.$message.warning('房间号不能为空');
                    return;
                }
                this.tic.destroyClassroom(this.roomID, res => {
                    if (res.code) {
                        console.error(this.constData.MESSAGE_TYPE_SYSTEM, "销毁课堂失败,错误码" + res.code + ",失败原因:" + res.desc);
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_LOGINED);
                        this.$router.push("/home").catch(() => {
                        });
                    } else {
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_LOGINED);
                        this.$router.push("/home").catch(() => {
                        });
                    }
                    this.updateFinishedCourseHour();
                });
            },
            // 进入房间
            joinClassroom() {
                if (!this.roomID) {
                    this.$message.warning('房间号不能为空');
                    return;
                }
                if (this.ticUserStatus === this.constData.USER_STATUS_INCLASS) {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "已经在房间里面了");
                    return;
                }
                this.tic.joinClassroom({
                    // compatSaas: true,
                    classId: this.roomID
                }, {
                    //实时通话模式，支持1000人以下场景，低延时
                    mode: TIC.CONSTANT.TICClassScene.TIC_CLASS_SCENE_VIDEO_CALL,
                }, {
                    id: 'whiteboard',
                    ratio: '16:9',
                    smoothLevel: 0,
                    boardContentFitMode: 1,
                    toolType: this.toolType.value,
                }, res => {
                    if (res.code) {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "加入课堂失败,错误码" + res.code + ",失败原因:" + res.desc);
                    } else {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "加入课堂成功");
                        window.teduBoard = this.teduBoard = this.tic.getBoardInstance();
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_INCLASS);
                        this.$store.commit("setRoomId", this.roomID);
                        this.getStudentList();
                        this.insertCourseRecord();
                        this.initBoardEvent();
                    }
                });
            },
            /**
             * 退出课堂
             */
            quitClassroom(callback) {
                if (this.ticUserStatus <= constData.USER_STATUS_LOGINED) {
                    this.initData();
                } else {
                    this.tic.quitClassroom(res => {
                        if (res.code) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "退出课堂失败,错误码" + res.code);
                            console.error('quitClassroom error' + res);
                        } else {
                            this.initData();
                            this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_LOGINED);
                        }
                        callback && callback({
                            code: 0
                        });
                    });
                }
            },
            // 监听白板事件（按需监听）
            initBoardEvent() {
                let teduBoard = this.teduBoard;
                // 撤销状态改变
                teduBoard.on("TEB_OPERATE_CANUNDO_STATUS_CHANGED", (enable) => {
                    this.canUndo = enable ? 1 : 0;
                });
                // 重做状态改变
                teduBoard.on("TEB_OPERATE_CANREDO_STATUS_CHANGED", (enable) => {
                    this.canRedo = enable ? 1 : 0;
                });
                // 新增白板
                teduBoard.on("TEB_ADDBOARD", () => {
                    this.proBoardData();
                });
                // 白板同步数据回调(收到该回调时需要将回调数据通过信令通道发送给房间内其他人，接受者收到后调用AddSyncData接口将数据添加到白板以实现数据同步)
                // TIC已经处理好了，可忽略该事件
                teduBoard.on("TEB_SYNCDATA", () => {
                });
                // 收到白板初始化完成事件后，表示白板已处于正常工作状态（此时白板为空白白板，历史数据尚未拉取完成）
                teduBoard.on("TEB_INIT", () => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "互动白板已启动");
                });
                teduBoard.on("TEB_HISTROYDATA_SYNCCOMPLETED", () => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "互动白板同步完成");
                });
                // 白板错误回调
                teduBoard.on("TEB_ERROR", (code, msg) => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "onTEBError code=" + code + " msg:" + msg);
                });
                // 白板警告回调
                teduBoard.on("TEB_WARNING", (code, msg) => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "onTEBWarning code=" + code + " msg:" + msg);
                });
                // 图片状态加载回调
                teduBoard.on("TEB_IMAGE_STATUS_CHANGED", () => {
                });
                // 删除白板页回调
                teduBoard.on("TEB_DELETEBOARD", () => {
                    this.proBoardData();
                });
                // 跳转白板页回调
                teduBoard.on("TEB_GOTOBOARD", () => {
                    this.proBoardData();
                });
                // ppt动画步数改变回调
                teduBoard.on("TEB_GOTOSTEP", () => {
                });
                // 增加H5动画PPT文件回调
                teduBoard.on("TEB_ADDH5PPTFILE", () => {
                    this.proBoardData();
                });
                // 增加文件回调
                teduBoard.on("TEB_ADDFILE", () => {
                    this.proBoardData();
                });
                // 增加转码文件回调
                teduBoard.on("TEB_ADDTRANSCODEFILE", () => {
                    this.proBoardData();
                });
                // 增加Images文件回调
                teduBoard.on("TEB_ADDIMAGESFILE", () => {
                    this.proBoardData();
                });
                // 删除文件回调
                teduBoard.on("TEB_DELETEFILE", () => {
                    this.proBoardData();
                });
                // 文件上传状态
                teduBoard.on("TEB_FILEUPLOADSTATUS", (status) => {
                    if (status === 1) {
                        this.$message.success('上传成功');
                    } else {
                        this.$message.error('上传失败');
                    }
                    document.getElementById('file_input').value = '';
                });
                // 切换文件回调
                teduBoard.on("TEB_SWITCHFILE", () => {
                    this.proBoardData();
                });
                // 上传背景图片的回调
                teduBoard.on("TEB_SETBACKGROUNDIMAGE", () => {
                });
                // 增加图片元素
                teduBoard.on("TEB_ADDIMAGEELEMENT", () => {
                });
                // 文件上传进度
                teduBoard.on("TEB_FILEUPLOADPROGRESS", (data) => {
                    this.$message.success('上传进度:' + parseInt(data.percent * 100) + '%');
                });
                // H5背景加载状态
                teduBoard.on("TEB_H5BACKGROUND_STATUS_CHANGED", () => {
                });
                // 转码进度
                teduBoard.on("TEB_TRANSCODEPROGRESS", res => {
                    if (res.code) {
                        this.$message.error('转码失败code:' + res.code + ' message:' + res.message);
                    } else {
                        let status = res.status;
                        if (status === 'ERROR') {
                            this.$message.error('转码失败');
                        } else if (status === 'UPLOADING') {
                            this.$message.success('上传中，当前进度:' + parseInt(res.progress) + '%');
                        } else if (status === 'CREATED') {
                            this.$message.success('创建转码任务');
                        } else if (status === 'QUEUED') {
                            this.$message.success('正在排队等待转码');
                        } else if (status === 'PROCESSING') {
                            this.$message.success('转码中，当前进度:' + res.progress + '%');
                        } else if (status === 'FINISHED') {
                            this.$message.success('转码完成');
                            this.teduBoard.addTranscodeFile({
                                url: res.resultUrl,
                                title: res.title,
                                pages: res.pages,
                                resolution: res.resolution
                            });
                        }
                    }
                });
            },
            /**
             * 白板事件回调处理
             */
            proBoardData() {
                this.fileInfoList = this.teduBoard.getFileInfoList();
                this.currentFileId = this.teduBoard.getCurrentFile();
                this.thumbUrls = this.teduBoard.getThumbnailImages(this.currentFileId);
                var fileInfo = this.teduBoard.getFileInfo(this.currentFileId);
                if (fileInfo) {
                    this.boardData = {
                        currentBoardId: this.currentFileId,
                        boardIdlist: this.teduBoard.getFileBoardList(this.currentFileId),
                        current: fileInfo.currentPageIndex + 1,
                        total: fileInfo.pageCount
                    }
                }
            },
            onDeleteFileById(fid) {
                if (fid === "#DEFAULT") {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '缺省文件 不能删除!');
                    return;
                }
                this.teduBoard.deleteFile(fid);
            },
            onClickBoardTab(targetTab) {
                let fid = targetTab.name;
                this.teduBoard.switchFile(fid);
            },
            setCurrentInput(setCurrent) {
                setCurrent = parseInt(setCurrent);
                if (this.$util.isEmpty(setCurrent)) {
                    this.setCurrent = 1;
                    return;
                }
                if (setCurrent === this.boardData.current) {
                    return;
                }
                if (setCurrent > this.boardData.total) {
                    setCurrent = this.boardData.total;
                }
                this.setCurrent = setCurrent;
            },
            onThumbClick(index) {
                let fileId = this.teduBoard.getCurrentFile();
                let boardList = this.teduBoard.getFileBoardList(fileId);
                let boardId = boardList[index];
                this.teduBoard.gotoBoard(boardId);
            },
            //Board(涂鸦操作)
            onSetDrawEnable() {
                this.teduBoard.setDrawEnable(this.drawEnable);
            },
            /**
             * 清空当前页涂鸦(保留背景色/图片)
             */
            onclearDraws() {
                this.teduBoard.clear();
            },
            /**
             * 清空当前页涂鸦 + 背景色/图片
             */
            onClear() {
                this.teduBoard.clear(true);
            },
            // 回退
            onUndo() {
                this.teduBoard.undo();
            },
            // 重做
            onRedo() {
                this.teduBoard.redo();
            },
            onSetTextSize(size) {
                this.teduBoard.setTextSize(size);
            },
            onSetTextColor(color) {
                this.textColor = this.rgbToHex(color);
                this.teduBoard.setTextColor(this.textColor);
            },
            onSetBackgroundImage(backgroundImage) {
                this.teduBoard.setBackgroundImage(backgroundImage);
            },
            onSetToolType(toolType) {
                this.toolType = toolType;
                this.teduBoard.setToolType(toolType);
            },
            setToolHead(toolHead) {
                this.toolHead = toolHead;
            },
            onSetBackgroundH5(backgroundImageH5) {
                this.teduBoard.setBackgroundH5(backgroundImageH5);
            },
            onGotoBoard(boardId) {
                this.teduBoard.gotoBoard(boardId, false);
            },
            onSetScale(scale) {
                this.teduBoard.setBoardScale(scale);
            },
            /**
             * 上一页
             */
            prevBoard() {
                this.teduBoard.prevBoard();
            },

            /**
             * 下一页
             */
            nextBoard() {
                this.teduBoard.nextBoard();
            },
            // 动画上一步
            prevStep() {
                this.teduBoard.prevStep();
            },
            // 动画下一步
            nextStep() {
                this.teduBoard.nextStep();
            },
            /**
             * 新增一页
             */
            addBoard() {
                this.teduBoard.addBoard();
            },
            /**
             * 设置涂鸦粗细
             * @param {*} num
             */
            onSetThin(num) {
                this.teduBoard.setBrushThin(num);
            },
            onAddImageElement(url) {
                this.teduBoard.addImageElement(url);
            },
            uploadFile() {
                let file = document.getElementById('file_input').files[0];
                if (/\.(bmp|jpg|jpeg|png|gif|webp|svg|psd|ai)/i.test(file.name)) {
                    // this.teduBoard.setBackgroundImage({
                    //   data: file,
                    //   userData: 'image'
                    // });
                    this.teduBoard.addImageElement({
                        data: file,
                        userData: 'image'
                    });
                } else {
                    this.teduBoard.applyFileTranscode({
                        data: file,
                        userData: 'hello'
                    }, {
                        minResolution: '960x540',
                        isStaticPPT: false,
                        thumbnailResolution: '200x200'
                    });
                }
            },
            onAddVideoFile(url) {
                this.teduBoard.addVideoFile(url);
            },
            onAddH5File(url) {
                this.teduBoard.addH5PPTFile(url);
            },
            onSwitchFile(file) {
                this.teduBoard.switchFile(file.fid);
            },
            onDeleteFile(file) {
                this.onDeleteFileById(file.fid);
            },
            /**
             * 删除当前页
             */
            onDeleteBoard(boardId) {
                this.teduBoard.deleteBoard(boardId);
            },
            /**
             * 设置当前页背景色
             * @param {*} color Hex 色值，如 #ff00ff
             */
            onSetBackgroudColor(color) {
                this.backgroundColor = this.rgbToHex(color);
                this.teduBoard.setBackgroundColor(this.backgroundColor);
            },
            /**
             * 设置涂鸦颜色
             * @param {*} color Hex 色值，如 #ff00ff
             */
            onSetBrushColor(color) {
                this.brushColor = this.rgbToHex(color);
                this.teduBoard.setBrushColor(this.brushColor);
            },
            rgbToHex(color) {
                let arr = [], strHex = null;
                if (/^(rgb|RGB)/.test(color)) {
                    arr = color.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(",");
                    strHex = '#' + ((1 << 24) + (arr[0] << 16) + (arr[1] << 8) + parseInt(arr[2])).toString(16).substr(1);
                } else {
                    strHex = color;
                }
                return strHex;
            },
            sendMsg(messageType, data) {
                if (!this.imMsg.common.data || this.imMsg.common.data.length < 1) {
                    this.$message.warning(`不能发送空消息`);
                    return;
                }
                let message = {};
                message.type = messageType;
                message.text = this.imMsg.common.data;
                message.user = this.imMsg.common.toUser;
                message.fromUserName = this.$util.getUser().empName;
                message.data = data;
                // C2C 文本
                if (this.imMsg.common.toUser && this.imMsg.common.data.length > 1) {
                    this.tic.sendTextMessage(this.imMsg.common.toUser, JSON.stringify(message), res => {
                        if (res.code !== 0) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '发送消息失败,错误码' + res.code);
                        } else {
                            this.showMessageInBox(messageType, message.fromUserName + ":" + message.text);
                        }
                    });
                    // 群组 文本
                } else {
                    if (!this.roomID) {
                        this.$message.error('发送群消息时，房间号为空');
                        return;
                    }
                    this.tic.sendGroupTextMessage(JSON.stringify(message), res => {
                        if (res.code !== 0) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '发送消息失败,错误码' + res.code);
                        } else {
                            this.showMessageInBox(messageType, message.fromUserName + ":" + message.text);
                        }
                    });
                }
                this.imMsg.common.data = "";
                this.imMsg.common.toUser = "";
            },
            // 启动推流(推摄像头)
            startRTC() {
                // 从麦克风和摄像头采集本地音视频流
                let cameraStream = window.TRTC.createStream({
                    audio: true,
                    video: true
                });
                // 设置视频分辨率等参数
                cameraStream.setVideoProfile('720p');
                if (this.localStream && this.isPushing) { // 如果正在推流, 先停止发布流
                    this.stopPush(() => {
                        this.publishLocalStream(cameraStream);
                    });
                } else {
                    this.publishLocalStream(cameraStream);
                }
            },
            /**
             * 结束推流
             */
            stopPush(callback) {
                if (this.ticUserStatus < constData.USER_STATUS_INCLASS) {
                    return;
                }
                if (this.localStream && this.isPushing) {
                    window.trtcClient.unpublish(window.localStream).then(() => {
                        this.isPushing = false;
                        document.getElementById('local_video').remove();
                        this.localStream.stop();
                        this.localStream = null;
                        if (Object.prototype.toString.call(callback) === '[object Function]') {
                            callback();
                        }
                    });
                }
            },
            // 发布本地流
            publishLocalStream(localStream) {
                window.localStream = localStream;
                localStream.initialize().catch(error => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '视频推流失败');
                    console.error('failed initialize localStream ' + error);
                }).then(() => {
                    let localVideoWrapEl = document.getElementById('local_video');
                    if (!localVideoWrapEl) {
                        localVideoWrapEl = document.createElement('div');
                        localVideoWrapEl.id = 'local_video';
                        localVideoWrapEl.className = 'video-item';
                        document.querySelector("#video-box").insertBefore(localVideoWrapEl, null);
                    }
                    // 本地流播放
                    localStream.play(localVideoWrapEl, {
                        muted: true
                    });
                    // 发布本地流（远端可收到）
                    window.trtcClient && window.trtcClient.publish(localStream).then(() => {
                        // 本地流发布成功
                        this.isPushing = true; // 正在推流
                        this.isPushCamera = true; // 正在推摄像头
                        this.localStream = localStream;
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '视频推流成功');
                    }).catch(() => {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '视频推流失败');
                    });
                }).catch(error => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `获取本地流失败, ${JSON.stringify(error)}`);
                });
            },
            updateHandler() {
                if (this.status.videotapeStatus === this.constData.VIDEOTAPE_STATUS_ON) {
                    this.pauseVideotape();
                }
                this.quitClassroom();
            },
            beginVideotape() {
                this.$request({roomId: this.roomID}, "/whiteboard/getTaskId", data => {
                    if (data.list && data.list.length > 0) {
                        this.taskId = data.list[0].taskId;
                        let eventType = data.list[0].eventType;
                        if (eventType === 2) {
                            this.$message.warning("每个课时只能录制一次");
                            return;
                        }
                        this.goOnVideotape();
                    } else {
                        let RecordUserId = `tic_record_user_${this.roomID}_${new Date().getTime()}`;
                        this.getUserSig(constData.SDK_APP_ID, RecordUserId, userSig => {
                            let params = {
                                SdkAppId: constData.SDK_APP_ID,
                                RoomId: this.roomID,
                                RecordUserId: RecordUserId,
                                RecordUserSig: userSig,
                                Concat: {
                                    Enabled: true
                                },
                                MixStream: {
                                    Enabled: true,
                                    DisableAudio: false,
                                    ModelId: 1,
                                    TeacherId: this.ticUserInfo.userId
                                }
                            };
                            this.$request(params, "/whiteboard/startOnlineRecord", data => {
                                let taskIdString = data.list[0];
                                if (taskIdString && taskIdString.length > 0) {
                                    this.taskId = JSON.parse(taskIdString).TaskId;
                                    this.status.videotapeStatus = this.constData.VIDEOTAPE_STATUS_ON;
                                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '开始录制');
                                }
                            })
                        });
                    }
                });
            },
            stopVideotape() {
                let params = {
                    SdkAppId: constData.SDK_APP_ID,
                    TaskId: this.taskId,
                    roomId: this.roomID
                };
                this.$request(params, "/whiteboard/stopOnlineRecord", () => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '停止录像成功');
                    this.status.videotapeStatus = this.constData.VIDEOTAPE_STATUS_OFF;
                })
            },
            pauseVideotape() {
                let params = {
                    SdkAppId: constData.SDK_APP_ID,
                    TaskId: this.taskId
                };
                this.$request(params, "/whiteboard/pauseOnlineRecord", () => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '暂停录像成功');
                    this.status.videotapeStatus = this.constData.VIDEOTAPE_STATUS_PAUSE;
                }, () => {

                })
            },
            goOnVideotape() {
                let params = {
                    SdkAppId: constData.SDK_APP_ID,
                    TaskId: this.taskId
                };
                this.$request(params, "/whiteboard/resumeOnlineRecord", () => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '恢复录像成功');
                    this.status.videotapeStatus = this.constData.VIDEOTAPE_STATUS_ON;
                }, () => {

                })
            },
            getUserSig(sdkAppId, userId, success_callBack) {
                let params = {
                    sdkAppId: sdkAppId,
                    userId: userId
                };
                this.$request(params, "/user/getSign", data => {
                    if (data.list && data.list[0]) {
                        let userSign = data.list[0].userSign;
                        success_callBack && success_callBack(userSign);
                    }
                })
            },
            //添加老师上课记录
            insertCourseRecord() {
                let params = {
                    teacherId: this.ticUserInfo.userId,
                    courseId: this.courseId,
                    courseHourId: this.courseHourId,
                    courseTimeId: this.courseTimeId
                };
                this.$request(params, "/teacher/insertCourseRecord");
            },
            //增加老师课程记录
            updateFinishedCourseHour() {
                let params = {
                    courseId: this.courseId,
                    roomId: this.roomID,
                    teacherId: this.ticUserInfo.userId,
                    courseHourId: this.courseHourId
                };
                this.$request(params, "/masters/updateFinishedCourseHour");
            },
            answerStart(answerType) {
                this.answerType = answerType;
                this.$store.commit("setAnswering", true);
            },
            openStudentList() {
                if (this.ticUserStatus < constData.USER_STATUS_INCLASS) {
                    return;
                }
                this.$store.commit("setStudentListDialog", true);
            },
            getStudentList() {
                this.$request({roomId: this.roomID}, '/masters/mapper/select/studentStatus.selectStudentStatus', data => {
                    this.$store.commit("setStudentList", data.list);
                });
            }
        },
        beforeDestroy() {
            this.updateHandler();
        },
        destroyed() {
            window.removeEventListener('beforeunload', this.updateHandler);
        }
    }
</script>

<style lang="less">
    @import "./classroom";
</style>
