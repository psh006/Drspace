<template>
    <div class="login">
        <div class="login-left">
            <el-image class="login-img" :src="require('./../assets/img/login.png')" fit="full"></el-image>
        </div>
        <div class="login-right">
            <div class="login-form">
                <div class="login-title">{{loginTitle}}</div>
                <el-input class="login-input" placeholder="请输入帐号" maxlength="20" autocomplete="off"
                          prefix-icon="el-icon-user-solid" v-model="loginParams.loginCode">
                </el-input>
                <el-input class="login-input" placeholder="请输入密码" type="password" autocomplete="off" maxlength="20"
                          prefix-icon="el-icon-lock" v-model="loginParams.loginPass">
                </el-input>
                <el-radio-group class="login-role" v-model="loginParams.loginRole">
                    <el-radio :label="1">老师</el-radio>
                    <el-radio :label="2">管理员</el-radio>
                </el-radio-group>
                <el-button type="primary" :loading="status.loginLoading" class="login-button" @click="doLogin">登录</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'login',
        data() {
            return {
                loginTitle: "名师荟教育",
                loginParams: {
                    loginCode: "",
                    loginPass: "",
                    loginRole: 2,
                },
                status: {
                    loginLoading: false
                }
            }
        },
        created() {
            document.onkeydown = (ev) => {
                var event = ev || event;
                if (event.keyCode == 13) {
                    this.doLogin();
                }
            }
        },
        methods: {
            doLogin() {
                let loginCode = this.loginParams.loginCode;
                let loginPass = this.loginParams.loginPass;
                let loginRole = this.loginParams.loginRole;
                if (this.$util.isEmpty(loginCode)) {
                    this.$message.error("请输入帐号");
                    return;
                }
                if (this.$util.isEmpty(loginPass)) {
                    this.$message.error("请输入密码");
                    return;
                }
                if (this.$util.isEmpty(loginRole)) {
                    this.$message.error("请输入选择您的身份");
                    return;
                }

                let params = {};
                params.loginCode = loginCode;
                params.loginPass = loginPass;
                params.loginRole = loginRole;
                this.status.loginLoading = true;
                this.$request(params, "/login/userLogin", (data) => {
                        this.status.loginLoading = false;
                        let user = data.list[0];
                        if (this.$util.isEmpty(user.menuList)) {
                            this.$message.error("没有任何权限，请联系管理员！");
                            return;
                        }
                        user.loginRole = loginRole;
                        this.$util.saveUser(user);//保存用户信息
                        this.$store.commit("setSystemUserInfo", user);
                        this.$dict.initDict();//初始化数据字典
                        // this.queryAreaList();//初始化省市区数据
                        this.initMenuList(user.roleId);//初始化用户菜单列表
                    }, () => {
                        this.status.loginLoading = false;
                    }
                );
            },
            // queryAreaList() {
            //     this.$request({}, "/area/queryAreaList", (data) => {
            //         this.$util.setAreaList(data.list);
            //     });
            //
            // },
            initMenuList(roleId) {
                localStorage.removeItem("FIRST_MENU");
                localStorage.removeItem("SELECT_MENU");
                this.$request({roleId: roleId}, "/system/querySysMenuList", (data) => {
                    let menuList = data.list;
                    if (this.$util.isEmpty(menuList)) {
                        this.$message.error("没有任何权限，请联系管理员！");
                        return;
                    }
                    localStorage.setItem("VUE_MENU_LIST", JSON.stringify(menuList));
                    this.$router.push("/home");
                });
            },
        }
    }
</script>

<style lang="less">
    .login {
        width: 80vw;
        height: 70vh;
        top: 15vh;
        left: 10vw;
        position: absolute;
        min-width: 1000px;

        .login-left {
            float: left;
            width: 49%;
            height: 100%;
            position: relative;

            .login-img {
                position: absolute;
                right: 0px;
                top: 50%;
                transform: translate(0px, -50%);
            }
        }

        .login-right {
            float: left;
            width: 49%;
            height: 100%;
            position: relative;

            .login-form {
                width: 60%;
                height: 55%;
                border: 1px solid #e1e1e1;
                position: absolute;
                left: 10%;
                top: 50%;
                transform: translate(0px, -50%);
                padding: 50px 30px 30px 30px;
                min-height: 350px;
                min-width: 350px;

                .login-input {
                    height: 60px;
                    line-height: 60px;

                    input {
                        height: 45px;
                        font-size: 16px;
                    }
                }

                .login-title {
                    font-size: 24px;
                    width: 100%;
                    height: 90px;
                    line-height: 90px;
                    text-align: center;
                }

                .login-role {
                    margin: 20px 0px;
                }

                .login-button {
                    width: 100%;
                    border-radius: 5px;
                    margin-top: 20px;

                    span {
                        line-height: 25px;
                        font-size: 20px;
                    }
                }
            }
        }
    }
</style>