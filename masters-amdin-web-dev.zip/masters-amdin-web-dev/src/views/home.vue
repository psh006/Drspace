<template>
    <el-container class="home">
        <el-header class="home-header">
            <div class="logo">
                名师荟教育
            </div>
            <div class="first-menu-box">
                <div class="title">{{systemTitle}}</div>
                <div class="first-menu">
                    <div v-for="(item,index) in firstMenuData"
                         :key="index"
                         :class="`first-menu-item ${nowSelectFirstMenu.menuId === item.menuId ? 'first-menu-item-active' : ''}`"
                         @click="firstMenuClick(item)">
                        <img v-if="item.menuName !== '聊天'" :src="require(`./../assets/img/${item.menuIcon}`)"/>
                        <el-badge v-else :value="notReadTotal" :max="99" class="item" :hidden="notReadTotal < 1" :key="index">
                            <img :src="require(`./../assets/img/${item.menuIcon}`)"/>
                        </el-badge>
                        <div>{{item.menuName}}</div>
                    </div>
                </div>
                <div class="user-info">
                    <el-popover popper-class="home-top-popper" width="95" placement="bottom" v-model="status.isShowLoginOut">
                        <el-button icon="el-icon-key" style="float: right;border: none;width: 100%" size="mini"
                                   @click="showUpdatePassword">修改密码
                        </el-button>
                        <el-button icon="el-icon-switch-button" style="float: right;border: none;width: 100%" size="mini"
                                   @click="loginOut">退出登录
                        </el-button>
                        <el-image slot="reference"
                                  :src="$getFileUrl + $util.getUser().avatar"
                                  class="head-img"
                                  fit="cover"
                                  @click.stop="status.isShowLoginOut = !status.isShowLoginOut">
                            <el-image class="head-img-error" :src="require('./../assets/img/default-head.png')" slot="error" fit="cover"/>
                        </el-image>
                    </el-popover>
                    <div class="user-name">{{systemUserInfo.campusName}}-{{systemUserInfo.empName}}</div>
                </div>
            </div>
        </el-header>
        <el-container class="home-container">
            <el-aside width="180px" class="home-aside">
                <el-menu class="home-el-menu"
                         background-color="#5D2385" active-text-color="#FFFFFF" text-color="#FFFFFF"
                         @select="menuSelect">
                    <template v-for="(menu,menuIndex) in menuData">
                        <el-submenu v-if="menu.isLeaf === 2" :key="menuIndex" :index="menu.menuId">
                            <template slot="title">
                                <img class="menu-icon-img" :src="require(`./../assets/img/${menu.menuIcon}`)"/>
                                <span>{{menu.menuName}}</span>
                            </template>
                            <el-menu-item v-for="(children,childrenIndex) in menu.children" :key="childrenIndex"
                                          :class="children.menuUrl === editableTabsValue ? 'active' : ''"
                                          :index="children.menuUrl">
                                <span slot="title">{{children.menuName}}</span>
                            </el-menu-item>
                        </el-submenu>
                        <el-menu-item :class="menu.menuUrl === editableTabsValue ? 'active' : ''" v-else :key="menuIndex" :index="menu.menuUrl">
                            <img class="menu-icon-img" :src="require(`./../assets/img/${menu.menuIcon}`)"/>
                            <span slot="title">{{menu.menuName}}</span>
                        </el-menu-item>
                    </template>
                </el-menu>
            </el-aside>
            <el-main class="home-main">
                <el-tabs :value="editableTabsValue" class="home-tab" type="border-card" closable
                         @tab-remove="removeTab" @tab-click="tabClick">
                    <el-tab-pane
                            v-for="(item) in editableTabs"
                            :key="item.menuId"
                            :label="item.menuName"
                            :name="item.menuUrl"
                    >
                        <component :is=item.menuUrl></component>
                    </el-tab-pane>
                </el-tabs>
            </el-main>
        </el-container>
        <el-dialog title="修改密码" :visible.sync="status.isShowUpdatePassword" width="400px" @closed="closedDialog">
            <div>
                <el-form :model="passForm" :rules="rules" ref="passForm" label-width="80px">
                    <el-form-item label="原密码" prop="oldPass">
                        <el-input show-password v-model="passForm.oldPass" maxlength="20" placeholder="请输入原密码" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="新密码" prop="newPass">
                        <el-input show-password v-model="passForm.newPass" maxlength="20" placeholder="请输入新密码" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="确认密码" prop="confirmPass">
                        <el-input show-password v-model="passForm.confirmPass" maxlength="20" placeholder="请输入确认密码" clearable></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="closedDialog">取 消</el-button>
                <el-button type="primary" @click="savePass">确 定</el-button>
            </span>
        </el-dialog>
        <conversation v-if="showConversation"/>
    </el-container>
</template>
<script>
    import {mapState} from 'vuex';
    import constData from "./../assets/javascript/const-data"
    import conversation from "./conversation"

    export default {
        name: "home",
        components: {
            conversation
        },
        data() {
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请输入确认密码'));
                } else {
                    if (this.passForm.newPass !== this.passForm.confirmPass) {
                        callback(new Error('两次输入的密码不一致'));
                    }
                    callback();
                }
            };
            return {
                constData: constData,
                status: {
                    isShowLoginOut: false,
                    isShowUpdatePassword: false
                },
                // 一级菜单数据
                firstMenuData: [],
                // 当前被选择的一级菜单
                nowSelectFirstMenu: {},
                nowDateTime: "",
                userName: "用户",
                systemTitle: "",
                headImg: "",
                rules: {
                    oldPass: [
                        {required: true, message: "请输入原密码", trigger: "blur"}
                    ],
                    newPass: [
                        {required: true, message: "请输入新密码", trigger: "blur"}
                    ],
                    confirmPass: [
                        {required: true, message: "请输入确认密码", trigger: "blur"},
                        {required: true, validator: validatePass, trigger: 'blur'}
                    ]
                },
                passForm: {
                    oldPass: "",
                    newPass: "",
                    confirmPass: ""
                }
            }
        },
        mounted() {
            let user = this.$util.getUser();
            if (this.$util.isEmpty(user)) {
                this.$message.error("您还没有登录，请先登录！");
                this.$router.push("/login").finally(() => {
                    window.location.reload(true);
                });
                return;
            }
            this.$store.commit("setSystemUserInfo", user);
            let campusName = user.campusName;
            let empName = user.empName;
            this.userName = this.$util.isEmpty(campusName) ? empName : campusName + "-" + empName;
            let roleId = user.roleId;
            this.systemTitle = roleId == 1 ? "管理端" : "老师端";
            let avatar = user.avatar;
            if (!this.$util.isEmpty(avatar)) {
                this.headImg = avatar;
            }
            this.getFirstMenuData();
            this.getUserSig(user.empId);
            window.addEventListener('beforeunload', this.updateHandler);
        },
        computed: {
            ...mapState({
                ticUserStatus: state => state.ticUserStatus,
                tic: state => state.tic,
                notReadTotal: state => state.notReadTotal,
                ticUserInfo: state => state.ticUserInfo,
                editableTabsValue: state => state.editableTabsValue,
                menuData: state => state.menuData,
                editableTabs: state => state.editableTabs,
                showConversation: state => state.showConversation,
                systemUserInfo: state => state.systemUserInfo,
                roomId: state => state.classroomStudentModules.roomId
            })
        },
        beforeDestroy() {
            this.updateHandler();
        },
        destroyed() {
            window.removeEventListener('beforeunload', this.updateHandler);
        },
        methods: {
            savePass() {
                let passForm = this.$refs.passForm;
                passForm.validate((valid) => {
                    if (valid) {
                        if (this.passForm.oldPass === this.passForm.newPass) {
                            this.$message.error('新密码不可与旧密码相同');
                            return;
                        }
                        this.passForm.loginRole = this.$util.getUser().loginRole;
                        this.$request(this.passForm, "/login/updateLoginPass", () => {
                            this.$message.success("密码已修改，请重新登录");
                            this.$util.removeUser();
                            this.$router.push("/login").finally(()=>{
                                window.location.reload(true);
                            });
                        });
                    } else {
                        return false;
                    }
                });
            },
            showUpdatePassword() {
                this.status.isShowUpdatePassword = true;
            },
            closedDialog() {
                this.passForm = {};
                this.$refs.passForm.resetFields();
                this.status.isShowUpdatePassword = false
            },
            loginOut() {
                this.$confirm('确定要退出登录吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    if(this.$util.isEmpty(this.$util.getUser())){
                        this.status.isShowLoginOut = false;
                        this.$store.commit("clearTab");
                        this.$router.push("/login").finally(() => {
                            window.location.reload(true);
                        });
                        this.logout_internal();
                        return;
                    }
                    this.$request(this.$util.getUser(), "/login/userLoginOut", () => {
                        this.status.isShowLoginOut = false;
                        this.$util.removeUser();
                        this.$store.commit("clearTab");
                        this.$router.push("/login").finally(() => {
                            window.location.reload(true);
                        });
                        this.logout_internal();
                    });
                }).catch(() => {
                });
            },
            getFirstMenuData() {
                this.firstMenuData = JSON.parse(localStorage.getItem("VUE_MENU_LIST"));
                if (this.$util.isEmpty(this.firstMenuData)) {
                    this.$util.removeUser();
                    this.$message.warning("菜单丢失，请重新登录");
                    this.$router.push("/home").finally(() => {
                        window.location.reload(true);
                    });
                    return;
                }
                this.firstMenuClick(this.firstMenuData[0]);
            },
            //一级菜单点击函数
            firstMenuClick(menu) {
                if (menu.menuName === '聊天') {
                    this.$store.commit("setShowConversation", true);
                    return;
                }
                this.$store.commit("setMenuData", menu.children);
                this.nowSelectFirstMenu = menu;
                if (menu.children[0].isLeaf === 1) {
                    this.menuSelect(menu.children[0].menuUrl);
                } else {
                    this.menuSelect(menu.children[0].children[0].menuUrl);
                }
            },
            //二级菜单被选中函数
            menuSelect(path) {
                let isHave = false;
                for (let menu of this.editableTabs) {
                    if (menu.menuUrl === path) {
                        isHave = true;
                        break;
                    }
                }
                if (isHave) {
                    this.$store.commit("removeTab", path);
                }
                this.$nextTick(() => {
                    this.$store.commit("menuSelect", path);
                });

            },
            tabClick(tab) {
                this.$store.commit("menuSelect", tab.name);
            },
            //删除Tab栏
            removeTab(menu) {
                this.$store.commit("removeTab", menu);
            },
            initTic() {
                if (this.ticUserStatus === this.constData.USER_STATUS_UNINIT) {
                    this.$store.commit("initTic", () => {
                        this.loginTic();
                    })
                } else if (this.ticUserStatus <= this.constData.USER_STATUS_UNLOGIN) {
                    this.loginTic();
                }
            },
            updateMyProfile() {
                let getPromise = window.tim.getMyProfile();
                getPromise.then(imResponse => {
                    let user = this.$util.getUser();
                    let userInfo = imResponse.data;
                    let updateUserInfo = {};
                    if (userInfo.nick !== user.empName) {
                        updateUserInfo.nick = user.empName || ""
                    }
                    if (userInfo.avatar !== user.avatar) {
                        updateUserInfo.avatar = user.avatar || ""
                    }
                    if (!this.$util.isEmpty(updateUserInfo)) {
                        let promise = window.tim.updateMyProfile(updateUserInfo);
                        promise.then(() => {
                            console.log("tim:更新资料成功")
                        }).catch(function (imError) {
                            console.warn('更新资料失败:', imError); // 更新资料失败的相关信息
                        });
                    }
                }).catch(imError => {
                    console.warn('获取资料失败:', imError); // 获取个人资料失败的相关信息
                });
            },
            loginTic() {
                this.clearEvent();
                // 登录成功后会触发 SDK_READY 事件，该事件触发后，可正常使用 SDK 接口
                window.tim.on(window.TIM.EVENT.SDK_READY, this.onReadyStateUpdate, this);
                // 收到新消息
                window.tim.on(window.TIM.EVENT.MESSAGE_RECEIVED, this.onReceiveMessage);
                // 会话列表更新
                window.tim.on(window.TIM.EVENT.CONVERSATION_LIST_UPDATED, this.onUpdateConversationList);
                this.tic.login(this.ticUserInfo, (res) => {
                    if (res.code) {
                        console.error(this.constData.MESSAGE_TYPE_SYSTEM, "登录失败", res);
                    } else {
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_LOGINED);
                        // 增加事件监听
                        this.addTICEventListener();
                        this.addTICStatusListener();
                    }
                });
            },
            clearEvent() {
                this.tic.removeTICEventListener();
                this.tic.removeTICStatusListener();
                window.tim.off(window.TIM.EVENT.SDK_READY, this.onReadyStateUpdate);
                window.tim.off(window.TIM.EVENT.MESSAGE_RECEIVED, this.onReceiveMessage);
                window.tim.off(window.TIM.EVENT.CONVERSATION_LIST_UPDATED, this.onUpdateConversationList);
            },
            onReadyStateUpdate() {
                this.getConversationList();
                this.updateMyProfile();
            },
            onReceiveMessage({data: messageList}) {
                this.$store.commit('pushCurrentMessageList', messageList)
            },
            onUpdateConversationList(event) {
                this.getConversationList(event.data)
            },
            getConversationList(updateConversationList) {
                if (updateConversationList) {
                    let conversationList = updateConversationList.filter(conversation => {
                        return conversation.type === window.TIM.TYPES.CONV_C2C;
                    });
                    this.$store.commit("setConversationList", conversationList);
                } else {
                    let conversationListProperties = window.tim.getConversationList();
                    conversationListProperties.then(data => {
                        let conversationList = data.data.conversationList.filter(conversation => {
                            return conversation.type === window.TIM.TYPES.CONV_C2C;
                        });
                        this.$store.commit("setConversationList", conversationList);
                    });
                }

            },
            // 事件监听回调
            addTICEventListener() {
                this.tic.addTICEventListener({
                    onTICMemberJoin: () => {
                        this.$request({roomId: this.roomId}, '/masters/mapper/select/studentStatus.selectStudentStatus', data => {
                            this.$store.commit("setStudentList", data.list);
                        });
                    },
                    onTICMemberQuit: () => {

                    },
                    onTICClassroomDestroy: () => {
                    },
                    onTICTrtcClientCreated: () => {
                        window.trtcClient = this.trtcClient = this.tic.getTrtcClient();
                        this.initTRTCEvent();
                    }
                });
            },
            // TRTC事件
            initTRTCEvent() {
                this.trtcClient.on('stream-added', event => {
                    const remoteStream = event.stream;
                    const remoteUserId = remoteStream.getUserId();
                    console.log('received a remoteStream ID: ' + remoteStream.getId() + ' from user: ' + remoteUserId);
                    // 若需要观看该远端流，则需要订阅它，默认会自动订阅
                    this.trtcClient.subscribe(remoteStream);
                });

                // 监听‘stream-removed’事件
                this.trtcClient.on('stream-removed', event => {
                    const remoteStream = event.stream;
                    console.log('remoteStream ID: ' + remoteStream.getId() + ' has been removed');
                    // 停止播放并删除相应<video>标签
                    remoteStream.stop();
                    document.getElementById(remoteStream.getId()).remove();
                });

                // 监听‘stream-updated’事件
                this.trtcClient.on('stream-updated', event => {
                    const remoteStream = event.stream;
                    console.log('remoteStream ID: ' + remoteStream.getId() + ' was updated hasAudio: ' +
                        remoteStream.hasAudio() + ' hasVideo: ' + remoteStream.hasVideo());
                });

                // 监听‘stream-subscribed’事件
                this.trtcClient.on('stream-subscribed', event => {

                    const remoteStream = window.remoteStream = event.stream;
                    // 远端流订阅成功，在HTML页面中创建一个<video>标签，假设该标签ID为‘remote-video-view’
                    // 播放该远端流
                    let remoteVideoWrapEl = document.createElement('div');
                    remoteVideoWrapEl.id = remoteStream.getId();
                    remoteVideoWrapEl.className = 'video-item';
                    document.querySelector("#video-box").insertBefore(remoteVideoWrapEl, null);
                    remoteStream.play(remoteVideoWrapEl);
                });

                this.trtcClient.on('mute-audio', event => {
                    console.log('mute-audio', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}关闭了麦克风`);
                });

                this.trtcClient.on('mute-video', event => {
                    console.log('mute-video', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}关闭了摄像头`);
                });

                this.trtcClient.on('unmute-audio', event => {
                    console.log('unmute-audio', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}打开了麦克风`);
                });

                this.trtcClient.on('unmute-video', event => {
                    console.log('unmute-video', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}打开了摄像头`);
                });

                this.trtcClient.on('error', error => {
                    console.error('client error observed: ' + error);
                    // const errorCode = error.getCode();
                    // 根据ErrorCode列表查看详细错误原因。
                });
            },
            // IM状态监听回调
            addTICStatusListener() {
                this.tic.addTICStatusListener({
                    onTICForceOffline: () => {
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_UNLOGIN);
                        this.$message.warning("帐号其他地方登录，被T了");
                        this.clearEvent();
                        this.$util.removeUser();
                        this.$router.push("/login").then(() => {
                            window.location.reload(true);
                        });
                    }
                });
            },
            updateHandler() {
                // this.logout_internal();
            },
            logout_internal() {
                if (this.tic) {
                    this.tic.logout((res) => {
                        if (res.code) {
                            this.$message.error('登出失败');
                            console.error(res);
                        } else {
                            this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_UNLOGIN);
                            // 删除事件监听
                            this.tic.removeTICMessageListener();
                            this.tic.removeTICEventListener();
                            this.tic.removeTICStatusListener();
                        }
                    });
                }
            },
            getUserSig(userId) {
                if (this.ticUserStatus <= constData.USER_STATUS_UNLOGIN) {
                    let params = {
                        sdkAppId: this.constData.SDK_APP_ID,
                        userId: userId
                    };
                    this.$request(params, "/user/getSign", data => {
                        if (data.list && data.list[0]) {
                            let userSign = data.list[0].userSign;
                            let ticUserInfo = {
                                userId: userId,
                                userSig: userSign
                            };
                            this.$store.commit("setTicUserInfo", ticUserInfo);
                            this.initTic();
                        }
                    })
                }
            },
            showMessageInBox(messageType, text) {
                let d = new Date();
                let time = `${('0' + d.getHours()).substr(-2)}:${('0' + d.getMinutes()).substr(-2)}:${('0' + d.getSeconds()).substr(-2)}`;
                let msg = {
                    time: time + ' ',
                    send: messageType + ' ',
                    content: text
                };
                this.$store.commit("insertGroupMsg", msg)
            }
        }
    }
</script>

<style scoped lang="less">
    @import "./home.less";
</style>

<style lang="less">
    .home {
        .home-tab {
            height: 100%;
            box-shadow: none;
            border: none;

            & > .el-tabs__header {

            }

            & > .el-tabs__content {
                height: calc(100% - 40px - 15px);
                width: calc(100% - 20px);
                overflow: auto;
                padding: 15px 10px 0 10px;
            }
        }
        .home-container {
            .home-aside {
                .home-el-menu {
                    .el-submenu__title {
                        height: 40px;
                        line-height: 40px;
                    }
                }
            }
        }
    }
</style>
