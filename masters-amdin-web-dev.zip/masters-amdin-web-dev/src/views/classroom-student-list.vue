<template>
    <el-dialog class="classroom-student-list"
               title="学生管理"
               :visible="studentListDialog"
               width="800px"
               @open="studentListDialogOpen"
               @close="studentListDialogClose">
        <el-table :data="studentList" v-loading="status.getStudentListLoading" max-height="500px">
            <el-table-column label="姓名" prop="nickName"></el-table-column>
            <el-table-column label="上下台状态">
                <template slot-scope="scope">
                    <el-link type="primary" v-if="scope.row.onStageState === 2">未上台</el-link>
                    <el-link type="success" v-else>上台中</el-link>
                </template>
            </el-table-column>
            <el-table-column label="麦克风状态">
                <template slot-scope="scope">
                    <el-link type="success" v-if="scope.row.prosodyState === 2">未禁麦</el-link>
                    <el-link type="danger" v-else>禁麦中</el-link>
                </template>
            </el-table-column>
            <el-table-column label="发言状态">
                <template slot-scope="scope">
                    <el-link type="success" v-if="scope.row.estoppelState === 2">未禁言</el-link>
                    <el-link type="danger" v-else>禁麦中</el-link>
                </template>
            </el-table-column>
            <el-table-column label="黑名单状态">
                <template slot-scope="scope">
                    <el-link type="success" v-if="scope.row.blacklistState === 2">未拉黑</el-link>
                    <el-link type="danger" v-else>已拉黑</el-link>
                </template>
            </el-table-column>
            <el-table-column label="操作" width="240">
                <template slot-scope="scope">
                    <el-link class="button-link" type="primary" v-if="scope.row.onStageState === 2" @click="setOnStageState(scope.row.studentId,1)">
                        上台
                    </el-link>
                    <el-link class="button-link" type="primary" v-else @click="setOnStageState(scope.row.studentId,2)">下台</el-link>
                    <el-link class="button-link" type="primary" v-if="scope.row.prosodyState === 2" @click="setProsodyState(scope.row.studentId,1)">
                        禁麦
                    </el-link>
                    <el-link class="button-link" type="primary" v-else @click="setProsodyState(scope.row.studentId,2)">解除禁麦</el-link>
                    <el-link class="button-link" type="primary" v-if="scope.row.estoppelState === 2" @click="setEstoppelState(scope.row.studentId,1)">
                        静言
                    </el-link>
                    <el-link class="button-link" type="primary" v-else @click="setEstoppelState(scope.row.studentId,2)">解除静言</el-link>
                    <el-link class="button-link" type="primary" v-if="scope.row.blacklistState === 2"
                             @click="setBlacklistState(scope.row.studentId,1)">拉黑
                    </el-link>
                    <el-link class="button-link" type="primary" v-else @click="setBlacklistState(scope.row.studentId,2)">解除拉黑</el-link>
                </template>
            </el-table-column>
        </el-table>
    </el-dialog>
</template>

<script>
    import {mapState} from 'vuex'
    import constData from "./../assets/javascript/const-data"

    export default {
        name: "classroom-student-list",
        computed: {
            ...mapState({
                studentList: state => state.classroomStudentModules.studentList,
                studentListDialog: state => state.classroomStudentModules.studentListDialog,
                roomId: state => state.classroomStudentModules.roomId
            })
        },
        data() {
            return {
                status: {
                    getStudentListLoading: false
                }
            }
        },
        methods: {
            studentListDialogOpen(){
                this.getStudentList();
            },
            studentListDialogClose() {
                this.$store.commit("setStudentListDialog", false);
            },
            setOnStageState(studentId, onStageState) {
                this.$request({roomId: this.roomId, studentId, onStageState}, '/masters/mapper/select/studentStatus.updateStudentStatus', () => {
                    this.$message.success("操作成功");
                    this.teacherDo(studentId, constData.MESSAGE_TYPE_ONSTAGE_STATE, onStageState);
                    this.getStudentList();
                });
            },
            setProsodyState(studentId, prosodyState) {
                this.$request({roomId: this.roomId, studentId, prosodyState}, '/masters/mapper/select/studentStatus.updateStudentStatus', () => {
                    this.$message.success("操作成功");
                    this.teacherDo(studentId, constData.MESSAGE_TYPE_PROSODY_STATE, prosodyState);
                    this.getStudentList();
                });
            },
            setEstoppelState(studentId, estoppelState) {
                this.$request({roomId: this.roomId, studentId, estoppelState}, '/masters/mapper/select/studentStatus.updateStudentStatus', () => {
                    this.$message.success("操作成功");
                    this.teacherDo(studentId, constData.MESSAGE_ESTOPPEL_STATE, estoppelState);
                    this.getStudentList();
                });
            },
            setBlacklistState(studentId, blacklistState) {
                this.$request({roomId: this.roomId, studentId, blacklistState}, '/masters/mapper/select/studentStatus.updateStudentStatus', () => {
                    this.$message.success("操作成功");
                    this.teacherDo(studentId, constData.MESSAGE_BLACKLIST_STATE, blacklistState);
                    this.getStudentList();
                });
            },
            getStudentList() {
                this.status.getStudentListLoading = true;
                this.$request({roomId: this.roomId}, '/masters/mapper/select/studentStatus.selectStudentStatus', data => {
                    this.status.getStudentListLoading = false;
                    this.$store.commit("setStudentList", data.list);
                }, () => {
                    this.status.getStudentListLoading = false;
                });
            },
            teacherDo(studentId, messageType, status) {
                let text = {};
                text.type = messageType;
                text.data = {status};
                const message = window.tim.createTextMessage({
                    to: studentId,
                    conversationType: window.TIM.TYPES.CONV_C2C,
                    payload: {text: JSON.stringify(text)}
                });
                window.tim.sendMessage(message).catch(error => {
                    this.$message.error(error.message);
                });
            }
        }
    }
</script>

<style lang="less" scoped>
    .classroom-student-list {
        .button-link {
            margin-right: 5px;
        }
    }
</style>