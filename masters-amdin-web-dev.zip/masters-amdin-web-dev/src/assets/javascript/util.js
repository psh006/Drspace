/**
 * @description 全局公用函数
 * @author mgLuoBo
 * @createTime 2019/7/23 0023 22:04
 */


/**
 * 保存用户
 * @param user 用户信息
 */
const saveUser = (user) => {
    localStorage.setItem("user", JSON.stringify(user));
};

/**
 * 移除用户
 */
const removeUser = () => {
    localStorage.removeItem("user");
};

/**
 * 去掉最后一个逗号
 */
const removeLastComma = (str) => {
    if (str.endsWith(",") || str.endsWith("，")) {
        return str.substring(0, str.length - 1);
    }
    return str;
};

/**
 * 获取用户
 */
const getUser = () => {
    let user = localStorage.getItem("user");
    if (isEmpty(user) || user === 'undefined') {
        return {};
    } else {
        return JSON.parse(user);
    }
};

/**
 * 将一个字符串数组转化为逗号分割的字符串
 * @param arr {Array<string>} 需要被转换的数组
 */
const arrToString = arr => {
    let strings = "";
    for (let string of arr) {
        strings += `${string},`;
    }
    return strings.substring(0, strings.length - 1);
};

/**
 * 获取当前时间
 * @returns {string} yyyy-MM-dd hh:mm:ss 格式的时间字符串
 */
const getNowDateTime = () => {
    let date = new Date();
    let y = date.getFullYear();
    let MM = date.getMonth() + 1;
    MM = MM < 10 ? ('0' + MM) : MM;
    let d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    let h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    let m = date.getMinutes();
    m = m < 10 ? ('0' + m) : m;
    let s = date.getSeconds();
    s = s < 10 ? ('0' + s) : s;
    return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
};
/**
 * 获取当前日期
 * @returns {string} yyyy-MM-dd
 * 正数:未来val天
 * 负数:过去val天
 */
const getNowDate = (val) => {
    var date = new Date();
    if (val !== undefined && val !== 0) {
        var curTime = 0;
        var startDate = 0;
        if (val > 0) {
            curTime = new Date().getTime();
            startDate = curTime + (val * 3600 * 24 * 1000);
            date = new Date(startDate);
        } else if (val < 0) {
            curTime = new Date().getTime();
            startDate = curTime - (Math.abs(val) * 3600 * 24 * 1000);
            date = new Date(startDate);
        }
    }
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    return date.getFullYear() + "-" + month + "-" + strDate;
};

/**
 * 时间格式方法
 *
 * @param {String} nS  时间戳，秒级/毫秒级
 * @param {String} str 格式化时间类型，默认  Y-M-D H:I:S
 * @param {String} _date 直接转换（）
 * @returns {string} formatTime 格式化后的时间 例如： 2017-05-05 12:09:22
 */
const formatDate = (nS, str, _date) => {
    if(!_date){
        if (!nS) {
            return ''
        }
        if (isNaN(parseInt(nS))) {
            return nS
        }
        var date = new Date(nS);
        var year = date.getFullYear();
        var mon = date.getMonth() + 1;
        var day = date.getDate();
        var week = date.getDay();
        var hours = date.getHours();
        var minu = date.getMinutes();
        var sec = date.getSeconds();
        var msec = date.getMilliseconds();
        if (msec < 100) {
            msec = '00' + msec;
        }
        if (msec < 10) {
            msec = '0' + msec;
        }

        if (str === 'yyyy-MM-dd') {
            return year + '-' + (mon < 10 ? '0' + mon : mon) + '-' + (day < 10 ? '0' + day : day)
        } else if (str === 'hh-mm-ss') {
            return (hours < 10 ? '0' + hours : hours) + ':' + (minu < 10 ? '0' + minu : minu) + ':' + (sec < 10 ? '0' + sec : sec)
        } else if (str === 'hh-mm') {
            return (hours < 10 ? '0' + hours : hours) + ':' + (minu < 10 ? '0' + minu : minu)
        } else if (str === 'yyyy/MM/dd') {
            return year + '/' + (mon < 10 ? '0' + mon : mon) + '/' + (day < 10 ? '0' + day : day)
        } else if (str === 'yyyy年MM月dd日') {
            return year + '年' + (mon < 10 ? '0' + mon : mon) + '月' + (day < 10 ? '0' + day : day) + '日'
        } else if (str === 'MM-dd') {
            return (mon < 10 ? '0' + mon : mon) + '-' + (day < 10 ? '0' + day : day)
        } else if (str === 'MM月dd日 HH:mm') {
            return (mon < 10 ? '0' + mon : mon) + "月" + (day < 10 ? '0' + day : day) + "日 " + (hours < 10 ? '0' + hours : hours) + ":" + (minu < 10 ? '0' + minu : minu);
        } else if (str === 'yyyy-MM-dd HH:mm') {
            return year + '-' + (mon < 10 ? '0' + mon : mon) + "-" + (day < 10 ? '0' + day : day) + " " + (hours < 10 ? '0' + hours : hours) + ":" + (minu < 10 ? '0' + minu : minu);
        } else if (str === 'yyyyMMddHHmmssSSS') {
            return year + (mon < 10 ? '0' + mon : mon) + (day < 10 ? '0' + day : day) + (hours < 10 ? '0' + hours : hours) + (minu < 10 ? '0' + minu : minu) + (sec < 10 ? '0' + sec : sec) + msec;
        } else if (str === 'EEEE'){
            switch (week) {
                case 1:
                    week = '星期一';
                    break;
                case 2:
                    week = '星期二';
                    break;
                case 3:
                    week = '星期三';
                    break;
                case 4:
                    week = '星期四';
                    break;
                case 5:
                    week = '星期五';
                    break;
                case 6:
                    week = '星期六';
                    break;
                case 0:
                    week = '星期日';
                    break;
            }
            return week
        } else {
            return year + '-' + (mon < 10 ? '0' + mon : mon) + '-' + (day < 10 ? '0' + day : day) + ' ' + (hours < 10 ? '0' + hours : hours) + ':' + (minu < 10 ? '0' + minu : minu) + ':' + (sec < 10 ? '0' + sec : sec)
        }
    }else if(str==='年月日'){
        return _date.getFullYear() + '年' + (_date.getMonth() + 1) + '月' + _date.getDate() + '日'
    }else{
        return _date.getFullYear() + '-' + (_date.getMonth() + 1) + '-' + _date.getDate()
    }
};

/**
 * 使用@inpute时提供的校验方法 —— 校验纯数字
 * @param value
 * @param isString 是否返回字符串
 * @returns {*}
 */
const checkNumber = (value, isString) => {
    let _value = value.replace(/[^\d]/g, '');
    if(isEmpty(_value) || isString){
        return _value;
    }
    return parseInt(_value);
};

/**
 * 使用@inpute时提供的校验方法 —— 中英文校验
 * @param value
 * @returns {*}
 */
const checkCnEn = value => {
    return value.replace(/[^\u0391-\uFFE5A-Za-z]/g, '')
};

/**
 * 使用@inpute时提供的校验方法 —— 中,英,数字校验
 * @param value
 * @returns {*}
 */
const checkCnEnNu = value => {
    return value.replace(/[^\d\u0391-\uFFE5A-Za-z]/g, '')
};

/**
 * 使用@inpute时提供的校验方法 —— 英,数字校验
 * @param value
 * @returns {*}
 */
const checkEnNu = value => {
    return value.replace(/[^\dA-Za-z]/g, '')
};

/**
 * 使用@inpute时提供的校验方法 —— 校验金额，允许两位小数
 * @param value
 */
const checkMoney = value => {
    if (value) {
        value = value.toString();
        value = value.replace(/^\D*(\d*(?:\.\d{0,2})?).*$/g, '$1');
        if (value.length >= 2 && value[0] === '0' && (value[1] === '0' || value[1] !== '.')) {
            return '0';
        }
        return value;
    }
};

/**
 * 判空
 */
const isEmpty = (obj) => {
    if (typeof obj === "number" && !isNaN(obj)) {
        return false;
    }
    if (!obj) {
        return true;
    }
    return Object.keys(obj).length < 1
};

/**
 * 保存用户密码
 */
const saveUserPassword = (userPassword) => {
    localStorage.setItem("userPassword", userPassword);
};

/**
 * 获取用户密码
 */
const getUserPassword = () => {
    return localStorage.getItem("userPassword");
};

/**
 * 获取用户密码
 */
const removeUserPassword = () => {
    localStorage.removeItem("userPassword");
};

/**
 * 身份证判断
 */
const isCardId = (card) => {
    let reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
    return reg.test(card);
};

/**
 * 手机号码判断
 * @param number
 * @returns {boolean}
 */
const isPhoneNumber = (number) => {
    let reg = /^(\+86)?1[3456789]\d{9}$/;
    return reg.test(number);
};

/**
 * 中英文判断
 * @param val
 * @returns {boolean}
 */
const isCnEn = (val)=>{
    let reg = /^[\u0391-\uFFE5A-Za-z]+$/;
    return reg.test(val);
};

/**
 * 中文判断
 * @param val
 * @returns {boolean}
 */
const isChinese = val =>{
    let reg = /^[\u0391-\uFFE5]+$/;
    return reg.test(val);
};

/**
 * 英文判断
 * @param val
 * @returns {boolean}
 */
const isEnglish = val =>{
    let reg = /^[A-Za-z]+$/;
    return reg.test(val);
};

/**
 * 分转元
 * @param x
 * @returns {*}
 */
const pennyToYuan = (x) => {
    var f = parseFloat(x);
    if (isNaN(f)) {
        return false;
    }
    f = Math.round(x) / 100;
    var s = f.toString();
    var rs = s.indexOf('.');
    if (rs < 0) {
        rs = s.length;
        s += '.';
    }
    while (s.length <= rs + 2) {
        s += '0';
    }
    return s;
};

/**
 * Description:[两个时间格式毫秒数相减，返回“xx天xx小时xx分钟xx秒” ]
 *
 * @param startTime 开始时间毫秒数
 * @param endTime 结束时间毫秒数
 *
 * @return 返回“xx天xx小时xx分钟xx秒”
 */
function times2Minus(startTime, endTime) {
    var resultTime = '';
    //计算时间差
    var distanceTime = endTime - startTime;

    if (distanceTime > 0) {
        // 天时分秒换算
        var resultDay = Math.floor(distanceTime / 86400000);
        distanceTime -= resultDay * 86400000;

        var resultHour = Math.floor(distanceTime / 3600000);
        distanceTime -= resultHour * 3600000;

        var resultMinute = Math.floor(distanceTime / 60000);
        distanceTime -= resultMinute * 60000;

        var resultSecond = Math.floor(distanceTime / 1000);
        // 时分秒为单数时、前面加零
        if (resultDay < 10) {
            resultDay = "0" + resultDay;
        }
        if (resultHour < 10) {
            resultHour = "0" + resultHour;
        }
        if (resultMinute < 10) {
            resultMinute = "0" + resultMinute;
        }
        if (resultSecond < 10) {
            resultSecond = "0" + resultSecond;
        }
        resultTime = resultDay + '天' + resultHour + '小时' + resultMinute + '分钟' + resultSecond + '秒';
    } else {
        resultTime = '00天00小时00分钟00秒';
    }
    return resultTime;
}


/**
 * 省市区数据设置到缓存中
 */
const setAreaList = function (data) {
    let areaList = data[0].areaList;
    let provinceList = data[0].provinceList;
    let cityList = data[0].cityList;
    let districtList = data[0].districtList;
    localStorage.setItem("AREA_LIST", JSON.stringify(areaList));
    localStorage.setItem("PROVINCE_LIST", JSON.stringify(provinceList));
    localStorage.setItem("CITY_LIST", JSON.stringify(cityList));
    localStorage.setItem("DISTRICT_LIST", JSON.stringify(districtList));
};

/**
 * 从缓存中获取省市区数据
 */
const getAreaList = function () {
    let areaList = localStorage.getItem("AREA_LIST");
    if (isEmpty(areaList) || isEmpty(areaList)) {
        return [];
    }
    return JSON.parse(areaList);
};

/**
 * 根据区域编号获取省市区名称
 */
const getAreaListByAreaId = function (val) {
    let result = {};
    if (isEmpty(val)) {
        result.areaId = "";
        result.areaName = "";
        return result;
    }
    let areaId = val.toString();
    let provinceList = JSON.parse(localStorage.getItem("PROVINCE_LIST"));
    let cityList = JSON.parse(localStorage.getItem("CITY_LIST"));
    let districtList = JSON.parse(localStorage.getItem("DISTRICT_LIST"));
    let flag = false;
    let province = null;
    let city = null;
    let district = null;
    for (let districtMap of districtList) {
        if (districtMap.id === areaId) {
            district = districtMap;
            flag = true;
        }
    }

    if (!flag) {
        result.areaId = "";
        result.areaName = "";
        return result;
    }
    for (let cityMap of cityList) {
        if (cityMap.id.toString().substring(0, 4) === areaId.substring(0, 4)) {
            city = cityMap;
        }
    }
    for (let provinceMap of provinceList) {
        if (provinceMap.id.toString().substring(0, 2) === areaId.substring(0, 2)) {
            province = provinceMap;
        }
    }
    result.areaId = province.id + "," + (city == null ? "" : city.id + ",") + district.id;
    result.areaName = province.name + "," + (city == null ? "" : city.name + ",") + district.name;
    return result;
};

/**
 * 根据生日计算年龄
 * @param strAge
 * @returns {*}
 */
const getAge = function (strAge) {
    if (strAge == null || strAge.length===0){
        return ""
    }
    let birArr = strAge.split("-");
    let birYear = birArr[0];
    let birMonth = birArr[1];
    let birDay = birArr[2];

    let d = new Date();
    let nowYear = d.getFullYear();
    let nowMonth = d.getMonth() + 1;
    let nowDay = d.getDate();
    let returnAge;

    if (birArr == null) {
        return 0
    }
    returnAge = nowYear - birYear;
    if (nowMonth < birMonth) {
        returnAge--
    }else if (nowMonth === birMonth){
        if (nowDay<birDay){
            returnAge--
        }
    }
    return returnAge
};

/*数组快捷删除*/
Array.prototype.remove = function (val) {
    var index = this.indexOf(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};

/**
 * 小数转百分数（保留两位小数）
 * @param decimal
 * @returns {*}
 */
const decimal2Per = function (decimal) {
    if (isNaN(decimal)) {
        return 0;
    }
    let num = decimal*10000/100;
    return num.toFixed(2);
};

export default {
    getUser,
    saveUser,
    removeUser,
    isEmpty,
    checkMoney,
    checkNumber,
    getNowDateTime,
    getNowDate,
    formatDate,
    arrToString,
    saveUserPassword,
    getUserPassword,
    removeUserPassword,
    isCardId,
    isPhoneNumber,
    pennyToYuan,
    removeLastComma,
    setAreaList,
    getAreaList,
    getAreaListByAreaId,
    times2Minus,
    isCnEn,
    isChinese,
    isEnglish,
    getAge,
    decimal2Per,
    checkCnEn,
    checkCnEnNu,
    checkEnNu
}
