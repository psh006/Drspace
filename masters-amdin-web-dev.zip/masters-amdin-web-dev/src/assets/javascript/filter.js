/**
 * @Describe:全局过滤器
 * @Author: ouxin
 * @Date: 2019/12/3 15:54
 */

/**
 * 是否
 */
const filterYesNo = value => {
    let code = {1: '是', 2: '否'};
    return code[value];
};

const filters = {
    filterYesNo,
};

const install = function (Vue) {
    Object.keys(filters).forEach(key => {
        Vue.filter(key, filters[key])
    })
};

export default install
