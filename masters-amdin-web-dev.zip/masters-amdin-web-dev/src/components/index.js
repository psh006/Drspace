/**
 * @description
 * @author mgLuoBo
 * @createTime 2019/11/1 0001 15:32
 */

import orderManage from './order-manage/index'
import classManage from './class-manage/index'
import studentManage from './student-manage/index';
import myStudent from './student-manage/index';
import coursewareManage from './courseware-manage/index';
import myCourseware from './courseware-manage/index';
import system from './system/index'
import teacherManage from './teacher-manage/index'
import courseManage from './course-manage/index'
import courseManageTeacher from './course-manage/index'
import campusManage from './campus-manage/index'
import testManage from './test-manage/index'

const components = [
    orderManage,
    classManage,
    teacherManage,
    studentManage,
    myStudent,
    coursewareManage,
    myCourseware,
    system,
    courseManage,
    courseManageTeacher,
    campusManage,
    testManage
];

const viewComponents = {
    install: (Vue) => {
        for (let componentArr of components) {
            for (let component of componentArr) {
                Vue.component(component.name, component);
            }
        }
    }
};

export default viewComponents;
