/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/4/22 0022 11:36
 */

import bannerManage from './banner-manage';
import specialTopicManage from './special-topic-manage';
import courseList from './course-list';
import classManageTeacher from './class-manage-teacher';

export default [
    bannerManage,
    courseList,
    bannerManage,
    // eslint-disable-next-line no-undef
    specialTopicManage,
    classManageTeacher
]
