<template>
  <div class="banner-manage">
    <el-form v-model="bannerForm" inline>
      <el-form-item label="课程名称">
        <el-input v-model="bannerForm.courseName" placeholder="请输入名称" maxlength="20" style="width: 140px;"
                  clearable></el-input>
      </el-form-item>
      <el-form-item label="年级">
        <el-select v-model="bannerForm.gradeName" placeholder="请选择年级" style="width: 150px;" clearable>
          <el-option v-for="item in gradeList" :key="item.gradeName" :label="item.gradeName"
                     :value="item.gradeName"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="科目">
        <el-select v-model="bannerForm.subjectName" placeholder="请选择科目" clearable style="width: 150px;">
          <el-option v-for="item in subjectList" :key="item.subjectName" :label="item.subjectName"
                     :value="item.subjectName"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="难度">
        <!--<div style="margin-top:6px;display: flex;align-items: center">
          <el-rate v-model="bannerForm.hardLevel" allow-half></el-rate>
          <i class="el-icon-circle-close" @click="bannerForm.hardLevel = 0" style="cursor: pointer"></i>
        </div>-->
        <el-select popper-class="hard-level" class="hard-level" v-model="bannerForm.hardLevel"
                   style="width: 150px;" placeholder="请选择难度" clearable>
          <el-option v-for="item in hardLevelList" :label="item.label" :value="item.value"
                     :key="item.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="学习管理师">
        <el-select v-model="bannerForm.managerTeacherName" filterable placeholder="请选择" style="width: 150px;"
                   :filter-method="searchManageTeacher" clearable>
          <el-option v-for="item in managerTeacherNameList" :key="item.teacherId"
                     :label="item.realName" :value="item.teacherId"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="任课老师">
        <el-select v-model="bannerForm.lecturerName" filterable placeholder="请选择" style="width: 150px;"
                   :filter-method="searchLectureTeacher" clearable>
          <el-option v-for="item in lecturerNameList" :key="item.teacherId"
                     :label="item.realName" :value="item.teacherId"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" :loading="status.getDataLoading" icon="el-icon-search"
                   @click="handleCurrentChange(1)">搜索
        </el-button>
      </el-form-item>
      <el-form-item>
        <el-button type="success" @click="addBanner">添加</el-button>
      </el-form-item>
    </el-form>

    <el-table :data="tableList" :loading="status.getDataLoading" style="border: 1px solid #EBEEF5; border-bottom: none">
      <el-table-column label="序号" type="index" min-width="50px" align="center"></el-table-column>
      <el-table-column label="课程名称" prop="courseName" min-width="200px" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column label="年级" prop="gradeName" min-width="100px" align="center"></el-table-column>
      <el-table-column label="科目" prop="subjectName" min-width="100px" align="center"></el-table-column>
      <el-table-column label="难度" prop="hardLevel" min-width="100px" align="center">
        <template slot-scope="scope">
          <el-rate prop="hardLevel" allow-half v-model="scope.row.hardLevel"
                   disabled score-template="{scope.row.hardLevel}"></el-rate>
        </template>
      </el-table-column>
      <el-table-column label="学习管理师" prop="managerTeacherName" min-width="100px" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column label="授课老师" prop="lecturerName" min-width="100px" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column label="课程价格" prop="coursePrice" min-width="120px" align="center"></el-table-column>
      <el-table-column label="操作" min-width="200px" align="center">
        <template slot-scope="scope">
          <el-button type="text" @click="bannerDetail(scope.row)">查看</el-button>
          <el-button type="text" @click="updateBanner(scope.row)">编辑</el-button>
          <el-button type="text" @click="upBanner(scope.row)" :loading="status.getDataLoading">上移</el-button>
          <el-button type="text" @click="downBanner(scope.row)" :loading="status.getDataLoading">下移
          </el-button>
          <el-button type="text" @click="delBanner(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :title="dialogTitle" :visible.sync="status.dialogOpen" @closed="dialogClosed" width="800px">
      <div>
        <el-form label-width="100px" :inline="true" style="margin-top: 10px" :model="dialogForm" ref="dialogForm">
          <el-form-item label="banner封面" prop="imageUrl" label-width="100px"
                        :rules="[{ required: true, message:'请上传封面'}]">
            <el-upload
                    ref="upload"
                    :disabled="isDetail"
                    class="avatar-uploader"
                    :action="$uploadFileUrl"
                    :show-file-list="false"
                    :on-success="handleAvatarSuccess"
                    :before-upload="beforeAvatarUpload">
              <el-image v-if="dialogForm.imageUrl" :src="$getFileUrl + dialogForm.imageUrl" fit="cover" class="avatar" placeholder="加载中"/>
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              <div slot="tip" class="el-upload__tip" v-show="!isDetail">只能上传jpg/png文件，且不超过2M，建议图片长宽比为19:6</div>
            </el-upload>
          </el-form-item>
          <el-form-item style="width: 150px"></el-form-item>
          <el-form-item label="课程名称" prop="courseName" label-width="100px"
                        :rules="[{ required: true, message:'请选择课程名称', trigger: 'blur'}]">

            <el-select v-model="dialogForm.courseName" placeholder="请选择课程名称" @change="getCourseItem"
                       :disabled="isDetail" style="width: 240px;" popper-class="course-name" class="course-name">
              <el-option v-for="(item,index) in courseNameList" :key="item.courseId" :label="item.courseName"
                         :value="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="名称" prop="adName" label-width="100px"
                        :rules="[{ required: true,message:'请输入banner名称',trigger: 'blur'}]">
            <el-input v-model="dialogForm.adName" placeholder="请输入名称" style="width: 240px" :disabled="isDetail" maxlength="20"/>
          </el-form-item>
          <el-form-item label="上课时间">
            <el-input v-model="dialogForm.courseStart" style="width: 240px" disabled></el-input>
          </el-form-item>
          <el-form-item label="科目">
            <el-input v-model="dialogForm.subjectName" style="width: 240px" disabled></el-input>
          </el-form-item>
          <el-form-item label="课时">
            <el-input v-model="dialogForm.allCourseHour" style="width: 240px" disabled></el-input>
          </el-form-item>
          <el-form-item label="学习管理师">
            <el-input v-model="dialogForm.managerTeacherName" style="width: 240px" disabled></el-input>
          </el-form-item>

          <el-form-item label="课程日期">
            <el-date-picker v-model="dialogForm.courseDate"
                            disabled
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            value-format="yyyy-MM-dd"
                            style="width: 240px"></el-date-picker>
          </el-form-item>
          <el-form-item label="所属年级">
            <el-input v-model="dialogForm.gradeName"  style="width: 240px" disabled></el-input>
          </el-form-item>
          <el-form-item label="难度">
            <el-rate style="height: 32px;line-height: 32px;margin-top: 6px;width: 240px"
                     allow-half
                     disabled v-model="dialogForm.hardLevel"></el-rate>
          </el-form-item>
          <el-form-item label="价格">
            <el-input v-model="dialogForm.coursePrice"  style="width: 240px" disabled></el-input>
          </el-form-item>
          <el-form-item label="任课老师">
            <el-input v-model="dialogForm.lecturerName"  style="width: 240px" disabled></el-input>
          </el-form-item>
        </el-form>
      </div>

      <span slot="footer" class="dialog-footer">
                    <el-button plain @click="status.dialogOpen = false">取消</el-button>
                    <el-button type="primary" @click="submitBanner" v-if="!isDetail"
                               :loading="status.saving">保存</el-button>
            </span>
    </el-dialog>
    <el-pagination
            layout="total, sizes, prev, pager, next, jumper"
            background
            :current-page="bannerForm.currentPage"
            :page-sizes="[5, 10, 20, 50]"
            :page-size="bannerForm.pageSize"
            :total="listTotal"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
    </el-pagination>

  </div>
</template>

<script>
  import {requestData} from "../../assets/javascript/request";

  export default {
    name: "banner-manage",
    data() {
      return {
        manageTeacher: '',
        lectureTeacher: '',
        hardLevelList: [
          {
            label: "★",
            value: 2
          },
          {
            label: "★ ★",
            value: 4
          },
          {
            label: "★ ★ ★",
            value: 6
          },
          {
            label: "★ ★ ★ ★",
            value: 8
          },
          {
            label: "★ ★ ★ ★ ★",
            value: 10
          },
        ],
        lecturerNameList: [],
        managerTeacherNameList: [],
        gradeList: [],
        subjectList: [],
        fileList: [],
        adCover: "",
        isDetail: false,
        courseNameList: [],
        dialogTitle: "添加专题",
        status: {
          dialogOpen: false,
          getDataLoading: false,
          saving: false
        },
        dialogForm: {
          courseDate: [],
          imageUrl: "",
        },
        tableList: [],
        listTotal: 0,
        bannerForm: {
          courseName: "",
          gradeName: "",
          subjectName: "",
          hardLevel: "",
          adName: "",
          managerTeacherName: "",
          lecturerName: "",
          currentPage: 1,
          pageSize: 10
        },
      }
    },
    created() {
      this.getTableList();
      this.getSelectListData();
      this.queryLecturer();
      this.queryManageTeacher();
    },
    methods: {
      getTableList() {
        this.status.getDataLoading = true;
        let params = {...this.bannerForm};
        params.method = "POST";
        requestData(params, "/masters/banner/selectBanner",
            res => {
              let list = res.list;
              list.forEach(course=>course.coursePrice = this.$util.pennyToYuan(course.coursePrice));
              this.tableList = list;
              this.listTotal = res.total;
              this.status.getDataLoading = false;
            }, () => {
              this.status.getDataLoading = false;
            });

      },
      getSelectListData() {
        this.status.getDataLoading = true;
        let params = {};
        params.method = "POST";
        params.manageTeacher = this.manageTeacher;
        params.lectureTeacher = this.lectureTeacher;
        requestData(params, "/masters/banner/selectList",
            res => {
              this.courseNameList = res.list[0].courseNameList;
              this.subjectList = res.list[0].subjectList;
              this.gradeList = res.list[0].gradeList;
              // this.managerLecturerNameList = res.list[0].lecturerNameList;
              // this.managerTeacherNameList = res.list[0].teacherList;
            }, () => {
              this.status.getDataLoading = false;
            })
      },
      //查询授课老师
      queryLecturer(teacherName) {
        let param = {
          teacherName: teacherName,
          post: 1
        }
        this.$request(param, "/masters/mapper/select/banner.queryBannerLecturerNameList", (data) => {
          if (data.flag === 200) {
            this.lecturerNameList = data.list
          }
        }, () => {
        });
      },
      //查询班主任
      queryManageTeacher(teacherName) {
        let param = {
          teacherName: teacherName,
          post: 2
        }
        this.$request(param, "/masters/mapper/select/banner.queryBannerLecturerNameList", (data) => {
          if (data.flag === 200) {
            this.managerTeacherNameList = data.list
          }
        }, () => {
        });
      },
      // eslint-disable-next-line no-unused-vars
      handleSizeChange(pageSize) {
        this.bannerForm.pageSize = pageSize;

        this.getTableList();
      },
      // eslint-disable-next-line no-unused-vars
      handleCurrentChange(currentPage) {
        this.bannerForm.currentPage = currentPage;

        this.getTableList();

      },
      bannerDetail(item) {
        this.isDetail = true;
        this.dialogTitle = "查看详情";
        this.dialogForm = {...item};
        this.dialogForm.courseDate = [];
        this.dialogForm.courseDate.push(item.courseStart);
        this.dialogForm.courseDate.push(item.courseEnd);
        this.$set(this.dialogForm,"imageUrl",item.adCover);
        this.status.dialogOpen = true
      },
      updateBanner(item) {
        this.isDetail = false;
        this.dialogTitle = "修改banner";
        this.dialogForm = {...item};
        this.dialogForm.courseDate = [];
        this.dialogForm.courseDate.push(item.courseStart);
        this.dialogForm.courseDate.push(item.courseEnd);
        this.$set(this.dialogForm,"imageUrl",item.adCover);
        this.status.dialogOpen = true;
      },
      addBanner() {
        this.isDetail = false;
        this.dialogTitle = "添加banner";
        this.dialogForm = this.$options.data().dialogForm;
        this.status.dialogOpen = true;

      },
      //上移
      upBanner(item) {
        this.$confirm('确定要上移吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(() => {
          // ... (这里进行接口请求)
          let params = {};
          params.method = "POST";
          params.adSort = item.adSort;
          params.currentAdId = item.adId;
          params.isUp = "up";
          this.status.getDataLoading = true;
          requestData(params, "/masters/banner/moveHomeAd",
              () => {
                this.status.getDataLoading = false;
                this.handleCurrentChange(1);
              },
              () => {
                this.status.getDataLoading = false;
              });
        }).catch(() => {
        });


      },
      //下移
      downBanner(item) {
        this.$confirm('确定要下移吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(() => {
          this.status.getDataLoading = true;
          let params = {};
          params.method = "POST";
          params.adSort = item.adSort;
          params.currentAdId = item.adId;
          params.isUp = "down";
          requestData(params, "/masters/banner/moveHomeAd",
              () => {
                this.status.getDataLoading = false;
                this.handleCurrentChange(1);
              },
              () => {
                this.status.getDataLoading = false;
              })
        }).catch(() => {
        });

      },
      dialogClosed() {
        this.status.dialogOpen = false;
        this.$nextTick(()=>{
          this.$refs['dialogForm'].resetFields();
          this.dialogForm = this.$options.data().dialogForm;
        });
      },
      //删除一个banner
      delBanner(item) {
        this.$confirm('确定要删除吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(() => {
          // ... (这里进行接口请求)
          let params = {...item};
          params.method = "POST";
          this.status.getDataLoading = true;
          requestData(params, '/masters/banner/deleteHomeAd',
              () => {
                this.status.getDataLoading = false;
                this.$message.success(`删除成功`);
                this.handleCurrentChange(1);
              },
              () => {
                this.status.getDataLoading = false;
              })
        }).catch(() => {
        });
      },
      submitBanner() {
        this.status.saving = true;
        let adId = this.dialogForm.adId;
        let params = {...this.dialogForm};
        params.adCover = this.dialogForm.imageUrl;

        params.method = "POST";

        this.$refs.dialogForm.validate((valid) => {
          if (valid) {
            //修改
            if (!this.$util.isEmpty(adId)) {
              requestData(params, "/masters/banner/updateHomeAd",
                      () => {
                        this.status.saving = false;
                        this.$message.success(`修改成功`);
                        this.dialogClosed();
                        this.handleCurrentChange(1);
                      },
                      () => {
                        this.status.saving = false;
                      }
              )
            } else {
              // 添加
              requestData(params, "/masters/banner/insertHomeAd",
                      () => {
                        this.status.saving = false;
                        this.$message.success(`添加成功`);
                        this.dialogClosed();
                        this.handleCurrentChange(1);
                      },
                      () => {
                        this.status.saving = false;
                      }
              )
            }
          }else {
            this.status.saving = false;
          }
        });
      },
      getCourseItem(index) {

        this.dialogForm.hardLevel = this.courseNameList[index].hardLevel/2;
        this.dialogForm.gradeName = this.courseNameList[index].gradeName;
        // this.dialogForm.courseName = item.courseName;
        this.$set(this.dialogForm, "courseName", this.courseNameList[index].courseName);
        this.dialogForm.courseStart = this.courseNameList[index].courseStart;
        this.dialogForm.lecturerName = this.courseNameList[index].lecturerName;
        this.dialogForm.allCourseHour = this.courseNameList[index].allCourseHour;
        this.dialogForm.coursePrice = this.$util.pennyToYuan(this.courseNameList[index].coursePrice);
        this.dialogForm.managerTeacherName = this.courseNameList[index].managerTeacherName;
        this.dialogForm.courseId = this.courseNameList[index].courseId;
        this.dialogForm.courseEnd = this.courseNameList[index].courseEnd;
        this.dialogForm.subjectName = this.courseNameList[index].subjectName;
        this.dialogForm.courseDate = [];
        this.dialogForm.courseDate.push(this.courseNameList[index].courseStart);
        this.dialogForm.courseDate.push(this.courseNameList[index].courseEnd);
      },

      //图片上传成功后回调的函数
      handleAvatarSuccess(res) {
        this.$set(this.dialogForm,"imageUrl",res.message);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';
        const isLt2M = file.size / 1024 / 1024 < 2;
        const isTooLong = file.name.length > 30;

        if (!isJPG && !isPNG) {
          this.$message.error('上传banner图片只能是 jpg/png 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传banner图片大小不能超过 2MB!');
        }
        if(isTooLong){
          this.$message.error('上传banner图片名不能超过 30个字符');
        }
        return (isJPG || isPNG) && isLt2M && !isTooLong;
      },
      searchManageTeacher(value) {
        // this.manageTeacher = value;
        this.queryManageTeacher(value);
      },
      searchLectureTeacher(value) {
        // this.lectureTeacher = value;
        this.queryLecturer(value);
      }
    }
  }
</script>

<style lang="less">
  .hard-level {
    .el-select-dropdown__item {
      color: #f7ba2a;
    }

    .el-input__inner {
      color: #f7ba2a;
    }

    .el-select-dropdown__item.selected {
      color: #5D2385;
    }
  }

</style>

<style scoped>
  .banner-manage {

  }

  .el-tooltip__popper {
    max-width: 80%
  }

  .el-pagination {
    display: flex;
    justify-content: flex-end;
  }

  .imgHead {
    border: black 5px solid;
  }

  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 300px;
    height: 100px;
    line-height: 100px;
    text-align: center;
  }

  .avatar {
    width: 300px;
    height: 100px;
    display: block;
  }

</style>
