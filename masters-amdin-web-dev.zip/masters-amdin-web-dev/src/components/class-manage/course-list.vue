<template>
    <div class="course-list">
        <div class="queryColumn">
            <el-form inline class="demo-form-inline">
                <el-form-item label="日期">
                    <el-date-picker v-model="courseDate" type="daterange" range-separator="至" start-placeholder="开始日期"
                                    end-placeholder="结束日期" style="width: 300px"
                                    value-format="yyyy-MM-dd"></el-date-picker>
                </el-form-item>
                <el-form-item label="名称">
                    <el-input v-model="courseName" placeholder="请输入名称" maxlength="20" style="width: 150px"
                              clearable></el-input>
                </el-form-item>
                <el-form-item label="年级">
                    <el-select v-model="gradeId" filterable placeholder="全部" style="width: 150px"
                               v-loading="status.gradeLoading" clearable>
                        <el-option label="全部" value=""></el-option>
                        <el-option v-for="item in gradeOptions" :key="item.gradeId" :label="item.gradeName"
                                   :value="item.gradeId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="科目">
                    <el-select v-model="subjectId" filterable placeholder="全部" style="width: 150px"
                               v-loading="status.subjectLoading" clearable>
                        <el-option label="全部" value=""></el-option>
                        <el-option v-for="item in subjectOptions" :key="item.subjectId" :label="item.subjectName"
                                   :value="item.subjectId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="难度">
                    <el-select v-model="hardLevel" placeholder="全部" style="width: 150px" clearable>
                        <el-option label="全部" value=""></el-option>
                        <el-option v-for="item in hardLevelList" :key="item.value" :label="item.label"
                                   :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="学习管理师">
                    <el-select v-model="managerTeacherId" filterable placeholder="全部" style="width: 150px"
                               v-loading="status.managerTeacherLoading" clearable>
                        <el-option label="全部" value=""></el-option>
                        <el-option v-for="item in managerTeacherOptions" :key="item.teacherId" :label="item.realName"
                                   :value="item.teacherId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="老师">
                    <el-select v-model="lecturerId" filterable placeholder="全部" style="width: 150px"
                               v-loading="status.lecturerLoading" clearable>
                        <el-option label="全部" value=""></el-option>
                        <el-option v-for="item in lecturerOptions" :key="item.teacherId" :label="item.realName"
                                   :value="item.teacherId"></el-option>
                    </el-select>
                </el-form-item>
                <el-button type="primary" :loading="status.dataLoading" @click="handleCurrentChange(1)">查询</el-button>
                <el-button type="success" @click="addCourse()">添加</el-button>
            </el-form>
        </div>

        <div class="courseTable">
            <el-table ref="singleTable" :data="tableData" @current-change="handleCurrent"
                      style="border: 1px solid #EBEEF5; border-bottom: none">
                <el-table-column type="index" label="序号" min-width="50px" style="background-color: #8c939d;"
                                 align="center"></el-table-column>
                <el-table-column label="课程日期" min-width="200px" align="center">
                    <template slot-scope="scope">
                        <span>{{scope.row.courseStart}}~</span><span>{{scope.row.courseEnd}}</span>
                    </template>
                </el-table-column>
                <el-table-column property="courseName" label="课程名称" min-width="200px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column property="gradeName" label="年级" min-width="80px" align="center"></el-table-column>
                <el-table-column property="subjectName" label="科目" min-width="100px" align="center"></el-table-column>
                <el-table-column property="hardLevel" label="难度" min-width="150px" align="center">
                    <template slot-scope="scope">
                        <el-rate prop="hardLevel" v-model="scope.row.hardLevel" disabled
                                 score-template="{scope.row.hardLevel}"></el-rate>
                    </template>
                </el-table-column>
                <el-table-column label="课程进度" min-width="80px" align="center">
                    <template slot-scope="scope">
                        <span v-if="$util.isEmpty(scope.row.finishedCourseHour)">{{'0/'+scope.row.allCourseHour}}</span>
                        <span v-else>{{scope.row.finishedCourseHour+'/'+scope.row.allCourseHour}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="学生数量" min-width="80px" align="center">
                    <template slot-scope="scope">
                        <span v-if="$util.isEmpty(scope.row.studentCount)">{{'0/'+scope.row.maxAmount}}</span>
                        <span v-else>{{scope.row.studentCount+'/'+scope.row.maxAmount}}</span>
                    </template>
                </el-table-column>
                <el-table-column property="managerTeacherName" label="学习管理师" min-width="100px"
                                 align="center"></el-table-column>
                <el-table-column property="lecturerName" label="授课老师" width="100px" align="center"></el-table-column>
                <el-table-column property="nextCourseTime" label="下次上课时间" width="180px"
                                 align="center"></el-table-column>
                <el-table-column property="coursePrice" label="课程价格(元)" width="100px" align="center"
                                 :formatter="formatMoney"></el-table-column>
                <el-table-column label="操作" align="center" width="150px">
                    <template slot-scope="scope">
                        <el-button type="text" @click="lookCourse(scope.row)">查看</el-button>
                        <el-button type="text" @click="updateCourse(scope.row)">编辑</el-button>
                        <el-button type="text" @click="lookCourseStudent(scope.row)">学生列表</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <el-pagination align="right"
                           background
                           layout="total, sizes, prev, pager, next, jumper"
                           :current-page="searchParams.page"
                           :page-sizes="[5, 10, 20, 50]"
                           :page-size="searchParams.limit"
                           :total="classListTotal"
                           @size-change="handleSizeChange"
                           @current-change="handleCurrentChange">
            </el-pagination>
        </div>

        <div class="dialog">
            <el-dialog :title="dialogTitle" :visible.sync="status.dialogFormVisible" width="900px"
                       @closed="dialogClosed" :close-on-click-modal="false">
                <el-tabs v-model="activeName" @tab-click="handleTabClick">
                    <el-tab-pane label="基础信息" name="base">
                        <el-form :model="formData" inline :disabled="isAdd" ref="classForm" :rules="rules">
                            <el-form-item label="班级封面" label-width="80px" prop="courseCover"
                                          :rules="[{ required: true, message:'请上传封面'}]">
                                <el-upload
                                        class="avatar-uploader"
                                        :action="$uploadFileUrl"
                                        :show-file-list="false"
                                        :on-success="handleAvatarSuccess"
                                        :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                        :before-upload="beforeAvatarUpload">
                                    <img v-if="imageUrl" :src="$getFileUrl + imageUrl" class="avatar">
                                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                    <div slot="tip" class="el-upload__tip" v-show="!isAdd">
                                        只能上传jpg/png文件，且不超过2M，建议图片长宽比为16:9
                                    </div>
                                </el-upload>
                            </el-form-item>
                            <br>
                            <el-form-item label="课程名称" label-width="80px" prop="courseName">
                                <el-input placeholder="请输入" v-model="formData.courseName" maxlength="20"
                                          style="width: 300px"
                                          :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                          @input="value=>{this.formData.courseName=this.$util.checkCnEnNu(value)}"></el-input>
                            </el-form-item>

                            <el-form-item label="课程日期" label-width="80px" prop="courseDate">
                                <el-date-picker v-model="formData.courseDate"
                                                type="daterange"
                                                range-separator="至"
                                                start-placeholder="开始日期"
                                                end-placeholder="结束日期"
                                                value-format="yyyy-MM-dd"
                                                :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                                style="width: 300px"></el-date-picker>
                            </el-form-item>

                            <el-form-item label="所属年级" label-width="80px" prop="gradeId">
                                <el-select v-model="formData.gradeId" filterable placeholder="请选择"
                                           v-loading="status.gradeLoading" style="width: 300px" @change="gradeChange"
                                           :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                           clearable><!--value-key="gradeId"-->
                                    <el-option v-for="item in gradeOptions" :key="item.gradeId" :label="item.gradeName"
                                               :value="item.gradeId"></el-option>
                                </el-select>
                            </el-form-item>

                            <el-form-item label="科目" label-width="80px" prop="subjectId">
                                <el-select v-model="formData.subjectId" filterable placeholder="请选择"
                                           v-loading="status.subjectLoading" style="width: 300px"
                                           :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                           @change="subjectChange" clearable><!--value-key="subjectId"-->
                                    <el-option v-for="item in subjectOptions" :key="item.subjectId"
                                               :label="item.subjectName" :value="item.subjectId"></el-option>
                                </el-select>
                            </el-form-item>

                            <el-form-item label="总课时" label-width="80px" prop="allCourseHour">
                                <el-input v-model="formData.allCourseHour" placeholder="请输入" style="width: 300px"
                                          :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                          @input="value=>{this.formData.allCourseHour = this.$util.checkNumber(value)}"></el-input>
                            </el-form-item>

                            <el-form-item label="难度" label-width="80px" prop="hardLevel">
                                <div style="margin-top: 6px;width: 300px">
                                    <el-rate v-model="formData.hardLevel" :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"></el-rate>
                                </div>
                            </el-form-item>

                            <el-form-item label="价格(元)" label-width="80px" prop="coursePrice">
                                <el-input v-model.number="formData.coursePrice" placeholder="请输入" maxlength="6"
                                          style="width: 300px"
                                          :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                          @input="value=>{this.formData.coursePrice = this.$util.checkMoney(value)}"></el-input>
                            </el-form-item>

                            <el-form-item label="学习管理师" label-width="80px" prop="managerTeacherId">
                                <el-select v-model="formData.managerTeacherId" filterable placeholder="请选择"
                                           v-loading="status.managerTeacherLoading" style="width: 300px"
                                           :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                           @change="managerTeacherChange" clearable><!-- value-key="teacherId"-->
                                    <el-option v-for="item in managerTeacherOptions" :key="item.teacherId"
                                               :label="item.realName" :value="item.teacherId"></el-option>
                                </el-select>
                            </el-form-item>

                            <el-form-item label="授课老师" label-width="80px" prop="lecturerId">
                                <el-select v-model="formData.lecturerId" filterable placeholder="请选择"
                                           :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                           v-loading="status.lecturerLoading" style="width: 300px"
                                           @change="lecturerChange" clearable><!--value-key="teacherId"-->
                                    <el-option v-for="item in lecturerOptions" :key="item.teacherId"
                                               :label="item.realName" :value="item.teacherId"></el-option>
                                </el-select>
                            </el-form-item>

                            <el-form-item label="专题名称" label-width="80px" prop="specialId">
                                <el-select v-model="formData.specialId" filterable placeholder="请选择"
                                           :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                           v-loading="status.lecturerLoading" style="width: 300px"
                                           @change="specialChange" clearable><!-- value-key="specialId"-->
                                    <el-option v-for="item in specialOptions" :key="item.specialId"
                                               :label="item.specialName" :value="item.specialId"></el-option>
                                </el-select>&nbsp;
                            </el-form-item>

                            <el-form-item label="最大人数" label-width="80px" prop="maxAmount">
                                <el-input v-model.number="formData.maxAmount" placeholder="请输入" maxlength="20"
                                          style="width: 300px"
                                          :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                          @input="value=>{this.formData.maxAmount = this.$util.checkNumber(value)}"></el-input>
                            </el-form-item>

                            <!--<el-form-item label="房间号" label-width="120px" prop="roomNumber">
                                <el-input v-model="formData.roomNumber" placeholder="请输入" maxlength="20" style="width: 300px"
                                          @input="value=>{this.formData.roomNumber = this.$util.checkNumber(value)}"></el-input>
                            </el-form-item>-->

                            <el-form-item label="能力测验" label-width="80px" prop="testPaperId">
                                <el-select v-model="formData.testPaperId" filterable placeholder="请选择"
                                           v-loading="status.testPaperLoading" style="width: 300px"
                                           :disabled="!$util.isEmpty(formData.courseState) && formData.courseState !== 1"
                                           @change="testPaperChange" clearable>
                                    <el-option v-for="item in testPaperOptions" :key="item.testPaperId"
                                               :label="item.testPaperName" :value="item.testPaperId"></el-option>
                                </el-select>
                            </el-form-item>

                        </el-form>
                    </el-tab-pane>
                    <el-tab-pane label="课程介绍" name="courseIntroduce"></el-tab-pane>
                    <el-tab-pane label="课程大纲" name="courseOutline"></el-tab-pane>
                    <el-tab-pane label="常见问题" name="commonProblem"></el-tab-pane>
                </el-tabs>
                <editor style="width: 100%;overflow: auto;" ref="editor"
                        class="ql-editor"
                        v-show="!status.isShowBase && !status.isLook"
                        @editor-change="editorChange"
                        :content="content"></editor>
                <div v-show="!status.isShowBase && status.isLook" v-html="content"
                     style="width: 100%;overflow: auto;height:470px;"
                     class="ql-editor"></div>
                <span class="dialog-footer" slot="footer" v-show="!status.isLook">
                    <el-button @click="status.dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="insertCourse('classForm')"
                               :disabled="isSave || (!$util.isEmpty(formData.courseState) && formData.courseState !== 1)">
                        保存
                    </el-button>
                </span>
            </el-dialog>
        </div>
        <div class="studentListDialog">
            <el-dialog title="学生列表" :visible.sync="status.studentListDialogVisible" width="1000px"
                       :close-on-click-modal="false">
                <el-table ref="studentListTable" :data="studentListData" highlight-current-row
                          style="border: 1px solid #EBEEF5; border-bottom: none">
                    <el-table-column type="index" label="序号" min-width="50"></el-table-column>
                    <el-table-column property="nickName" label="学生昵称" min-width="100"
                                     show-overflow-tooltip></el-table-column>
                    <el-table-column property="realName" label="学生姓名" min-width="120"
                                     show-overflow-tooltip></el-table-column>
                    <el-table-column property="gender" label="性别" min-width="50"
                                     :formatter="formatGender"></el-table-column>
                    <el-table-column property="birthday" label="年龄" min-width="50"></el-table-column>
                    <el-table-column property="parentName" label="家长姓名" min-width="100"
                                     show-overflow-tooltip></el-table-column>
                    <el-table-column property="parentContact" label="联系方式" min-width="100"></el-table-column>
                    <el-table-column property="entryDate" label="入学日期" min-width="100"></el-table-column>
                    <el-table-column property="remark" label="备注" min-width="100"
                                     show-overflow-tooltip></el-table-column>
                    <!--避免删除学生后，学生不能再次购买该课程bug-->
                    <!--<el-table-column label="操作" min-width="50">
                        <template slot-scope="scope">
                            <el-button type="text" @click="deleteStudent(scope.row)">删除</el-button>
                        </template>
                    </el-table-column>-->
                </el-table>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import 'quill/dist/quill.core.css';
    import 'quill/dist/quill.snow.css';
    import 'quill/dist/quill.bubble.css';
    import editor from "../common/editor";

    export default {
        name: "course-list",
        data() {
            let validateCoursePrice = (rule, value, callback) => {
                if (value <= 0) {
                    return callback(new Error('课程价格必须大于0元!'));
                }
                return callback();
            };
            return {
                isSave: false, //保存按钮状态
                isAdd: true,//表单状态
                courseId: "", //弹出学生列表的班级编号
                //分页数据
                searchParams: {
                    page: 1, //第几页
                    limit: 10 //每页条数
                },
                classListTotal: 0,

                imageUrl: '', //对话框图片地址

                //对话框数据
                formData: {
                    maxAmount: '',
                    courseCover: '',
                    courseId: '',
                    courseName: '',
                    courseDate: [],
                    gradeId: '',
                    gradeName: '',
                    subjectId: '',
                    subjectName: '',
                    allCourseHour: '',
                    hardLevel: 0,
                    coursePrice: '',
                    managerTeacherId: '',
                    managerTeacherName: '',
                    lecturerId: '',
                    lecturerName: '',
                    specialId: '',
                    specialName: '',
                    /*roomNumber: '',*/
                    testPaperId: '',
                    testPaperName: '',
                    courseIntroduce: '',
                    courseOutline: '',
                    commonProblem: '',
                },
                formDataLecturer: '',

                //状态(下拉框，弹窗)
                status: {
                    dataLoading: false,
                    studentListDialogVisible: false,
                    dialogFormVisible: false,
                    gradeLoading: true,
                    subjectLoading: true,
                    managerTeacherLoading: true,
                    lecturerLoading: true,
                    specialLoading: true,
                    testPaperLoading: true,
                    addOrUpdateFlag: false,
                    isShowBase: true,
                },
                courseDate: [],//日期选择框
                courseName: '',//课程名（班级名）
                gradeId: '',//年级下拉框value
                gradeOptions: [],//年级下拉框选项
                subjectId: '',//科目下拉框value
                subjectOptions: [],//科目下拉框选项
                managerTeacherId: '',//班主任下拉框value
                managerTeacherOptions: [],//班主任下拉框选项
                lecturerId: '',//授课老师下拉框value
                lecturerOptions: [],//授课老师下拉框选项
                specialOptions: [],//专题下拉列表
                testPaperOptions: [],//能力试卷
                tableData: [],//课程列表表格
                studentListData: [],//学生列表表格
                hardLevel: '', //搜索栏难度
                dialogTitle: '添加班级',
                hardLevelList: [
                    {
                        label: "★",
                        value: 2
                    },
                    {
                        label: "★ ★",
                        value: 4
                    },
                    {
                        label: "★ ★ ★",
                        value: 6
                    },
                    {
                        label: "★ ★ ★ ★",
                        value: 8
                    },
                    {
                        label: "★ ★ ★ ★ ★",
                        value: 10
                    },
                ], //搜索栏难度下拉选项

                /*
                * 表单验证规则
                * */
                rules: {
                    courseName: [
                        {required: true, message: '请输入班级名称', trigger: 'blur'},
                        {min: 1, max: 20, message: '长度在 1 到 20 个字符', trigger: 'blur'}
                    ],
                    courseDate: [
                        {required: true, message: '请选择课程的开始日期和结束日期', trigger: 'blur'},
                    ],
                    gradeId: [
                        {required: true, message: '请选择年级', trigger: 'blur'},
                    ],
                    subjectId: [
                        {required: true, message: '请选择科目', trigger: 'blur'},
                    ],
                    allCourseHour: [
                        {required: true, message: '请输入课时数', trigger: 'blur'},
                        {type: 'number', max: 9999, message: '不得超过9999课时', trigger: 'blur'},
                    ],
                    coursePrice: [
                        {required: true, message: '请输入价格', trigger: 'blur'},
                        {validator: validateCoursePrice, trigger: 'blur'}
                    ],
                    managerTeacherId: [
                        {required: true, message: '请选择班主任', trigger: 'blur'},
                    ],
                    lecturerId: [
                        {required: true, message: '请选择授课老师', trigger: 'blur'},
                    ],
                    specialId: [
                        {required: true, message: '请选择班级', trigger: 'blur'},
                    ],
                    maxAmount: [
                        {required: true, message: '请输入班级可容纳最大人数', trigger: 'blur'},
                        {type: 'number', min: 1, max: 100000, message: '人数应在1~100000人之间', trigger: 'blur'},
                    ],
                    /*roomNumber:[
                        {required: true, message: '请输入房间号', trigger: 'blur'},
                    ],*/
                    hardLevel: [
                        {type: 'number', min: 1, max: 5, message: "请选择难度", trigger: 'blur'}
                    ]
                },
                content: "",
                str: '',
                editorOption: {},
                uploadURL: this.$uploadFileUrl,
                activeName: 'base',
                // 性别列表
                genderList: [],
            }
        },
        mounted() {

            // 性别字典
            this.genderList = this.$dict.getDictByCode('GENDER') || [];

            let params = {};
            this.$request(params, "/masters/course/selectOptions", res => {
                this.gradeOptions = res.list[0].gradeList;
                this.status.gradeLoading = false;
                this.subjectOptions = res.list[0].subjectList;
                this.status.subjectLoading = false;
                this.managerTeacherOptions = res.list[0].manageTeacherList;
                this.status.managerTeacherLoading = false;
                this.lecturerOptions = res.list[0].lecturerList;
                this.status.lecturerLoading = false;
                this.specialOptions = res.list[0].specialList;
                this.status.specialLoading = false;
                this.testPaperOptions = res.list[0].testPaperList;
                this.status.testPaperLoading = false;
            }, () => {
            });
            this.queryCourse();
        },
        components: {
            editor
        },
        methods: {

            /**
             * 课程（班级）列表初始化及查询课程
             */
            queryCourse() {
                this.status.dataLoading = true;
                let params = {};
                if (this.courseDate != null) {
                    params.courseStart = this.courseDate[0];
                    params.courseEnd = this.courseDate[1];
                }
                params.courseName = this.courseName;
                params.gradeId = this.gradeId;
                params.subjectId = this.subjectId;
                params.hardLevel = this.hardLevel;
                params.managerTeacherId = this.managerTeacherId;
                params.lecturerId = this.lecturerId;
                params.page = this.searchParams.page;
                params.limit = this.searchParams.limit;
                this.$request(params, "/masters/course/courseList", res => {
                    res.list.forEach(function (cur, index, arr) {
                        arr[index].hardLevel = (cur.hardLevel || 0) / 2;
                    });
                    this.classListTotal = res.total;
                    this.tableData = res.list;
                    this.status.dataLoading = false;
                }, () => {
                    this.tableData = [];
                    this.classListTotal = 0;
                    this.status.dataLoading = false;
                });
            },

            /**
             * 打开添加对话框，添加课程（班级）
             */
            addCourse() {
                this.dialogTitle = '添加班级';
                this.formData = this.$options.data().formData;
                this.content = "";
                this.status.isLook = false;
                this.status.addOrUpdateFlag = true;
                this.isSave = false;
                this.isAdd = false;
                this.status.dialogFormVisible = true;
                // 刷新选择数据
                let params = {};
                this.$request(params, "/masters/course/selectOptions", res => {
                    this.managerTeacherOptions = res.list[0].manageTeacherList;
                    this.lecturerOptions = res.list[0].lecturerList;
                    this.specialOptions = res.list[0].specialList;
                    this.testPaperOptions = res.list[0].testPaperList;
                }, () => {
                });
            },

            /**
             *保存按钮
             */
            insertCourse(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        if (!this.$util.isEmpty(this.formData.courseName) && this.formData.courseDate != null) {
                            this.isSave = true;
                            let params = {};
                            let path = "";
                            if (this.status.addOrUpdateFlag === true) {
                                //添加
                                params = {...this.formData}
                                params.courseCover = this.imageUrl;
                                params.courseStart = this.formData.courseDate[0];
                                params.courseEnd = this.formData.courseDate[1];
                                if (this.$util.isEmpty(this.formData.hardLevel)) {
                                    params.hardLevel = 0;
                                } else {
                                    params.hardLevel = this.formData.hardLevel * 2;
                                }
                                params.coursePrice = this.formData.coursePrice * 100;
                                params.courseState = 1;
                                path = "/masters/course/insertCourse";
                            } else if (this.status.addOrUpdateFlag === false) {
                                //修改
                                params = {...this.formData}
                                params.courseCover = this.imageUrl;
                                params.coursePrice = this.formData.coursePrice * 100;
                                params.courseStart = this.formData.courseDate[0];
                                params.courseEnd = this.formData.courseDate[1];
                                if (this.$util.isEmpty(this.formData.hardLevel)) {
                                    params.hardLevel = 0;
                                } else {
                                    params.hardLevel = this.formData.hardLevel * 2;
                                }
                                path = "/masters/course/updateCourseInf";
                            }
                            this.$request(params, path, res => {
                                this.isSave = false;
                                this.status.dialogFormVisible = false;
                                this.$message.success(res.message);
                                this.queryCourse();
                            }, () => {
                                this.isSave = false;
                            });
                        } else {
                            this.$message.warning("参数错误")
                        }
                    }else {
                        let tab= {
                            name: "base"
                        }
                        this.handleTabClick(tab);
                    }
                });


            },

            /**
             * 查看班级
             */
            lookCourse(item) {
                this.dialogTitle = '查看班级';
                this.status.isLook = true;
                this.status.dialogFormVisible = true;
                let params = {
                    courseId: item.courseId
                }
                this.$request(params, "/masters/mapper/select/course.queryCourseById", res => {
                    this.$nextTick(() => {
                        this.isSave = true;
                        this.isAdd = true;
                        this.imageUrl = res.list[0].courseCover;
                        this.formData = {...res.list[0]};
                        this.formData.coursePrice = this.$util.pennyToYuan(this.formData.coursePrice);
                        if (this.$util.isEmpty(this.formData.hardLevel)) {
                            this.formData.hardLevel = 0;
                        } else {
                            this.formData.hardLevel = res.list[0].hardLevel / 2;
                        }
                        this.imageUrl = this.formData.courseCover;
                        if (res.list[0].courseStart && res.list[0].courseEnd) {
                            this.$set(this.formData, "courseDate", [res.list[0].courseStart, res.list[0].courseEnd]);
                        }
                    });
                }, () => {

                })
            },

            /**
             * 编辑班级
             */
            updateCourse(item) {
                this.status.isLook = false;
                this.status.dialogFormVisible = true;
                // 刷新选择选项
                let params = {};
                this.$request(params, "/masters/course/selectOptions", res => {
                    this.managerTeacherOptions = res.list[0].manageTeacherList;
                    this.lecturerOptions = res.list[0].lecturerList;
                    this.specialOptions = res.list[0].specialList;
                    this.testPaperOptions = res.list[0].testPaperList;

                    let params = {
                        courseId: item.courseId
                    }
                    this.$request(params, "/masters/mapper/select/course.queryCourseById", res => {
                        this.$nextTick(() => {
                            this.dialogTitle = '编辑班级';
                            this.status.addOrUpdateFlag = false;
                            this.isSave = false;
                            this.isAdd = false;
                            this.imageUrl = res.list[0].courseCover;
                            this.formData = {...res.list[0]};
                            this.formData.coursePrice = this.$util.pennyToYuan(this.formData.coursePrice);
                            if (this.$util.isEmpty(this.formData.hardLevel)) {
                                this.formData.hardLevel = 0;
                            } else {
                                this.formData.hardLevel = res.list[0].hardLevel / 2;
                            }
                            this.imageUrl = this.formData.courseCover;
                            if (res.list[0].courseStart && res.list[0].courseEnd) {
                                this.$set(this.formData, "courseDate", [res.list[0].courseStart, res.list[0].courseEnd]);
                            }
                        });
                    }, () => {

                    })
                }, () => {
                    let params = {
                        courseId: item.courseId
                    }
                    this.$request(params, "/masters/mapper/select/course.queryCourseById", res => {
                        this.$nextTick(() => {
                            this.dialogTitle = '编辑班级';
                            this.status.addOrUpdateFlag = false;
                            this.isSave = false;
                            this.isAdd = false;
                            this.imageUrl = res.list[0].courseCover;
                            this.formData = {...res.list[0]};
                            this.formData.coursePrice = this.$util.pennyToYuan(this.formData.coursePrice);
                            if (this.$util.isEmpty(this.formData.hardLevel)) {
                                this.formData.hardLevel = 0;
                            } else {
                                this.formData.hardLevel = res.list[0].hardLevel / 2;
                            }
                            this.imageUrl = this.formData.courseCover;
                            if (res.list[0].courseStart && res.list[0].courseEnd) {
                                this.$set(this.formData, "courseDate", [res.list[0].courseStart, res.list[0].courseEnd]);
                            }
                        });
                    }, () => {

                    })
                });
            },

            /**
             * 查看班级学生列表
             */
            lookCourseStudent(item) {
                let params = {};
                this.courseId = item.courseId;
                params.courseId = item.courseId;
                this.$request(params, "/masters/course/courseStudentList", res => {
                    this.studentListData = res.list;
                }, () => {
                    this.studentListData = [];
                });
                this.status.studentListDialogVisible = true;
            },

            /**
             * 删除学生
             */
            deleteStudent(item) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                }).then(() => {
                    // 重置密码
                    let params = {
                        method: 'POST',
                        studentId: item.studentId,
                        courseId: this.courseId
                    };
                    this.$request(params, "/masters/mapper/delete/studentCourse.deleteStudentCourse", () => {
                        this.$message.success(`删除成功`);
                        this.lookCourseStudent(params);
                    });
                });
            },


            handleSizeChange(limit) {
                this.searchParams.limit = limit;
                this.queryCourse();
            },
            handleCurrentChange(page) {
                if (page) {
                    this.searchParams.page = page;
                }
                this.queryCourse();
            },

            handleCurrent() {
            },

            handleAvatarSuccess(res) {
                this.imageUrl = res.message;
                this.formData.courseCover = this.imageUrl;
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg';
                const isPNG = file.type === 'image/png';
                const isLt2M = file.size / 1024 / 1024 < 2;
                if (!isJPG && !isPNG) {
                    this.$message.error('上传头像图片只能是 JPG/PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return (isJPG || isPNG) && isLt2M;
            },

            /*
            * 对话框关闭时清除数据
            * */
            dialogClosed() {
                this.isSave = false;
                this.imageUrl = '';
                this.$nextTick(() => {
                    this.$refs['classForm'].resetFields();
                    this.activeName = 'base';
                    this.status.isShowBase = true;
                    this.formData = this.$options.data().formData;
                    this.content = "";
                })
            },

            gradeChange(gradeId) {
                let obj = this.gradeOptions.find(item => {
                    return item.gradeId === gradeId;
                });
                this.formData.gradeId = obj.gradeId;
                this.formData.gradeName = obj.gradeName;
            },
            subjectChange(subjectId) {
                let obj = this.subjectOptions.find(item => {
                    return item.subjectId === subjectId;
                });
                this.formData.subjectId = obj.subjectId;
                this.formData.subjectName = obj.subjectName;
            },
            managerTeacherChange(teacherId) {
                let obj = this.managerTeacherOptions.find(item => {
                    return item.teacherId === teacherId;
                });
                this.formData.managerTeacherId = obj.teacherId;
                this.formData.managerTeacherName = obj.realName;
            },
            lecturerChange(teacherId) {
                let obj = this.lecturerOptions.find(item => {
                    return item.teacherId === teacherId;
                });
                this.formData.lecturerId = obj.teacherId;
                this.formData.lecturerName = obj.realName;
            },
            specialChange(specialId) {
                let obj = this.specialOptions.find(item => {
                    return item.specialId === specialId;
                });
                this.formData.specialId = obj.specialId;
                this.formData.specialName = obj.specialName;
            },
            testPaperChange(testPaperId) {
                let obj = this.testPaperOptions.find(item => {
                    return item.testPaperId === testPaperId;
                });
                this.formData.testPaperId = obj.testPaperId;
                this.formData.testPaperName = obj.testPaperName;
            },
            // 分转元
            formatMoney(row) {
                return this.$util.pennyToYuan(row.coursePrice);
            },
            onEditorReady() { // 准备编辑器
            },
            // 获得焦点事件
            onEditorChange() {
            },
            // 内容改变事件
            editorChange(content) {
                this.$set(this.formData, this.activeName, content);
            },
            // 格式化性别
            formatGender(row) {
                let gender = row.gender.toString();
                for (let i = 0; i < this.genderList.length; i++) {
                    if (gender === this.genderList[i].itemVal) {
                        return this.genderList[i].itemName;
                    }
                }
                return "-";
            },
            handleRemove() {
            },
            handlePictureCardPreview(file) {
                this.dialogImageUrl = file.url;
                this.dialogVisible = true;
            },
            handleTabClick(tab) {
                switch (tab.name) {
                    case "base":
                        this.status.isShowBase = true;
                        break;
                    case "courseIntroduce":
                        this.status.isShowBase = false;
                        this.updateEditorContent(this.formData.courseIntroduce);
                        break;
                    case "courseOutline":
                        this.status.isShowBase = false;
                        this.updateEditorContent(this.formData.courseOutline);
                        break;
                    case "commonProblem":
                        this.status.isShowBase = false;
                        this.updateEditorContent(this.formData.commonProblem);
                        break;
                }
            },
            updateEditorContent(val) {
                this.$set(this, "content", val || "");
                this.$refs.editor.updateEditorContent(val);
            }

        },
        computed: {
            editor() {
                return this.$refs.myQuillEditor.quill;
            },
        },
    }
</script>

<style scoped>
</style>
<style>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 160px;
        height: 90px;
        line-height: 90px;
        text-align: center;
    }

    .avatar {
        width: 160px;
        height: 90px;
        display: block;
    }

    .el-dialog__body {
        padding: 0 20px 30px;
    }

</style>
<style lang="less" scoped>
    .course-list {

        .hard-level {
            /*.el-select-dropdown__item {
                color: #f7ba2a;
            }*/

            /*.el-input__inner {
                color: #f7ba2a;
            }*/

            .el-select-dropdown__item.selected {
                color: #5D2385;
            }
        }

    }

</style>