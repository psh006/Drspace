<template>
    <div class="special-topic-manage">
        <el-form inline v-model="topicForm">
            <el-form-item label="名称">
                <el-input v-model="topicForm.specialName" maxlength="20" placeHolder="请输入专题的名称" clearable
                          @input="value=>{this.topicForm.specialName=this.$util.checkCnEnNu(value)}"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="handleCurrentChange(1)" icon="el-icon-search" :loading="status.getDataLoading">
                    查询
                </el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="success" @click="addTopic" icon="el-icon-plus" :loading="status.adding">添加</el-button>
            </el-form-item>
        </el-form>

        <el-table :data="tableList" v-loading="status.getDataLoading"
                  style="border: 1px solid #EBEEF5; border-bottom: none">
            <el-table-column label="序号" type="index" align="center"></el-table-column>
            <el-table-column label="专题名称" prop="specialName" align="center"></el-table-column>
            <el-table-column label="课程数量" prop="courseCount" align="center"></el-table-column>
            <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                    <el-button type="text" @click="topicDetail(scope.row)">查看</el-button>
                    <el-button type="text" @click="updateTopic(scope.row)">编辑</el-button>
                    <el-button type="text" @click="upTopic(scope.row)">上移</el-button>
                    <el-button type="text" @click="downTopic(scope.row)">下移</el-button>
                    <el-button type="text" @click="delTopic(scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>

        <!-- 外部的分页组件 -->
        <el-pagination
                background
                layout="total, sizes, prev, pager, next, jumper"
                :current-page="topicForm.currentPage"
                :page-sizes="[5, 10, 20, 50]"
                :page-size="topicForm.pageSize"
                :total="listTotal"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
        </el-pagination>

        <el-dialog :title="dialogTitle" :visible.sync="status.dialogOpen" @closed="dialogClosed" width="1200px">
            <el-form label-width="100px" :model="dialogForm" :inline="true" ref="dialogForm">
                <el-form-item label="专题名称">
                    <el-input v-model="dialogForm.specialName" placeholder="请输入专题名称" autocomplete="off" maxlength="20"
                              :disabled="isPerview"
                              :rules="[{ required: true, message: '请输入专题名称', trigger: 'blur' }]"/>
                </el-form-item>
                <el-form-item label="课程" placeholder="请选择要添加的课程" v-show="!isPerview">
                    <template>
                        <el-select v-model="dialogForm.courseId" filterable placeholder="请选择" :disabled="isPerview"
                                   :filter-method="searchCourse" @change="getCourseItem">
                            <el-option v-for="item in courseList" :key="item.courseId" :label="item.courseName"
                                       :value="item.courseId"></el-option>
                        </el-select>
                    </template>
                </el-form-item>
                <el-form-item v-show="!isPerview">
                    <el-button @click="addCourse">添加</el-button>
                </el-form-item>
            </el-form>

            <el-table :data="courseTableList" v-loading="status.getDataLoading"
                      style="border: 1px solid #EBEEF5; border-bottom: none">
                <el-table-column label="序号" type="index" align="center"></el-table-column>
                <el-table-column label="课程日期" prop="courseTimeDate" v-if="false" align="center"></el-table-column>
                <el-table-column label="上课时间" prop="courseTime" v-if="false" align="center"></el-table-column>
                <el-table-column label="课程名称" prop="courseName" show-overflow-tooltip align="center"></el-table-column>
                <el-table-column label="年级" prop="gradeName" align="center"></el-table-column>
                <el-table-column label="科目" prop="subjectName" align="center"></el-table-column>
                <el-table-column label="难度" prop="hardLevel" align="center"></el-table-column>
                <el-table-column label="课程进度" prop="courseHour" align="center">
                    <template slot-scope="scope">
                        {{scope.row.finishedCourseHour?scope.row.finishedCourseHour:0}}/{{scope.row.allCourseHour?scope.row.allCourseHour:0}}
                    </template>
                </el-table-column>
                <el-table-column label="学生数量" prop="courseAmount" align="center"></el-table-column>
                <el-table-column label="学习管理师" prop="managerTeacherName" align="center"></el-table-column>
                <el-table-column label="授课老师" prop="lecturerName" align="center"></el-table-column>
                <el-table-column label="课程价格(元)" prop="coursePrice" align="center" :formatter="formatMoney"></el-table-column>
                <el-table-column label="操作" v-if="!isPerview" align="center">
                    <template slot-scope="scope">
                        <el-button type="text" @click="delCourseFromTopic(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <!-- 对话框中的分页组件 -->
            <el-pagination
                    background
                    layout="total, sizes, prev, pager, next, jumper"
                    :current-page="topicForm.currentPage"
                    :page-sizes="[5, 10, 20, 50]"
                    :page-size="topicForm.pageSize"
                    :total="courseListTotal"
                    @size-change="handleDialogSizeChange"
                    @current-change="handleDialogCurrentChange">
            </el-pagination>


            <span slot="footer" class="dialog-footer">
                    <el-button type="primary" plain @click="status.dialogOpen = false">取消</el-button>
                    <el-button type="primary" @click="submitTopic" v-if="!isPerview">保存</el-button>
            </span>
        </el-dialog>
    </div>


</template>

<script>
    import {requestData} from "../../assets/javascript/request";

    export default {
        name: "special-topic-manage",
        data() {
            return {
                courseListTotal: 0,
                courseId: "",
                courseTableList: [],
                isPerview: false,
                dialogTitle: "",
                status: {
                    dialogOpen: false,
                    getDataLoading: false,
                    adding: false
                },
                tableList: [],
                listTotal: 0,
                dialogForm: {
                    specialId: "",
                    specialSort: "",
                    specialName: "",
                    courseName: "",
                    courseId: "",
                    currentPage: 1,
                    pageSize: 10,
                },
                courseList: [],
                topicForm: {
                    specialId: "",
                    specialName: "",
                    currentPage: 1,
                    pageSize: 10,
                },
                courseName: "",


            }
        },
        created() {
            this.getTableList();
            this.getCourseList();
        },
        methods: {
            //获取列表数据
            getTableList() {
                this.status.getDataLoading = true;
                let params = {...this.topicForm};
                params.method = "POST";
                requestData(params, "/masters/specialTopic/selectSpecialTopicList",
                    res => {
                        this.tableList = res.list;
                        this.listTotal = res.total;
                        this.status.getDataLoading = false;
                    },
                    () => {
                        this.tableList = [];
                        this.listTotal = 0;
                        this.status.getDataLoading = false;
                    })
            },

            //获取课程的下拉列表的数据
            getCourseList() {
                let params = {};
                params.method = "POST";
                params.courseName = this.courseName;
                this.status.getDataLoading = true;
                requestData(params, "/masters/specialTopic/selectCourseList",
                    res => {
                        this.status.getDataLoading = false;
                        this.courseList = res.list;
                    },()=>{
                        this.courseList = [];
                        this.status.getDataLoading = false;
                    });
            },

            //获取专题对应的课程
            getCourseTableData() {
                let params = {...this.dialogForm};
                params.method = "POST";
                this.status.getDataLoading = true;
                requestData(params, "/masters/specialTopic/selectCourse",
                    res => {
                        this.status.getDataLoading = false;
                        this.courseTableList = res.list;
                        this.courseListTotal = res.total;
                    }, () => {
                        this.courseTableList = [];
                        this.courseListTotal = 0;
                        this.status.getDataLoading = false;
                    });
            },
            //添加专题
            addTopic() {
                let params = {...this.topicForm};
                params.method = "POST";
                let specialName = params.specialName;
                if (specialName === "" || specialName === null) {
                    this.$message.error("添加时请输入专题名称");
                } else {
                    this.status.adding = true;
                    requestData(params, "/masters/specialTopic/insertSpecialTopic",
                        () => {
                            this.topicForm = this.$options.data().topicForm;
                            this.status.adding = false;
                            this.$message.success(`添加成功`);
                            this.handleCurrentChange(1);
                            this.getTableList();
                        },
                        () => {
                            this.status.adding = false;
                        })
                }
            },
            handleSizeChange(pageSize) {
                this.topicForm.pageSize = pageSize;
                this.getTableList();
            },
            handleCurrentChange(currentPage) {
                if(currentPage){
                    this.topicForm.currentPage = currentPage;
                }
                this.getTableList();
            },
            //专题相关查看
            topicDetail(item) {
                // this.dialogForm = {...item};
                this.dialogTitle = "查看";
                this.isPerview = true;
                this.dialogForm = item;
                this.handleDialogCurrentChange(1);
                this.status.dialogOpen = true;
            },
            //修改专题
            updateTopic(item) {
                this.isPerview = false;
                this.dialogTitle = "修改";
                this.dialogForm = item;
                this.handleDialogCurrentChange(1);
                this.status.dialogOpen = true;
            },
            //上移
            upTopic(item) {
                this.$confirm('确定要上移吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // ... (这里进行接口请求)
                    let params = {...item};
                    params.method = "POST";
                    params.isUp = "up";
                    this.status.getDataLoading = true;
                    requestData(params, "/masters/specialTopic/moveSpecialTopic",
                        () => {
                            this.status.getDataLoading = false;
                            this.handleCurrentChange(1);
                        },
                        () => {
                            this.status.getDataLoading = false;
                        })
                }).catch(() => {
                });

            },
            //下移
            downTopic(item) {
                this.$confirm('确定要下移吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // ... (这里进行接口请求)
                    let params = {...item};
                    params.method = "POST";
                    params.isUp = "down";
                    this.status.getDataLoading = true;
                    requestData(params, "/masters/specialTopic/moveSpecialTopic",
                        () => {
                            this.status.getDataLoading = false;
                            this.handleCurrentChange(1);
                        },
                        () => {
                            this.status.getDataLoading = false;
                        })
                }).catch(() => {
                });

            },
            //删除专题
            delTopic(item) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // ... (这里进行接口请求)
                    let params = {...item};
                    params.method = "POST";
                    this.status.getDataLoading = true;
                    requestData(params, '/masters/specialTopic/deleteSpecialTopic',
                        () => {
                            this.status.getDataLoading = false;
                            this.$message.success(`删除成功`);
                            this.handleCurrentChange(1);
                        },
                        () => {
                            this.status.getDataLoading = false;
                        })
                }).catch(() => {
                });
            },
            //提交修改
            submitTopic() {
                let specialName = this.dialogForm.specialName;
                if (specialName == '' || specialName == null) {
                    this.$message.error("修改的名称不能为空");
                } else {
                    let params = {...this.dialogForm};
                    params.method = "POST";
                    this.status.getDataLoading = true;
                    requestData(params, "/masters/specialTopic/updateSpecialTopic",
                        () => {
                            this.status.getDataLoading = false;
                            this.status.dialogOpen = false;
                            this.handleCurrentChange(1);
                        },
                        () => {
                            this.status.getDataLoading = false;
                        });
                }
            },
            //删除专题表中的一个课程
            delCourseFromTopic(item) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // ... (这里进行接口请求)
                    let params = {...item};
                    params.method = "POST";
                    this.status.getDataLoading = true;
                    requestData(params, '/masters/specialTopic/deleteCourse',
                        () => {
                            this.status.getDataLoading = false;
                            this.$message.success(`删除成功`);
                            this.handleDialogCurrentChange(1);
                            this.handleCurrentChange(1);
                        },
                        () => {
                            this.status.getDataLoading = false;
                        })
                }).catch(() => {
                });
            },
            handleDialogSizeChange(pageSize) {
                this.dialogForm.pageSize = pageSize;
                let currentPage = this.dialogForm.currentPage;
                if (currentPage == null || currentPage == 0) {
                    this.dialogForm.currentPage = 1;
                }
                this.getCourseTableData();
            },
            handleDialogCurrentChange(currentPage) {
                this.dialogForm.currentPage = currentPage;
                let size = this.dialogForm.pageSize;
                if (size == null || size == 0) {
                    this.dialogForm.pageSize = 10;
                }
                this.getCourseTableData();
            },
            dialogClosed() {
                this.dialogForm = {};
                this.dialogForm.pageSize = 10;
                this.dialogForm.currentPage = 1;
            },
            //添加課程
            addCourse() {
                let params = {...this.dialogForm};
                params.method = "POST";
                params.courseId = this.courseId;
                this.status.getDataLoading = true;
                requestData(params, "/masters/specialTopic/updateOneTopicToCourse",
                    () => {
                        this.status.getDataLoading = false;
                        this.handleDialogCurrentChange(1);
                        this.handleCurrentChange(1);
                        this.dialogForm.courseId = '';
                    }, () => {
                        this.status.getDataLoading = false;
                        this.dialogForm.courseId = '';
                    });
            },

            getCourseItem(item) {
                this.courseId = item;
            },
            searchCourse(value) {
                this.courseName = value;
                this.getCourseList();
            },
            // 分转元
            formatMoney(row){
                return this.$util.pennyToYuan(row.coursePrice);
            }
        },
    }

</script>

<style type="less" scoped>
    .special-topic-manage {

    }
</style>
