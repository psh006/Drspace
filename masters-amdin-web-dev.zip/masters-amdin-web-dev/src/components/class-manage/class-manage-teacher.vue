<!--suppress RequiredAttributes -->
<template>
    <div class="class-manage-teacher">
        <el-form inline>
            <el-form-item label="日期">
                <el-date-picker v-model="timeSelect"
                                type="daterange"
                                value-format="yyyy-MM-dd"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"
                                style="width: 250px"/>
            </el-form-item>
            <el-form-item label="年级">
                <el-select v-model="searchParams.gradeId" filterable placeholder="请选择" style="width: 150px" clearable>
                    <el-option v-for="item in gradeOptions" :key="item.gradeId" :label="item.gradeName"
                               :value="item.gradeId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="科目">
                <el-select v-model="searchParams.subjectId" style="width: 100px;" clearable>
                    <el-option
                            v-for="item in subjectList"
                            :key="item.subjectId"
                            :label="item.subjectName"
                            :value="item.subjectId">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="授课老师">
                <el-select v-model="searchParams.lecturerId" filterable remote placeholder="请选择"
                           style="width: 150px" :loading="lecturerStatu" clearable
                           :remote-method="remoteTeacher"
                           @clear="clearTeacher">
                    <el-option v-for="item in lecturerOptions" :key="item.teacherId" :label="item.realName"
                               :value="item.teacherId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="handleCurrentChange(1)" :loading="courseListLoading">查询
                </el-button>
            </el-form-item>
        </el-form>
        <el-table :data="courseList" v-loading="courseListLoading" style="border: 1px solid #EBEEF5; border-bottom: none">
            <el-table-column type="index" label="序号" width="50px" style="background-color: #8c939d;" align="center"/>
            <el-table-column label="年级" prop="gradeName" width="100" align="center"/>
            <el-table-column label="科目" prop="subjectName" width="100" align="center"/>
            <el-table-column label="课程名称" prop="courseName" min-width="150" align="center" show-overflow-tooltip/>
            <el-table-column label="状态" min-width="100" align="center">
                <template slot-scope="scope">
                    <span>{{$dict.getItemNameByCodeAndVal("COURSE_STATE", scope.row.courseState)}}</span>
                </template>
            </el-table-column>
            <el-table-column label="开始日期" prop="courseStart" min-width="150" align="center"/>
            <el-table-column label="结束日期" prop="courseEnd" min-width="150" align="center"/>
            <el-table-column label="课时" prop="allCourseHour" width="80" align="center"/>
            <el-table-column label="下次上课时间" prop="nextStartTime" min-width="150" align="center">
                <template slot-scope="scope">
                    <span>{{$util.formatDate(scope.row.nextStartTime,'yyyy-MM-dd HH:mm:ss')}}</span>
                </template>
            </el-table-column>
            <el-table-column label="授课教师" prop="lecturerName" width="100" align="center" show-overflow-tooltip/>
            <el-table-column label="学生数量" width="100" align="center">
                <template slot-scope="scope">
                        <span :class="scope.row.applyAmount&&scope.row.applyAmount>0?'stu-num':''"
                              @click="openStudentDialog(scope.row.applyAmount,scope.row.courseId)">
                            {{scope.row.applyAmount?scope.row.applyAmount:0}}
                        </span>
                </template>
            </el-table-column>
            <el-table-column label="操作" min-width="120" align="center">
                <template slot-scope="scope">
                    <!--<el-button type="text" @click="toRoom(scope.row)"-->
                               <!--v-if="scope.row.courseState===2">旁听-->
                    <!--</el-button>-->
                    <el-button type="text" @click="openTeacherChat(scope.row.courseId)">班级查看</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <el-pagination background
                       align="right"
                       layout="total, sizes, prev, pager, next, jumper"
                       :current-page="searchParams.page"
                       :page-sizes="[5, 10, 20, 50]"
                       :page-size="searchParams.limit"
                       :total="teacherListTotal"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange"/>
        <el-dialog title="班级学生情况" :visible.sync="dialogCourseInfoVisible" width="60%" height="40%">
            <div style="display: flex">
                <div style="width: 45%">
                    <el-table :data="studentList" @row-click="getCourseHour" style="border: 1px solid #EBEEF5; border-bottom: none">
                        <el-table-column type="index" label="序号"/>
                        <el-table-column property="nickName" label="学生昵称" show-overflow-tooltip/>
                        <el-table-column property="realName" label="学生姓名" show-overflow-tooltip/>
                        <el-table-column property="parentName" label="家长姓名" show-overflow-tooltip/>
                        <el-table-column property="parentContact" label="电话" width="100px"/>
                        <el-table-column label="上课次数">
                            <template slot-scope="scope">
                                <span>{{scope.row.finishedCourseHour?scope.row.finishedCourseHour:0}}/{{scope.row.sumCourseHour?scope.row.sumCourseHour:0}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="操作" width="100">
                            <template slot-scope="scope">
                                <el-button type="text" @click.stop="handleTalk(scope.row.studentId)">聊天</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
                <div style="margin-left: 10px;width: 55%">
                    <el-table :data="courseHourList"
                              show-summary
                              style="border: 1px solid #EBEEF5; border-bottom: none"
                              :summary-method="getSummaries">
                        <el-table-column type="index" label="序号"/>
                        <el-table-column property="operateTime" label="上课时间" width="150"/>
                        <el-table-column property="examTimes" label="参与测验次数"/>
                        <el-table-column property="rightTimes" label="正确次数次数"/>
                        <el-table-column property="rightRate" label="正确率">
                            <template slot-scope="scope">
                                <span>{{$util.decimal2Per(scope.row.rightRate)}}%</span>
                            </template>
                        </el-table-column>
                        <el-table-column property="homeworkScore" label="课后作业成绩"/>
                    </el-table>
                </div>
            </div>
        </el-dialog>
        <!--    作业  弹框  -->
        <el-dialog :visible.sync="ClassCurriculumDialog" width="1000px" @close="handleTopicManageClose">
            <div class="homework-conten">
                <div class="student">
                    <span class="class-title">班级课程情况</span>
                    <div class="bordercss" style="margin-top: 5px">
                        <template>
                            <el-table :data="tableData" :header-cell-style="headClass" style="border: 1px solid #EBEEF5; border-bottom: none"
                                      :cell-style="rowClass" @row-click="handleClickTopic" highlight-current-row>
                                <el-table-column
                                        prop="courseHourNumerical"
                                        label="序号"
                                        width="50"
                                >
                                </el-table-column>
                                <el-table-column
                                        prop="classTime"
                                        label="上课时间"
                                        width="150"
                                >
                                </el-table-column>
                                <el-table-column
                                        prop="courseRecordAmount"
                                        label="学生"
                                        width="80"
                                >
                                </el-table-column>
                            </el-table>
                        </template>
                    </div>
                </div>
                <div class="curriculum">
                    <div>
                        <el-tabs v-model="activeName" @tab-click="handleClick">
                            <el-tab-pane label="课件" name="first">
                                <div>
                                    <el-table ref="courseWareTable" :data="courseWareTableData"
                                              style="border: 1px solid #EBEEF5; border-bottom: none">
                                        <el-table-column type="index" label="序号" min-width="50" align="center"></el-table-column>
                                        <el-table-column property="fileName" label="文件名称" min-width="200" align="center"
                                                         show-overflow-tooltip></el-table-column>
                                        <el-table-column property="fileSize" label="文件大小" min-width="80" align="center"></el-table-column>
                                        <el-table-column property="operateTime" label="上传时间" min-width="150" align="center"></el-table-column>
                                        <el-table-column label="操作" align="center" min-width="100">
                                            <template slot-scope="scope">
                                                <el-link type="primary" :underline="false" class="download-link" target="_blank"
                                                         :href="$getFileUrl + scope.row.fileUrl">下载
                                                </el-link>
                                            </template>
                                        </el-table-column>
                                    </el-table>
                                </div>
                            </el-tab-pane>
                            <el-tab-pane label="作业" name="second">
                                <div class="bordercss">
                                    <template>
                                        <el-table :data="homeWorkList" style="width: 100%"
                                                  :header-cell-style="headClass" :cell-style="rowClass"
                                                  highlight-current-row>
                                            <el-table-column type="index" label="序号"
                                                             width="50"></el-table-column>
                                            <el-table-column prop="studentName" label="姓名" min-width="97" show-overflow-tooltip></el-table-column>
                                            <el-table-column prop="isFinish" label="完成情况" min-width="70">
                                                <template slot-scope="scope">
                                                    <span v-if="scope.row.isFinish  === 1" >已完成</span>
                                                    <span v-else-if="scope.row.isFinish === 2">未完成</span>
                                                </template>
                                            </el-table-column>
                                            <el-table-column prop="finishTime" label="完成时间"
                                                             min-width="160"></el-table-column>
                                            <el-table-column prop="operateTime" label="用时"
                                                             min-width="160"></el-table-column>
                                            <el-table-column prop="studentScore" label="分数"
                                                             min-width="50"></el-table-column>
                                            <el-table-column label="操作" min-width="80">
                                                <template slot-scope="scope">
                                                    <el-button type="text" @click="lookWork(scope.row)">查看</el-button>
                                                </template>

                                            </el-table-column>
                                        </el-table>
                                    </template>
                                </div>
                            </el-tab-pane>
                            <!--<el-tab-pane label="回放" name="third">回放</el-tab-pane>-->
                        </el-tabs>
                    </div>
                    <div>

                    </div>
                </div>
            </div>
        </el-dialog>
        <!--    作业 弹框 结束-->
        <!--   查看试卷详情 答题卡 弹框     -->
        <el-dialog :title="testPaperList.testPaperName" :visible.sync="operationDetailsDialog" width="900px" lock-scroll top="60px" >
            <div  class="conten" >
                <div class="homeword-img" >
                    <el-scrollbar style="height:100%"  v-if="fileList.length>0">
                        <div class="fileimg" v-for="(item,fileId) in fileList" :key="fileId">
                            <img v-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.jpg' ||  item.file_url.substring(item.file_url.lastIndexOf('.'))=='.png' || item.file_url.substring(item.file_url.lastIndexOf('.'))==='.jpeg' " :src="$getFileUrl+item.file_url">
                            <div class="pdf" v-else-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.pdf'">
                                <div  style="width:200px;margin-top: 20px;margin-left: 20px">
                                    <!--    上一页-->
                                    <span @click="changePdfPage(0)" >上一页</span>
                                    {{currentPage}} / {{pageCount}}
                                    <!--下一页-->
                                    <span  @click="changePdfPage(1)">下一页</span>
                                </div>
                                <pdf ref="myPDF"
                                     :src="$getFileUrl+item.file_url"
                                     :page="currentPage"
                                     @num-pages="pageCount=$event"
                                     @page-loaded="currentPage=$event"
                                     @loaded="loadPdfHandler"
                                >
                                </pdf>
                            </div>
                            <div v-else style="height:700px;width: 99%;position: relative">
                                <div style="position: absolute;width: 100%;height: 88px;background-color: white"></div>
                                <iframe   style="height:650px;width: 500px;" :src="'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com'+item.file_url" ></iframe>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
                <div class="homeword-conten">
                    <el-scrollbar style="height:100%">
                        <div class="title">
                            <p><span class="text-underline">{{testPaperList.testPaperName}}</span></p>
                        </div>
                        <div class="achievement" v-if="testPaperList.homework_score>0"><span class="achievementscore">成绩:</span><span class="text-underline">{{testPaperList.homework_score}}</span></div>
                         <template    v-for="(answeritem,index) in answerList" >
                             <div class="question-type" v-if="answeritem.topic_type === 2"   :key="index">
                                 <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span style="padding-right: 10px">填空题</span><span></span>
                                 </p>
                                 <div class="question">
                                     <div class="question-conten" v-for="(item,indexId) in answeritem.themeList " :key="indexId">
                                         <div class="question-conten-list">
                                             <div class="write"><span class="theme-number" >{{item.theme_number}}, </span><span>{{item.student_answer}}</span>
                                             </div>
                                             <div class="list-img">
                                                 <i v-if="item.right_answer===item.student_answer"
                                                    class="el-icon-check hook"></i>
                                                 <i v-else class="el-icon-close fork"></i>
                                             </div>
                                             <div class="ider" v-if="item.is_show_theme_solve===1">
                                                 <span class="ideastext">解题思路</span>
                                                 <el-checkbox checked="checked" onclick="return false"></el-checkbox>
                                             </div>
                                             <div v-else class="ider"></div>
                                         </div>

                                     </div>
                                 </div>
                             </div>
                             <div class="question-type" v-if="answeritem.topic_type === 1"   :key="index">
                                 <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span style="padding-right: 10px">选择题</span><span> </span>
                                 </p>
                                 <div class="question">
                                     <div class="question-conten" v-for="(item,indexId) in answeritem.themeList " :key="indexId">
                                         <div class="question-conten-list">
                                             <div class="write"><span  class="theme-number">{{item.theme_number}} , </span>
                                                 <div class="chose-button">{{item.student_answer}}</div>
                                             </div>
                                             <div class="list-img">
                                                 <i v-if="item.right_answer===item.student_answer"
                                                    class="el-icon-check hook"></i>
                                                 <i v-else class="el-icon-close fork"></i>
                                             </div>
                                             <div class="ider" v-if="item.is_show_theme_solve===1">
                                                 <span class="ideastext">解题思路</span>
                                                 <el-checkbox checked="checked" onclick="return false"></el-checkbox>
                                             </div>
                                             <div v-else class="ider"></div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="question-type"  v-if="answeritem.topic_type === 3"   :key="index">
                                 <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span style="padding-right: 10px">判断题</span><span>{{judgeFaction.fraction}} </span>
                                 </p>
                                 <div class="question">
                                     <div class="question-conten" v-for="(item,indexId) in answeritem.themeList " :key="indexId">
                                         <div class="question-conten-list">
                                             <div class="write"><span
                                                     class="theme-number">{{item.theme_number}} , </span>
                                                 <div v-if="item.is_right===1"><i class="el-icon-check hook"></i></div>
                                                 <div v-else><i class="el-icon-close fork"></i></div>
                                             </div>
                                             <div class="list-img">
                                                 <i v-if="item.right_answer===item.student_answer"
                                                    class="el-icon-check hook"></i>
                                                 <i v-else class="el-icon-close fork"></i>
                                             </div>
                                             <div class="ider" v-if="item.is_show_theme_solve===1">
                                                 <span class="ideastext">解题思路</span>
                                                 <el-checkbox checked="checked" onclick="return false"></el-checkbox>
                                             </div>
                                             <div v-else class="ider"></div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="question-type"  v-if="answeritem.topic_type === 5"   :key="index">
                                 <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span style="padding-right: 10px">连线题</span><span>{{connectFaction.fraction}} </span>
                                 </p>
                                 <div class="question">
                                     <div class="question-conten" v-for="(item,indexId) in answeritem.themeList " :key="indexId">
                                         <div class="question-conten-list">
                                             <div class="write"><span
                                                     class="theme-number">{{item.theme_number}} , </span>
                                                 <div>{{item.student_answer}}</div>
                                             </div>
                                             <div class="list-img">
                                                 <i v-if="item.right_answer===item.student_answer"
                                                    class="el-icon-check hook"></i>
                                                 <i v-else class="el-icon-close fork"></i>
                                             </div>
                                             <div class="ider" v-if="item.is_show_theme_solve===1">
                                                 <span class="ideastext">解题思路</span>
                                                 <el-checkbox checked="checked" onclick="return false"></el-checkbox>
                                             </div>
                                             <div v-else class="ider"></div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="question-type" v-if="answeritem.topic_type === 4"   :key="index">
                                 <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span>解答题 </span>
                                     <span> {{subjectiveFaction.fraction}}</span></p>
                                 <div class="question">
                                     <div class="answer-question" v-for="(item,indexId) in answeritem.themeList" :key="indexId">
                                         <div class="scoring">
                                             <div class="ider" v-if="item.is_show_theme_solve===1">
                                                 <span class="ideastext">解题思路</span>
                                                 <el-checkbox checked="checked" onclick="return false"></el-checkbox>
                                             </div>
                                             <div v-else class="ider"></div>
                                             <div style="margin-right: 35px">老师批改内容</div>
                                         </div>
                                         <div class="answer">
                                             <div class="reple" @click="look" v-if="lookShow===true"> 点击查看实际作答</div>
                                             <div class="reple" v-else>
                                                 <el-input  readonly type="textarea"  :rows="5" :value="item.student_answer" > </el-input>
                                             </div>

                                             <div class="correction">
                                                 <el-input readonly type="textarea" :rows="5" :value="item.teacher_remark"> </el-input>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </template>
                        <div class="comment">
                            <span  class="comment-textarea">老师点评 :</span>
                            <el-input  type="textarea" maxlength="200" :value="testPaperList.teacher_comment" readonly></el-input>
                        </div>

                    </el-scrollbar>
                </div>

            </div>
        </el-dialog>
        <!--查看试卷详情 弹框结束-->

    </div>
</template>

<script>
    import pdf from 'vue-pdf'
    export default {
        name: "class-manage-teacher",
        components: {
            pdf
        },
        data() {
            return {
                //pdf  在线预览  翻页
                currentPage: 0, // pdf文件页码
                pageCount: 0, // pdf文件总页数
                lookShow: true,
                //选择分数
                choseFaction: {
                    studentScore: null,
                    themeScore: null,
                    fraction: null,
                },
                //填空题分数
                fillFaction: {
                    studentScore: null,
                    themeScore: null,
                    fraction: null,
                },
                //判断分数
                judgeFaction: {
                    studentScore: null,
                    themeScore: null,
                    fraction: null,
                },
                //解答题分数
                subjectiveFaction: {
                    studentScore: null,
                    themeScore: null,
                    fraction: null,
                },
                //连线题分数
                connectFaction: {
                    studentScore: null,
                    themeScore: null,
                    fraction: null,
                },
                //试卷 标题 总分
                testPaperList: [],
                //答题卡展示内容
                answerList:[],
                //老师评语
                teacherComments: "",

                //答题卡
                isCorrect: true,
                judgeisCorrect: true,
                checked: false,
                answerSheetQuest: {
                    studentId:"",
                    testPaperId:""
                },
                //试卷标题
                testPaper: "五年级数学课后作业",
                //试卷
                fileList:[],
                //作业
                textarea: "",
                lookHomeWorkList: {
                    courseId: "",
                    limit: 10,
                    page: 1
                },
                homeWorkCoursDetails: {
                    courseHourId: "1",
                },
                courseWareTableData:[],//课件表格数据
                homeWorkList: [],
                tableData: [],
                activeName: 'second',
                searchParams: {
                    gradeId: '',
                    subjectId: '',
                    lecturerId: '',
                    page: 1,
                    limit: 10
                },
                courseList: [],
                teacherListTotal: 0,
                timeSelect: [],
                gradeOptions: [],
                subjectList: [],
                studentList: [],
                courseHourList: [],
                lecturerOptions: [],
                courseListLoading: false,
                lecturerStatu: false,
                dialogCourseInfoVisible: false,
                operationDetailsDialog: false,
                ClassCurriculumDialog: false,
            }
        },
        mounted() {
            this.handleCurrentChange();
            this.queryGrade();
            this.querySubject();
            this.remoteTeacher();
        },
        methods: {
            // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
            changePdfPage(val) {
                // console.log(val)
                if (val === 0 && this.currentPage > 1) {
                    this.currentPage--
                    // console.log(this.currentPage)
                }
                if (val === 1 && this.currentPage < this.pageCount) {
                    this.currentPage++
                    // console.log(this.currentPage)
                }
            },
            // pdf加载时
            loadPdfHandler() {
                this.currentPage = 1 // 加载的时候先加载第一页
            },
            look() {
                this.lookShow = false
            },

            headClass() {
                return 'text-align:center';
            },
            //点击作业  查看答题卡
            lookWork(row) {
                 this.answerSheetQuest.studentId=row.studentId;
                 this.answerSheetQuest.testPaperId=row.testPaperId;
                this.answerSheet()
            },
            answerSheet() {
                let params = {...this.answerSheetQuest};
                this.$request(params, "/student/queryStudentWorkInfo", (res) => {
                    this.testPaperList=res.list[0].testPaper;
                    this.answerList=res.list[0].list;
                    this.fileList=res.list[0].fileList;
                    this.answerList.map(item=>{
                        console.log(item.topic_index)
                    });
                    this.operationDetailsDialog=true


                },()=>{
                    this.operationDetailsDialog=false
                })
            },
            rowClass() {
                return 'text-align:center';
            },
            //班级查看中选项卡切换
            handleClick() {
                this.handleClickTopic(this.homeWorkCoursDetails.courseHourId);
            },
            //关闭查看班级 弹框  触发的事件
            handleTopicManageClose(){
                this.courseWareTableData=[];
                this.homeWorkList=[];
                this.tableData=[];

            },
            //查看班级列表单击事件
            handleClickTopic(row) {
                if (this.activeName==='first'){
                    this.queryCourseWareInfo(row);
                }else if (this.activeName==='second'){
                    this.homeWorkCoursDetailsRepuest(row)//班级课程完成情况详情
                }else if (this.activeName==='third'){
                    console.log("回放",row)
                }
            },
            //课件请求数据
            queryCourseWareInfo(row){
                let params={...row};
                this.$request(params,"/masters/courseHourCourseware",res=>{
                    this.courseWareTableData=res.list;
                },()=>{
                })
            },
            //点击作业  弹出 查看作业  框
            openTeacherChat(courseId) {
                this.lookHomeWorkList.courseId = courseId;
                this.activeName = 'first';
                this.ClassCourseRequest();//班级课程情况
                this.ClassCurriculumDialog = true;
            },
            //班级课程情况
            ClassCourseRequest() {
                let params = {...this.lookHomeWorkList};
                this.$request(params, "/masters/mapper/select/course.queryFinishCourseHourByCourseId", (res) => {
                    res.list.map((item) => {
                        item.courseRecordAmount = (item.courseRecordAmount) + "/" + (item.applyAmount || '0')
                    });
                    this.tableData = res.list;
                    // 默认获取第一课程情况
                    if (this.tableData.length > 0) {
                        let row = this.tableData[0];
                        this.homeWorkCoursDetails.courseHourId = row;
                        this.handleClickTopic(row);
                    }
                }, () => {

                })
            },
            //班级课程完成情况详情
            homeWorkCoursDetailsRepuest(row) {
                let params = {...row};
                this.$request(params, "/masters/mapper/select/course.queryCourseHourHomework", (res) => {
                    res.list.map(item => {
                        let finishTime = new Date(item.finishTime).getTime();
                        let operateTime = new Date(item.operateTime).getTime();
                        item.operateTime = this.$util.times2Minus(finishTime - operateTime);
                    });
                    this.homeWorkList = res.list

                })
            },
            handleCurrentChange(currentPage) {
                this.searchParams.page = currentPage;
                this.getTeacherList();
            },
            // 每页几条
            handleSizeChange(pageSize) {
                this.searchParams.limit = pageSize;
                this.handleCurrentChange(1);
            },
            getTeacherList() {
                let params = {...this.searchParams};
                if (this.timeSelect && this.timeSelect.length === 2) {
                    params.courseStart = this.timeSelect[0];
                    params.courseEnd = this.timeSelect[1];
                }
                this.courseListLoading = true;
                this.$request(params, "/masters/course/queryCourseByTeacher", (data) => {
                    this.courseList = data.list;
                    this.teacherListTotal = data.total;
                    this.courseListLoading = false;
                }, () => {
                    this.courseListLoading = false;
                });
            },
            queryGrade() {
                this.$request({}, "/masters/mapper/select/gradeList", (data) => {
                    if (data.flag === 200) {
                        this.gradeOptions = data.list;
                    }
                }, () => {
                    console.log('年级查询失败');
                });
            },
            querySubject() {
                this.$request({}, "/masters/mapper/select/querySubject", (data) => {
                    if (data.flag === 200) {
                        this.subjectList = data.list
                    }
                }, () => {
                    console.log('科目查询失败');
                });
            },
            //模糊查询教师
            remoteTeacher(query) {
                this.lecturerStatu = true;
                this.$request({"name": query}, "/masters/mapper/select/queryTeacherByTeacherName", (data) => {
                    if (data.flag === 200) {
                        this.lecturerOptions = data.list;
                        this.lecturerStatu = false
                    }
                }, () => {
                    console.log('科目查询失败');
                    this.lecturerStatu = false
                });
            },
            clearTeacher() {
                this.remoteTeacher('');
            },
            openStudentDialog(applyAmount, courseId) {
                if (applyAmount == null || applyAmount == 0) {
                    return;
                }
                this.courseHourList = [];
                this.dialogCourseInfoVisible = true;
                this.$request({"courseId": courseId}, "/masters/mapper/select/studentCourse.queryStudentByCourse", (data) => {
                    if (data.flag === 200) {
                        this.studentList = data.list;
                        this.getCourseHour(data.list[0])
                    }
                }, () => {
                    console.log('学生查询失败');
                });
            },
            getCourseHour(student) {
                let param = {};
                param.courseId = student.courseId;
                param.studentId = student.studentId;
                this.$request(param, "/masters/mapper/select/studentCourseRecord.queryCourseRecordByStuCors", (data) => {
                    if (data.flag === 200) {
                        this.courseHourList = data.list
                    }
                }, () => {
                    console.log('上课信息查询失败');
                });
            },
            getSummaries(param) {
                const {columns, data} = param;
                const sums = [];
                const length = data.length;
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '合计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                            const value = Number(curr);
                            if (!isNaN(value)) {
                                return prev + curr;
                            } else {
                                return prev;
                            }
                        }, 0);
                        if (index === 4) {
                            sums[index] = this.$util.decimal2Per(sums[index] / length) + '%'
                        }
                        if (index === 5) {
                            sums[index] = sums[index] / length
                        }
                    }
                });
                return sums;
            },
            // 旁听去直播间
            toRoom(row) {
                let roomNumber = row.roomNumber;
                console.log("roomNumber", roomNumber);
                // TODO: 旁听跳转
                // this.$router.push({path: "/",query:{}});
            },
            // 聊天
            handleTalk(studentId) {
                this.$store
                    .dispatch('checkoutConversation', `C2C${studentId}`)
                    .then(() => {
                        this.dialogCourseInfoVisible = false;
                        this.$nextTick(() => {
                            this.$store.commit("setShowConversation", true);
                        });
                    }).catch(() => {
                    this.$store.commit('showMessage', {
                        message: '此学生可能没有登录过系统',
                        type: 'warning'
                    })
                });
            },
        }
    }
</script>

<style scoped>
    .stu-num {
        color: #1890ff;
        text-decoration: underline;
        cursor: pointer;
    }


</style>
<style lang="less">
    .class-manage-teacher {
        .conten {
            display: flex;
            justify-content: space-between;

            .homeword-img {
                width: 578px;
                height: 650px;
                background-color: #ffffff;
                border-right: solid 1px #e4e7ed;
                box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
                border-radius: 4px;
                overflow: hidden;
                //答题卡样式 滚动
                .el-scrollbar__thumb {
                    display: none;
                }

                .el-scrollbar__wrap {
                    overflow-x: hidden;
                    overflow-y: auto;
                }

                .el-dialog__body {
                    padding: 0 20px 30px;
                    color: #606266;
                    font-size: 14px;
                    word-break: break-all;
                    margin-top: 15px;
                }

                .fileimg {
                    width: 578px;
                    height: 506px;
                    img {
                        width: 100%;
                        height: 100%;
                    }
                }

            }

            .homeword-conten {
                width: 384px;
                height: 650px;
                background-color: #ffffff;
                border-right: solid 1px #e4e7ed;
                box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
                border-radius: 4px;
                .comment {
                    width: 90%;
                    margin: auto;
                    .comment-textarea {
                        display: inline-block;
                        margin-bottom: 6px;
                        margin-left: 4px;
                    }
                }
                //答题卡样式 滚动
                .el-scrollbar__thumb {
                    display: none;
                }

                .el-scrollbar__wrap {
                    overflow-x: hidden;
                    overflow-y: auto;
                }

                .el-dialog__body {
                    padding: 0 20px 30px;
                    color: #606266;
                    font-size: 14px;
                    word-break: break-all;
                    margin-top: 15px;
                }

                .title {
                    margin: 15px auto 10px;
                    text-align: center;
                }

                .achievement {
                    width: 30%;
                    margin-left: 230px;

                    .achievementscore {
                        font-family: SourceHanSansSC;
                        font-weight: 400;
                        font-size: 28px;
                        color: rgb(16, 16, 16);
                        font-style: normal;
                        letter-spacing: 0;
                        line-height: 41px;
                        text-decoration: none;
                    }
                }

                .question-type {
                    width: cale(100%-30px);
                    margin: auto;
                    padding: 0 30px;

                    .question {
                        .answer-question {
                            width: 100%;
                            height: 200px;
                            padding-top: 5px;

                            .scoring {
                                display: flex;
                                justify-content: space-between;
                                align-items: center;

                                .ideastext {
                                    padding: 0 10px;
                                }
                            }

                            .answer {
                                width: 100%;
                                margin-top: 10px;
                                display: flex;
                                justify-content: space-between;

                                .reple {
                                    width: 45%;
                                    text-align: center;
                                    line-height: 100px;
                                }

                                .correction {
                                    width: 45%;
                                }
                            }
                        }
                    }

                    .Types-of {
                        font-size: 16px;
                        padding-bottom: 10px;
                    }

                    .question-conten {
                        width: 100%;
                        padding-bottom: 10px;
                        font-size: 16px;

                        .question-conten-list {
                            width: 100%;
                            height: 30px;
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                            .write {
                                width: 120px;
                                display: flex;
                                justify-content: flex-start;
                                align-items: center;
                                .theme-number {
                                    width: 25px;
                                }

                                .chose-button {
                                    height: 25px;
                                    text-align: center;
                                    line-height: 25px;
                                    margin-left: 20px;
                                }
                            }

                            .list-img {
                                font-size: 30px;

                                .hook {
                                    color: green;
                                }

                                .fork {
                                    color: red;
                                }
                            }

                            .ider {
                                width: 100px;

                                .ideastext {
                                    padding: 0 10px;
                                }
                            }
                        }
                    }
                }
            }

            .text-underline {
                font-family: SourceHanSansSC;
                font-weight: 400;
                font-size: 28px;
                /* color: rgb(16, 16, 16); */
                font-style: normal;
                letter-spacing: 0;
                line-height: 41px;
                text-decoration: underline;
            }
        }

        /*作业弹框*/
        .homework-conten {
            width: 100%;
            display: flex;
            justify-content: space-between;

            .curriculum {
                width: 66%;

                .download-link {
                    font-size: 12px;
                    margin-left: 10px;
                    margin-right: 10px;
                    border-radius: 3px;
                    vertical-align: baseline;
                }
            }

            .bordercss {
                border-left: solid 1px #EBEEF5;
                border-right: solid 1px #EBEEF5;
            }

            .student {
                .class-title {
                    height: 40px;
                    margin-top: 8px;
                    line-height: 40px;
                    display: inline-block;
                    font-size: 16px;
                }

            }

        }
    }
</style>