import coursewareManage from './courseware-manage';
import mycCourseware from './my-courseware';

export default [
    coursewareManage,
    mycCourseware
]
