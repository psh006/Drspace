<template>
    <!-- 课件管理 -->
    <div class="courseware-manage">
        <!-- 搜索表单 -->
        <el-form ref="searchForm" :model="pageInfo" inline>
            <el-form-item label="名称">
                <el-input v-model="pageInfo.fileName" placeholder="请输入名称" clearable style="width: 150px;"
                          maxlength="50"></el-input>
            </el-form-item>
            <el-form-item label="属性">
                <el-select v-model="pageInfo.coursewareType" clearable style="width: 120px;">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in coursewareTypeList" :key="item.itemVal" :label="item.itemName"
                               :value="item.itemVal"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="年级">
                <el-select v-model="pageInfo.gradeId" clearable style="width: 120px;">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in gradeList" :key="item.gradeId" :label="item.gradeName"
                               :value="item.gradeId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="科目">
                <el-select v-model="pageInfo.subjectId" clearable style="width: 120px;">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in subjectList" :key="item.subjectId" :label="item.subjectName"
                               :value="item.subjectId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="老师">
                <el-select v-model="pageInfo.teacherId" style="width: 150px;"
                           clearable filterable remote placeholder="请输入老师姓名" @clear="searchTeacher(null)"
                           :remote-method="searchTeacher" :loading="status.teacherLoading">
                    <el-option
                            v-for="item in teacherList"
                            :key="item.teacherId"
                            :label="item.realName"
                            :value="item.teacherId">
                        <el-tooltip class="item" effect="dark" :content="item.info" placement="right">
                            <span style="float: left">{{ item.realName }}</span>
                        </el-tooltip>
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="上传时间">
                <el-date-picker v-model="pageInfo.uploadTime"
                                style="width: 250px;"
                                type="daterange"
                                value-format="yyyy-MM-dd"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"/>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" :loading="status.dataLoading" @click="handleSearch(1)"
                           icon="el-icon-search">查询
                </el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="success" @click="handleDialog('insert')">添加
                </el-button>
            </el-form-item>
        </el-form>

        <!-- 数据表格 -->
        <el-table :data="data" v-loading="status.dataLoading"
                  style="border: 1px solid #EBEEF5; border-bottom: none" type="index">
            <el-table-column label="序号" type="index" min-width="50px" align="center"></el-table-column>
            <el-table-column label="课件名称" prop="fileName" min-width="250px" show-overflow-tooltip align="center"></el-table-column>
            <el-table-column label="所属老师" prop="teacherName" :formatter="formatTeacher" align="center"></el-table-column>
            <el-table-column label="属性" prop="coursewareType" min-width="100px" align="center">
                <template slot-scope="scope">
                    <el-tag
                            v-if="scope.row.coursewareType  === 1"
                            type="primary" size="mini">
                        {{formatCoursewareType(scope.row)}}
                    </el-tag>
                    <el-tag
                            v-else-if="scope.row.coursewareType  === 2"
                            type="success" size="mini">
                        {{formatCoursewareType(scope.row)}}
                    </el-tag>
                    <span v-else>
                        {{formatCoursewareType(scope.row)}}
                    </span>
                </template>
            </el-table-column>
            <el-table-column label="年级" prop="gradeName" align="center"></el-table-column>
            <el-table-column label="科目" prop="subjectName" align="center"></el-table-column>
            <el-table-column label="上传时间" prop="operateTime" min-width="150px" align="center"></el-table-column>
            <el-table-column label="文件大小" prop="fileSize" width="80px" align="center"></el-table-column>
            <el-table-column label="操作" width="200px" align="center">
                <template slot-scope="scope">
                    <el-button type="text" @click.stop="handleDialog('update',scope.row.coursewareId)">编辑</el-button>
                    <el-link type="primary" :underline="false" class="download-link" target="_blank"
                             :href="$getFileUrl + scope.row.fileUrl">下载</el-link>
                    <el-button type="text" @click.stop="handleDelete(scope.row.coursewareId,scope.row.fileUrl)">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <el-pagination
                layout="total, sizes, prev, pager, next, jumper"
                background
                :current-page="pageInfo.page"
                :page-sizes="[5, 10, 20, 50]"
                :page-size="pageInfo.limit"
                :total="total"
                @size-change="handlePageSize"
                @current-change="handleSearch">
        </el-pagination>

        <!-- 查看、添加、编辑课件的弹窗 -->
        <el-dialog :title="dialogTitle" :visible.sync="status.dialogOpen" @closed="handleResetForm('dataForm')"
                   width="500px" :close-on-click-modal="false">
            <el-form :model="formData" ref="dataForm" :rules="dataFormRules" label-width="110px">
                <el-form-item label="属性" prop="coursewareType">
                    <el-select v-model="formData.coursewareType" style="width: 300px;"
                               :disabled="status.dataFormDisabled">
                        <el-option v-for="item in coursewareTypeList" :key="item.itemVal" :label="item.itemName"
                                   :value="parseInt(item.itemVal)"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="所属老师" prop="teacherId" v-if="parseInt(formData.coursewareType)===1">
                    <el-select v-model="formData.teacherId" style="width: 300px;"
                               clearable filterable remote
                               :remote-method="searchTeacher" :loading="status.teacherLoading">
                        <el-option
                                v-for="item in teacherList"
                                :key="item.teacherId"
                                :label="item.realName"
                                :value="item.teacherId">
                            <el-tooltip class="item" effect="dark" :content="item.info" placement="right">
                                <span style="float: left">{{ item.realName }}</span>
                            </el-tooltip>
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="所属年级" prop="gradeId">
                    <el-select v-model="formData.gradeId" style="width: 300px"
                               :disabled="status.dataFormDisabled">
                        <el-option v-for="item in gradeList" :key="item.gradeId" :label="item.gradeName"
                                   :value="item.gradeId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="科目" prop="subjectId">
                    <el-select v-model="formData.subjectId" style="width: 300px"
                               :disabled="status.dataFormDisabled">
                        <el-option v-for="item in subjectList" :key="item.subjectId" :label="item.subjectName"
                                   :value="item.subjectId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="文件上传" prop="fileUrl">
                    <el-upload
                            class="upload-demo"
                            ref="upload"
                            :action="this.$uploadFileUrl"
                            accept=".doc,.docx,.ppt,.pptx"
                            :before-upload="beforeUpload"
                            :on-success="uploadSuccess"
                            :on-remove="removeFile"
                            :limit="1"
                            :file-list="fileList">
                        <el-button size="small" type="primary">点击上传</el-button>
                        <div slot="tip" class="el-upload__tip">只能上传word/ppt文件，且不超过5MB</div>
                    </el-upload>
                </el-form-item>
                <el-form-item label="课件名称" prop="fileName">
                    <el-input v-model="formData.fileName" style="width: 300px" :readonly="status.dataFormDisabled"
                              placeholder="请以.docx、.doc、.pptx、.ppt结尾"
                              maxlength="50" ></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer" v-if="!status.dataFormDisabled">
                    <el-button @click="status.dialogOpen = false">取消</el-button>
                    <el-button type="primary" @click="handleSubmit" :loading="status.saving"
                               >保存</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>

    export default {
        name: "courseware-manage",
        data() {
            let validateFileName = (rule, value, callback) => {
                if (value.endsWith(".docx")||value.endsWith(".doc")||
                    value.endsWith(".pptx")||value.endsWith(".ppt")) {
                    return callback();
                }else {
                    return callback(new Error('请以.docx、.doc、.pptx、.ppt结尾'));
                }
            };
            // 这里是数据中心 这里面的值会驱动页面渲染
            return {
                coursewareTypeList: [],
                // 年级列表
                gradeList: [],
                // 老师列表
                teacherList: [],
                // 科目列表
                subjectList: [],
                // 分页参数
                pageInfo: {
                    page: 1,
                    limit: 10,
                    coursewareType: "",
                    gradeId: "",
                    subjectId: "",
                },
                // 列表数据
                data: [],
                // 数据总条数
                total: 0,
                // 状态
                status: {
                    dataLoading: false,
                    saving: false,
                    dialogOpen: false,
                    dataFormDisabled: true,
                    teacherLoading: false,
                },
                // 学生数据表单
                formData: {
                    fileName: "",
                    coursewareType: "",
                    gradeId: "",
                    subjectId: "",
                    teacherId: "",
                    fileUrl: "",
                    size: ""
                },
                fileList: [],
                // 弹窗标题
                dialogTitle: "添加课件",
                // 表单校验规则
                dataFormRules: {
                    fileName: [
                        {required: true, message: '名称不能为空', trigger: 'blur'},
                        {validator: validateFileName, trigger: 'blur'}
                    ],
                    coursewareType: [
                        {required: true, message: '课件类型不能为空', trigger: 'change'}
                    ],
                    teacherId: [
                        {required: true, message: '老师不能为空', trigger: 'change'}
                    ],
                    gradeId: [
                        {required: true, message: '年级不能为空', trigger: 'change'}
                    ],
                    subjectId: [
                        {required: true, message: '科目不能为空', trigger: 'blur'}
                    ],
                    fileUrl: [
                        {required: true, message: '请上传文件'}
                    ]

                },
                //列表统计
                studentCourseTotal: {}
            }
        },
        // created函数会在页面渲染完成之前加载，一般在这里面请求数据
        mounted() {
            // 课件类型字典
            this.coursewareTypeList = this.$dict.getDictByCode('COURSEWARE_TYPE') || [];
            // 获取列表数据
            this.handleSearch(1);
            // 年级数据初始化
            this.gradeList = [];
            let params = {
                method: 'POST',
            }
            this.$request(params, "/grade/gradeList", (res) => {
                this.gradeList = res.list;
            });
            // 科目数据初始化
            this.subjectList = [];
            this.$request(params, "/subject/subjectList", (res) => {
                this.subjectList = res.list;
            });
            this.searchTeacher();
        },
        // 在这里面定义页面所需函数
        methods: {
            // 请求列表数据
            getData() {
                let params = {...this.pageInfo};
                if (params.uploadTime && params.uploadTime.length >= 2) {
                    params.startTime = params.uploadTime[0] + " 00:00:00";
                    params.endTime = params.uploadTime[1] + " 23:59:59";
                    delete params.uploadTime;
                }
                this.status.dataLoading = true;
                // 这里请求数据
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/courseware.queryCourseware", (res) => {
                    this.data = res.list;
                    this.total = res.total;
                    this.status.dataLoading = false;
                }, () => {
                    this.$message.error("获取数据失败");
                    this.status.dataLoading = false;
                });
            },
            // 根据课程名搜索课程
            searchTeacher(realName) {
                this.courseLoading = true;
                let params = {
                    realName: realName,
                    method: 'POST'
                }
                this.$request(params, "/masters/mapper/select/teacher.queryTeacherByName", (res) => {
                    this.teacherLoading = false;
                    this.teacherList = res.list;
                }, () => {
                    this.teacherList = [];
                });
            },
            // 每页几条
            handlePageSize(limit) {
                this.pageInfo.limit = limit;
                this.handleSearch(1);
            },
            // 搜索
            handleSearch(page) {
                if (page) {
                    this.pageInfo.page = page;
                }
                this.getData();
            },
            handleDialog(type, coursewareId) {
                if (type === "insert") {
                    // 添加
                    this.formData = this.$options.data().formData;
                    delete this.formData.coursewareId;
                    this.dialogTitle = "添加课件";
                    this.status.dialogOpen = true;
                    this.status.dataFormDisabled = false;
                    return;
                }
                if (type === "update") {
                    // 修改
                    this.dialogTitle = "编辑课件";
                    this.status.dataFormDisabled = false;
                    this.status.dialogOpen = true;
                } else {
                    // 查询
                    this.dialogTitle = "课件信息";
                    this.status.dataFormDisabled = true;
                    this.status.dialogOpen = true;
                }
                // 获取数据
                let params = {
                    method: "POST",
                    coursewareId: coursewareId
                };
                this.$request(params, "/masters/mapper/select/courseware.queryByCoursewareId", (res) => {
                    this.$nextTick(() => {
                        this.formData = res.list[0];
                        if (!this.$util.isEmpty(res.list[0].fileUrl) && !this.$util.isEmpty(res.list[0].fileName)) {
                            let file = {
                                name: res.list[0].fileName,
                                url: res.list[0].fileUrl,
                            }
                            this.fileList.push(file);
                        }
                    });
                }, () => {
                    this.$message.error("获取课件信息失败");
                    this.status.dialogOpen = false;
                });
            },
            // 当弹窗关闭时情况表单状态
            handleResetForm(form) {
                if (form === "searchForm") {
                    this.pageInfo = this.$options.data().pageInfo;
                    this.$refs.searchForm.resetFields();
                    this.handleSearch(1);
                } else if (form === "dataForm") {
                    this.fileList = [];
                    this.formData = this.$options.data().formData;
                    this.$refs.dataForm.resetFields();
                }
            },
            // 提交课件信息
            handleSubmit() {
                this.$refs.dataForm.validate((valid) => {
                    if (valid) {
                        if (this.$util.isEmpty(this.formData.fileUrl)) {
                            this.$message.error(`请上传课件`);
                            return;
                        }

                        this.status.saving = true;
                        let params = this.formData;
                        if(parseInt(this.formData.coursewareType)  === 1){
                            if(this.$util.isEmpty(this.formData.teacherId)){
                                this.$message.error(`老师不能为空`);
                                return;
                            }
                        }else {
                            this.formData.teacherId = null;
                        }

                        params.method = 'POST';
                        this.gradeList.forEach(grade => {
                            if (grade.gradeId === params.gradeId) {
                                params.gradeName = grade.gradeName;
                            }
                        });
                        this.subjectList.forEach(subject => {
                            if (subject.subjectId === params.subjectId) {
                                params.subjectName = subject.subjectName;
                            }
                        })
                        if (!this.$util.isEmpty(params.coursewareId)) {
                            // 修改
                            this.$request(params, "/courseware/updateCourseware", () => {
                                this.$message.success(`修改成功`);
                                this.status.saving = false;
                                this.status.dialogOpen = false;
                                // 刷新数据
                                this.getData();
                            }, () => {
                                this.status.saving = false;
                            });
                        } else {
                            // 添加
                            delete params.coursewareId;

                            this.$request(params, "/courseware/insertCourseware", () => {
                                this.$message.success(`添加成功`);
                                this.status.saving = false;
                                this.status.dialogOpen = false;
                                // 刷新数据
                                this.handleSearch(1);
                            }, () => {
                                this.status.saving = false;
                            });
                        }
                    }
                });
            },
            // 处理删除
            handleDelete(coursewareId, fileUrl) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // 重置密码
                    let params = {
                        method: 'POST',
                        coursewareId: coursewareId
                    };
                    this.$request(params, "/masters/mapper/delete/courseware.deleteCourseware", () => {
                        this.$message.success("删除成功");
                        this.getData();
                    });
                    this.$removeFile(fileUrl);
                });
            },
            // 上传之前，检查文件大小
            beforeUpload(file) {
                const isLt5M = file.size / 1024 / 1024 < 5;
                if (!isLt5M) {
                    this.$message.error("上传文件大小不能超过 5MB!");
                }
                return isLt5M;
            },
            // 文件上传成功回调
            uploadSuccess(res, file) {
                this.formData.fileUrl = res.message;
                this.formData.fileName = file.name;
                // 计算文件大小，保留两位小数
                this.formData.fileSize = (file.size / 1024 / 1024).toFixed(2) + "MB";
                this.fileList.push({name: file.name, url: res.message});
            },
            // 移除文件
            removeFile() {
                this.formData.fileUrl = null;
                this.fileList = [];
                this.$message.success("移除成功");
            },
            // 格式化课件类型
            formatCoursewareType(row) {
                let coursewareType = row.coursewareType.toString();
                for (let i = 0; i < this.coursewareTypeList.length; i++) {
                    if (coursewareType === this.coursewareTypeList[i].itemVal) {
                        return this.coursewareTypeList[i].itemName;
                    }
                }
                return "-";
            },
            formatTeacher(row){
                let teacherName = row.teacherName;
                return !this.$util.isEmpty(teacherName)? teacherName : "-";
            }
        }
    }
</script>
<style>
    /* 当内容过长被隐藏时显示tooltip，须限制tooltip宽度，不能放在scoped中，所以单独写 */
    .el-tooltip__popper {
        max-width: 200px;
    }
</style>
<style lang="less" scoped>
    .courseware-manage {

    }

    .item {
        margin: 4px;
    }

    .download-link {
        font-size: 12px;
        margin-left: 10px;
        margin-right: 10px;
        border-radius: 3px;
        vertical-align: baseline;
    }

    .el-pagination {
        display: flex;
        justify-content: flex-end;
    }
</style>