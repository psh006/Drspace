<template>
    <div class="order-manage">
        订单管理
    </div>
</template>

<script>

    export default {
        name: "order-manage"
    }
</script>

<style scoped lang="less"></style>
