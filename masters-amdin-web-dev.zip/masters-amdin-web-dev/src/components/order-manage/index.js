/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/4/22 0022 11:22
 */

import orderManage from './order-manage';

export default [
    orderManage
]
