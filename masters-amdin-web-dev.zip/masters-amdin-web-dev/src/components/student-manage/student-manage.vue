<template>
    <!-- 学生管理 -->
    <div class="student-manage">
        <!-- 搜索表单 -->
        <el-form ref="searchForm" :model="pageInfo" inline>
            <el-form-item label="姓名">
                <el-input v-model="pageInfo.realName" placeholder="请输入姓名" clearable style="width: 140px;"
                          @input="value=>{this.pageInfo.realName = this.$util.checkCnEnNu(value)}"
                          maxlength="20"></el-input>
            </el-form-item>
            <el-form-item label="年级">
                <el-select v-model="pageInfo.gradeId" clearable style="width: 120px;">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in gradeList" :key="item.gradeId" :label="item.gradeName"
                               :value="item.gradeId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="科目">
                <el-select v-model="pageInfo.subjectId" clearable style="width: 120px;">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in subjectList" :key="item.subjectId" :label="item.subjectName"
                               :value="item.subjectId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="课程">
                <el-select v-model="pageInfo.courseId" style="width: 150px;"
                           clearable filterable remote placeholder="请输入课程名称"
                           :remote-method="searchCourse" :loading="status.courseLoading">
                    <el-option
                            v-for="item in courseList"
                            :key="item.courseId"
                            :label="item.courseName"
                            :value="item.courseId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="家长">
                <el-input v-model="pageInfo.parentName" placeholder="请输入姓名" style="width: 120px;" maxlength="20"
                          @input="value=>{this.pageInfo.parentName = this.$util.checkCnEnNu(value)}"
                          clearable></el-input>
            </el-form-item>
            <el-form-item label="联系方式">
                <el-input v-model="pageInfo.parentContact" placeholder="请输入手机号" style="width: 140px;" maxlength="11"
                          @input="value=>{this.pageInfo.parentContact = this.$util.checkNumber(value)}"
                          clearable></el-input>
            </el-form-item>
            <el-form-item label="入学日期">
                <el-date-picker v-model="pageInfo.entryDate"
                                style="width: 250px;"
                                type="daterange"
                                value-format="yyyy-MM-dd"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"/>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" :loading="status.dataLoading" @click="handleSearch(1)"
                           icon="el-icon-search">查询
                </el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="success" @click="handleDialog('insert')">添加</el-button>
            </el-form-item>
        </el-form>

        <!-- 数据表格 -->
        <el-table :data="data" v-loading="status.dataLoading" type="index" max-height="600px"
                  style="border: 1px solid #EBEEF5; border-bottom: none">
            <el-table-column label="序号" type="index" min-width="50px" align="center"></el-table-column>
            <el-table-column label="姓名" prop="realName" min-width="120px"
                             show-overflow-tooltip align="center"></el-table-column>
            <el-table-column label="昵称" prop="nickName" min-width="120px" align="center" show-overflow-tooltip></el-table-column>
            <el-table-column label="性别" prop="gender" min-width="80px" :formatter="formatGender" align="center"></el-table-column>
            <el-table-column label="年龄" prop="birthday" min-width="80px" :formatter="formatBirthday" align="center"></el-table-column>
            <el-table-column label="年级" prop="gradeId" min-width="100px" :formatter="formatGrade" align="center"></el-table-column>
            <el-table-column label="家长姓名" prop="parentName" min-width="120px" show-overflow-tooltip align="center"></el-table-column>
            <el-table-column label="联系方式" prop="parentContact" min-width="150px" align="center"></el-table-column>
            <el-table-column label="入学日期" prop="entryDate" min-width="100px" align="center"></el-table-column>
            <el-table-column label="课程数量" min-width="100px" prop="courseCount" align="center">
                <template slot-scope="scope">
                    <div v-if="scope.row.courseCount===0">
                        {{scope.row.courseCount}}
                    </div>
                    <el-button type="text" v-else @click.stop="handleStudentCourse(scope.row.studentId)"
                               style="color: #1890ff;">
                        {{scope.row.courseCount}}
                    </el-button>
                </template>
            </el-table-column>
            <el-table-column label="上课次数" prop="recordCount" min-width="100px" align="center"></el-table-column>
            <el-table-column label="下次上课时间" prop="nextCourseTime" min-width="150px" align="center"></el-table-column>
            <el-table-column label="备注" prop="remark" min-width="200px" show-overflow-tooltip align="center"></el-table-column>
            <el-table-column label="操作" min-width="200px" align="center">
                <template slot-scope="scope">
                    <el-button type="text" @click.stop="handleDialog('info',scope.row.studentId)">查看</el-button>
                    <el-button type="text" @click.stop="handleDialog('update',scope.row.studentId)">编辑</el-button>
                    <!--<el-button type="text" @click.stop="handleResetPassword(scope.row.studentId)">重置密码</el-button>-->
                    <el-button type="text" @click.stop="handleTalk(scope.row.studentId)">聊天</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <el-pagination
                layout="total, sizes, prev, pager, next, jumper"
                background
                :current-page="pageInfo.page"
                :page-sizes="[5, 10, 20, 50]"
                :page-size="pageInfo.limit"
                :total="total"
                @size-change="handlePageSize"
                @current-change="handleSearch">
        </el-pagination>

        <!-- 查看、添加、编辑学生的弹窗 -->
        <el-dialog :title="dialogTitle" :visible.sync="status.dialogOpen" @closed="handleResetForm('dataForm')"
                   width="500px" :close-on-click-modal="false">
            <el-form :model="formData" ref="dataForm" :rules="dataFormRules" label-width="110px">
                <el-form-item label="姓名" v-model="formData.realName" prop="realName">
                    <el-input v-model="formData.realName" style="width: 300px" :readonly="status.dataFormDisabled"
                              clearable maxlength="20"></el-input>
                </el-form-item>
                <el-form-item label="昵称" v-model="formData.nickName" prop="nickName">
                    <el-input v-model="formData.nickName" style="width: 300px" :readonly="status.dataFormDisabled"
                              clearable maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="账号" v-model="formData.loginCode" prop="loginCode">
                    <el-input v-model="formData.loginCode" style="width: 300px" :readonly="status.dataFormDisabled"
                              placeholder="请输入手机号"
                              @input="value=>{this.formData.loginCode = this.$util.checkNumber(value,true)}"
                              clearable maxlength="11"></el-input>
                </el-form-item>
                <el-form-item label="性别" prop="gender">
                    <el-select v-model="formData.gender" style="width: 300px" clearable
                               :disabled="status.dataFormDisabled">
                        <el-option
                                v-for="item in genderList"
                                :key="item.itemVal"
                                :label="item.itemName"
                                :value="parseInt(item.itemVal)"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="年级" prop="gradeId">
                    <el-select v-model="formData.gradeId" style="width: 300px" clearable
                               :disabled="status.dataFormDisabled">
                        <el-option v-for="item in gradeList" :key="item.gradeId" :label="item.gradeName"
                                   :value="item.gradeId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="出生日期" prop="birthday">
                    <el-date-picker v-model="formData.birthday"
                                    :readonly="status.dataFormDisabled"
                                    style="width: 300px"
                                    clearable
                                    type="date"
                                    value-format="yyyy-MM-dd"/>
                </el-form-item>
                <el-form-item label="家长姓名" v-model="formData.parentName" prop="parentName">
                    <el-input v-model="formData.parentName" style="width: 300px" :readonly="status.dataFormDisabled"
                              clearable minlength="2" maxlength="20"></el-input>
                </el-form-item>
                <el-form-item label="联系方式" v-model="formData.parentContact" prop="parentContact">
                    <el-input v-model="formData.parentContact" style="width: 300px" maxlength="11"
                              :readonly="status.dataFormDisabled"
                              @input="value=>{this.formData.parentContact = this.$util.checkNumber(value)}"
                              clearable></el-input>
                </el-form-item>
                <el-form-item label="入学日期" prop="entryDate">
                    <el-date-picker v-model="formData.entryDate"
                                    :readonly="status.dataFormDisabled"
                                    style="width: 300px"
                                    clearable
                                    type="date"
                                    value-format="yyyy-MM-dd"/>
                </el-form-item>
                <el-form-item label="备注" prop="remark">
                    <el-input type="textarea" v-model="formData.remark" :readonly="status.dataFormDisabled"
                              maxlength="200" show-word-limit
                              style="width: 300px"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer" v-if="!status.dataFormDisabled">
                    <el-button @click="status.dialogOpen = false">取消</el-button>
                    <el-button type="danger" @click="handleDeleteStudent"
                               v-if="!this.$util.isEmpty(formData.studentId)">删除</el-button>
                    <el-button type="primary" @click="handleSubmit" :loading="status.saving"
                               icon="el-icon-check">保存</el-button>
                </span>
        </el-dialog>

        <!-- 学生课程弹窗 -->
        <el-dialog title="课程情况" :visible.sync="status.courseDialogOpen" width="1200px" :close-on-click-modal="false">
            <el-row :gutter="20">
                <el-col :span="10">
                    <!-- 学生所购课程 -->
                    <el-table :data="courseData" v-loading="status.courseDataLoading" mx-height="460px"
                              style="border: 1px solid #EBEEF5; border-bottom: none"
                              @row-click="handleClickCourse" highlight-current-row>
                        <el-table-column label="序号" type="index" width="50px" align="center"></el-table-column>
                        <el-table-column label="课程名称" prop="courseName" align="center" show-overflow-tooltip></el-table-column>
                        <el-table-column label="课程进度" :formatter="formatCourseHour" align="center"></el-table-column>
                        <el-table-column label="授课老师" prop="lecturerName" align="center"></el-table-column>
                    </el-table>
                    <!--分页组件-->
                    <el-pagination
                            layout="total, prev, pager, next"
                            background
                            :current-page="coursePageInfo.page"
                            :page-size="coursePageInfo.limit"
                            :total="courseDataTotal"
                            @current-change="handleCoursePage">
                    </el-pagination>
                </el-col>
                <el-col :span="14">
                    <el-tabs v-model="activeName">
                        <el-tab-pane label="上课记录" name="first">
                            <!-- 学生课程排课情况 -->
                            <el-table :data="courseRecordData" v-loading="status.courseRecordDataLoading"
                                      style="border: 1px solid #EBEEF5; border-bottom: none"
                                      max-height="405px" :summary-method="getSummaries" show-summary>
                                <el-table-column label="序号" type="index" width="50px" align="center"></el-table-column>
                                <el-table-column label="上课时间" prop="operateTime" width="200px" align="center"></el-table-column>
                                <el-table-column label="参与测验次数" prop="examTimes" align="center"></el-table-column>
                                <el-table-column label="正确次数" prop="rightTimes" align="center"></el-table-column>
                                <el-table-column label="正确率" align="center">
                                    <template slot-scope="scope">
                                        <span v-if="$util.isEmpty(scope.row.rate)">
                                            -
                                        </span>
                                        <span v-else>
                                            {{scope.row.rate + '%'}}
                                        </span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="课后作业成绩" prop="homeworkScore" align="center"></el-table-column>
                            </el-table>
                            <!--分页组件-->
                            <el-pagination
                                    layout="total, prev, pager, next"
                                    background
                                    :current-page="courseRecordPageInfo.page"
                                    :page-size="courseRecordPageInfo.limit"
                                    :total="courseRecordDataTotal"
                                    @current-change="handleCourseRecordPage">
                            </el-pagination>
                        </el-tab-pane>
                        <el-tab-pane label="课时成绩折线图" name="second">
                            <highcharts :options="chartOptions"></highcharts>
                        </el-tab-pane>
                    </el-tabs>
                </el-col>
            </el-row>
        </el-dialog>
    </div>
</template>

<script>
    import {Chart} from 'highcharts-vue'
    import Highcharts from 'highcharts'
    import exportingInit from 'highcharts/modules/exporting'

    export default {
        name: "student-manage",
        components: {
            highcharts: Chart
        },
        data() {
            let validatePhone = (rule, value, callback) => {
                if (!this.$util.isPhoneNumber(value)) {
                    return callback(new Error('请输入正确的手机号码!'));
                }
                return callback();
            };
            let validateParentContact = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                if (!this.$util.isPhoneNumber(value)) {
                    return callback(new Error('请输入正确的手机号码!'));
                }
                return callback();
            };
            let isName = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                let nameReg = /^[\u4E00-\u9FA5.·\u36c3\u4DAE]{2,20}$|^[A-Za-z]{2,20}$/;
                if (!nameReg.test(value)) {
                    return callback(new Error('姓名格式须为2~20个连续的汉字或字母'));
                }
                return callback();
            };
            let isParentName = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                let nameReg = /^[\u4E00-\u9FA5.·\u36c3\u4DAE]{2,20}$|^[A-Za-z]{2,20}$/;
                if (!nameReg.test(value)) {
                    return callback(new Error('姓名格式须为2~20个连续的汉字或字母'));
                }
                return callback();
            };
            let validateBirthday = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                let min = new Date(1970, 1, 1);
                let max = new Date();
                let time = value.split("-");
                let birthday = new Date(time[0], time[1] - 1, time[2]);
                if (birthday.getTime() <= min.getTime() || birthday.getTime() >= max.getTime()) {
                    return callback(new Error('请选择1970年至现在的日期'));
                }
                return callback();
            };
            let validateEntryData = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                let min = new Date(2000, 1, 1);
                let now = new Date();
                let max = new Date(now.getFullYear() + 1, 12, 31);
                let time = value.split("-");
                let entryDate = new Date(time[0], time[1] - 1, time[2]);
                if (entryDate.getTime() <= min.getTime() || entryDate.getTime() >= max.getTime()) {
                    return callback(new Error('请选择2000年至' + (now.getFullYear() + 1) + '年的日期'));
                }
                return callback();
            };
            // 这里是数据中心 这里面的值会驱动页面渲染
            return {
                chartOptions: {
                    //图表标题
                    title: {
                        text: '课时-成绩折线图'
                    },
                    //Y轴
                    yAxis: {
                        title: {
                            text: '分数'
                        },
                        allowDecimals: false
                    },
                    //去掉logo
                    credits: {
                        enabled: false
                    },
                    //去掉打印按钮
                    exporting: {
                        enabled: false
                    },
                    //样式
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'middle'
                    },
                    //数据
                    series: [{
                        name: '分数',
                        data: [] // sample data
                    }],
                    plotOptions: {
                        series: {
                            label: {
                                connectorAllowed: false
                            }
                        }
                    },
                    //y轴
                    xAxis: {
                        title: {
                            text: '课时'
                        },
                        categories: []
                    }
                },
                // 性别列表
                genderList: [],
                // 年级列表
                gradeList: [],
                // 课程列表
                courseList: [],
                // 科目列表
                subjectList: [],
                // 分页参数
                pageInfo: {
                    page: 1,
                    limit: 10,
                    gradeId: "",
                    subjectId: "",
                },
                // 列表数据
                data: [],
                // 数据总条数
                total: 0,
                // 学生所购课程数据
                coursePageInfo: {
                    page: 1,
                    limit: 10,
                },
                courseData: [],
                courseDataTotal: 0,
                // 上课记录
                courseRecordPageInfo: {
                    page: 1,
                    limit: 10,
                },
                courseRecordData: [],
                courseRecordDataTotal: 0,
                activeName: "first",
                // 状态
                status: {
                    dataLoading: false,
                    saving: false,
                    dialogOpen: false,
                    dataFormDisabled: true,
                    courseLoading: false,
                    courseDialogOpen: false,
                    courseDataLoading: false,
                    courseRecordDataLoading: false
                },
                // 学生数据表单
                formData: {
                    studentId: "",
                    realName: "",
                    nickName: "",
                    loginCode: "",
                    gender: "",
                    birthday: "",
                    parentName: "",
                    parentContact: "",
                    entryDate: "",
                    gradeId: "",
                    remark: ""
                },
                // 弹窗标题
                dialogTitle: "添加学生",
                // 表单校验规则
                dataFormRules: {
                    realName: [
                        {validator: isName, trigger: 'blur'}
                    ],
                    nickName: [
                        {required: true, message: '昵称不能为空', trigger: 'blur'}
                    ],
                    gender: [
                        {required: true, message: '性别不能为空', trigger: 'change'}
                    ],
                    loginCode: [
                        {required: true, message: '账号不能为空', trigger: 'blur'},
                        {validator: validatePhone, trigger: 'blur'}
                    ],
                    gradeId: [
                        {required: true, message: '年级不能为空', trigger: 'change'}
                    ],
                    parentName: [
                        {validator: isParentName, trigger: 'blur'}
                    ],
                    parentContact: [
                        {validator: validateParentContact, trigger: 'blur'}
                    ],
                    entryDate: [
                        {validator: validateEntryData, trigger: 'blur'}
                    ],
                    birthday: [
                        {validator: validateBirthday, trigger: 'blur'}
                    ]
                },
                //列表统计
                studentCourseTotal: {}
            }
        },
        // created函数会在页面渲染完成之前加载，一般在这里面请求数据
        mounted() {
            // 获取列表数据
            this.handleSearch(1);
            // 年级数据初始化
            this.gradeList = [];
            let params = {
                method: 'POST',
            }
            this.$request(params, "/grade/gradeList", (res) => {
                this.gradeList = res.list;
            });
            // 科目数据初始化
            this.subjectList = [];
            this.$request(params, "/subject/subjectList", (res) => {
                this.subjectList = res.list;
            });
            this.searchCourse();
            // 性别字典
            this.genderList = this.$dict.getDictByCode('GENDER') || [];
        },
        // 在这里面定义页面所需函数
        methods: {
            // 请求列表数据
            getData() {
                let params = {...this.pageInfo};
                if (params.entryDate && params.entryDate.length >= 2) {
                    params.startTime = params.entryDate[0] + " 00:00:00";
                    params.endTime = params.entryDate[1] + " 23:59:59";
                    delete params.entryDate;
                }

                this.status.dataLoading = true;
                // 这里请求数据
                params.method = 'POST';
                this.$request(params, "/student/queryStudent", (res) => {
                    this.data = res.list;
                    this.total = res.total;
                    this.status.dataLoading = false;
                }, () => {
                    this.$message.error("获取数据失败");
                    this.total = 0;
                    this.data = [];
                    this.status.dataLoading = false;
                });
            },
            // 根据课程名搜索课程
            searchCourse(courseName) {
                if (!this.$util.isEmpty(courseName)) {
                    this.courseLoading = true;
                    let params = {
                        courseName: courseName,
                        method: 'POST'
                    }
                    this.$request(params, "/masters/course/queryCourseByName", (res) => {
                        this.courseLoading = false;
                        this.courseList = res.list;
                    }, () => {
                        this.courseList = [];
                    });
                } else {
                    let params = {
                        courseName: '',
                        method: 'POST'
                    }
                    this.$request(params, "/masters/course/queryCourseByName", (res) => {
                        this.courseList = res.list;
                    }, () => {
                        this.courseList = [];
                    });
                }
            },
            // 每页几条
            handlePageSize(limit) {
                this.pageInfo.limit = limit;
                this.handleSearch(1);
            },
            // 搜索
            handleSearch(page) {
                if (page) {
                    this.pageInfo.page = page;
                }
                this.getData();
            },
            handleDialog(type, studentId) {
                if (type === "insert") {
                    // 添加
                    this.formData = this.$options.data().formData;
                    this.formData.studentId = '';
                    this.dialogTitle = "添加学生";
                    this.status.dialogOpen = true;
                    this.status.dataFormDisabled = false;
                    return;
                }
                if (type === "update") {
                    // 修改
                    this.dialogTitle = "编辑学生";
                    this.status.dataFormDisabled = false;
                    this.status.dialogOpen = true;
                } else {
                    // 查询
                    this.dialogTitle = "学生信息";
                    this.status.dataFormDisabled = true;
                    this.status.dialogOpen = true;
                }
                // 获取数据
                let params = {
                    method: "POST",
                    studentId: studentId
                };
                this.$request(params, "/student/queryStudentById", (res) => {
                    this.$nextTick(() => {
                        this.formData = res.list[0];
                    });
                }, () => {
                    this.$message.error("获取学生信息失败");
                    this.status.dialogOpen = false;
                });
            },
            // 重置密码
            handleResetPassword(studentId) {
                this.$confirm('确定要重置密码吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // 重置密码
                    let params = {
                        method: 'POST',
                        studentId: studentId
                    };
                    this.$request(params, "/student/resetPassword", () => {
                        this.$message.success(`重置成功`);
                        this.getData();
                    });
                });
            },
            // 当弹窗关闭时情况表单状态
            handleResetForm(form) {
                if (form === "searchForm") {
                    this.pageInfo = this.$options.data().pageInfo;
                    this.$refs.searchForm.resetFields();
                    this.handleSearch(1);
                } else if (form === "dataForm") {
                    this.formData = this.$options.data().formData;
                    this.$refs.dataForm.resetFields();
                }
            },
            handleDeleteStudent(){
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // 重置密码
                    let params = {
                        method: 'POST',
                        studentId: this.formData.studentId
                    };
                    this.$request(params, "/masters/mapper/delete/student.deleteStudent", () => {
                        this.$message.success(`删除成功`);
                        this.status.dialogOpen = false;
                        this.getData();
                    });
                });
            },
            // 提交学生信息
            handleSubmit() {
                this.$refs.dataForm.validate((valid) => {
                    if (valid) {
                        this.status.saving = true;
                        let params = this.formData;
                        params.method = 'POST';
                        if (!this.$util.isEmpty(params.gradeId)) {
                            this.gradeList.forEach(grade => {
                                if (grade.gradeId === params.gradeId) {
                                    params.gradeName = grade.gradeName;
                                }
                            })
                        }
                        if (!this.$util.isEmpty(params.studentId)) {
                            // 修改
                            this.$request(params, "/student/updateStudent", () => {
                                this.$message.success(`修改成功`);
                                this.status.saving = false;
                                this.status.dialogOpen = false;
                                // 刷新数据
                                this.getData();
                            }, () => {
                                this.status.saving = false;
                            });
                        } else {
                            // 添加
                            delete params.studentId;
                            this.$request(params, "/student/insertStudent", () => {
                                this.$message.success(`添加成功`);
                                this.status.saving = false;
                                this.status.dialogOpen = false;
                                // 刷新数据
                                this.handleSearch(1);
                            }, () => {
                                this.status.saving = false;
                            });
                        }
                    }
                });
            },
            // 打开学生课程弹窗并获取数据
            handleStudentCourse(studentId) {
                exportingInit(Highcharts);
                this.coursePageInfo.studentId = studentId;
                this.courseRecordPageInfo.studentId = studentId;
                this.activeName = "first";
                this.status.courseDialogOpen = true;
                this.status.courseDataLoading = true;
                let params = this.coursePageInfo;
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/student.queryStudentCourse", (res) => {
                    this.courseData = res.list;
                    this.courseDataTotal = res.total;
                    if (this.courseData.length > 0) {
                        this.courseRecordPageInfo.courseId = this.courseData[0].courseId;
                        setTimeout(() => {
                            this.handleClickCourse(this.courseData[0]);
                        }, 500)
                    }
                    this.status.courseDataLoading = false;
                }, () => {
                    this.courseData = [];
                    this.courseDataTotal = 0;
                    this.status.courseDataLoading = false;
                });
            },
            // 获取课程数据
            getCourseData() {
                this.status.courseDataLoading = true;
                let params = this.coursePageInfo;
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/student.queryStudentCourse", (res) => {
                    this.courseData = res.list;
                    this.courseDataTotal = res.total;
                    this.status.courseDataLoading = false;
                }, () => {
                    this.courseData = [];
                    this.courseDataTotal = 0;
                    this.status.courseDataLoading = false;
                });
            },
            handleCoursePage(page) {
                this.coursePageInfo.page = page;
                this.getCourseData();
            },
            // 处理学生所购课程排课情况
            handleClickCourse(row) {
                this.courseRecordPageInfo.courseId = row.courseId;
                this.queryStudentCourseTotal();
            },
            handleCourseRecordPage(page) {
                this.courseRecordPageInfo.page = page;
                this.getCourseRecordData();
            },
            // 获取上课记录数据
            getCourseRecordData() {
                this.status.courseRecordDataLoading = true;
                let params = this.courseRecordPageInfo;
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/student.queryStudentCourseInfo", (res) => {
                    this.$nextTick(() => {
                        this.courseRecordData = res.list;
                        this.courseRecordDataTotal = res.total;
                        this.status.courseRecordDataLoading = false;
                    });
                }, () => {
                    this.$nextTick(() => {
                        this.courseRecordData = [];
                        this.courseRecordDataTotal = 0;
                        this.status.courseRecordDataLoading = false;
                    });
                });
            },
            queryStudentCourseTotal() {
                let params = {
                    method: 'POST',
                    studentId: this.courseRecordPageInfo.studentId,
                    courseId: this.courseRecordPageInfo.courseId
                };
                if (!this.$util.isEmpty(params.studentId) && !this.$util.isEmpty(params.courseId)) {
                    this.$request(params, "/student/queryStudentCourseTotal", (res) => {
                        this.$nextTick(() => {
                            this.studentCourseTotal = res.list[0] || {};
                        });
                        this.handleCourseRecordPage(1)
                    }, () => {
                        this.studentCourseTotal = {};
                        this.handleCourseRecordPage(1);
                    });
                }
                this.getCourseChartData();
            },
            // 获取课程详情总计
            getSummaries() {
                let sums = [];
                sums[0] = "总计";
                sums[1] = "--";
                sums[2] = this.studentCourseTotal.totalExamTimes;
                sums[3] = this.studentCourseTotal.totalRightTimes;
                sums[4] = this.studentCourseTotal.avgRate;
                sums[5] = this.studentCourseTotal.avgScore;
                return sums;
            },
            // 获取折线图数据
            getCourseChartData() {
                let params = {
                    method: 'POST',
                    studentId: this.courseRecordPageInfo.studentId,
                    courseId: this.courseRecordPageInfo.courseId
                };
                this.$request(params, "/student/queryStudentScoreInfo", (res) => {
                    this.chartOptions.xAxis.categories = res.list[0].xList || [];
                    this.chartOptions.series[0].data = res.list[0].yList || [];
                }, () => {
                    this.chartOptions.xAxis.categories = [];
                    this.chartOptions.series.data = [];
                });
            },
            // 聊天
            handleTalk(studentId) {
                this.$store
                    .dispatch('checkoutConversation', `C2C${studentId}`)
                    .then(() => {
                        this.$store.commit("setShowConversation", true);
                    }).catch(() => {
                    this.$store.commit('showMessage', {
                        message: '此学生可能没有登录过系统',
                        type: 'warning'
                    })
                });
            },
            // 格式化性别
            formatGender(row) {
                let gender = row.gender.toString();
                for (let i = 0; i < this.genderList.length; i++) {
                    if (gender === this.genderList[i].itemVal) {
                        return this.genderList[i].itemName;
                    }
                }
                return "-";
            },
            // 根据出生日期计算年龄
            formatBirthday(row) {
                let birthday = row.birthday;
                if(!this.$util.isEmpty(birthday)){
                    let birthYear = birthday.split("-")[0];
                    let nowYear = new Date().getFullYear();
                    return nowYear - birthYear;
                }else {
                    return "-";
                }
            },
            // 根据总课时和已完成课时得到课程进度
            formatCourseHour(row) {
                if (row.sumCourseHour != null && row.finishedCourseHour != null) {
                    return row.finishedCourseHour + "/" + row.sumCourseHour;
                }
            },
            // 格式化年级
            formatGrade(row) {
                let gradeId = row.gradeId + "";
                for (let i = 0; i < this.gradeList.length; i++) {
                    if (gradeId === this.gradeList[i].gradeId) {
                        return this.gradeList[i].gradeName;
                    }
                }
                return "-";
            }
        }
    }
</script>
<style>
    /* 当内容过长被隐藏时显示tooltip，须限制tooltip宽度，不能放在scoped中，所以单独写 */
    .el-tooltip__popper {
        max-width: 200px;
    }
</style>
<style lang="less" scoped>
    /*less 是css预编译语言，比css更好用*/
    /*scoped 是限制样式只在本组件使用*/
    .student-manage {

    }

    .el-tooltip__popper {
        max-width: 80%
    }

    .el-pagination {
        display: flex;
        justify-content: flex-end;
    }
</style>
