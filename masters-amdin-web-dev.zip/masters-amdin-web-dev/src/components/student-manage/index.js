import studentManage from './student-manage';
import myStudent from './my-student';
export default [
    studentManage,
    myStudent,
]