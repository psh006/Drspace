import courseManage from './course-manage';
import courseManageTeacher from './course-manage-teacher';

export default [
    courseManage,
    courseManageTeacher
]
