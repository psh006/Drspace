<!--suppress RequiredAttributes -->
<template>
    <div class="course-manage-teacher">
        <div>
            <el-calendar v-model="selectDay" class="calendar" ref="calendar" v-loading="status.getCalenderLoading">
                <template
                        slot="dateCell"
                        slot-scope="{date, data}">
                    <div>
                        <div>{{ data.day.split('-').slice(2).join('') }}</div>
                        <div v-for="(item,index) in courseDateList" :key="index">
                            <div class="course-state" v-if="(item.courseTimeDate).includes(data.day)">
                                <div class="course-count">{{item.totalCourse}}节课</div>
                                <div class="course-icon">
                                    <p class="course-morning" v-show="item.morningCourse === 1"></p>
                                    <p class="course-afternoon" v-show="item.afternoonCourse === 1"></p>
                                </div>
                            </div>
                            <div v-else></div>
                        </div>
                    </div>
                </template>
            </el-calendar>
            <div class="icon-explain">
                <p>注：</p>
                <p class="course-morning"></p>
                <p>上午有课</p>
                <p class="course-afternoon"></p>
                <p>下午有课</p>
            </div>
        </div>

        <div class="teacher-course" v-loading="status.getCourseLoading">
            <div class="course-date">{{currentDay}}<span style="margin-right: 18px"></span>{{currentWeek}}</div>
            <div class="course-number">
                教师课程（{{courseList.length}}）
            </div>
            <div v-if="courseList.length>0">
                <div class="course-info" v-for="(item,index) in courseList" :key="index">
                    <div class="course-details">
                        <div class="course-detail">
                            <div class="detail-one">
                                {{item.courseName}}
                            </div>
                            <div class="detail-two">
                                <div class="course-difficult">难度：</div>
                                <el-rate v-model="item.hardLevel" disabled :colors="rateColors">
                                </el-rate>
                                <div class="course-time">
                                    时间：{{$util.formatDate(item.startTime,'yyyy-MM-dd HH:mm') + "~" +
                                    $util.formatDate(item.endTime,'hh-mm')}}
                                    （{{Math.floor((new Date(item.endTime).getTime() - new
                                    Date(item.startTime).getTime()) / 60000)}}分钟）
                                </div>
                            </div>
                            <div class="detail-three">
                                <div class="course-teachers">
                                    <div class="course-teacher-image">
                                        <el-avatar :src="$getFileUrl+item.lecturerAvatar"></el-avatar>
                                    </div>
                                    <div class="course-teacher">
                                        <div class="course-teacher-name">{{item.lecturerName}}</div>
                                        <div class="course-teacher-type">授课老师</div>
                                    </div>
                                </div>
                                <div class="course-teachers">
                                    <div class="course-teacher-image">
                                        <el-avatar :src="$getFileUrl+item.managerAvatar"></el-avatar>
                                    </div>
                                    <div class="course-teacher">
                                        <div class="course-teacher-name">{{item.managerTeacherName}}</div>
                                        <div class="course-teacher-type">学习管理师</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="course-progress">
                            <el-progress
                                    type="circle"
                                    :percentage="parseFloat((item.finishedCourseHour/item.allCourseHour*100).toFixed(0))"
                                    :width="80"
                                    :height="80"
                                    color="#27B148"
                                    :stroke-width="10"
                                    stroke-linecap="butt"
                                    :format="()=>{
                                        return `${item.finishedCourseHour || 0}/${item.allCourseHour}`
                                    }">
                            </el-progress>
                        </div>
                    </div>
                    <div class="course-button">
                        <el-button type="primary" :loading="status.getRoomIdLoading" @click="getRoomInfo(item)">进入教室
                        </el-button>
                        <el-button type="primary" @click="handleCourseHourCourseware(item.courseId,item.courseName)">
                            课程资料
                        </el-button>
                        <el-button type="primary" :loading="status.getRoomIdLoading || status.getVideoLoading"
                                   @click="getRoomInfo(item,true)">观看回放
                        </el-button>
                        <el-button type="primary" @click="homework(item)">课后作业</el-button>
                    </div>
                </div>
                <!--课程列表分页-->
                <el-pagination
                        layout="prev, pager, next"
                        :current-page="queryCourseListParams.page"
                        :page-size="queryCourseListParams.limit"
                        :total="courseListLength"
                        @current-change="changeCourseListPage"
                        :hide-on-single-page="status.showCourseListPage"
                        style="border:none; margin-top: 10px"
                >
                </el-pagination>
            </div>
            <div v-else class="no-data">暂无课程</div>
        </div>

        <!-- 课程资料弹窗 -->
        <el-dialog :visible.sync="status.courseHourCoursewareDialogOpen" :title="courseHourCoursewareDialogTitle"
                   width="835px" :close-on-click-modal="false">
            <el-tabs v-model="coursewareActiveName">
                <el-tab-pane label="课堂课件" name="courseHourCourseware">
                    <!-- 搜索表单 -->
                    <el-form :model="courseHourCoursewarePageInfo" inline>
                        <el-form-item label="课时">
                            <el-select v-model="courseHourCoursewarePageInfo.courseHourId" clearable>
                                <el-option label="全部" value=""></el-option>
                                <el-option v-for="item in courseHourList" :key="item.courseHourId"
                                           :label="item.courseHourNumerical"
                                           :value="item.courseHourId"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="名称">
                            <el-input v-model="courseHourCoursewarePageInfo.fileName"
                                      placeholder="请输入文件名称" clearable
                                      maxlength="50"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" :loading="status.courseHourCoursewareDataLoading"
                                       @click="handleCourseHourCoursewarePage(1)"
                                       icon="el-icon-search">查询
                            </el-button>
                        </el-form-item>
                    </el-form>
                    <!-- 课堂课件 -->
                    <el-table :data="courseHourCoursewareData" v-loading="status.courseHourCoursewareDataLoading"
                              style="border: 1px solid #EBEEF5; border-bottom: none">
                        <el-table-column label="文件名称" prop="fileName" min-width="150px"
                                         show-overflow-tooltip></el-table-column>
                        <el-table-column label="文件大小" prop="fileSize" min-width="100px"></el-table-column>
                        <el-table-column label="上传时间" prop="operateTime" min-width="150px"></el-table-column>
                        <el-table-column label="操作" width="80px">
                            <template slot-scope="scope">
                                <el-button type="text"
                                           @click.stop="handleDeleteCourseHourCourseware(scope.row)">删除
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页组件-->
                    <el-pagination
                            layout="total, sizes, prev, pager, next, jumper"
                            background
                            :current-page="courseHourCoursewarePageInfo.page"
                            :page-sizes="[5, 10, 20, 50]"
                            :page-size="courseHourCoursewarePageInfo.limit"
                            :total="courseHourCoursewareTotal"
                            @size-change="handleCourseHourCoursewarePageSize"
                            @current-change="handleCourseHourCoursewarePage">
                    </el-pagination>
                </el-tab-pane>
                <el-tab-pane label="添加课件" name="addCourseware">
                    <!-- 搜索表单 -->
                    <el-form :model="coursewarePageInfo" inline>
                        <el-form-item label="属性">
                            <el-select v-model="coursewarePageInfo.coursewareType" clearable style="width: 120px;">
                                <el-option v-for="item in coursewareTypeList" :key="item.itemVal" :label="item.itemName"
                                           :value="item.itemVal"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="名称">
                            <el-input v-model="coursewarePageInfo.fileName" placeholder="请输入课件名称" clearable
                                      style="width: 150px;"
                                      maxlength="50"></el-input>
                        </el-form-item>
                        <el-form-item label="年级">
                            <el-select v-model="coursewarePageInfo.gradeId" clearable style="width: 120px;">
                                <el-option label="全部" value=""></el-option>
                                <el-option v-for="item in gradeList" :key="item.gradeId" :label="item.gradeName"
                                           :value="item.gradeId"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="科目">
                            <el-select v-model="coursewarePageInfo.subjectId" clearable style="width: 120px;">
                                <el-option label="全部" value=""></el-option>
                                <el-option v-for="item in subjectList" :key="item.subjectId" :label="item.subjectName"
                                           :value="item.subjectId"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" :loading="status.coursewareDataLoading"
                                       @click="handleCoursewarePage(1)"
                                       icon="el-icon-search">查询
                            </el-button>
                        </el-form-item>
                    </el-form>
                    <!-- 数据表格 -->
                    <el-table :data="coursewareData" v-loading="status.coursewareDataLoading"
                              style="border: 1px solid #EBEEF5; border-bottom: none" type="index">
                        <el-table-column label="文件名称" prop="fileName" min-width="250px"
                                         show-overflow-tooltip></el-table-column>
                        <el-table-column label="年级" prop="gradeName" min-width="100px"></el-table-column>
                        <el-table-column label="科目" prop="subjectName" min-width="100px"></el-table-column>
                        <el-table-column label="文件大小" prop="fileSize"></el-table-column>
                        <el-table-column label="上传时间" prop="operateTime" min-width="150px"></el-table-column>
                        <el-table-column label="操作" width="80px">
                            <template slot-scope="scope">
                                <el-button type="text" @click.stop="handleAddCourseware(scope.row.coursewareId)">添加
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页组件-->
                    <el-pagination
                            layout="total, sizes, prev, pager, next, jumper"
                            background
                            :current-page="coursewarePageInfo.page"
                            :page-sizes="[5, 10, 20, 50]"
                            :page-size="coursewarePageInfo.limit"
                            :total="coursewareTotal"
                            @size-change="handleCoursewarePageSize"
                            @current-change="handleCoursewarePage">
                    </el-pagination>
                </el-tab-pane>
            </el-tabs>
        </el-dialog>
        <el-dialog title="添加课件" :visible.sync="status.addCoursewareDialogOpen" width="300px"
                   @close="courseHourCousewareFormData=$options.data().courseHourCousewareFormData">
            <el-form>
                <el-form-item label="请选择课时" required>
                    <el-select v-model="courseHourCousewareFormData.courseHourId" clearable style="width: 150px;">
                        <el-option v-for="item in courseHourList" :key="item.courseHourId"
                                   :label="item.courseHourNumerical"
                                   :value="item.courseHourId"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                    <el-button @click="status.addCoursewareDialogOpen = false">取消</el-button>
                    <el-button type="primary" @click="handleSubmit" :loading="status.addCoursewareSaving"
                               :disabled="$util.isEmpty(courseHourCousewareFormData.courseHourId)"
                               >保存</el-button>
            </span>
        </el-dialog>

        <div>
            <el-dialog :title="homeworkDialogTitle" :visible.sync="status.homeworkDialogVisible"
                       @closed="homeworkDialogClose">
                <el-table style="border: 1px solid #EBEEF5; border-bottom: none"
                          ref="homeworkList" :data="homeworkList" height="205"
                          highlight-current-row>
                    <el-table-column property="courseHourNumerical" label="课时号" min-width="50px"></el-table-column>
                    <el-table-column property="testPaperName" label="名称" min-width="400px" show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column label="操作" min-width="120px">
                        <template slot-scope="scope">
                            <el-button type="text" @click.stop="homeworkListClickRow(scope.row)"
                                       v-if="!$util.isEmpty(scope.row.testPaperId)">完成情况
                            </el-button>
                            <el-button type="text" @click.stop="deleteCourseHomework(scope.row)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <el-pagination background align="right"
                               layout="total, sizes, prev, pager, next, jumper"
                               :current-page="searchParams.page"
                               :page-sizes="[5, 10, 20, 50]"
                               :page-size="searchParams.limit"
                               :total="classListTotal"
                               @size-change="handleSizeChange"
                               @current-change="handleCurrentChange">
                </el-pagination>

                <div style="margin-top: 20px">
                    <el-tabs v-model="homeworkActiveName" @tab-click="handleClick">
                        <el-tab-pane label="我的试卷" name="myPaper"></el-tab-pane>
                        <el-tab-pane label="公共试卷" name="publicPaper"></el-tab-pane>
                    </el-tabs>
                    <el-form inline align="left">
                        <el-input v-model="queryPaperFrame" placeholder="请输入您想搜索的试卷"
                                  maxlength="50" style="width: 95%"></el-input>
                        <el-button type="primary" icon="el-icon-search" style="margin-left: 1px"
                                   @click="queryPaperButton"></el-button>
                    </el-form>
                    <el-table ref="paperList" :data="paperList" height="205"
                              highlight-current-row
                              style="border: 1px solid #EBEEF5; border-bottom: none;margin-top: 5px;">
                        <el-table-column type="index" label="序号" min-width="50"></el-table-column>
                        <el-table-column property="testPaperName" label="试卷名称" min-width="150"
                                         show-overflow-tooltip></el-table-column>
                        <el-table-column property="gradeName" label="年级" min-width="80"></el-table-column>
                        <el-table-column property="subjectName" label="科目" min-width="80"></el-table-column>
                        <el-table-column property="hardLevel" label="难度" min-width="50">
                            <template slot-scope="scope">
                                <span v-if="scope.row.hardLevel=== 1">{{difficultyType(scope.row)}}</span>
                                <span v-else-if="scope.row.hardLevel === 2">  {{difficultyType(scope.row)}} </span>
                                <span v-else-if="scope.row.hardLevel === 3">  {{difficultyType(scope.row)}} </span>
                            </template>
                        </el-table-column>
                        <el-table-column property="themeNum" label="题目数量" min-width="80"></el-table-column>
                        <el-table-column property="isSubjective" label="是否主观" min-width="80">
                            <template slot-scope="scope">
                                <span v-if="scope.row.isSubjective=== 1">{{isSubjectiveType(scope.row)}}</span>
                                <span v-else-if="scope.row.isSubjective === 2">  {{isSubjectiveType(scope.row)}} </span>
                            </template>
                        </el-table-column>
                        <el-table-column property="operateTime" label="上传日期" min-width="150"></el-table-column>
                        <el-table-column label="操作" min-width="80">
                            <template slot-scope="scope">
                                <el-button type="text" @click.stop="paperListClickRow(scope.row)">设置
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination background align="right"
                                   layout="total, sizes, prev, pager, next, jumper"
                                   :current-page="searchParams.PaperPage"
                                   :page-sizes="[5, 10, 20, 50]"
                                   :page-size="searchParams.PaperLimit"
                                   :total="paperClassListTotal"
                                   @size-change="publicPaperHandleSizeChange"
                                   @current-change="publicPaperHandleCurrentChange">
                    </el-pagination>
                </div>
            </el-dialog>
        </div>
        <div>
            <el-dialog title="设置课后作业" :visible.sync="status.aadHomeworkDialogVisible" width="300px" @closed="aadHomeworkDialogClose">
                <el-form>
                    <el-form-item label="请选择课时" label-width="90px">
                        <el-select v-model="addHomeworkParams.courseHourId" clearable style="width: 150px;">
                            <el-option v-for="item in courseHourList" :key="item.courseHourId"
                                       :label="item.courseHourNumerical"
                                       :value="item.courseHourId"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="完成时间" label-width="90px">
                        <el-date-picker style="width: 150px;" v-model="addHomeworkParams.mustFinishTime" type="datetime"
                                        value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item>
                </el-form>
                <span class="dialog-footer" slot="footer" style="margin-right: 20px">
                    <el-button @click="status.aadHomeworkDialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="confirmAddHomework"
                               :loading="status.addCourseHomeworkSaving"
                               :disabled="$util.isEmpty(addHomeworkParams.courseHourId)">保存</el-button>
                </span>
            </el-dialog>
        </div>
        <!-- 查看课后作业弹框   -->
        <el-dialog title="课后作业" :visible.sync="HomeworkAfterClass" width="400px">
            <el-table :data="workData">
                <el-table-column prop="classHour" label="课时" width="50"></el-table-column>
                <el-table-column prop="name" label="名称" width="260">
                </el-table-column>
                <el-table-column label="操作" width="50">
                    <el-button type="text" @click="lookJobDetailsMethod()">查看</el-button>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <el-pagination
                    background
                    small
                    layout="prev, pager, next"
                    :total="70"
                    style="border: none"
            >
            </el-pagination>
        </el-dialog>
        <!--课后作业详情页面 弹框-->
        <el-dialog title="完成情况" :visible.sync="homeWorkDetailsDialog" width="650px">
            <div>{{ homeworkCompletionText }}</div>
            <div>
                <el-table :data="workDetailData" style="border:1px solid #D9D9D9;margin-top: 20px">
                    <el-table-column prop="studentName" label="姓名" min-width="90" >
                        <template slot-scope="scope">
                            <el-tooltip class="item" effect="dark" :content="scope.row.studentName" placement="top">
                                <p style="width: 60px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">{{scope.row.studentName}}</p>
                            </el-tooltip>
                        </template>
                    </el-table-column>
                    <el-table-column prop="isFinish" label="完成情况" min-width="100">
                        <template slot-scope="scope">
                            <span v-if="scope.row.isFinish === 1"> 已完成 </span>
                            <span v-else style="color: #FD4D4D"> 未完成</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="studentScore" label="得分" min-width="78"></el-table-column>
                    <el-table-column prop="finishTime" label="完成时间" min-width="200"></el-table-column>
                    <el-table-column label="操作" min-width="140">
                        <template slot-scope="scope">
                            <el-button type="text" @click="lookAnswerSheetDetailsMethods(scope.row)" v-if="scope.row.isFinish===1">查看</el-button>
                            <el-button type="text" @click.stop="handleTalk(scope.row.studentId)">聊天</el-button>
                            <el-button type="text" @click="Correction(scope.row)"
                                       v-if="scope.row.isFinish === 1 && $util.isEmpty(scope.row.studentScore)">批改
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </el-dialog>
        <!-- 课后作业答题卡-->
        <el-dialog :title="testPaperAnswerList.testPaperName" :visible.sync="HomeWorkDetailsAnswerSheetDialog"
                   width="1200px" top="60px" @closed="subjectDialogFormVisibleClosed">
            <div class="conten" >
                <div class="homeword-img">
                    <el-scrollbar style="height:100%" >
                        <div class="fileimg" v-for="item in fileList" :key="item.file_id">
                        <img style="width: 100%;height: 100%" v-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.jpg' ||  item.file_url.substring(item.file_url.lastIndexOf('.'))=='.png' || item.file_url.substring(item.file_url.lastIndexOf('.'))==='.jpeg' " :src="$getFileUrl+item.file_url">
                            <div class="pdf" v-else-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.pdf'">
                                <div  style="width:200px;margin-top: 20px;margin-left: 20px">
                                    <!--    上一页-->
                                    <span @click="changePdfPage(0)" >上一页</span>
                                    {{currentPage}} / {{pageCount}}
                                    <!--下一页-->
                                    <span  @click="changePdfPage(1)">下一页</span>
                                </div>
                                <pdf ref="myPDF"
                                     :src="$getFileUrl+item.file_url"
                                     :page="currentPage"
                                     @num-pages="pageCount=$event"
                                     @page-loaded="currentPage=$event"
                                     @loaded="loadPdfHandler"
                                >
                                </pdf>
                            </div>
                            <div v-else style="height:700px;width: 99%;position: relative">
                                <div style="position: absolute;width: 100%;height: 88px;background-color: white;"></div>
                                <iframe  style="height:650px;width: 100%" :src="'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com'+item.file_url" ></iframe>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
                <div class="homeword-conten">
                    <el-scrollbar style="height:100%">
                        <div class="title">
                            <p><span class="text-underline">{{testPaperAnswerList.testPaperName}}</span></p>
                        </div>
                        <div class="achievement" v-if="testPaperAnswerList.homework_score>=0"><span
                                class="achievementscore"  v-if="scoreShow===true">成绩:</span><span class="text-underline">{{testPaperAnswerList.homework_score}}</span>
                        </div>
                        <template v-for="(answeritem,indexId) in answerList">
                            <div class="question-type" v-if="answeritem.topic_type === 2" :key="indexId">
                                <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}}, </span><span style="padding-right: 10px">填空题</span><span>{{fillFaction.fraction}}</span>
                                </p>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write">
                                                <span   class="theme-number">{{item.theme_number}}, </span >
                                                <div class="fill-student-answer" >{{item.student_answer}}</div>
                                            </div>
                                            <div>
                                            </div>
                                        </div>
                                        <div class="fill-scoring" v-if="isShowThemeSolve">
                                           <div class="fill-scoring-form">
                                               <el-form inline ref="scoreRef">
                                                   <el-form-item label="打分 :" prop="score">
                                                       <el-input maxlength="3" style="width: 60px"
                                                                 v-model="item.student_score"
                                                                 @input="value=>{item.student_score = $util.checkNumber(value)}"></el-input>
                                                   </el-form-item>
                                               </el-form>
                                           </div>
                                            <div class="ider" v-if="item.hasSolve===1">
                                                <el-checkbox :checked="checked" v-model="item.theme_solve" label="1"
                                                             @change="value=>{themSolve(item,value)}">
                                                    解题思路
                                                </el-checkbox>
                                            </div>
                                            <div v-else class="ider"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="question-type" v-if="answeritem.topic_type === 1" :key="indexId">
                                <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span
                                        style="padding-right: 10px">选择题</span><span>{{choseFaction.fraction}} </span>
                                </p>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="theme-number">{{item.theme_number}} , </span>
                                                <div class="chose-button">{{item.student_answer}}</div>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer === item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div >
                                                <div class="ider"  v-if="item.hasSolve===1">
                                                    <el-checkbox :checked="checked" v-model="item.theme_solve"  label="1" @change="value=>{themSolve(item,value)}">
                                                        解题思路
                                                    </el-checkbox>
                                                </div>
                                                <div v-else class="ider"></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="question-type" v-if="answeritem.topic_type === 3" :key="indexId">
                                <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}}, </span><span
                                        style="padding-right: 10px">判断题</span><span>{{judgeFaction.fraction}} </span>
                                </p>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="theme-number">{{item.theme_number}} , </span>
                                                <div v-if="item.is_right===1"><i class="el-icon-check hook"></i></div>
                                                <div v-else><i class="el-icon-close fork"></i></div>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer===item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div>
                                                <div class="ider" v-if="item.hasSolve===1">
                                                    <el-checkbox :checked="checked" v-model="item.theme_solve" label="1"
                                                                 @change="value=>{themSolve(item,value)}">
                                                        解题思路
                                                    </el-checkbox>
                                                </div>
                                                <div v-else class="ider"></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="question-type" v-if="answeritem.topic_type ===4" :key="indexId">
                                <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)">
                                    <span>{{answeritem.topic_index}} , </span><span>解答题 </span> <span>{{subjectiveFaction.fraction}}</span></p>
                                <div class="question">
                                    <div class="answer-question" v-for="(item,indexId) in answeritem.themeList" :key="indexId">
                                        <div class="scoring">
                                            <div>
                                                <div class="ider" v-if="item.hasSolve===1">
                                                    <el-checkbox :checked="checked" v-model="item.theme_solve" label="1"
                                                                 @change="value=>{themSolve(item,value)}">
                                                        解题思路
                                                    </el-checkbox>
                                                </div>
                                                <div v-else class="ider"></div>
                                            </div>
                                            <div style="margin-right: 35px">老师批改内容</div>
                                        </div>
                                        <div class="answer">
                                            <div class="reple" style="height: 105px" @click="look"
                                                 v-if="lookShow===true"> 查看学生解题
                                            </div>
                                            <div class="reple" style="border: none" v-else>
                                                <el-input readonly type="textarea" :rows="5"
                                                          :value="item.student_answer"></el-input>
                                            </div>
                                            <div class="correction">
                                                <el-form ref="subjectForm">
                                                    <el-form-item prop="teacherremark">
                                                        <el-input ref="scoreRef" v-if="isShowThemeSolve" type="textarea" :rows="5"
                                                                  :value="item.teacher_remark"
                                                                  v-model="item.teacher_remark"
                                                                  maxlength="50"></el-input>
                                                        <el-input v-else readonly type="textarea" :rows="5"
                                                                  :value="item.teacher_remark" maxlength="50"
                                                                  v-model="item.teacher_remark"></el-input>
                                                    </el-form-item>
                                                </el-form>
                                            </div>
                                        </div>
                                        <div class="scoring" v-if="isShowThemeSolve">
                                            <el-form inline ref="scoreRef" >
                                                <el-form-item label="打分:" prop="score">
                                                    <el-input maxlength="3" style="width: 100px"
                                                              v-model="item.student_score"
                                                              @input="value=>{item.student_score = $util.checkNumber(value)}"></el-input>
                                                </el-form-item>
                                            </el-form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="question-type" v-if="answeritem.topic_type ===5" :key="indexId">
                                <p class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}}, </span><span
                                        style="padding-right: 10px">连线题</span><span>{{connectFaction.fraction}} </span>
                                </p>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="theme-number">{{item.theme_number}} , </span>
                                                <div>{{item.student_answer}}</div>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer===item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div>
                                                <div class="ider" v-if="item.hasSolve===1">
                                                    <el-checkbox :checked="checked" v-model="item.theme_solve" label="1"
                                                                 @change="value=>{themSolve(item,value)}">
                                                        解题思路
                                                    </el-checkbox>
                                                </div>
                                                <div v-else class="ider"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                        <div class="comment">
                            <el-form>
                                <el-form-item label="老师点评 :">
                                    <el-input type="textarea" maxlength="200" v-model="testPaperAnswerList.teacher_comment" v-if="isShowThemeSolve"></el-input>
                                    <el-input type="textarea" maxlength="200" :value="testPaperAnswerList.teacher_comment" readonly v-else></el-input>
                                </el-form-item>
                            </el-form>
                        </div>
                    </el-scrollbar>
                </div>
            </div>
            <span slot="footer" class="dialog-footer" v-if="isShowThemeSolve">
                         <el-button type="primary" @click="CorrectionSubmit"
                                    :loading="status.correctionSubmitDataLoading">提交</el-button>
                        </span>
        </el-dialog>
        <videoPlayer :video-visible="status.videoVisible" :video-url="videoUrl" :video-title="videoTitle" @video-player-close="status.videoVisible = false"></videoPlayer>
    </div>
</template>

<script>
    import videoPlayer from "./video-player";
    import pdf from 'vue-pdf'
    export default {
        name: "course-manage-teacher",
        components: {
            pdf,
            videoPlayer
        },
        data() {
            return {
                videoUrl: "",
                videoTitle:"",
                //pdf  在线预览  翻页
                currentPage: 0, // pdf文件页码
                pageCount: 0, // pdf文件总页数
                isShowThemeSolve: false,
                lookShow: true,
                checked: "",
                //打分规则
                subjectFormRules: {
                    score: [
                        {required: true, message: '分数不能为空', trigger: 'blur'},
                        {type: "number", min: 0, max: 100, message: '分数只能取0~100之间的数字', trigger: 'blur'},
                    ],
                },
                //选择分数
                choseFaction: {
                    studentScore: 0,
                    themeScore: 0,
                    fraction: 0,
                },
                //填空题分数
                fillFaction: {
                    studentScore: 0,
                    themeScore: 0,
                    fraction: 0,
                },
                //判断分数
                judgeFaction: {
                    studentScore: 0,
                    themeScore: 0,
                    fraction: 0,
                },
                //解答题分数
                subjectiveFaction: {
                    studentScore: 0,
                    themeScore: 0,
                    fraction: 0,
                },
                //连线题分数
                connectFaction: {
                    studentScore: 0,
                    themeScore: 0,
                    fraction: 0,
                },
                //课后作业 试卷答案
                answerList: [],
                testPaperAnswerList: [],
                //试卷图片文件
                fileList: [],
                //试卷 标题 总分
                //老师评语
                teacherComments: "",

                //答题卡
                isCorrect: true,
                judgeisCorrect: true,
                answerSheetQuest: {
                    studentId: "",
                    testPaperId: "",
                    homeworkId:""
                },
                //提交批改作业
                CorrectionQuest: {
                    answerCardId: "",
                    testPaperId: "",
                    studentId: "",
                    homeworkId: "",
                    courseHourId: "",
                    teacherComment: "",
                    list: [],
                },

                //作业
                textarea: "",
                // 课后作业完成文本
                homeworkCompletionText: "",
                HomeworkAfterClass: false,
                homeWorkDetailsDialog: false,
                HomeWorkDetailsAnswerSheetDialog: false,
                scoreShow:true,
                //查看课后作业列表
                workData: [{
                    classHour: '5',
                    name: '有理数的加减法',
                }, {
                    classHour: '5',
                    name: '有理数的加减法',
                }, {
                    classHour: '5',
                    name: '有理数的加减法',
                }, {
                    classHour: '5',
                    name: '有理数的加减法',
                }],
                //课后作业详情
                workDetailData: [],
                searchParams: {
                    page: 1,
                    limit: 5,
                    PaperPage: 1, //第几页
                    PaperLimit: 5,//每页条数
                    //publicPaperPage:1,
                    //publicPaperLimit:5,
                },
                classListTotal: 0,
                paperClassListTotal: 0,
                homeworkActiveName: 'myPaper',
                addHomeworkParams: { //确认添加课后作业的参数
                    courseHourId: '',
                    courseId: '',
                    courseName: '',
                    testPaperId: '',
                    testPaperName: '',
                    courseHourNumerical: '',//第几节课
                    totalScore: '',//试卷总分
                    mustFinishTime:'',//作业完成时间
                },
                queryPaperFrame: '',//布置作业弹框搜索框数据

                selectDay: new Date(),
                currentDay: '',
                currentWeek: '',
                courseDateList: [],
                courseList: [],
                courseListLength: '',
                queryCourseListParams: {
                    page: 1,
                    limit: 3
                },
                rateColors: ['#4BAF50', '#4BAF50', '#4BAF50'],
                homeworkList: [],
                paperList: [],
                item: {},
                workDetialDate: [],
                ifFiinisg: '',
                // 老师编号
                teacherId: "",
                // 选中课时编号
                courseHourId: "",
                // 课堂课件
                courseHourCoursewareDialogTitle: "课堂课件",
                coursewareActiveName: "courseHourCourseware",
                courseHourCoursewarePageInfo: {
                    page: 1,
                    limit: 5,
                    courseHourId: ""
                },
                courseHourList: [],
                courseHourCoursewareData: [],
                courseHourCoursewareTotal: 0,
                // 我的课件、公共课件
                coursewarePageInfo: {
                    page: 1,
                    limit: 5,
                    coursewareType: "1",
                    gradeId: "",
                    subjectId: "",
                },
                gradeList: [],
                subjectList: [],
                coursewareTypeList: [],
                coursewareData: [],
                coursewareTotal: 0,
                courseHourCousewareFormData: {
                    coursewareId: "",
                    courseHourId: ""
                },
                //课后作业名称
                courseName: "",
                status: {
                    courseHourCoursewareDialogOpen: false,
                    courseHourCoursewareDataLoading: false,
                    coursewareDataLoading: false,
                    getCalenderLoading: false,
                    getCourseLoading: false,
                    homeworkDialogVisible: false,
                    addCoursewareDialogOpen: false,
                    addCoursewareSaving: false,
                    aadHomeworkDialogVisible: false,//添加课后作业-输入课时的弹框
                    correctionSubmitDataLoading: false,
                    getRoomIdLoading: false,
                    getVideoLoading: false,
                    addCourseHomeworkSaving: false, // 添加课后作业保存中
                    videoVisible: false,
                    showCourseListPage: false
                },
                WorkInfoByTest: {
                    testPaperId: "",
                    courseHourId: "",
                    limit: 10,
                    page: 1
                },
                homeworkDialogTitle: "课后作业",
            }
        },
        mounted() {
            // 老师编号
            let teacher = this.$util.getUser();
            this.teacherId = teacher.empId;
            // 年级数据初始化
            let params = {
                method: 'POST',
            };
            this.$request(params, "/grade/gradeList", (res) => {
                this.gradeList = res.list;
            });
            // 科目数据初始化
            this.$request(params, "/subject/subjectList", (res) => {
                this.subjectList = res.list;
            });
            // 课件类型字典
            this.coursewareTypeList = this.$dict.getDictByCode('COURSEWARE_TYPE') || [];

        },
        methods: {
            // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
            changePdfPage(val) {
                // console.log(val)
                if (val === 0 && this.currentPage > 1) {
                    this.currentPage--
                    // console.log(this.currentPage)
                }
                if (val === 1 && this.currentPage < this.pageCount) {
                    this.currentPage++
                    // console.log(this.currentPage)
                }
            },
            // pdf加载时
            loadPdfHandler(e) {
                console.log(e)
                this.currentPage = 1 // 加载的时候先加载第一页
            },
            //课后作业弹框

            homeworkListClickRow(row) {
                this.courseName = row.courseName
                this.WorkInfoByTest.testPaperId = row.testPaperId
                this.WorkInfoByTest.courseHourId = row.courseHourId

                let params = {...this.WorkInfoByTest};
                this.homeWorkDetailsDialog = true;
                this.$request(params, "/masters/mapper/select/course.queryWorkInfoByTestPaperId", res => {
                    this.workDetailData = res.list;
                    // 课后作业完成结果结算
                    let completeCount = res.list.filter(cur => cur.isFinish === 1).length;
                    let studentAvg = "-";
                    if (completeCount > 0) {
                        studentAvg = (res.list.filter(cur => cur.isFinish === 1)
                            .map(cur => cur.studentScore)
                            .reduce((pre, cur) => pre + cur) / completeCount).toFixed(2);
                    }
                    this.homeworkCompletionText = "您选择的课后作业为:" +
                        row.testPaperName + ",目前完成进度为:" +
                        completeCount + "/" + res.list.length + " ，平均分：" + studentAvg + "。";
                })
            },
            //点击查看 实际作答
            look() {
                this.lookShow = false;
            },
            //关闭弹窗时触发的事件
            subjectDialogFormVisibleClosed() {
                this.CorrectionQuest.teacherComment = ''
                // this.$nextTick(() => {
                //     this.$refs['scoreRef'].resetFields()
                // });

            },
            //点击查看 弹出  作业详情页面
            lookJobDetailsMethod() {
                this.homeWorkDetailsDialog = true
            },
            //点击查看 答题详情
            lookAnswerSheetDetailsMethods(row){
                if(row.isFinish===2){
                    this.scoreShow=true;
                }else{
                    this.scoreShow=false;
                }
                this.homeWorkDetailsDialog=false
                    this.answerSheetQuest.studentId =  row.studentId;
                    this.answerSheetQuest.testPaperId =  row.testPaperId;
                   this.answerSheetQuest.homeworkId =  row.homeworkId;

                    this.lookShow = true;
                    this.isShowThemeSolve=false;
                    this.HomeWorkDetailsAnswerSheetDialog=true;
                    this.answerSheet()
                // this.$nextTick(() => {
                //     this.$refs['scoreRef'].resetFields();
                //     this.$refs['scoreRef'].clearValidate();
                // });
            },
            //点击 批改作业 弹框
            Correction(row) {
                this.homeWorkDetailsDialog = false
                this.lookShow = true;
                this.scoreShow=false;
                this.answerSheetQuest.studentId = row.studentId;
                this.answerSheetQuest.testPaperId = row.testPaperId;
                this.answerSheetQuest.homeworkId = row.homeworkId;
                this.CorrectionQuest.studentId = row.studentId;
                this.CorrectionQuest.testPaperId = row.testPaperId;
                this.CorrectionQuest.homeworkId = row.homeworkId;
                this.CorrectionQuest.courseHourId = row.courseHourId;

                this.isShowThemeSolve = true;
                this.HomeWorkDetailsAnswerSheetDialog = true;

                this.answerSheet()
            },
            //批改作业
            setObj(item, params) {
                if (item.hasSolve === 1) {
                    let obj = {};
                    obj.cardThemeId = item.card_theme_id;
                    if (item.theme_solve === true) {
                        obj.isShowThemeSolve = 1
                    } else if (item.theme_solve === false) {
                        obj.isShowThemeSolve = 2
                    }
                    params.list.push(obj)
                }
            },
            CorrectionSubmit() {
                this.status.correctionSubmitDataLoading = true
                let params = {...this.CorrectionQuest}
                let answerList = JSON.parse(JSON.stringify(this.answerList));
                this.CorrectionQuest.list = [];
                params.teacherComment = this.testPaperAnswerList.teacher_comment

                answerList.map(item => {
                    if (item.topic_type === 1) {
                        item.themeList.map(item => {
                            this.setObj(item, params);
                        })
                    }
                    if (item.topic_type === 2) {
                        item.themeList.map(item => {
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            if (item.theme_solve === true) {
                                obj.isShowThemeSolve = 1
                            } else if (item.theme_solve === false) {
                                obj.isShowThemeSolve = 2
                            }
                            obj.studentScore = item.student_score;
                            obj.teacherRemark = item.teacher_remark;

                            params.list.push(obj)
                        })
                    }
                    if (item.topic_type === 3) {
                        item.themeList.map(item => {
                            this.setObj(item, params);
                        })
                    }
                    if (item.topic_type === 4) {
                        item.themeList.map(item => {
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            if (item.theme_solve === true) {
                                obj.isShowThemeSolve = 1
                            } else if (item.theme_solve === false) {
                                obj.isShowThemeSolve = 2
                            }
                            obj.studentScore = item.student_score;
                            obj.teacherRemark = item.teacher_remark;

                            params.list.push(obj)
                        })
                    }
                    if (item.topic_type === 5) {
                        item.themeList.map(item => {
                            this.setObj(item, params);
                        })
                    }
                });
                this.$request(params, "/teacher/correctiveWork", () => {
                    this.homeWorkDetailsDialog = false
                    this.status.correctionSubmitDataLoading = false
                    this.$message.success("批改成功")
                }, () => {
                    this.$message.error("批改失败")
                    this.status.correctionSubmitDataLoading = false
                });
                this.HomeWorkDetailsAnswerSheetDialog = false


            },
            //解题思路
            themSolve(item, value) {
                if (!this.isShowThemeSolve) {
                    this.$nextTick(() => {
                        if (value) {
                            this.$set(item, "theme_solve", false);
                        } else {
                            this.$set(item, "theme_solve", true);
                        }
                    })
                }
            },
            //获取答题卡内容
            answerSheet() {
                let params = {...this.answerSheetQuest};
                this.choseFaction.themeScore = 0;
                this.choseFaction.studentScore = 0;
                this.fillFaction.themeScore = 0;
                this.fillFaction.studentScore = 0;
                this.judgeFaction.themeScore = 0;
                this.judgeFaction.studentScore = 0;
                this.connectFaction.themeScore = 0;
                this.connectFaction.studentScore = 0;
                this.subjectiveFaction.themeScore = 0;
                this.subjectiveFaction.studentScore = 0;
                this.$request(params, "/student/queryStudentWorkInfo", (res) => {
                    let answerList = res.list[0].list;
                    answerList.map(item => {
                        if (item.topic_type === 1) {
                            item.themeList.map(choseItem => {
                                if(!this.$util.isEmpty(choseItem.student_score)){
                                    this.choseFaction.studentScore += choseItem.student_score
                                }
                                if(!this.$util.isEmpty(choseItem.theme_score)){
                                    this.choseFaction.themeScore += choseItem.theme_score
                                }
                                if (choseItem.hasSolve === 1) {
                                    choseItem.theme_solve = choseItem.is_show_theme_solve === 1
                                } else {
                                    choseItem.theme_solve = null
                                }
                            });
                            this.choseFaction.fraction = this.choseFaction.studentScore + '/' + this.choseFaction.themeScore
                        }
                        if (item.topic_type === 2) {
                            item.themeList.map(fillItem => {
                                if(!this.$util.isEmpty(fillItem.student_score)){
                                    this.fillFaction.studentScore += fillItem.student_score
                                }
                                if(!this.$util.isEmpty(fillItem.theme_score)){
                                    this.fillFaction.themeScore += fillItem.theme_score
                                }
                                if (fillItem.hasSolve === 1) {
                                    fillItem.theme_solve = fillItem.is_show_theme_solve === 1
                                } else {
                                    fillItem.theme_solve = null
                                }
                            });
                            this.fillFaction.fraction =this.fillFaction.studentScore + '/' + this.fillFaction.themeScore
                        }
                        if (item.topic_type === 3) {
                            item.themeList.map(judgeItem => {
                                if(!this.$util.isEmpty(judgeItem.student_score)){
                                    this.judgeFaction.studentScore += judgeItem.student_score
                                }
                                if(!this.$util.isEmpty(judgeItem.theme_score)){
                                    this.judgeFaction.themeScore += judgeItem.theme_score
                                }
                                if (judgeItem.hasSolve === 1) {
                                    judgeItem.theme_solve = judgeItem.is_show_theme_solve === 1
                                } else {
                                    judgeItem.theme_solve = null
                                }
                            });
                            this.judgeFaction.fraction = this.judgeFaction.studentScore + '/' + this.judgeFaction.themeScore
                        }
                        if (item.topic_type === 4) {
                            item.themeList.map(subjectiveItem => {
                                if(!this.$util.isEmpty(subjectiveItem.student_score)){
                                    this.subjectiveFaction.studentScore += subjectiveItem.student_score
                                }
                                if(!this.$util.isEmpty(subjectiveItem.theme_score)){
                                    this.subjectiveFaction.themeScore += subjectiveItem.theme_score
                                }
                                if (subjectiveItem.hasSolve === 1) {
                                    subjectiveItem.theme_solve = subjectiveItem.is_show_theme_solve === 1
                                } else {
                                    subjectiveItem.theme_solve = null
                                }
                            });
                            this.subjectiveFaction.fraction = this.subjectiveFaction.studentScore + '/' + this.subjectiveFaction.themeScore

                        }
                        if (item.topic_type === 5) {
                            item.themeList.map(connectItem => {
                                if(!this.$util.isEmpty(connectItem.student_score)){
                                    this.connectFaction.studentScore += connectItem.student_score
                                }
                                if(!this.$util.isEmpty(connectItem.theme_score)){
                                    this.connectFaction.themeScore += connectItem.theme_score
                                }
                                if (connectItem.hasSolve === 1) {
                                    connectItem.theme_solve = connectItem.is_show_theme_solve === 1
                                } else {
                                    connectItem.theme_solve = null
                                }
                            });
                            this.connectFaction.fraction = this.connectFaction.studentScore + '/' + this.connectFaction.themeScore
                        }


                    });
                    this.answerList = res.list[0].list;
                    this.testPaperAnswerList = res.list[0].testPaper;
                    this.fileList = res.list[0].fileList;
                    this.CorrectionQuest.answerCardId = res.list[0].testPaper.answer_card_id
                }, () => {
                    this.HomeWorkDetailsAnswerSheetDialog = false
                })

            },
            getCalenderList() {
                let params = {};
                params.teacherId = this.$util.getUser().empId;
                params.today = this.$util.formatDate(null, 'yyyy-MM-dd', this.selectDay);
                this.currentDay = this.$util.formatDate(params.today, 'yyyy年MM月dd日');
                this.currentWeek = this.$util.formatDate(params.today, 'EEEE');
                this.status.getCalenderLoading = true;
                this.$request(params, "/teacher/queryTeacherCourse", (data) => {
                    this.courseDateList = data.list;
                    this.status.getCalenderLoading = false;
                }, () => {
                    this.status.getCalenderLoading = false;
                });
            },
            changeCourseListPage(currentPage) {
                this.queryCourseListParams.page = currentPage;
                this.getCourseList();
            },
            getCourseList() {
                let params = {...this.queryCourseListParams};
                params.teacherId = this.$util.getUser().empId;
                params.courseTimeDate = this.$util.formatDate(null, 'yyyy-MM-dd', this.selectDay);
                this.status.getCourseListLoading = true;
                this.$request(params, "/teacher/queryTeacherCourseInfoByDate", (data) => {
                    for (let item of data.list) {
                        item.hardLevel = item.hardLevel / 2;
                    }
                    this.courseList = data.list;
                    this.courseListLength = data.total;
                    this.status.showCourseListPage = this.courseListLength <= this.queryCourseListParams.limit;
                    this.status.getCourseListLoading = false;
                }, () => {
                    this.status.getCourseListLoading = false;
                });
            },
            //进入教室
            getRoomInfo(item, playVideo) {
                let nowTime = new Date();
                //可提前十分钟进入教室
                if (!playVideo && new Date(item.startTime).getTime() > (nowTime.getTime() + 600000)) {
                    this.$message.warning("课时未开始");
                    return;
                }
                //不允许在结束时间之后进入教师
                if (!playVideo && new Date(item.endTime).getTime() < nowTime.getTime()) {
                    this.$message.warning("课时已结束");
                    return;
                }
                let courseId = item.courseId;
                let courseName = item.courseName;
                let lecturerName = item.lecturerName;
                let courseTimeId = item.courseTimeId;
                this.status.getRoomIdLoading = true;
                //获取课时信息,用于进入教室或者播放录像
                this.$request({courseId,courseTimeId}, '/teacher/comingRoom', data => {
                    this.status.getRoomIdLoading = false;
                    //如果返回的数据为空
                    if (this.$util.isEmpty(data.list) || this.$util.isEmpty(data.list[0])) {
                        this.$message.warning("课时信息不存在或课程已结束");
                        return;
                    }
                    //获取课时ID
                    let courseHourId = data.list[0].courseHourId;
                    if (playVideo) {
                        if (this.$util.isEmpty(courseHourId)) {
                            this.$message.warning("未能获取到课时ID");
                            return;
                        }
                        this.playVideo(courseHourId, `${courseName} ${lecturerName}`);
                    } else {
                        let roomID = data.list[0].roomId;
                        let courseState = data.list[0].courseState;
                        if(this.$util.isEmpty(roomID)){
                            this.$message.warning("未能查询到房间号");
                            return;
                        }
                        if(!this.$util.isEmpty(courseState) && courseState === 3){
                            this.$message.warning("课时已结束");
                            return;
                        }
                        this.$router.push({
                            path: "/classroom",
                            query: {roomID, courseHourId, courseName, courseId,courseTimeId}
                        })
                    }
                }, () => {
                    this.status.getRoomIdLoading = false;
                });
            },
            playVideo(courseHourId, videoTitle) {
                this.status.getVideoLoading = true;
                this.$request({courseHourId}, "/masters/mapper/select/course.selectVideoUrlByCourseHour", data => {
                    this.status.getVideoLoading = false;
                    this.videoTitle = videoTitle;
                    if (data.list && data.list[0] && !this.$util.isEmpty(data.list[0].videoUrl)) {
                        this.videoUrl = data.list[0].videoUrl;
                        this.status.videoVisible = true;
                    } else {
                        this.$message.warning("这堂课还没有录像");
                    }
                }, () => {
                    this.status.getVideoLoading = false;
                })
            },
            // 课程课件弹框
            handleCourseHourCourseware(courseId, courseName) {
                this.courseHourCoursewareDialogTitle = courseName + " - 课堂课件";
                this.coursewareActiveName = "courseHourCourseware";
                this.courseHourCoursewarePageInfo = this.$options.data().courseHourCoursewarePageInfo;
                this.coursewarePageInfo = this.$options.data().coursewarePageInfo;
                this.status.courseHourCoursewareDialogOpen = true;
                // 课时列表
                let params = {
                    courseId: courseId,
                    method: "POST"
                };
                this.$request(params, "/masters/mapper/select/courseHour.queryCourseHour", (res) => {
                    this.courseHourList = res.list;
                });
                this.courseHourCoursewarePageInfo.courseId = courseId;
                this.getCourseHourCoursewareData();
                this.getCoursewareData();
            },
            // 获取课程课件
            getCourseHourCoursewareData() {
                this.status.courseHourCoursewareDataLoading = true;
                let params = {...this.courseHourCoursewarePageInfo};
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/courseHour.queryCourseHourCourseware", (res) => {
                    this.courseHourCoursewareData = res.list;
                    this.courseHourCoursewareTotal = res.total;
                    this.status.courseHourCoursewareDataLoading = false;
                }, () => {
                    this.$message.error("获取数据失败");
                    this.courseHourCoursewareData = [];
                    this.courseHourCoursewareTotal = 0;
                    this.status.courseHourCoursewareDataLoading = false;
                });
            },
            // 获取课件
            getCoursewareData() {
                this.status.coursewareDataLoading = true;
                let params = {...this.coursewarePageInfo};
                params.teacherId = this.teacherId;
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/courseware.myCourseware", (res) => {
                    this.coursewareData = res.list;
                    this.coursewareTotal = res.total;
                    this.status.coursewareDataLoading = false;
                }, () => {
                    this.$message.error("获取数据失败");
                    this.coursewareData = [];
                    this.coursewareTotal = 0;
                    this.status.coursewareDataLoading = false;
                });
            },
            // 课时课件第几页
            handleCourseHourCoursewarePage(page) {
                if (page) {
                    this.courseHourCoursewarePageInfo.page = page;
                }
                this.getCourseHourCoursewareData();
            },
            // 课时课件页数大小
            handleCourseHourCoursewarePageSize(limit) {
                this.courseHourCoursewarePageInfo.limit = limit;
                this.getCourseHourCoursewareData();
            },
            // 删除课程课件关联
            handleDeleteCourseHourCourseware(row) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    let params = {
                        courseHourId: row.courseHourId,
                        coursewareId: row.coursewareId
                    };
                    this.$request(params, "/masters/mapper/delete/courseHour.deleteCourseHourCourseware", () => {
                        this.$message.success("删除成功");
                        this.handleCourseHourCoursewarePage(1);
                    });
                });
            },
            // 添加课程课时管理
            handleAddCourseware(coursewareId) {
                this.courseHourCousewareFormData.coursewareId = coursewareId;
                this.status.addCoursewareDialogOpen = true;
            },
            // 提交课件信息
            handleSubmit() {
                this.status.addCoursewareSaving = true;
                let params = this.courseHourCousewareFormData;
                params.method = 'POST';
                this.$request(params, "/courseHour/addCourseware", () => {
                    this.$message.success(`添加成功`);
                    this.status.addCoursewareSaving = false;
                    this.status.addCoursewareDialogOpen = false;
                    // 刷新数据
                    this.handleCourseHourCoursewarePage(1);
                }, () => {
                    this.status.addCoursewareSaving = false;
                });
            },
            handleCoursewarePageSize(limit) {
                this.coursewarePageInfo.limit = limit;
                this.getCoursewareData();
            },
            handleCoursewarePage(page) {
                if (page) {
                    this.coursewarePageInfo.page = page;
                }
                this.getCoursewareData();
            },
            /**
             * 课后作业按钮
             */
            homework(item) {
                this.searchParams = this.$options.data().searchParams;
                this.item = item;
                this.hasHomeworkList();
                this.testPaperList();
                this.status.homeworkDialogVisible = true;
                this.homeworkDialogTitle = item.courseName + " - 课后作业";
                // 课时列表
                let params = {
                    courseId: item.courseId,
                    method: "POST"
                };
                this.$request(params, "/masters/mapper/select/courseHour.queryCourseHour", (res) => {
                    this.courseHourList = res.list;
                });
            },
            //已布置课后作业列表
            hasHomeworkList() {
                let item = this.item;
                let params = {};
                params.courseId = item.courseId;
                params.page = this.searchParams.page;
                params.limit = this.searchParams.limit;
                this.$request(params, "/masters/courseHomeworkList", res => {
                    this.classListTotal = res.total;
                    this.homeworkList = res.list;
                }, err => {
                    this.$message.error(err.message);
                });
            },
            //我的试卷列表
            testPaperList() {
                let teacherId = this.$util.getUser().empId;
                let params = {};
                params.page = this.searchParams.PaperPage;
                params.limit = this.searchParams.PaperLimit;
                params.teacherId = teacherId;
                params.queryPaperFrame = this.queryPaperFrame;
                this.$request(params, "/masters/myTestPaper", res => {
                    this.paperClassListTotal = res.total;
                    this.paperList = res.list
                }, err => {
                    console.log(err);
                });
            },
            //公共试卷
            publicTestPaper() {
                let params = {};
                params.page = this.searchParams.PaperPage;
                params.limit = this.searchParams.PaperLimit;
                params.testPaperType = "2";
                params.queryPaperFrame = this.queryPaperFrame;
                this.$request(params, "/masters/publicTestPaper", res => {
                    this.paperClassListTotal = res.total;
                    this.paperList = res.list
                }, err => {
                    console.log(err);
                })
            },
            //布置作业管理查询按钮
            queryPaperButton() {
                this.searchParams.PaperPage = 1;
                this.searchParams.PaperLimit = 5;
                if (this.homeworkActiveName === 'myPaper') {
                    //this.searchParams.page=1;
                    //this.searchParams.publicPaperPage=1;
                    this.testPaperList();
                } else if (this.homeworkActiveName === 'publicPaper') {
                    //this.searchParams.page=1;
                    //this.searchParams.publicPaperPage=1;
                    this.publicTestPaper();
                }
            },

            handleSizeChange(limit) {
                this.searchParams.limit = limit;
                this.hasHomeworkList();
            },
            handleCurrentChange(page) {
                this.searchParams.page = page;
                this.hasHomeworkList();
            },

            publicPaperHandleSizeChange(limit) {
                this.searchParams.PaperLimit = limit;
                if (this.homeworkActiveName === 'myPaper') {
                    this.testPaperList();
                } else if (this.homeworkActiveName === 'publicPaper') {
                    this.publicTestPaper();
                }
            },
            publicPaperHandleCurrentChange(page) {
                this.searchParams.PaperPage = page;
                if (this.homeworkActiveName === 'myPaper') {
                    this.testPaperList();
                } else if (this.homeworkActiveName === 'publicPaper') {
                    this.publicTestPaper();
                }
            },

            //我的试卷，公共试卷选项卡切换
            handleClick() {
                this.paperClassListTotal = 0;
                this.paperList = [];
                this.queryPaperFrame = '';
                this.searchParams.PaperPage = 1;
                this.searchParams.PaperLimit = 5;
                if (this.homeworkActiveName === 'myPaper') {
                    this.testPaperList();
                } else if (this.homeworkActiveName === 'publicPaper') {
                    this.publicTestPaper();
                }
            },
            //单击试卷列表行
            paperListClickRow(row) {
                this.status.aadHomeworkDialogVisible = true;
                this.addHomeworkParams.courseId = this.item.courseId;
                this.addHomeworkParams.courseName = this.item.courseName;
                this.addHomeworkParams.testPaperId = row.testPaperId;
                this.addHomeworkParams.testPaperName = row.testPaperName;
                this.addHomeworkParams.totalScore = row.totalScore;
            },
            //格式化  难度程度
            difficultyType(row) {
                let hardLevel = row.hardLevel;
                return hardLevel === 1 ? "简单" : hardLevel === 2 ? "中等" : hardLevel === 3 ? "困难" : "-";
            },
            //格式化 是否主观
            isSubjectiveType(row) {
                let isSubjective = row.isSubjective;
                return isSubjective === 1 ? "是" : isSubjective === 2 ? "否" : "-";
            },

            //确认添加课后作业
            confirmAddHomework() {
                this.status.addCourseHomeworkSaving = true;
                let params = {};
                params = {...this.addHomeworkParams};
                this.$request(params, "/masters/addCourseHomework", res => {
                    this.status.addCourseHomeworkSaving = false;
                    this.$message.success(res.message);
                    this.status.aadHomeworkDialogVisible = false;
                    this.hasHomeworkList(this.item);
                }, () => {
                    this.status.addCourseHomeworkSaving = false;
                })
            },
            //删除已添加的课后作业
            deleteCourseHomework(item) {
                this.$confirm('确定要删除此节课程的课后作业吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    let params = {};
                    params.courseHourId = item.courseHourId;
                    this.$request(params, "/masters/deleteCourseHomework", res => {
                        this.$message.success(res.message);
                        this.hasHomeworkList(this.item);
                    }, () => {

                    })
                });
            },
            //确认添加课程弹框关闭事件
            aadHomeworkDialogClose() {
                this.addHomeworkParams.courseHourNumerical = '';
            },
            //布置课后作业弹框关闭
            homeworkDialogClose() {
                this.queryPaperFrame = '';
                this.homeworkActiveName = 'myPaper';
                this.searchParams = this.$options.data().searchParams;
            },
            // 聊天
            handleTalk(studentId) {
                this.homeWorkDetailsDialog = false;
                this.status.homeworkDialogVisible = false;
                this.$store
                    .dispatch('checkoutConversation', `C2C${studentId}`)
                    .then(() => {
                        this.$store.commit("setShowConversation", true);
                    }).catch(() => {
                    this.$store.commit('showMessage', {
                        message: '此学生可能没有登录过系统',
                        type: 'warning'
                    })
                });
            },
        },
        watch: {
            selectDay: function () {
                this.getCalenderList();
                this.queryCourseListParams.page = 1;
                this.getCourseList();
            }
        },
        created() {
            this.getCalenderList();
            this.getCourseList();
        },

    }
</script>

<style lang="less">
    @import "./course-manage-teacher.less";

    .el-pagination {
        display: flex;
        justify-content: flex-end;
    }

    .theme-number {
        width: 30px;
    }

    //.打分
    .scoring {
        margin-top: 15px;

        span {
            margin-right: 10px;
        }

    }
</style>