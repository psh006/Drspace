<template>
    <div class="course-manage">

        <el-form inline style="display: flex; justify-content: space-between">
            <div>
                <el-form-item label="日期">
                    <el-date-picker
                            v-model="queryDate"
                            type="daterange"
                            value-format="yyyy-MM-dd"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            style="width: 250px"
                            clearable
                            @blur="getDateRange">
                    </el-date-picker>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="getCourseList" :loading="status.getCourseListLoading">查询
                    </el-button>
                    <el-button type="primary" @click="setTimeDialog">时间设置</el-button>
                </el-form-item>
            </div>

            <div class="icon-intro">
                <el-image :src="require('./../../assets/img/warning.png')"
                          style="width: 16px;height: 16px;position: relative;top: 3px;"></el-image>
                课程冲突
                <i class="el-icon-circle-plus" style="color: #28b149; margin-left: 10px"></i>
                增加课程
                <i class="el-icon-error" style="color: #C0C4CC; margin-left: 10px"></i>
                删除课程
                <i class="el-icon-document-copy" style="color: #888; margin-left: 10px"></i>
                复制课程
                <i class="el-icon-document-add" style="color: #888; margin-left: 10px"></i>
                粘贴课程
                <span class="choose-class">
                    <span :class="'choose-class-type' + (queryParams.courseTimeType === '2'  ? ' active' : ' inactive')"
                          @click="changeClassType('2')">1V1</span>
                    <span :class="'choose-class-type' + (queryParams.courseTimeType === '1' ? ' active' : ' inactive')"
                          @click="changeClassType('1')">班课</span>
                </span>
            </div>
        </el-form>

        <!--排课列表-->
        <div class="table-list" v-loading="status.getCourseListLoading" v-if="dialogTableData.length>0">
            <table border="0" cellpadding='0' cellspacing="0" v-for="(dateItem, dateIndex) in dateList"
                   :key="dateIndex">
                <tr style="height: 30px;">
                    <th colspan="3">
                        <span style="margin-right: 10px">{{dateItem}}</span>
                        <span>{{$util.formatDate(dateItem,'EEEE')}}</span>
                    </th>
                </tr>
                <tr style="height: 60px;" v-for="(timeItem,timeIndex) in dialogTableData" :key="timeIndex">

                    <td style="width: 80px;">
                        {{timeItem.startTime.substr(0,5)}}~{{timeItem.endTime.substr(0,5)}}
                    </td>
                    <td style="width: 215px;">
                            <span v-for="(item1, index1) in courseList" :key="index1">
                                <span v-for="(item2, index2) in item1.courseList" :key="index2">
                                    <span v-if="timeItem.startTime === item2.startTime.substr(11,8) && timeItem.endTime === item2.endTime.substr(11,8) && dateItem===item1.courseTimeDate">
                                        <div :class="'scroll-list' + (item2.courseList.length>3 ? ' h60' : '')">
                                            <div v-for="(item3,index3) in item2.courseList" :key="index3">
                                                <div class="icon-conflict">
                                                    <el-tooltip class="item" :content="item3.conflictDesc"
                                                                placement="top-start"
                                                                effect="light">
                                                        <el-image :src="require('./../../assets/img/warning.png')"
                                                                  v-show="item3.isConflict === 1"
                                                                  style="width: 16px;height: 16px;position: relative;top: 3px;"></el-image>
                                                    </el-tooltip>
                                                </div>
                                                <!--班级排课-->
                                                <span v-if="item3.courseType==1" class="normal-class">
                                                    <el-tooltip :content="item3.courseName" placement="top-start" effect="light" v-if="item3.courseName&&item3.courseName.length>8">
                                                        <div class="normal-class-name">{{item3.courseName}}</div>
                                                    </el-tooltip>
                                                    <div v-else class="normal-class-name">{{item3.courseName}}</div>
                                                    <el-tooltip :content="item3.teacherName" placement="top-start" effect="light" v-if="item3.teacherName&&item3.teacherName.length>4">
                                                        <div class="normal-teacher-name">{{item3.teacherName}}</div>
                                                    </el-tooltip>
                                                    <div v-else class="normal-teacher-name">{{item3.teacherName}}</div>
                                                </span>
                                                <!--1V1排课-->
                                                <span v-else class="only-class">
                                                    <el-tooltip :content="item3.teacherName" placement="top-start" effect="light" v-if="item3.teacherName&&item3.teacherName.length>5">
                                                        <div class="only-teacher-name">{{item3.teacherName}}</div>
                                                    </el-tooltip>
                                                    <div v-else class="only-teacher-name">{{item3.teacherName}}</div>
                                                    <div class="only-divide">-</div>
                                                    <el-tooltip :content="item3.studentName" placement="top-start" effect="light" v-if="item3.studentName&&item3.studentName.length>5">
                                                        <div class="only-student-name">{{item3.studentName}}</div>
                                                    </el-tooltip>
                                                    <div v-else class="only-student-name">{{item3.studentName}}</div>
                                                </span>
                                                <i class="el-icon-document-copy" v-show="item3.courseName"
                                                   style="margin-right: 5px"
                                                   @click="copyCourse(item3)"></i>
                                                <i class="el-icon-error" v-show="item3.courseName"
                                                   @click="deleteCourse(item3.courseTimeId)"></i>
                                            </div>
                                        </div>
                                    </span>
                                </span>
                            </span>
                    </td>
                    <td style="width: 26px;">
                        <i class="el-icon-circle-plus" v-show="!status.showPaste"
                           @click="addCourseDialog(dateItem,timeItem.startTime,timeItem.endTime)"></i>
                        <i class="el-icon-document-add" v-show="status.showPaste"
                           @click="pasteCourse(dateItem,timeItem.startTime,timeItem.endTime)"></i>
                    </td>
                </tr>
            </table>
        </div>

        <div v-else class="table-list" v-loading="status.getCourseListLoading">
            <table border="0" cellpadding='0' cellspacing="0" v-for="(dateItem, dateIndex) in dateList"
                   :key="dateIndex">
                <tr style="height: 30px;">
                    <th>
                        <span style="margin-right: 10px">{{dateItem}}</span>
                        <span>{{$util.formatDate(dateItem,'EEEE')}}</span>
                    </th>
                </tr>
                <tr style="height: 60px; line-height: 60px">
                    <td style="width: 321px;color: #777">未设置排课时间段</td>
                </tr>
            </table>
        </div>

        <!--排课管理页面-时间设置弹窗-->
        <div class="timeQuantumSettingTime">
            <el-dialog title="时间设置" :visible.sync="status.SettingTimeDialogVisible" width="480px"
                       @closed="SettingTimeDialogClose">
                <el-form inline class="demo-form-inline">
                    <el-time-picker
                            is-range
                            v-model="timeRange"
                            range-separator="至"
                            value-format="HH:mm:ss"
                            start-placeholder="开始时间"
                            end-placeholder="结束时间"
                            placeholder="选择时间范围">
                    </el-time-picker>
                    <el-button type="primary" style="margin-left: 5px" @click="addtimeQuantum()">添加</el-button>
                    <el-table ref="singleTable" :data="dialogTableData" style="width: 95%; margin-top: 15px">
                        <el-table-column type="index" label="序号" width="100px" style="background-color: #8c939d;"
                                         align="center"></el-table-column>
                        <el-table-column label="开始时间" property="startTime" width="100px"
                                         align="center"></el-table-column>
                        <el-table-column label="结束时间" property="endTime" width="100px" align="center"></el-table-column>
                        <el-table-column label="操作" align="center">
                            <template slot-scope="scope">
                                <el-button type="text" @click="deleteTimeQuantue(scope.row)">删除</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-form>
            </el-dialog>
        </div>

        <!--添加排课弹窗-->
        <el-dialog :title="addCourseTitle" :visible.sync="status.addCourseDialogVisible" width="550px"
                   @close="onCloseAddCourseDialog">
            <el-form inline :model="searchCourseParams" ref="searchCourseForm">
                <el-form-item label="课程" prop="courseName">
                    <el-input v-model.trim="searchCourseParams.courseName" maxlength="50" clearable
                              style="width: 220px"></el-input>
                </el-form-item>
                <el-form-item label="授课老师" prop="lecturerName">
                    <el-input v-model.trim="searchCourseParams.lecturerName" maxlength="20" clearable
                              style="width: 105px"></el-input>
                </el-form-item>
                <el-form-item style="margin-right: 0px">
                    <el-button type="primary" @click="searchCourse">搜索</el-button>
                </el-form-item>
            </el-form>
            <el-table :data="searchCoureList" tooltip-effect="light" border highlight-current-row @current-change="handleCourseItem">
                <el-table-column type="index" label="序号" width="50px" style="background-color: #8c939d;"
                                 align="center"></el-table-column>
                <el-table-column label="课程名称" property="courseName" width="180px" align="center" show-overflow-tooltip></el-table-column>
                <el-table-column label="授课老师" property="lecturerName" width="140px" align="center"></el-table-column>
                <el-table-column label="年级" property="gradeName" align="center"></el-table-column>
            </el-table>
            <span slot="footer" class="dialog-footer">
                <el-button @click="onCloseAddCourseDialog">取消</el-button>
                <el-button type="primary" @click="submitAddCourse">添加</el-button>
            </span>

            <!--分页组件-->
            <el-pagination align="right"
                           layout="total, sizes, prev, pager, next, jumper"
                           :current-page="searchCourseParams.page"
                           :page-sizes="[5, 10, 20, 50]"
                           :page-size="searchCourseParams.limit"
                           :total="searchCourseListTotal"
                           @size-change="handleSizeChange"
                           @current-change="handleCurrentChange"/>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "course-manage",
        data() {
            return {
                timeRange: ["00:00:00", "23:59:59"], //时间设置弹窗-时间范围选择器数据
                dialogTableData: [],//时间设置弹窗-表格数据
                addCourseTitle: '',
                status: {
                    getCourseListLoading: false,
                    SettingTimeDialogVisible: false,
                    addCourseDialogVisible: false,
                    deleteDialogVisible: false,
                    getDateListLoading: false,
                    showPaste: false
                },
                queryDate: [],
                queryParams: {  //查询排课列表
                    courseTimeType: '1',
                    startDate: '',
                    endDate: ''
                },
                searchCourseParams: {   //搜索课程列表
                    courseName: '',
                    lecturerName: '',
                    page: 1,
                    limit: 10
                },
                searchCourseListTotal: 0,
                addCourseParams: {},
                courseList: [],
                searchCoureList: [],
                dateList: []
            }
        },
        created() {
            this.getThisWeek();
            this.getCourseList();
        },
        methods: {
            // 当前第几页
            handleCurrentChange(CurrentPage) {
                this.searchCourseParams.page = CurrentPage;
                this.searchCourse();
            },
            // 每页几条
            handleSizeChange(pageSize) {
                this.searchCourseParams.limit = pageSize;
                this.handleCurrentChange(1);
            },
            /**
             * 关闭时间设置弹窗
             */
            SettingTimeDialogClose() {
                this.timeRange = ["00:00:00", "00:00:00"];
            },
            /**
             * 时间设置弹窗-打开及初始化
             */
            getTimeList() {
                this.$request({}, "/masters/timeQuantumList", res => {
                    this.dialogTableData = res.list;
                }, err => {
                    console.log(err);
                })
            },
            setTimeDialog() {
                this.status.SettingTimeDialogVisible = true; //时间设置弹窗-显示状态
                this.getTimeList();
            },
            /**
             * 时间设置-添加
             */
            addtimeQuantum() {
                let params = {};
                let startTime = '';
                let endTime = '';
                if (this.timeRange != null) {
                    startTime = this.timeRange[0];
                    endTime = this.timeRange[1];
                    if (startTime === endTime) {
                        this.$message.error("开始时间和结束时间不能重复!");
                    } else {
                        if(this.dialogTableData.length>0){
                            for (let i = 0; i <this.dialogTableData.length; i++) {
                                if (startTime>=this.dialogTableData[i].startTime && startTime<=this.dialogTableData[i].endTime) {
                                    this.$message.error("请输入正确的时间段");
                                    break;
                                }else if (endTime>=this.dialogTableData[i].startTime && endTime<=this.dialogTableData[i].endTime){
                                    this.$message.error("请输入正确的时间段");
                                    break;
                                } else {
                                    params.startTime = startTime;
                                    params.endTime = endTime;
                                    this.$request(params, "/masters/addTimeQuantum", res => {
                                        this.$message.success(res.message);
                                        this.setTimeDialog();
                                    }, err => {
                                        console.log(err);
                                    });
                                    break;
                                }
                            }
                        }else {
                            params.startTime = startTime;
                            params.endTime = endTime;
                            this.$request(params, "/masters/addTimeQuantum", res => {
                                this.$message.success(res.message);
                                this.setTimeDialog();
                            }, err => {
                                console.log(err);
                            });
                        }
                        this.getCourseList();
                    }
                }

            },
            /**
             *  时间设置-删除
             * @param item
             */
            deleteTimeQuantue(item) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    let params = {...item};
                    //params.timeQuantumId = item.timeQuantumId;
                    this.$request(params, "/masters/deleteTimeQuantum", () => {
                        this.setTimeDialog();
                    }, err => {
                        console.log(err);
                    })
                });
            },
            /*获取日期选择器的值*/
            getDateRange() {
                if (this.queryDate && this.queryDate.length === 2) {
                    this.queryParams.startDate = this.queryDate[0];
                    this.queryParams.endDate = this.queryDate[1];
                }
            },
            /*查询排课列表*/
            getCourseList() {
                this.dateList = this.formatEveryDay(this.queryParams.startDate, this.queryParams.endDate);
                this.getTimeList();
                let params = {...this.queryParams};
                this.status.getCourseListLoading = true;
                this.$request(params, "/courseTime/queryCourseTime", (data) => {
                    this.courseList = data.list;
                    this.status.getCourseListLoading = false;
                }, () => {
                    this.status.getCourseListLoading = false;
                });
            },
            /*切换排课类型*/
            changeClassType(data) {
                this.status.showPaste = false;
                this.addCourseParams = {};
                this.queryParams.courseTimeType = data;
                this.dateList = '';
                this.courseList = '';
                this.getCourseList();
            },
            /*复制排课*/
            copyCourse(item) {
                if(this.addCourseParams.courseId === item.courseId || !this.addCourseParams.courseId){
                    this.status.showPaste = !this.status.showPaste;
                }
                this.addCourseParams.courseId = item.courseId;
                this.addCourseParams.courseName = item.courseName;
                this.addCourseParams.teacherName = item.teacherName;
                this.addCourseParams.teacherId = item.teacherId;
            },
            /*粘贴排课*/
            pasteCourse(courseTimeDate, startTime, endTime) {
                this.$confirm('确定要添加吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.addCourseParams.courseTimeDate = courseTimeDate;
                    this.addCourseParams.startTime = courseTimeDate + ' ' + startTime;
                    this.addCourseParams.endTime = courseTimeDate + ' ' + endTime;
                    let params = {...this.addCourseParams};
                    params.courseTimeType = this.queryParams.courseTimeType;

                    this.$request(params, "/courseTime/insertCourseTime", () => {
                        this.$message.success('添加成功!');
                        this.getCourseList();
                    }, () => {
                    });
                }).catch(() => {
                    this.status.showPaste = false;
                });
            },
            /*删除排课*/
            deleteCourse(courseTimeId) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$request({courseTimeId: courseTimeId}, "/courseTime/deleteCourseTime", () => {
                        this.$message.success('删除成功!');
                        this.getCourseList();
                        this.status.showPaste = false;
                        this.addCourseParams = {};
                    }, () => {
                        this.$message.error('删除失败!');
                    });
                }).catch(() => {
                });
            },
            /*搜索课程*/
            searchCourse() {
                if (this.searchCourseParams.courseName === "" && this.searchCourseParams.lecturerName === "") {
                    this.$message.warning('请输入课程或授课老师');
                    return;
                }
                let params = {...this.searchCourseParams};
                params.courseTimeType = this.queryParams.courseTimeType;
                this.$request(params, "/masters/mapper/select/course.queryCourseByNameAmount", (data) => {
                    this.searchCoureList = data.list;
                    this.searchCourseListTotal = data.total;
                }, () => {
                });
            },
            /*打开添加排课弹窗*/
            addCourseDialog(courseTimeDate, startTime, endTime) {
                this.addCourseParams = {};
                this.addCourseParams.courseTimeDate = courseTimeDate;
                this.addCourseParams.startTime = courseTimeDate + ' ' + startTime;
                this.addCourseParams.endTime = courseTimeDate + ' ' + endTime;
                this.addCourseTitle = "正在增加" + this.addCourseParams.startTime.substr(0, 16) + '~' + endTime.substr(0, 5) + "的排课"
                this.status.addCourseDialogVisible = true;

            },
            /*关闭添加排课弹窗*/
            onCloseAddCourseDialog() {
                this.status.addCourseDialogVisible = false;
                this.$refs.searchCourseForm.resetFields();
                this.searchCoureList = [];
                this.searchCourseListTotal = 0;
                this.addCourseParams = {};
            },
            /*搜索后获取排课table点击项*/
            handleCourseItem(item) {
                if (item) {
                    this.addCourseParams.courseId = item.courseId;
                    this.addCourseParams.courseName = item.courseName;
                    this.addCourseParams.teacherName = item.lecturerName;
                    this.addCourseParams.teacherId = item.lecturerId;
                }
            },
            /*添加课程*/
            submitAddCourse() {
                if (!this.addCourseParams.courseId) {
                    this.$message.warning('请选择课程');
                    return;
                }
                this.$confirm('确定添加？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {...this.addCourseParams};
                    params.courseTimeType = this.queryParams.courseTimeType;
                    this.$request(params, "/courseTime/insertCourseTime", () => {
                        this.$message.success('添加成功!');
                        this.addCourseParams = {};
                        this.status.addCourseDialogVisible = false;
                        this.getCourseList();
                    }, () => {
                    });
                }).catch(() => {
                });
            },
            /*获取时间段中的每一天*/
            formatEveryDay(start, end) {
                let dateList = [];
                var startTime = this.getDate(start);
                var endTime = this.getDate(end);
                while ((endTime.getTime() - startTime.getTime()) >= 0) {
                    var year = startTime.getFullYear();
                    var month = startTime.getMonth() + 1 < 10 ? '0' + (startTime.getMonth() + 1) : startTime.getMonth() + 1;
                    var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                    dateList.push(year + "-" + month + "-" + day);
                    startTime.setDate(startTime.getDate() + 1);
                }
                return dateList;
            },
            getDate(datestr) {
                var temp = datestr.split("-");
                var date = new Date(temp[0], temp[1] - 1, temp[2]);
                return date;
            },
            /*获取本周日期*/
            getThisWeek() {
                const date = new Date();
                /*周一*/
                date.setDate(date.getDate() - date.getDay() + 1);
                const start = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
                /*周日*/
                date.setDate(date.getDate() + 6);
                const end = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
                this.queryDate = [new Date(start), new Date(end)];
                this.queryParams.startDate = start;
                this.queryParams.endDate = end;
            }
        }
    }
</script>

<style lang="less">
    @import "./course-manage.less";
</style>

<style lang="less" scoped>
    /*冲突提示*/
    .el-tooltip__popper.is-light {
        border: 1px solid #ddd;
        color: #555;
    }

    .el-tooltip__popper.is-light[x-placement^=top] .popper__arrow {
        border-top-color: #ddd;
    }
</style>
