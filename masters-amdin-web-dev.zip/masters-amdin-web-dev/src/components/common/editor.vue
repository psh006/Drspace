<template>
    <div class="editor">
        <quill-editor style="height: 400px;" readyOnly
                      v-model="editorContent" ref="myQuillEditor" :options="editorOption"
                      @change="onEditorChange($event)" @ready="onEditorReady($event)"></quill-editor>
        <el-upload style="display: none" class="avatar-uploader" id="editor-img-upload"
                   :action="action" :data="{fileType: 'editorImg'}"
                   name="file" accept="image/png,image/gif,image/jpeg,image/bmp,image/x-icon"
                   :show-file-list="false"
                   :on-success="imageUploadSuccess" :on-error="imageUploadError">
        </el-upload>
    </div>
</template>

<script>
    import {quillEditor} from 'vue-quill-editor'

    export default {
        name: "editor",

        components: {quillEditor},

        props: {
            content: String,
            readyOnly: {
                type: Boolean,
                default: true
            }
        },

        watch: {
            content(val) {
                this.editorContent = val;
            }
        },

        data() {
            return {
                action: this.$uploadFileUrl,
                editorContent: '',
                editorOption: {},
            }
        },
        created() {
            /*初始化富文本组件的参数*/
            this.editorOption = {
                placeholder: '请输入',
                theme: 'snow',  // or 'bubble'
                modules: {
                    toolbar: {
                        container: [
                            ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
                            ['blockquote', 'code-block'],

                            [{'header': 1}, {'header': 2}],               // custom button values
                            [{'list': 'ordered'}, {'list': 'bullet'}],
                            [{'script': 'sub'}, {'script': 'super'}],      // superscript/subscript
                            [{'indent': '-1'}, {'indent': '+1'}],          // outdent/indent
                            [{'direction': 'rtl'}],                         // text direction

                            [{'size': ['small', false, 'large', 'huge']}],  // custom dropdown
                            [{'header': [1, 2, 3, 4, 5, 6, false]}],

                            [{'color': []}, {'background': []}],          // dropdown with defaults from theme
                            [{'font': []}],
                            [{'align': []}],
                            ['link', 'image', 'video'],
                            ['clean']                                         // remove formatting button
                        ],  // 工具栏
                        handlers: {
                            'image': function (value) {
                                if (value) {
                                    document.querySelector('#editor-img-upload input').click();
                                } else {
                                    this.quill.format('image', false);
                                }
                                // _this.$emit('open-image', value);
                            }
                        }
                    }
                }

            }
        },

        methods: {
            /*更新组件中的内容，防止content改变内容不更新*/
            updateEditorContent(val){
                this.editorContent = val;
            },
            /*插入图片方法*/
            insertImage(imgPath) {
                let quill = this.$refs.myQuillEditor.quill;
                let length = quill.getSelection().index;
                quill.insertEmbed(length, 'image', imgPath);
                quill.setSelection(length + 1);
            },
            /*加载完成*/
            onEditorReady() {
            },
            /*改变方法*/
            onEditorChange(event) {
                this.$emit('editor-change', event.html);
            },
            imageUploadSuccess(res) {
                let quill = this.$refs.myQuillEditor.quill;
                if (res.flag === 200) {
                    let length = quill.getSelection().index;
                    let imgPath = this.$getFileUrl + res.message;
                    quill.insertEmbed(length, 'image', imgPath);
                    quill.setSelection(length + 1);
                } else {
                    this.$message.warning('图片插入失败')
                }
            },
            imageUploadError() {
                this.$message.warning('图片插入失败');
            }
        }
    }
</script>

<style scoped>
    .editor {
        height: 500px;
    }
</style>
