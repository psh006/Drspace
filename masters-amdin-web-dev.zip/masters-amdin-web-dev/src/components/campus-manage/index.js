/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/4/22 0022 11:22
 */

import campusManage from './campus-manage';

export default [
    campusManage
]
