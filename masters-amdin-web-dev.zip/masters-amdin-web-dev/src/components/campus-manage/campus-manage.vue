<template>
    <div class="campus-manage">
        <div class="queryColumn" >
            <el-form inline class="demo-form-inline" v-model="formData">
                <el-form-item label="省份">
                    <el-select v-model="formData.provinceId" filterable placeholder="请选择" style="width: 130px" v-loading="status.provinceStatu" clearable @change="selectCity">
                        <el-option v-for="item in provinceOptions" :key="item.areaCode" :label="item.areaName" :value="item.areaCode"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="市级">
                    <el-select v-model="formData.cityId" filterable placeholder="请选择" style="width: 120px" v-loading="status.cityStatu" clearable @change="selectDistrict">
                        <el-option v-for="item in cityOptions" :key="item.areaCode" :label="item.areaName" :value="item.areaCode"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="区县">
                    <el-select v-model="formData.districtId" filterable placeholder="请选择" style="width: 120px" v-loading="status.districtStatu" clearable>
                        <el-option v-for="item in districtOptions" :key="item.areaCode" :label="item.areaName" :value="item.areaCode"></el-option>
                    </el-select>
                </el-form-item>
                <el-button type="primary" :loading="status.dataLoading" @click="handleCurrentChange(1)">查询</el-button>
                <el-button type="success" @click="addCampus()" >添加</el-button>
            </el-form>
        </div>

        <div class="courseTable">
            <el-table ref="singleTable" :data="tableData" style="border: 1px solid #EBEEF5; border-bottom: none" type="index">
                <el-table-column type="index" label="序号" width="50px" style="background-color: #8c939d;" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="省份" property="provinceName" min-width="150px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="市级" property="cityName" min-width="150px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="区县" property="areaName"  min-width="150px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="学校名称" property="campusName" min-width="200px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="地址" property="address" min-width="250px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="学生人数" property="number" min-width="80px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="联系人" property="contact" min-width="100px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="联系方式" property="contactInfo" min-width="100px" align="center"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="操作" align="center" min-width="120px">
                    <template slot-scope="scope">
                        <el-button type="text" @click="lookCampus(scope.row)">查看</el-button>
                        <el-button type="text" @click="updateCampus(scope.row)">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <el-pagination background
                           align="right"
                           layout="total, sizes, prev, pager, next, jumper"
                           :current-page="searchParams.page"
                           :page-sizes="[5, 10, 20, 50]"
                           :page-size="searchParams.limit"
                           :total="campusListTotal"
                           @size-change="handleSizeChange"
                           @current-change="handleCurrentChange">
            </el-pagination>
        </div>

        <div class="campusDialog">
            <el-dialog :title="campusDialogTitle" :visible.sync="status.campusDialogVisible" width="480px" @closed="dialogClosed">
                <el-form :model="dialogFormData" inline class="demo-form-inline" ref="dialogFormData" :rules="rules">
                    <el-form-item label="省份" label-width="120px" prop="provinceId">
                        <el-select v-model="dialogFormData.provinceId" filterable placeholder="请选择" style="width: 300px" v-loading="status.provinceStatu" clearable @change="dialogSelectCity">
                            <el-option v-for="item in provinceOptions" :key="item.areaCode" :label="item.areaName" :value="item.areaCode"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="市级" label-width="120px" prop="cityId">
                        <el-select v-model="dialogFormData.cityId" filterable placeholder="请选择" style="width: 300px" v-loading="status.cityStatu" clearable @change="dialogSelectDistrict">
                            <el-option v-for="item in dialogCityOptions" :key="item.areaCode" :label="item.areaName" :value="item.areaCode"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="区县" label-width="120px" prop="areaId">
                        <el-select v-model="dialogFormData.areaId" filterable placeholder="请选择" style="width: 300px" v-loading="status.districtStatu" clearable @change="dialogGetDistrict">
                            <el-option v-for="item in dialogDistrictOptions" :key="item.areaCode" :label="item.areaName" :value="item.areaCode"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="校区名称" label-width="120px" prop="campusName">
                        <el-input placeholder="" type="textarea" v-model="dialogFormData.campusName" maxlength="50" style="width: 300px"
                                  @input="value=>{this.dialogFormData.campusName=this.$util.checkCnEnNu(value)}"></el-input>
                    </el-form-item>
                    <el-form-item label="地址" label-width="120px" prop="address">
                        <el-input placeholder="" type="textarea" v-model="dialogFormData.address" maxlength="50" style="width: 300px"  @input="value=>{this.dialogFormData.address=this.$util.checkCnEnNu(value)}"></el-input>
                    </el-form-item>
                    <el-form-item label="联系人" label-width="120px" prop="contact">
                        <el-input placeholder="" v-model="dialogFormData.contact" maxlength="10"
                                  style="width: 300px" @input="value=>{this.dialogFormData.contact=this.$util.checkCnEn(value)}"></el-input>
                    </el-form-item>
                    <el-form-item label="联系方式" label-width="120px" prop="contactInfo">
                        <el-input placeholder="" v-model="dialogFormData.contactInfo" maxlength="11" style="width: 300px" @input="value=>{this.dialogFormData.contactInfo = this.$util.checkNumber(value,true)}"></el-input>
                    </el-form-item>
                </el-form>
                <span class="dialog-footer" slot="footer">
                    <el-button type="primary" v-show="status.saveButtonVisible" @click="save('dialogFormData')" :disabled="isSave">保存</el-button>
                    <el-button type="danger" v-show="status.deleteButtonVisible" @click="deleteCampus">删除</el-button>
                    <el-button @click="status.campusDialogVisible = false" v-show="status.cancelButtonVisible">取 消</el-button>
                </span>
            </el-dialog>
        </div>
        <div class="lookCampusDialog">
            <el-dialog title="校区资料" :visible.sync="status.lookCampusDialogVisible" width="480px">
                <el-form :model="lookDialogFormData" inline class="demo-form-inline" :rules="rules">
                    <el-form-item label="省份" label-width="120px">
                        <el-input placeholder="" v-model="lookDialogFormData.provinceName" maxlength="20" style="width: 300px" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="市级" label-width="120px">
                        <el-input placeholder="" v-model="lookDialogFormData.cityName" maxlength="20" style="width: 300px" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="区县" label-width="120px">
                        <el-input placeholder="" v-model="lookDialogFormData.areaName" maxlength="20" style="width: 300px" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="校区名称" label-width="120px">
                        <el-input placeholder="" type="textarea" v-model="lookDialogFormData.campusName" maxlength="20" style="width: 300px" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="地址" label-width="120px">
                        <el-input placeholder="" type="textarea" v-model="lookDialogFormData.address" maxlength="20" style="width: 300px" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="联系人" label-width="120px">
                        <el-input placeholder="" v-model="lookDialogFormData.contact" maxlength="10" style="width: 300px" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="联系方式" label-width="120px">
                        <el-input placeholder="" v-model.number="lookDialogFormData.contactInfo" maxlength="11" style="width: 300px" readonly></el-input>
                    </el-form-item>
                </el-form>
            </el-dialog>
        </div>

    </div>
</template>

<script>
    let addOrUpdate;
    export default {
        name: "campus-manage",
        data(){
            return{
                isSave:false,
                tableData: [], //表格数据
                campusDialogTitle:'',
                status:{
                    lookCampusDialogVisible:false,
                    deleteButtonVisible:false,
                    saveButtonVisible:false,
                    cancelButtonVisible:false,
                    dataLoading:false,
                    provinceStatu:false,
                    cityStatu:false,
                    districtStatu:false,
                    campusDialogVisible:false,
                },

                provinceOptions:[], //省份下拉列表
                cityOptions:[],//市下拉列表
                districtOptions:[],//区下拉列表

                dialogProvinceOptions:[], //省份下拉列表
                dialogCityOptions:[],//市下拉列表
                dialogDistrictOptions:[],//区下拉列表

                //查询条件数据
                formData:{
                    provinceId:'',
                    cityId:'',
                    districtId:'',
                },

                //查看框数据
                lookDialogFormData:{
                    provinceName:'',
                    cityName:'',
                    areaName:'',
                    campusName:'',
                    address:'',
                    contact:'',
                    contactInfo:'',
                },

                dialogFormData:{
                    provinceId:'',
                    provinceName:'',
                    cityId:'',
                    cityName:'',
                    areaId:'',
                    areaName:'',
                    campusName:'',
                    address:'',
                    contact:'',
                    contactInfo:'',
                },
                searchParams:{
                    page:1, //第几页
                    limit:10 //每页条数
                },
                campusListTotal:0,

                rules:{
                    provinceId:[
                        { required: true, message: '请选择省份', trigger: 'blur' },
                    ],
                    cityId:[
                        { required: true, message: '请选择市', trigger: 'blur' },
                    ],
                    areaId:[
                        { required: true, message: '请选择区县', trigger: 'blur' },
                    ],
                    campusName:[
                        { required: true, message: '请输入校区名', trigger: 'blur' },
                    ],
                    address:[
                        { required: true, message: '请输入校区地址', trigger: 'blur' },
                    ],
                    contact:[
                        { required: true, message: '请输入联系人姓名', trigger: 'blur' },
                    ],
                    contactInfo:[
                        { required: true, message: '请输入联系人手机号码', trigger: 'blur' },
                        { min: 11, max: 11, message: '长度为11个字符', trigger: 'blur' }
                    ],
                }
            }
        },
        created() {
            this.queryCampus();
            this.selectProvince();
        },
        methods:{
            /**
             * 添加校区
             */
            save(formName){
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        if (addOrUpdate==="add"){
                            let params={};
                            params=this.dialogFormData;
                            this.isSave=true;
                            this.$request(params,"/masters/addCampus",res=>{
                                this.status.campusDialogVisible=false;
                                this.$message.success(res.message);
                                this.queryCampus();
                            },()=>{
                                this.isSave=false;
                            })
                        }else if (addOrUpdate==="update"){
                            let params={};
                            params=this.dialogFormData;
                            this.isSave=true;
                            this.$request(params,"/masters/updateCampus",res=>{
                                this.status.campusDialogVisible=false;
                                this.$message.success(res.message);
                                this.queryCampus();
                            },()=>{
                                this.isSave=false;
                            })
                        }
                    }
                });
            },

            /**
             * 删除校区
             */
            deleteCampus(){
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    let params={}
                    params.campusId=this.dialogFormData.campusId
                    this.$request(params,"/masters/deleteCampus",res=>{
                        this.status.campusDialogVisible=false;
                        this.$message.success(res.message);
                        this.queryCampus();
                    },err=>{
                        this.$message.success(err.message);
                        console.log(err);
                    })
                });
            },

            /**
             * 初始化校区列表及查询
             */
            queryCampus(){
                this.status.dataLoading=true;
                let params={};
                params=this.formData;
                params.page=this.searchParams.page;
                params.limit=this.searchParams.limit;
                this.$request(params,"/masters/campusList",res=>{
                    this.campusListTotal=res.total;
                    this.tableData=res.list;
                    this.status.dataLoading=false;
                },err=>{
                    console.log(err);
                    this.status.dataLoading=false;
                })
            },

            /**
             * 添加按钮
             */
            addCampus(){
                addOrUpdate="add";
                this.campusDialogTitle="添加校区";
                this.status.campusDialogVisible=true;
                this.status.deleteButtonVisible=false;
                this.status.saveButtonVisible=true;
                this.status.cancelButtonVisible=true;

            },

            /**
             * 查看校区
             * @param item
             */
            lookCampus(item){
                this.status.lookCampusDialogVisible=true;
                this.lookDialogFormData=item;
            },

            /**
             * 编辑校区
             * @param item
             */
            updateCampus(item){
                addOrUpdate="update";
                this.dialogSelectCity(item.provinceId)
                this.dialogSelectDistrict(item.cityId)
                this.campusDialogTitle="编辑资料"
                this.status.campusDialogVisible=true;
                this.status.deleteButtonVisible=true;
                this.status.saveButtonVisible=true;
                this.status.cancelButtonVisible=true;
                this.$nextTick(()=>{
                    this.dialogFormData= {...item};
                })
            },


            handleSizeChange(limit){
                this.searchParams.limit = limit;
                this.queryCampus();
            },
            handleCurrentChange(page){
                if(page){
                    this.searchParams.page=page;
                }
                this.queryCampus();
            },


            //查询所有省
            selectProvince(){
                this.$request({},"/masters/mapper/select/area.queryProvince",res=>{
                    if (res.flag === 200){
                        this.provinceOptions = res.list
                    }
                },err=>{
                    console.log(err);
                })
            },
            //查询所有市
            selectCity(areaCode){
                this.formData.cityId = '';
                this.formData.districtId = '';
                this.$request({"areaCode":areaCode},"/masters/mapper/select/area.queryCity",res=>{
                    if (res.flag === 200){
                        this.cityOptions = res.list
                    }
                },err=>{
                    console.log(err);
                })
            },
            dialogSelectCity(areaCode){
                this.dialogFormData.cityId='';
                this.dialogFormData.areaId='';
                this.$request({"areaCode":areaCode},"/masters/mapper/select/area.queryCity",res=>{
                    if (res.flag === 200){
                        this.dialogCityOptions = res.list;
                        let pro = this.provinceOptions.find(province=>{
                            return province.areaCode === areaCode
                        });
                        this.dialogFormData.provinceId=pro.areaCode;
                        this.dialogFormData.provinceName=pro.areaName;
                    }
                },err=>{
                    console.log(err);
                })
            },

            //查询所有区
            selectDistrict(areaCode){
                this.formData.districtId = '';
                this.$request({"areaCode":areaCode},"/masters/mapper/select/area.queryDistrict",res=>{
                    if (res.flag === 200){
                        this.districtOptions = res.list
                    }
                },err=>{
                    console.log(err);
                })
            },
            dialogSelectDistrict(areaCode){
                this.dialogFormData.areaId='';
                this.$request({"areaCode":areaCode},"/masters/mapper/select/area.queryDistrict",res=>{
                    if (res.flag === 200){
                        this.dialogDistrictOptions = res.list;
                        let pro = this.dialogCityOptions.find(district=>{
                            return district.areaCode === areaCode
                        });
                        this.dialogFormData.cityId=pro.areaCode;
                        this.dialogFormData.cityName=pro.areaName;
                    }
                },err=>{
                    console.log(err);
                })
            },

            dialogGetDistrict(areaCode){
                let pro = this.dialogDistrictOptions.find(district=>{
                    return district.areaCode === areaCode
                });
                this.dialogFormData.areaId=pro.areaCode;
                this.dialogFormData.areaName=pro.areaName;
            },


            /*
            * 对话框关闭时清除数据
            * */
            dialogClosed(){
                this.isSave=false;
                this.$refs.dialogFormData.resetFields();
            },
        },
    }
</script>

<style scoped lang="less"></style>
