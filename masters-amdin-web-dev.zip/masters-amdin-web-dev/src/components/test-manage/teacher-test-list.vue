<template>
    <div class="teacher-test-list">
        <!-- 搜索列表-->
        <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
            <el-form-item label="试卷名称" prop="testPaperType">
                <el-select v-model="formInline.testPaperType" style="width: 100px">
                    <el-option label="全部" value="" ></el-option>
                    <el-option v-for="itme in testpaperlist" :key="itme.testPaperType" :label="itme.attribute"
                               :value="itme.testPaperType"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="年级" prop="gradeId">
                <el-select v-model="formInline.gradeId" style="width: 100px">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in gradeList" :key="item.gradeId" :label="item.gradeName"
                               :value="item.gradeId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="科目" prop="subjectId">
                <el-select v-model="formInline.subjectId" style="width: 100px">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="itme in subjectList" :key="itme.subjectId" :label="itme.subjectName"
                               :value="itme.subjectId"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="难度" prop="hardLevel">
                <el-select v-model="formInline.hardLevel" style="width: 100px">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="itme in difficultylist" :key="itme.hardLevel" :label="itme.difficultyvalue"
                               :value="itme.hardLevel"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="是否主观" prop="isSubjective">
                <el-select v-model="formInline.isSubjective" style="width: 100px">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="itme in isSubjectivelist" :key="itme.isSubjective" :label="itme.isSubjectivename"
                               :value="itme.isSubjective"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="testLishandleSearch(1)" :loading="status.dataLoading"> 查询</el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="success" @click="add">添加</el-button>
            </el-form-item>
        </el-form>
        <!--试题列表-->
        <template>
            <el-table :data="tableData" style="width: 100%;border: 1px solid #EBEEF5; border-bottom: none"
                      v-loading="status.tabledataLoading">
                <el-table-column prop="index" label="序号" min-width="50" type="index"></el-table-column>
                <el-table-column prop="testPaperType" label="试卷属性" min-width="100">
                    <template slot-scope="scope">
                        <span v-if="scope.row.testPaperType=== 1">{{formatCourssewareType(scope.row)}}</span>
                        <span v-else-if="scope.row.testPaperType === 2">  {{formatCourssewareType(scope.row)}} </span>
                        <span v-else-if="scope.row.testPaperType === 3">  {{formatCourssewareType(scope.row)}} </span>
                    </template>
                </el-table-column>
                <el-table-column prop="gradeName" label="年级" min-width="80"></el-table-column>
                <el-table-column prop="subjectName" label="科目" min-width="80"></el-table-column>
                <el-table-column prop="testPaperName" label="试卷名称" min-width="200"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column prop="hardLevel" label="难度" min-width="80">
                    <template slot-scope="scope">
                        <span v-if="scope.row.hardLevel=== 1">{{difficultyType(scope.row)}}</span>
                        <span v-else-if="scope.row.hardLevel === 2">  {{difficultyType(scope.row)}} </span>
                        <span v-else-if="scope.row.hardLevel === 3">  {{difficultyType(scope.row)}} </span>
                    </template>
                </el-table-column>
                <el-table-column prop="themeNum" label="题目数量" min-width="80"></el-table-column>
                <el-table-column prop="isSubjective" label="是否主观" min-width="50">
                    <template slot-scope="scope">
                        <span v-if="scope.row.isSubjective=== 1">{{isSubjectiveType(scope.row)}}</span>
                        <span v-else-if="scope.row.isSubjective === 2">  {{isSubjectiveType(scope.row)}} </span>
                    </template>
                </el-table-column>
                <el-table-column prop="operateTime" label="上传日期" min-width="150"></el-table-column>
                <el-table-column prop="operation" label="操作" min-width="150">
                    <template slot-scope="scope">
                        <el-button type="text" @click="lookTest(scope.row.testPaperId)">
                            查看
                        </el-button>
                        <el-button type="text" @click="edit(scope.row.testPaperId)" v-if="scope.row.testPaperType===1">
                            编辑
                        </el-button>
                        <el-button type="text" @click="handleTopicManage(scope.row.testPaperId)"
                                   v-if="scope.row.testPaperType===1">题型管理
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </template>
        <!--分页组件-->
        <div class="pages">
            <el-pagination
                    background
                    :page-sizes="[5, 10, 20, 50]"
                    :page-size="formInline.limit"
                    :current-page="formInline.page"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @size-change="testListhandlePageSize"
                    @current-change="testLishandleSearch">

            </el-pagination>
        </div>
        <!--添加  编辑  试卷弹框-->
        <el-dialog :title="addTitle" width="650px" :visible.sync="dialogFormVisible" @closed="dialogFormVisibleClosed">
            <div class="test-scrollbar">
                <el-scrollbar style="height:100%">
                    <el-form :model="AddOrEditForm" ref="AddOrEditForm" :rules="AddOrFormRules" :inline="true"
                             class="demo-form-inline demo-form-margin" :label-position="labelPosition"
                             label-width="80px">
                        <el-form-item label="年级" prop="gradeName">
                            <el-select v-model="AddOrEditForm.gradeName" style="width:100px" placeholder="年级"
                                       @change="getgradeName($event)">
                                <el-option v-for="itme in  gradeList " :key="itme.gradeId" :label="itme.gradeName"
                                           :value="itme.gradeId"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="科目" prop="subjectName">
                            <el-select v-model="AddOrEditForm.subjectName" style="width: 100px" placeholder="科目"
                                       @change="getSubject($event)">
                                <el-option v-for="itme in subjectList" :key="itme.subjectId" :label="itme.subjectName"
                                           :value="itme.subjectId"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="难度" prop="hardLevel">
                            <el-select v-model="AddOrEditForm.hardLevel" style="width: 100px" placeholder="难度">
                                <el-option v-for="itme in difficultylist" :key="itme.hardLevel"
                                           :label="itme.difficultyvalue"
                                           :value="itme.hardLevel"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="总分" prop="totalScore">
                            <el-input v-model="AddOrEditForm.totalScore" style="width: 100px" maxlength="4"
                                      @input="value=>{this.AddOrEditForm.totalScore = this.$util.checkNumber(value)}"></el-input>
                        </el-form-item>
                        <el-form-item label="主观" prop="isSubjective">
                            <el-select v-model="AddOrEditForm.isSubjective" placeholder="是否主观" style="width: 100px">
                                <el-option v-for="itme in isSubjectivelist" :key="itme.isSubjective"
                                           :label="itme.isSubjectivename" :value="itme.isSubjective"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="题目数量" prop="themeNum">
                            <el-input v-model="AddOrEditForm.themeNum" style="width: 100px" maxlength="4"
                                      @input="value=>{this.AddOrEditForm.themeNum = this.$util.checkNumber(value)}"></el-input>
                        </el-form-item>
                        <el-form-item label="试卷名称" prop="testPaperName">
                            <el-input v-model="AddOrEditForm.testPaperName" style="width: 200px" placeholder="试卷名称"
                                      minlength="2" maxlength="12"></el-input>
                        </el-form-item>
                        <el-form-item label="试卷文件" prop="fileList"><span
                                class="supported">支持扩展名为docx,ppt,pdf,jpg,png,jpeg,ppt,pptx</span>
                        </el-form-item>
                        <el-form-item>
                            <!--上传 图片 文件-->
                            <div :class="!$util.isEmpty(AddOrEditForm.fileList) && AddOrEditForm.fileList.length >4 ? 'el-form-item-image' : 'el-form-item-image-height'"
                                 style="margin-left: 27px">
                                <div class="imga-update">
                                    <el-upload :action="this.$uploadFileUrl" list-type="picture-card"
                                               :on-success="fileUploadSuccess"
                                               :before-upload="fileUpload"
                                               :file-list="AddOrEditForm.fileList"
                                    >
                                        <i slot="default" class="el-icon-plus"></i>
                                        <div slot="file" slot-scope="{file}">
                                            <div class="uid-type" v-if="!isImg(file)">
                                                <span style="padding-right: 5px"><i class="el-icon-folder"></i></span>
                                                <span v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'">{{file.uid.substring(file.uid.lastIndexOf("_")+1)}}</span>
                                            </div>
                                            <img v-else class="el-upload-list__item-thumbnail"
                                                 :src="$getFileUrl+file.uid" style="height: 100px" alt/>
                                            <span class="el-upload-list__item-actions">
                                             <el-tooltip effect="light"
                                                         v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'"
                                                         :content="file.uid.substring(file.uid.lastIndexOf('_')+1)"
                                                         placement="top">
                                                 <span class="el-upload-list__item-preview"
                                                       @click="handlePictureCardPreview(file)"><i
                                                         class="el-icon-view"></i> </span>
                                             </el-tooltip>
                                             <span class="el-upload-list__item-preview" @click="handleRemove(file)"><i
                                                     class="el-icon-delete"></i> </span>
                                    </span>
                                        </div>
                                    </el-upload>
                                    <el-dialog :visible.sync="dialogVisible" width="900px" top="80px" @close="lookDialogVisibleClose">
                                        <div style="width: 100%;height: 650px;margin-top: 20px">
                                            <el-scrollbar style="height:100%">
                                                <img v-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.jpg' || dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))=='.png' || dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))==='.jpeg' "
                                                     style="height:100%;width: 100%" :src="dialogImageUrl"/>
                                                <div class="pdf"
                                                     v-else-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.pdf'">
                                                    <div style="width:200px">
                                                        <!--    上一页-->
                                                        <span @click="changePdfPage(0)">上一页</span>
                                                        {{currentPage}} / {{pageCount}}
                                                        <!--下一页-->
                                                        <span @click="changePdfPage(1)">下一页</span>
                                                    </div>
                                                    <pdf ref="myPDF"
                                                         :src="dialogImageUrl"
                                                         :page="currentPage"
                                                         @num-pages="pageCount=$event"
                                                         @page-loaded="currentPage=$event"
                                                         @loaded="loadPdfHandler"
                                                    >
                                                    </pdf>
                                                </div>
                                                <div v-else style="height:700px;width: 97%">
                                                    <iframe style="height:700px;width: 100%;margin-top: -90px"
                                                            :src="dialogImageUrl"></iframe>
                                                </div>
                                            </el-scrollbar>
                                        </div>
                                    </el-dialog>
                                </div>
                            </div>
                        </el-form-item>
                    </el-form>
                </el-scrollbar>
            </div>

            <!--上传图片-->
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="saveAdd" :loading="status.topicSaving">保存</el-button>
                <el-button type="danger" v-show="showdel" @click="deltest">删除</el-button>
                <el-button @click="dialogFormVisible = false">取 消</el-button>
            </div>
        </el-dialog>
        <!--  点击  查看试卷 -->
        <el-dialog title="查看试卷" width="520px" :visible.sync="LookTestFormVisible" v-loading="status.dataLoading"
                   @closed="LookTestFormVisibleClosed">
            <div class="test-scrollbar">
                <el-scrollbar style="height:100%">
                    <el-form ref="dataForm" :model="lookDetails" :inline="true"
                             class="demo-form-inline demo-form-margin"
                             label-position="left" label-width="100px" style="margin-left: 10px">
                        <el-form-item label="年级" style="letter-spacing: 30px">
                            <el-input readonly v-model="lookDetails.gradeName" style="width: 100px;margin-left: -30px"
                                      placeholder="试卷名称"></el-input>

                        </el-form-item>
                        <el-form-item label="科目" style="margin-left: 30px;letter-spacing: 30px">
                            <el-input readonly v-model="lookDetails.subjectName" style="width: 100px;margin-left: -30px"
                                      placeholder="试卷名称"></el-input>
                        </el-form-item>
                        <el-form-item label="难度" style="letter-spacing: 30px">
                            <el-input readonly v-model="lookDetails.hardLevel" style="width: 100px;margin-left: -30px"
                                      placeholder="试卷名称"></el-input>
                        </el-form-item>
                        <el-form-item label="属性" style="margin-left: 30px;letter-spacing: 30px">
                            <el-input readonly v-model="lookDetails.testPaperType"
                                      style="width: 100px;margin-left: -30px"
                                      placeholder="试卷名称"></el-input>
                        </el-form-item>
                        <el-form-item label="总分" style="letter-spacing: 30px">
                            <el-input readonly v-model="lookDetails.totalScore"
                                      style="width: 100px;margin-left: -30px"></el-input>
                        </el-form-item>
                        <el-form-item label="题目数量" style="margin-left: 30px">
                            <el-input readonly v-model="lookDetails.themeNum"
                                      style="width: 100px;margin-left: -30px"></el-input>
                        </el-form-item>
                    </el-form>
                    <el-form style="margin-left: 10px">
                        <el-form-item label="试卷名称">
                            <el-input readonly v-model="lookDetails.testPaperName" style="width: 200px"
                                      placeholder="试卷名称"></el-input>
                        </el-form-item>
                        <el-form-item label="试卷文件"></el-form-item>
                        <el-form-item>
                            <!-- 查看上传 图片 文件-->
                            <div :class="fileListlength > 5 ? 'el-form-item-image' : 'el-form-item-image-height'">
                                <div class="imga-update imga-update-show  " style="width: 460px">
                                    <el-upload action="#" list-type="picture-card"
                                               :file-list="lookDetails.fileList"
                                               disabled
                                    >
                                        <div slot="file" slot-scope="{file}">
                                            <div class="uid-type" v-if="!isImg(file)"><span
                                                    style="padding-right: 5px"><i
                                                    class="el-icon-folder"></i></span>
                                                <span v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'">{{file.uid.substring(file.uid.lastIndexOf("_")+1)}}</span>
                                            </div>
                                            <img v-else class="el-upload-list__item-thumbnail"
                                                 :src="$getFileUrl+file.uid"
                                                 style="height: 100px"
                                                 alt/>
                                            <span class="el-upload-list__item-actions">
                                            <el-tooltip effect="light"
                                                        v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'"
                                                        :content="file.uid.substring(file.uid.lastIndexOf('_')+1)"
                                                        placement="top">
                                                   <span class="el-upload-list__item-preview"
                                                         @click="handlePictureCardPreview(file)"><i
                                                           class="el-icon-view"></i> </span>
                                                  </el-tooltip>
                                    </span>


                                        </div>
                                    </el-upload>
                                    <el-dialog :visible.sync="dialogVisible" width="900px" top="80px"   @close="lookDialogVisibleClose">
                                        <div style="width: 100%;height: 700px;margin-top: 20px">
                                            <el-scrollbar style="height:100%">
                                                <img v-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.jpg' ||  dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))=='.png' || dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))==='.jpeg' "
                                                     style="height:100%;width: 100%" :src="dialogImageUrl"/>
                                                <div class="pdf"
                                                     v-else-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.pdf'">
                                                    <div style="width:200px">
                                                        <!--    上一页-->
                                                        <span @click="changePdfPage(0)">上一页</span>
                                                        {{currentPage}} / {{pageCount}}
                                                        <!--下一页-->
                                                        <span @click="changePdfPage(1)">下一页</span>
                                                    </div>
                                                    <pdf ref="myPDF"
                                                         :src="dialogImageUrl"
                                                         :page="currentPage"
                                                         @num-pages="pageCount=$event"
                                                         @page-loaded="currentPage=$event"
                                                         @loaded="loadPdfHandler"
                                                    >
                                                    </pdf>
                                                </div>
                                                <div v-else style="height:700px;width: 97%">
                                                    <iframe style="height:700px;width: 100%;margin-top: -90px"
                                                            :src="dialogImageUrl"></iframe>
                                                </div>
                                            </el-scrollbar>
                                        </div>
                                    </el-dialog>
                                </div>
                            </div>
                        </el-form-item>
                        <div class="onpaper" v-show="onpaper"> 暂无试卷</div>
                    </el-form>
                </el-scrollbar>
            </div>
        </el-dialog>

        <!-- 题型管理弹窗 -->
        <el-dialog title="题型管理" :visible.sync="status.topicManageDialogOpen" width="1200px"
                   @close="handleTopicManageClose"
                   :close-on-click-modal="false">
            <!-- 试卷答案与解析 -->
            <div>
                <el-row :gutter="20">
                    <!-- 题型管理 -->
                    <el-col :span="12">
                        <div style="height:40px;">
                            试卷题型
                            <el-button type="success" @click="handleTopicDialog(null)" style="float: right">添加题型
                            </el-button>
                        </div>
                        <el-table :data="topicData" v-loading="status.topicDataLoading"
                                  style="border: 1px solid #EBEEF5; border-bottom: none"
                                  @row-click="handleClickTopic" highlight-current-row>
                            <el-table-column label="题号" prop="topicIndex" min-width="50px"></el-table-column>
                            <el-table-column label="题型" min-width="100px"
                                             :formatter="formatTopicType"></el-table-column>
                            <el-table-column label="数量" prop="topicThemeNum" min-width="80px"></el-table-column>
                            <el-table-column label="分数" prop="topicScore" min-width="80px"></el-table-column>
                            <el-table-column label="操作" min-width="100px">
                                <template slot-scope="scope">
                                    <el-button type="text" @click.stop="handleTopicDialog(scope.row)">编辑</el-button>
                                    <el-button type="text" @click.stop="handleTopicDelete(scope.row.topicId)">删除
                                    </el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <!--分页组件-->
                        <el-pagination
                                layout="total"
                                background
                                :total="topicDataTotal">
                        </el-pagination>
                    </el-col>
                    <!-- 题目管理 -->
                    <el-col :span="12">
                        <div style="height:40px;">
                            所属题目
                            <el-button type="success" @click="handleThemeDialog(themePageInfo.topicType)"
                                       style="float: right"
                                       :disabled="$util.isEmpty(themePageInfo.topicId) || $util.isEmpty(themePageInfo.testPaperId)">
                                添加题目
                            </el-button>
                        </div>
                        <el-table :data="themeData" v-loading="status.themeDataLoading"
                                  style="border: 1px solid #EBEEF5; border-bottom: none">
                            <el-table-column label="题号" prop="themeIndex" min-width="50px"></el-table-column>
                            <el-table-column label="类型" min-width="100px"
                                             :formatter="formatTopicType"></el-table-column>
                            <el-table-column label="分数" prop="score" min-width="80px"></el-table-column>
                            <el-table-column label="答案" prop="answer" min-width="100px"
                                             show-overflow-tooltip></el-table-column>
                            <el-table-column label="解题思路" prop="index" min-width="100px" align="center">
                                <template slot-scope="scope">
                                    <el-button type="text"
                                               v-if="!$util.isEmpty(scope.row.themeSolveCount) && scope.row.themeSolveCount>0"
                                               @click="handleShowThemeSolve(scope.row)">查看
                                    </el-button>
                                    <i v-else class="el-icon-upload upload-icon"
                                       @click="handleUploadThemeSolve(scope.row)"></i>
                                </template>
                            </el-table-column>
                            <el-table-column label="操作" min-width="100px">
                                <template slot-scope="scope">
                                    <el-button type="text" @click.stop="editSubject(scope.row)">编辑
                                    </el-button>
                                    <el-button type="text" @click.stop="handleThemeDelete(scope.row.themeId)">删除
                                    </el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <!--分页组件-->
                        <el-pagination
                                layout="total, prev, pager, next"
                                background
                                :current-page="themePageInfo.page"
                                :page-size="themePageInfo.limit"
                                :total="themeDataTotal"
                                @current-change="handleThemePage">
                        </el-pagination>
                    </el-col>
                </el-row>
            </div>
        </el-dialog>
        <!-- 题型添加、编辑弹窗 -->
        <el-dialog :title="topicDialogTitle" :visible.sync="status.topicDialogOpen" width="500px"
                   :close-on-click-modal="false" @closed="handleResetForm('topicForm')">
            <el-form :model="topicFormData" ref="topicForm" :rules="topicFormRules" label-width="110px">
                <el-form-item label="题号" prop="topicIndex">
                    <el-input v-model.number="topicFormData.topicIndex" style="width: 300px" placeholder="请输入数字"
                              @input="value=>{this.topicFormData.topicIndex = this.$util.checkNumber(value)}"></el-input>
                </el-form-item>
                <el-form-item label="题型" prop="topicType">
                    <el-select v-model="topicFormData.topicType" style="width: 300px">
                        <el-option
                                v-for="item in topicTypeList"
                                :key="item.itemVal"
                                :label="item.itemName"
                                :value="parseInt(item.itemVal)"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="题目数量" prop="topicThemeNum">
                    <el-input v-model.number="topicFormData.topicThemeNum" style="width: 300px" placeholder="请输入正数"
                              @input="value=>{this.topicFormData.topicThemeNum = this.$util.checkNumber(value)}"></el-input>
                </el-form-item>
                <el-form-item label="分数" prop="topicScore">
                    <el-input v-model.number="topicFormData.topicScore" style="width: 300px" placeholder="请输入正数"
                              @input="value=>{this.topicFormData.topicScore = this.$util.checkNumber(value)}"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                    <el-button @click="status.topicDialogOpen = false">取消</el-button>
                    <el-button type="primary" @click="handleTopicSubmit" :loading="status.topicSaving"
                               >保存</el-button>
                </span>
        </el-dialog>
        <!--添加 编辑题目 弹框 -->
        <el-dialog :title="AddeditTitle" :visible.sync="EditingQuestionsFormVisible" width="550px"
                   @closed="subjectDialogFormVisibleClosed">
            <div class="test-scrollbar">
                <el-scrollbar style="height:100%">
                    <el-form :model="subjectForm" label-width="70px" ref="subjectFormrule" :rules="subjectFormrule">
                        <el-form-item label="题号" prop="themeIndex">
                            <el-input :readonly="readonly" v-model.number="subjectForm.themeIndex" style="width: 200px"
                                      minlength="0"
                                      maxlength="2" placeholder="请输入数字"
                                      @input="value=>{this.subjectForm.themeIndex = this.$util.checkNumber(value)}"></el-input>
                        </el-form-item>
                        <el-form-item label="题型" v-model="subjectForm.topicType" prop="topicType">
                            <el-input readonly :value="topicName" :label="topicName" style="width: 200px"></el-input>
                            <el-select v-if="optionShow" v-model="subjectForm.choseType"
                                       style="width: 100px;margin-left: 10px" :disabled="readonly"
                                       placeholder="请选择">
                                <el-option
                                        :readonly="readonly"
                                        v-for="item in options"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="选项" v-if="optionShow" prop="option">
                            <el-input :readonly="readonly" v-model="subjectForm.option" style="width: 330px"
                                      placeholder="例如:A：苹果；B：香蕉；C：桃子"
                                      maxlength="150"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="答案" v-if="answerShow" prop="answer">
                            <el-input :readonly="readonly" v-model="subjectForm.answer" style="width: 200px"
                                      minlength="0" maxlength="24" :placeholder="placeholder"></el-input>
                        </el-form-item>
                        <el-form-item label="答案" v-if="radioShow" prop="answer">
                            <el-radio-group v-model="subjectForm.answer">
                                <el-radio label="YES">正确</el-radio>
                                <el-radio label="NO">错误</el-radio>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="分数" prop="score">
                            <el-input v-model.number="subjectForm.score" :readonly="readonly" style="width: 200px"
                                      placeholder="请输入正数"
                                      @input="value=>{this.subjectForm.score = this.$util.checkNumber(value)}"
                                      maxlength="3"

                            ></el-input>
                        </el-form-item>
                        <el-form-item label="解题思路">
                            <span class="supported">支持扩展名为docx,ppt,pdf,jpg,png,jpeg,ppt,pptx</span>
                        </el-form-item>
                        <el-form-item prop="fileList">
                            <!--查看  编辑 添加 题目 上传 图片 文件-->
                            <div class=" el-form-item-paper">
                                <div :class="showClass">
                                    <el-upload :action="this.$uploadFileUrl" list-type="picture-card"
                                               :on-success="fileUploadSuccesspaper"
                                               :before-upload="fileUpload"
                                               :file-list="subjectForm.fileList"
                                               :disabled="disabled"

                                    >
                                        <i slot="default" class="el-icon-plus"></i>
                                        <div slot="file" slot-scope="{file}">
                                            <div class="uid-type" v-if="!isImg(file)"><span
                                                    style="padding-right: 5px"><i
                                                    class="el-icon-folder"></i></span>
                                                <span v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'">{{file.uid.substring(file.uid.lastIndexOf("_")+1)}}</span>
                                            </div>
                                            <img class="el-upload-list__item-thumbnail" :src="$getFileUrl+file.uid"
                                                 style="height:100px"
                                                 alt/>
                                            <span class="el-upload-list__item-actions">
                                          <el-tooltip effect="light"
                                                      v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'"
                                                      :content="file.uid.substring(file.uid.lastIndexOf('_')+1)"
                                                      placement="top">
                                                   <span class="el-upload-list__item-preview"
                                                         @click="handlePictureCardPreview(file)"><i
                                                           class="el-icon-view"></i> </span>
                                          </el-tooltip>
                                              <span class="el-upload-list__item-preview"
                                                    @click="handleRemovepaper(file)" v-if="readonly === false  "><i
                                                      class="el-icon-delete"></i> </span>
                                            <span class="el-upload-list__item-preview" @click="handleRemovepaper(file)"
                                                  v-if="readonlyThemeSolve===true"><i
                                                    class="el-icon-delete"></i> </span>
                                    </span>
                                        </div>
                                    </el-upload>
                                    <el-dialog :visible.sync="dialogVisible" width="900px" top="80px" @close="lookDialogVisibleClose">
                                        <div style="width: 100%;height: 700px;margin-top: 20px">
                                            <el-scrollbar style="height:100%">
                                                <img v-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.jpg' ||  dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))=='.png' || dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))==='.jpeg' "
                                                     style="height:100%;width: 100%" :src="dialogImageUrl"/>
                                                <div class="pdf"
                                                     v-else-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.pdf'">
                                                    <div style="width:200px">
                                                        <!--    上一页-->
                                                        <span @click="changePdfPage(0)">上一页</span>
                                                        {{currentPage}} / {{pageCount}}
                                                        <!--下一页-->
                                                        <span @click="changePdfPage(1)">下一页</span>
                                                    </div>
                                                    <pdf ref="myPDF"
                                                         :src="dialogImageUrl"
                                                         :page="currentPage"
                                                         @num-pages="pageCount=$event"
                                                         @page-loaded="currentPage=$event"
                                                         @loaded="loadPdfHandler"
                                                    >
                                                    </pdf>
                                                </div>
                                                <div v-else style="height:700px;width: 97%">
                                                    <iframe style="height:700px;width: 100%;margin-top: -90px"
                                                            :src="dialogImageUrl"></iframe>
                                                </div>
                                            </el-scrollbar>
                                        </div>
                                    </el-dialog>
                                </div>
                            </div>

                        </el-form-item>
                    </el-form>
                </el-scrollbar>
            </div>
            <div slot="footer" class="dialog-footer" v-show="dialogFooter">
                <el-button type="primary" @click="preserEditingQuestionsFormVisible" :loading="status.topicSaving">保存
                </el-button>
                <el-button @click="EditingQuestionsFormVisible = false">取 消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import pdf from 'vue-pdf'

    export default {
        name: "teacher-test-list",
        components: {
            pdf
        },
        data() {
            //编辑 添加题目 选择题选项  规则
            let isOption = (rule, value, callback) => {
                let answer = value
                value = value + ";";
                let OptionReg = /^([A-Z][:|\uff1a][^;|:\uff1b|\uff1a]+[;|\uff1b|\s])+$/;
                if (!OptionReg.test(value.trim())) {
                    return callback(new Error('选项为A-Z,选项与答案之间冒号分隔,每个选项以分号分隔,答案中不能有分号和冒号'));
                } else {
                    value = value.trim()
                    value = value.substring(0, value.length - 1)
                    value = value.replace(/；/ig, ';')
                    value = value.replace(/：/ig, ':')
                    value = value.split(';')
                    for (let i = 0; i < value.length; i++) {
                        value[i] = value[i].split(':')[0]
                    }
                    for (let i = 0; i < value.length; i++) {
                        for (let j = i; j < value.length - 1; j++) {
                            if (value[i] === value[j + 1]) {
                                return callback(new Error('选项不能重复'));
                            }
                        }
                    }
                }
                answer = answer.split(';')
                for (let i = 0; i < answer.length; i++) {
                    answer[i] = answer[i].split(':')[1]
                }
                for (let i = 0; i < answer.length; i++) {
                    for (let j = i; j < answer.length - 1; j++) {
                        if (answer[i] === answer[j + 1]) {
                            return callback(new Error('答案不能重复'));
                        }
                    }
                }
                return callback()

            };
            //编辑 添加 题目 选择题答案  规则
            let isAnswer = (rule, value, callback) => {
                if (this.subjectForm.topicType === 1) {
                    this.subjectForm.answer = this.subjectForm.answer.replace(/，/ig, ',')
                    this.subjectForm.option = this.subjectForm.option.replace(/；/ig, ';')
                    this.subjectForm.option = this.subjectForm.option.replace(/：/ig, ':')
                    this.optionsvalue = this.subjectForm.option.split(';')
                    for (let i = 0; i < this.optionsvalue.length; i++) {
                        this.optionsvalue[i] = this.optionsvalue[i].split(':')[0]
                    }


                    if (this.subjectForm.choseType === 1) {
                        if (value.trim().length > 2) {
                            return callback(new Error('此选项为单选题,只能有一个答案'));
                        }
                        for (let i = 0; i < this.optionsvalue.length; i++) {
                            if (this.optionsvalue[i] === value.trim()) {
                                return callback();
                            }
                        }
                        return callback(new Error('答案必须在选项中存在'));
                    } else {
                        value = value + ",";
                        let answerReg = /^([A-Z]+[,|\uff0c])+$/;
                        if (!answerReg.test(value.trim())) {
                            return callback(new Error('答案必须为大写字母,以逗号分隔'));
                        }
                        if (value.trim().length < 3) {
                            return callback(new Error('答案必须为两个及两个以上'));
                        }
                        let option=this.subjectForm.option
                        option = option.split(';')
                        for (let i = 0; i < option.length; i++) {
                            option[i] = option[i].split(':')[0]
                        }
                        let  answerExit = value.substring(0, value.length - 1)
                        answerExit=answerExit.split(',')
                        //====
                        for (let i = 0; i < answerExit.length; i++) {
                            for (let j = i; j < answerExit.length - 1; j++) {
                                if (answerExit[i] === answerExit[j + 1]) {
                                    return callback(new Error('答案不能重复'));
                                }
                            }
                        }
                        //====
                        answerExit.find(item=>{
                            if(!option.includes(item)){
                                return callback(new Error('答案必须在选项中存在'));
                            }
                        })

                    }
                } else if (this.subjectForm.topicType === 5) {
                    value = value + ",";
                    let answerReg = /^(([1-9]?\d|100)[-]([1-9]?\d|100)[,|\uff0c])+$/;
                    if (!answerReg.test(value.trim())) {
                        return callback(new Error('选项以短横线分隔,每个答案以逗号分隔,选项不能超过100'));
                    }
                }
                return callback();
            };
            // 每种类型 的分数总和 不能大于 该题型 的总分

            return {
                optionsvalue: [],
                placeholder: "",
                readonly: false,
                readonlyThemeSolve: false,
                dialogFooter: true,
                disabled: false,
                showClass: "",
                SubjectDetailsRequest: {
                    themeId: "",
                    testPaperId: ""
                },
                onpaper: false,
                //判断题型
                optionShow: false,
                radioShow: false,
                choice: false,
                topicName: "",
                //题目表单
                subjectForm: {
                    themeIndex: "",
                    topicType: "",
                    answer: "",
                    score: null,
                    choseType: null,
                    option: null,
                    fileList: []
                },
                themeId: "",
                options: [{
                    value: 1,
                    label: "单选",
                }, {
                    value: 2,
                    label: "多选"
                }
                ],
                AddeditTitle: "",
                addsubjectlist: {},
                //判断文件类型
                fileType: true,
                labelPositione: 'right',
                testPaperId: "",
                formLabelAlign: {
                    name: '',
                    region: '',
                    type: ''
                },
                formInline: {
                    testPaperType: "",
                    gradeId: "",
                    subjectId: "",
                    hardLevel: "",
                    isSubjective: "",
                    teacherId: "",
                    page: 1,
                    limit: 10,
                },

                AddOrEditForm: {
                    gradeId: "",
                    gradeName: "",
                    subjectId: "",
                    subjectName: "",
                    hardLevel: "",
                    testPaperType: "1",
                    totalScore: "",
                    testPaperName: "",
                    isSubjective: "",
                    teacherId: "",
                    fileList: []
                },
                fileList: [],
                showdel: false,
                addform: {
                    subjectvalue: "",
                    gradevalue: "",
                },
                //是否主观
                isSubjectivelist: [{
                    isSubjective: 1,
                    isSubjectivename: "是"
                }, {
                    isSubjective: 2,
                    isSubjectivename: "否"
                }],
                //困难度
                difficultylist: [{
                    hardLevel: 1,
                    difficultyvalue: "简单",

                }, {
                    hardLevel: 2,
                    difficultyvalue: "中等",

                }, {
                    hardLevel: 3,
                    difficultyvalue: "困难",

                }],
                //试卷类型
                testpaperlist: [{
                    testPaperType: 1,
                    attribute: "个人试卷"
                }, {
                    testPaperType: 2,
                    attribute: "公共试卷"
                }],
                tableData: [],
                subjectList: [],
                gradeList: [],
                //查看试卷 详情
                lookDetails: {},
                fileListlength: 0,
                answerData: [{
                    tx: "填空题",
                    num: 4,
                    score: 100,
                }, {
                    tx: "填空题",
                    num: 4,
                    score: 100,
                }, {
                    tx: "填空题",
                    num: 4,
                    score: 100,
                }],
                // 试卷列表分页
                pageInfo: {
                    page: 1,
                    limit: 10,
                },
                dialogFormVisible: false,
                LookTestFormVisible: false,
                testTypeManageFormVisible: false,
                editTestFormVisible: false,
                addTitle: "添加试卷",
                form: {
                    name: '',
                    region: '',
                    date1: '',
                    date2: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
                labelPosition: 'right',
                //总条数
                total: 0,
                // 题目列表分页信息
                themePageInfo: {
                    page: 1,
                    limit: 10,
                },
                // 状态
                status: {
                    dataLoading: false,
                    topicManageDialogOpen: false,
                    topicDataLoading: false,
                    themeDataLoading: false,
                    topicDialogOpen: false,
                    topicSaving: false,
                    tabledataLoading: false,
                },
                topicDialogTitle: "添加题型",
                topicData: [],
                topicDataTotal: 0,
                topicFormData: {
                    topicId: "",
                    testPaperId: "",
                    topicIndex: "",
                    topicType: "",
                    topicThemeNum: "",
                    topicScore: "",
                },
                topicFormRules: {
                    topicIndex: [
                        {required: true, message: '题号不能为空', trigger: 'blur'},
                        {type: "number", min: 1, max: 10, message: '题号只能取1~10之间的数字', trigger: 'blur'},
                    ],
                    topicType: [
                        {required: true, message: '题型不能为空', trigger: 'change'}
                    ],
                    topicThemeNum: [
                        {required: true, message: '数量不能为空', trigger: 'blur'},
                        {type: "number", min: 1, max: 10000, message: '数量只能取1~10000之间的数字', trigger: 'blur'},
                    ],
                    topicScore: [
                        {required: true, message: '分数不能为空', trigger: 'blur'},
                        {type: "number", min: 0, max: 10000, message: '分数只能取0~10000之间的数字', trigger: 'blur'}
                    ],
                },
                AddOrFormRules: {
                    totalScore: [
                        {required: true, message: '总分不能为空', trigger: 'blur'},
                    ],
                    testPaperName: [
                        {required: true, message: '试卷名称不能为空', trigger: 'blur'},
                        {min: 2, max: 12, message: '账号长度须在2~16位之间'}
                    ],
                    gradeName: [{required: true, message: '年级不能为空', trigger: 'blur'}],
                    subjectName: [{required: true, message: '科目不能为空', trigger: 'blur'}],
                    hardLevel: [{required: true, message: '难度不能为空', trigger: 'blur'}],
                    testPaperType: [{required: true, message: '属性不能为空', trigger: 'blur'}],
                    isSubjective: [{required: true, message: '主观不能为空', trigger: 'blur'}],
                    fileList: [{required: true, message: '试卷文件不能为空', trigger: 'blur'}],

                },
                //题目表单验证
                subjectFormrule: {
                    themeIndex: [{required: true, message: '题号不能为空', trigger: 'blur'}],
                    topicType: [{required: true, message: '题型不能为空', trigger: 'blur'}],
                    option: [
                        {required: true, message: '选项不能为空', trigger: 'blur'},
                        {validator: isOption, trigger: 'blur'}
                    ],
                    answer: [
                        {required: true, message: '答案不能为空', trigger: 'blur'},
                        {validator: isAnswer, trigger: 'blur'}
                    ],
                    score: [
                        {required: true, message: '分数不能为空', trigger: 'blur'},
                    ],
                },
                themeData: [],
                themeDataTotal: 0,
                topicTypeList: [],
                //在线预览
                previewDomainName: 'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com',
                // 上传图片
                dialogImageUrl: "",
                currentPage: 0, // pdf文件页码
                pageCount: 0, // pdf文件总页数
                dialogVisible: false,
                flieList: [],
                // 添加题目 弹框
                EditingQuestionsFormVisible: false,
                answerShow: true,
            }
        },
        mounted() {
            // 题型字典
            this.topicTypeList = this.$dict.getDictByCode('TOPIC_TYPE') || [];
            this.testLishandleSearch(1);
        },
        created() {
        },
        methods: {
            //在线预览 打开  展示当前  文档
            lookDialogVisibleClose(){
                this.dialogImageUrl=''
            },
            // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
            changePdfPage(val) {
                if (val === 0 && this.currentPage > 1) {
                    this.currentPage--
                }
                if (val === 1 && this.currentPage < this.pageCount) {
                    this.currentPage++
                }
            },
            // pdf加载时
            loadPdfHandler() {
                this.currentPage = 1 // 加载的时候先加载第一页
            },
            //编辑题型 添加编辑题目  图片处理
            fileUploadSuccesspaper(res) {
                let index = res.message.lastIndexOf(".");//得到最后 "."在第几位
                let fileType = res.message.substring(index);   //截断"."之前的，得到后缀)
                const isJPEG = fileType === '.jpeg'
                const isPNG = fileType === '.png'
                const isJPG = fileType === '.jpg'
                const isDOCX = fileType === '.docx'
                const isPDF = fileType === '.pdf'
                const isDOC = fileType === '.doc'
                const isPpt = fileType === '.ppt'
                const isPptx = fileType === '.pptx'
                if (!isDOCX && !isPDF && !isDOC && !isJPEG && !isPNG && !isJPG && !isPpt && !isPptx) {
                    this.$message.info('只支持扩展名为docx,ppt,pdf,jpg,png,jpeg,ppt,pptx的文件!');
                } else {
                    this.subjectForm.fileList.push({uid: res.message});
                }

            },
            // 编辑题型 添加编辑题目  图片处理 移除
            handleRemovepaper(file) {
                let _this = this;
                for (let j = 0; j < this.subjectForm.fileList.length; j++) {
                    let item = this.subjectForm.fileList[j];
                    if (file.uid === item.uid) {
                        _this.subjectForm.fileList.splice(j, 1);
                    }
                }
            },

            fileUpload(res) {
                let index = res.name.lastIndexOf(".");//得到最后 "."在第几位
                let fileType = res.name.substring(index);   //截断"."之前的，得到后缀)
                const isJPEG = fileType === '.jpeg'
                const isPNG = fileType === '.png'
                const isJPG = fileType === '.jpg'
                const isDOCX = fileType === '.docx'
                const isPDF = fileType === '.pdf'
                const isDOC = fileType === '.doc'
                const isPpt = fileType === '.ppt'
                const isPptx = fileType === '.pptx'
                if (!isDOCX && !isPDF && !isDOC && !isJPEG && !isPNG && !isJPG && !isPpt && !isPptx) {
                    this.$message.info('只支持扩展名为docx,ppt,pdf,jpg,png,jpeg,ppt,pptx的文件');
                    return false
                }
                return true;
            },

            //添加 编辑  试卷文件上传成功
            fileUploadSuccess(res) {
                let index = res.message.lastIndexOf(".");//得到最后 "."在第几位
                let fileType = res.message.substring(index);   //截断"."之前的，得到后缀)
                const isJPEG = fileType === '.jpeg'
                const isPNG = fileType === '.png'
                const isJPG = fileType === '.jpg'
                const isDOCX = fileType === '.docx'
                const isPDF = fileType === '.pdf'
                const isDOC = fileType === '.doc'
                const isPpt = fileType === '.ppt'
                const isPptx = fileType === '.pptx'
                if (!isDOCX && !isPDF && !isDOC && !isJPEG && !isPNG && !isJPG && !isPpt && !isPptx) {
                    this.$message.info('只支持扩展名为docx,ppt,pdf,jpg,png,jpeg,ppt,pptx的文件');
                } else {
                    this.AddOrEditForm.fileList.push({uid: res.message});
                }

            },
            //试卷 图片  文件上传  下载
            handlePictureCardPreview(file) {
                let index = file.uid.lastIndexOf(".");//得到最后 "."在第几位
                let fileType = file.uid.substring(index);   //截断"."之前的，得到后缀)
                const isJPEG = fileType === '.jpeg'
                const isPNG = fileType === '.png'
                const isJPG = fileType === '.jpg'
                const isPDF = fileType === '.pdf'
                if (!isJPEG && !isPNG && !isJPG && !isPDF) {
                    this.dialogImageUrl = this.previewDomainName + file.uid;
                    this.dialogVisible = true;
                } else if (isPDF) {
                    this.dialogVisible = true;
                    this.$nextTick(() => {
                        this.dialogImageUrl = this.$getFileUrl + file.uid
                    });
                } else {
                    this.dialogImageUrl = this.$getFileUrl + file.uid;
                    this.dialogVisible = true;
                }
            },
            handleRemove(file) {
                let _this = this;
                for (let j = 0; j < this.AddOrEditForm.fileList.length; j++) {
                    let item = this.AddOrEditForm.fileList[j];
                    if (file.uid === item.uid) {
                        _this.AddOrEditForm.fileList.splice(j, 1);
                    }
                }
            },
            isImg(fileName) {
                if (!this.$util.isEmpty(fileName.uid) && typeof (fileName.uid) === 'string') {
                    let index = fileName.uid.lastIndexOf(".");//得到最后 "."在第几位
                    let fileType = fileName.uid.substring(index);   //截断"."之前的，得到后缀)
                    const isJPEG = fileType.includes('.jpeg');
                    const isPNG = fileType.includes('.png');
                    const isJPG = fileType.includes('.jpg');
                    return isJPEG || isPNG || isJPG;
                }
            },
            //添加  编辑 获取年级
            getgradeName(val) {
                let obj = {};
                obj = this.gradeList.find((item) => {//这里的gradeList就是上面遍历的数据源
                    return item.gradeId === val;//筛选出匹配数据
                });
                this.AddOrEditForm.gradeName = obj.gradeName //获取的 gradeName
                this.AddOrEditForm.gradeId = val
            },
            //添加  编辑 获取科目
            getSubject(val) {
                let obj = {};
                obj = this.subjectList.find((item) => {//这里的subjectList就是上面遍历的数据源
                    return item.subjectId === val;//筛选出匹配数据
                });
                this.AddOrEditForm.subjectName = obj.subjectName //获取的 subjectName
                this.AddOrEditForm.subjectId = val
            },

            //分页
            testListhandlePageSize(limit) {
                this.formInline.limit = limit
                this.testLishandleSearch(1);
            },
            //点击搜索
            testLishandleSearch(page) {
                if (page) {
                    this.formInline.page = page
                }
                this.getListData()
            },
            //添加 编辑试卷关闭 时触发 的事件
            dialogFormVisibleClosed() {
                this.$refs.AddOrEditForm.resetFields();
                this.AddOrEditForm.fileList = []
            },
            //查看试卷 弹窗关闭 触发的事件
            LookTestFormVisibleClosed() {
                this.lookDetails.fileList = []
            },
            //添加 编辑 题目关闭时触发
            subjectDialogFormVisibleClosed() {
                this.$refs.subjectFormrule.resetFields();
            },
            //格式化  试卷属性
            formatCourssewareType(row) {
                let testPaperType = row.testPaperType
                return testPaperType === 1 ? "个人试卷" : testPaperType === 2 ? "公共试卷" : "-";
            },
            //格式化 是否主观
            isSubjectiveType(row) {
                let isSubjective = row.isSubjective
                return isSubjective === 1 ? "是" : isSubjective === 2 ? "否" : "-";
            },
            //格式化  难度程度
            difficultyType(row) {
                let hardLevel = row.hardLevel
                return hardLevel === 1 ? "简单" : hardLevel === 2 ? "中等" : hardLevel === 3 ? "困难" : "-";
            },

            // 发送 请求 试卷数据列表
            getListData() {
                let params = {...this.formInline};
                params.teacherId = this.$util.getUser().empId
                this.status.dataLoading = true;
                this.status.tabledataLoading = true;
                this.$request(params, "/masters/mapper/select/testPaper.queryTestPaperByTeacher", (res) => {
                    this.total = res.total;
                    this.tableData = res.list;
                    this.status.dataLoading = false
                    this.status.tabledataLoading = false;
                }, () => {
                    this.$message.error("获取数据失败");
                    this.status.tabledataLoading = false;
                })
                //年级数据初始化
                this.$request({}, "/grade/gradeList", (res) => {
                    this.gradeList = res.list;
                });
                //科目数据初始化
                this.$request({}, "/subject/subjectList", (res) => {
                    this.subjectList = res.list;

                });
            },
            //添加  试卷按钮
            add() {
                this.testPaperId = ''
                this.showdel = false;
                this.dialogFormVisible = true;
                this.addTitle = "添加试卷";
            },
            //点击保存  保存试卷信息
            saveAdd() {
                this.$refs.AddOrEditForm.validate((valid) => {
                    if (valid) {
                        if (this.$util.isEmpty((this.testPaperId))) {
                            let params = {...this.AddOrEditForm};
                            params.teacherId = this.$util.getUser().empId
                            let fileList = []
                            for (let item of params.fileList) {
                                fileList.push(item.uid);
                            }
                            params.fileList = fileList;
                            //添加试卷请求
                            this.status.topicSaving = true;
                            this.$request(params, "/testPaper/insertTestPaper", () => {
                                this.status.topicSaving = false;
                                //清空  搜索框中的内容
                                this.dialogFormVisible = false
                                this.$refs.formInline.resetFields();
                                this.getListData();
                                this.$message.success("添加成功");
                            }, (res) => {
                                this.status.topicSaving = false;
                                this.$message.error(res.message)
                            });

                        } else {
                            let params = {...this.AddOrEditForm};
                            let fileList = []
                            for (let item of params.fileList) {
                                fileList.push(item.uid);
                            }
                            params.fileList = fileList;
                            //编辑试卷请求
                            this.status.topicSaving = true;
                            this.$request(params, "/testPaper/updateTestPaper", () => {
                                this.status.topicSaving = false;
                                this.dialogFormVisible = false;
                                this.getListData()
                                this.$message.success("编辑成功");
                            }, () => {
                                this.status.topicSaving = false;
                            });
                        }
                    }

                })

            },
            //点击 编辑 试卷
            edit(row) {
                this.testPaperId = row
                this.showdel = true
                this.dialogFormVisible = true
                this.addTitle = "编辑试卷";
                this.$request({testPaperId: this.testPaperId}, "/testPaper/queryTestPaperById", (res) => {
                    this.$nextTick(() => {
                        this.AddOrEditForm = res.list[0];
                        for (let item of this.AddOrEditForm.fileList) {
                            item.uid = item.file_url
                        }
                        switch (res.list[0].hardLevel) {
                            case 1:
                                this.lookDetails.hardLevel = "简单";
                                break;
                            case 2:
                                this.lookDetails.hardLevel = "中等";
                                break;
                            case 3:
                                this.lookDetails.hardLevel = "困难";
                                break;
                        }
                        switch (res.list[0].testPaperType) {
                            case 1:
                                this.lookDetails.testPaperType = "个人试卷";
                                break;
                            case 2:
                                this.lookDetails.testPaperType = "公共试卷";
                                break;
                        }
                    });
                })
            },
            // 查看试卷 详情
            lookTest(row) {
                let testPaperId = row
                this.LookTestFormVisible = true
                this.fileList = []
                this.$request({testPaperId: testPaperId}, "/testPaper/queryTestPaperById", (res) => {
                    if (this.$util.isEmpty(res.list[0].fileList)) {
                        this.onpaper = true
                    } else {
                        this.onpaper = false
                    }
                    this.lookDetails = res.list[0];
                    this.fileListlength = this.lookDetails.fileList.length
                    for (let item of this.lookDetails.fileList) {
                        item.uid = item.file_url
                    }
                    switch (res.list[0].hardLevel) {
                        case 1:
                            this.lookDetails.hardLevel = "简单";
                            break;
                        case 2:
                            this.lookDetails.hardLevel = "中等";
                            break;
                        case 3:
                            this.lookDetails.hardLevel = "困难";
                            break;
                    }
                    switch (res.list[0].testPaperType) {
                        case 1:
                            this.lookDetails.testPaperType = "个人试卷";
                            break;
                        case 2:
                            this.lookDetails.testPaperType = "公共试卷";
                            break;
                    }

                })
            },
            // 题型管理
            testTypeManage() {
                this.testTypeManageFormVisible = true
            },
            //    编辑题型
            answerEditMethod() {
                this.editTestFormVisible = true
            },
            // 获取题型数据
            getTopicData() {
                let params = {
                    page: 1,
                    limit: 10,
                    testPaperId: this.themePageInfo.testPaperId,
                    method: "POST"
                };
                this.$request(params, "/masters/mapper/select/testPaperTopic.queryByTestPaperId", (res) => {
                    this.status.topicDataLoading = false;
                    this.topicData = res.list;
                    this.topicDataTotal = res.total;
                }, () => {
                    this.status.topicDataLoading = false;
                    this.topicData = [];
                    this.topicDataTotal = 0;
                    this.themeData = [];
                    this.themeDataTotal = 0;
                });
            },
            // 获取题目数据
            getThemeData() {
                let params = this.themePageInfo;
                params.method = "POST";
                this.$request(params, "/masters/mapper/select/testPaperTheme.queryTheme", (res) => {
                    this.status.themeDataLoading = false;
                    this.themeData = res.list;
                    this.themeDataTotal = res.total;
                }, () => {
                    this.status.themeDataLoading = false;
                    this.themeData = [];
                    this.themeDataTotal = 0;
                });
            },
            // 试卷题型管理
            handleTopicManage(testPaperId) {
                this.status.topicManageDialogOpen = true;
                this.themePageInfo.testPaperId = testPaperId;
                let params = {
                    page: 1,
                    limit: 10,
                    testPaperId: this.themePageInfo.testPaperId,
                    method: "POST"
                };
                this.$request(params, "/masters/mapper/select/testPaperTopic.queryByTestPaperId", (res) => {
                    this.status.topicDataLoading = false;
                    this.topicData = res.list;
                    this.topicDataTotal = res.total;
                    // 默认获取第一个题型的题目
                    if (this.topicData.length > 0) {
                        let row1 = {
                            topicId: this.topicData[0].topicId,
                        }
                        this.handleClickTopic(row1);
                    }
                }, () => {
                    this.status.topicDataLoading = false;
                    this.topicData = [];
                    this.topicDataTotal = 0;
                    this.themeData = [];
                    this.themeDataTotal = 0;
                });
            },
            // 点击题型
            handleClickTopic(row) {
                this.subjectForm.testPaperId = row.testPaperId
                this.subjectForm.topicId = row.topicId;
                this.themePageInfo.topicId = row.topicId;
                this.themePageInfo.topicType = row.topicType;
                this.getThemeData();
            },
            // 题目
            handleThemePage(page) {
                this.themePageInfo.page = page;
                this.getThemeData();
            },
            // 编辑题型
            handleTopicDialog(row) {
                this.status.topicDialogOpen = true;
                if (!this.$util.isEmpty(row)) {
                    // 编辑
                    this.topicFormData = {...row};
                } else {
                    // 添加
                    this.handleResetForm("topicForm");
                    this.topicFormData.testPaperId = this.themePageInfo.testPaperId;
                }
            },
            // 添加题型，修改题型
            handleTopicSubmit() {
                this.$refs.topicForm.validate((valid) => {
                    if (valid) {
                        this.status.topicSaving = true;
                        let params = this.topicFormData;
                        params.method = 'POST';
                        if (!this.$util.isEmpty(params.topicId)) {
                            // 修改
                            this.topicDialogTitle = "修改题型";
                            this.$request(params, "/testPaperTopic/updateTopic", () => {
                                this.$message.success(`修改成功`);
                                this.status.topicSaving = false;
                                this.status.topicDialogOpen = false;
                                // 刷新数据
                                this.getTopicData();
                            }, () => {
                                this.status.topicSaving = false;
                            });
                        } else {
                            // 添加
                            this.topicDialogTitle = "添加题型";
                            delete params.topicId;
                            this.$request(params, "/testPaperTopic/insertTopic", () => {
                                this.$message.success(`添加成功`);
                                this.status.topicSaving = false;
                                this.status.topicDialogOpen = false;
                                // 刷新数据
                                this.getTopicData();
                            }, () => {
                                this.status.topicSaving = false;
                            });
                        }
                    }
                })
            },
            // 删除题型
            handleTopicDelete(topicId) {
                this.$confirm('确定要删除该题型吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // 重置密码
                    let params = {
                        method: 'POST',
                        topicId: topicId
                    };
                    this.$request(params, "/testPaperTopic/deleteTopic", () => {
                        this.$message.success(`删除成功`);
                        this.getTopicData();
                        this.getThemeData();
                    });
                });
            },
            //删除试卷
            deltest() {
                this.$confirm('确定要删除该试卷吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    this.$request({testPaperId: this.testPaperId}, "/testPaper/deleteTestPaperById", () => {
                        this.dialogFormVisible = false;
                        this.getListData()
                        this.$message.success(`删除成功`);
                    }, (res) => {
                        this.$message.error(res.message)
                    });
                });
            },
            // 关闭题型弹窗时
            handleTopicManageClose() {
                this.topicData = [];
                this.topicDataTotal = 0;
                this.themeData = [];
                this.themeDataTotal = 0;
            },
            // 处理上传解题思路
            handleUploadThemeSolve(row) {
                this.readonly = true;
                this.readonlyThemeSolve = true;
                this.readonlyThemeSolve = false;
                this.dialogFooter = true;
                this.disabled = false;
                this.showClass = "";
                this.AddeditTitle = "上传解题思路";
                this.themeId = row.themeId;
                let params = {...this.SubjectDetailsRequest}
                params.themeId = row.themeId;
                params.testPaperId = row.testPaperId;
                this.$request(params, "/theme/queryTheme", (res) => {
                    this.subjectForm = res.list[0];
                    for (let item of this.subjectForm.fileList) {
                        item.uid = item.theme_solve_url
                    }
                })
                this.EditingQuestionsFormVisible = true;
                this.optionShow = row.topicType === 1;
                this.answerShow = row.topicType !== 4;
                switch (row.topicType) {
                    case 1:
                        this.topicName = "选择题";
                        break;
                    case 2:
                        this.topicName = "填空题";
                        break;
                    case 3:
                        this.topicName = "判断题";
                        break;
                    case 4:
                        this.topicName = "主观题";
                        break;
                    case 5:
                        this.topicName = "连线题";
                        break;
                }

            },
            // 查看解题思路
            handleShowThemeSolve(row) {
                this.readonly = true;
                this.dialogFooter = false;
                this.disabled = true;
                this.showClass = "imga-update-show";
                this.themeId = row.themeId;
                let params = {...this.SubjectDetailsRequest};
                params.themeId = row.themeId;
                params.testPaperId = row.testPaperId;
                this.$request(params, "/theme/queryTheme", (res) => {
                    this.subjectForm = res.list[0];
                    for (let item of this.subjectForm.fileList) {
                        item.uid = item.theme_solve_url;
                    }
                })
                this.EditingQuestionsFormVisible = true;
                this.AddeditTitle = "查看解题思路"
                this.optionShow = row.topicType === 1;
                this.answerShow = row.topicType !== 4;
                switch (row.topicType) {
                    case 1:
                        this.topicName = "选择题";
                        break;
                    case 2:
                        this.topicName = "填空题";
                        break;
                    case 3:
                        this.topicName = "判断题";
                        break;
                    case 4:
                        this.topicName = "主观题";
                        break;
                    case 5:
                        this.topicName = "连线题";
                        break;
                }

                // TODO: 查看解题思路
            },
            //点击保存  发送  添加或编辑题目请求
            preserEditingQuestionsFormVisible() {
                if (this.subjectForm.topicType === 1 && this.subjectForm.choseType === 2 && !this.$util.isEmpty(this.subjectForm.answer) && this.subjectForm.answer.indexOf(',') != -1) {
                    this.subjectForm.answer = this.subjectForm.answer.split(',')
                    if (this.subjectForm.answer.length >= 2) {
                        this.subjectForm.answer = this.subjectForm.answer.sort().join(',')
                    }
                }
                this.$refs.subjectFormrule.validate((valid) => {
                    if (valid) {
                        if (!this.$util.isEmpty(this.themeId)) {
                            let params = {...this.subjectForm};
                            let fileList = [];
                            for (let item of params.fileList) {
                                fileList.push(item.uid);
                            }
                            params.fileList = fileList;
                            this.status.topicSaving = true;
                            this.$request(params, "/theme/updateTheme", () => {
                                this.$message.success("编辑成功");
                                this.EditingQuestionsFormVisible = false;
                                this.status.topicSaving = false
                                this.getThemeData()
                            }, () => {
                                this.status.topicSaving = false
                            })
                        } else {
                            let params = {...this.subjectForm};
                            let fileList = [];
                            for (let item of params.fileList) {
                                fileList.push(item.uid);
                            }
                            params.fileList = fileList;
                            this.status.topicSaving = true;
                            this.$request(params, "/theme/insertTheme", () => {
                                this.$message.success("保存成功");
                                this.EditingQuestionsFormVisible = false;
                                this.status.topicSaving = false;
                                this.getThemeData()
                            }, () => {
                                this.status.topicSaving = false;
                            })
                        }

                    }
                })

            }
            ,
            editSubject(row) {
                this.readonly = false;
                this.dialogFooter = true;
                this.disabled = false;
                this.showClass = "";
                this.themeId = row.themeId;
                this.$nextTick(() => {
                    let params = {...this.SubjectDetailsRequest}
                    params.themeId = row.themeId;
                    params.testPaperId = row.testPaperId;
                    this.$request(params, "/theme/queryTheme", (res) => {
                        this.subjectForm = res.list[0];
                        for (let item of this.subjectForm.fileList) {
                            item.uid = item.theme_solve_url
                        }
                    }, () => {
                    })
                    this.AddeditTitle = "编辑题目";
                    this.optionShow = row.topicType === 1;
                    this.answerShow = row.topicType !== 4 && row.topicType !== 3;
                    this.radioShow = row.topicType === 3;
                    switch (row.topicType) {
                        case 1:
                            this.topicName = "选择题";
                            break;
                        case 2:
                            this.topicName = "填空题";
                            break;
                        case 3:
                            this.topicName = "判断题";
                            this.subjectFormrule.answer[0].message="请选择答案";
                            break;
                        case 4:
                            this.topicName = "主观题";
                            break;
                        case 5:
                            this.topicName = "连线题";
                            break;
                    }
                    this.EditingQuestionsFormVisible = true;
                });


            }
            ,
            // 添加、编辑题目 弹窗
            handleThemeDialog(topicType) {
                this.subjectForm.choseType = 1
                this.readonly = false;
                this.dialogFooter = true;
                this.disabled = false;
                this.showClass = "";
                this.AddeditTitle = "添加题目";
                this.optionShow = topicType === 1;
                this.answerShow = topicType !== 4 && topicType !== 3;
                this.radioShow = topicType === 3;
                switch (topicType) {
                    case 1:
                        this.topicName = "选择题";
                        this.placeholder = "例如：A,B";
                        break;
                    case 2:
                        this.topicName = "填空题";
                        this.placeholder = ""
                        break;
                    case 3:
                        this.topicName = "判断题";
                        this.placeholder = "";
                        this.subjectFormrule.answer[0].message="请选择答案";
                        break;
                    case 4:
                        this.topicName = "主观题";
                        this.placeholder = ""
                        break;
                    case 5:
                        this.topicName = "连线题";
                        this.placeholder = "例如1-2,2-3（逗号隔开）"
                        break;

                }
                if (this.$util.isEmpty(topicType)) {
                    this.$message.warning("请选择题型")
                    this.EditingQuestionsFormVisible = false;
                } else {
                    this.EditingQuestionsFormVisible = true;
                }

                this.$nextTick(() => {
                    this.subjectForm.topicType = topicType;
                    this.themeId = null;
                })
            }
            ,
            // 修改题目...
            // TODO: 修改题目
            // 删除题目
            handleThemeDelete(themeId) {
                this.$confirm('确定要删除题目吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    let params = {
                        method: 'POST',
                        themeId: themeId
                    };
                    this.$request(params, "/masters/mapper/delete/testPaperTheme.deleteTheme", () => {
                        this.$message.success(`删除成功`);
                        this.handleThemePage(1);
                    });
                });
            }
            ,
            // 当弹窗关闭时情况表单状态
            handleResetForm(form) {
                if (form === "topicForm") {
                    this.topicFormData = this.$options.data().topicFormData;
                    this.$nextTick(() => {
                        this.$refs["topicForm"].resetFields()
                    })
                }
            }
            ,
            // 格式化题型
            formatTopicType(row) {
                let topicType = row.topicType.toString();
                for (let i = 0; i < this.topicTypeList.length; i++) {
                    if (topicType === this.topicTypeList[i].itemVal) {
                        return this.topicTypeList[i].itemName;
                    }
                }
                return "-";
            }
            ,
        },
    }
</script>
<style>
    /* 当内容过长被隐藏时显示tooltip，须限制tooltip宽度，不能放在scoped中，所以单独写 */
    .el-tooltip__popper {
        max-width: 200px;
    }

    .cui-viewerchrome {
        display: none;
        background: red;
    }

</style>
<!--滚动条样式-->
<style lang="less">
    .teacher-test-list {
        padding: 0 20px;

        .test-scrollbar {
            height: 500px;

            .AppAndBrandContainer {
                height: 90px;
            }

            .el-scrollbar__thumb {
                display: none;
            }

            .el-scrollbar__wrap {
                overflow-x: hidden;
                overflow-y: auto;
            }
        }

        .is-uploading {
            display: none !important;
        }

        .el-upload-list--picture-card .el-upload-list__item {
            width: 100px;
            height: 100px;
        }

        .el-upload--picture-card {
            width: 100px;
            height: 100px;
            line-height: 100px;
        }

        .imga-update-show .el-upload--picture-card {
            width: 100px;
            height: 100px;
            line-height: 100px;
            display: none;
        }

        .onpaper {
            color: #CCCCCC;
            width: 100px;
            height: 100px;
            line-height: 100px;
            text-align: center;
            border-radius: 6px;
            border: solid 1px #ccc;
            margin-left: 65px;
            margin-top: -15px;
        }

        .demo-form-inline {
            padding: 10px;
        }

        .el-table-column {
            border-left: solid 1px pink;
        }

        .el-pagination {
            display: flex;
            justify-content: flex-end;
        }

        .demo-form-margin {
            /*margin-left: 28px;*/
        }

        .demo-form-test {
            width: 60%;
        }

        .el-icon-upload2 {
            padding: 0 5px 0 0;
        }

        .supported {
            font-size: 12px;
            color: rgba(0, 0, 0, 0.45);
            margin-left: 10px;
        }

        .el-form-item-paper {
            margin-top: -10px;
            height: 150px;

            .uid-type {
                line-height: 100px;
                font-size: 12px;
                width: 80px;
                margin: auto;
                overflow: hidden; //超出的文本隐藏
                text-overflow: ellipsis; //溢出用省略号显示
                white-space: nowrap; //溢出不换行
            }

            .el-scrollbar__thumb {
                display: none;
            }

            .el-scrollbar__wrap {
                overflow-x: hidden;
                overflow-y: auto;
            }

            .imga-update {
                text-align: center;
                line-height: 55px;
                margin: 5px;
                display: flex;
                justify-content: flex-start;
            }
        }

        .el-form-item-image-height {
            .imga-update {
                width: 550px;
                text-align: center;
                line-height: 55px;
                margin: 5px;
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;

                .uid-type {
                    line-height: 100px;
                    font-size: 12px;
                    width: 80px;
                    margin: auto;
                    overflow: hidden; //超出的文本隐藏
                    text-overflow: ellipsis; //溢出用省略号显示
                    white-space: nowrap; //溢出不换行
                }


            }

        }

        .el-form-item-image {

            .imga-update {
                width: 550px;
                text-align: center;
                line-height: 55px;
                margin: 5px;
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;

                .uid-type {
                    line-height: 100px;
                    font-size: 12px;
                    width: 80px;
                    margin: auto;
                    overflow: hidden; //超出的文本隐藏
                    text-overflow: ellipsis; //溢出用省略号显示
                    white-space: nowrap; //溢出不换行
                }
            }
        }

        .answer-title {
            display: inline-block;
            padding: 5px 0 10px 0;
        }

        .answer-analysis {
            width: 90%;
            margin-left: 50px;
            display: flex;
            justify-content: space-between;

            .answer-left-table {
                width: 43%;
            }

            .answer-right-table {
                width: 56%;
            }
        }

        .test-paper-manage {
            padding: 20px;
        }

        .upload-icon:hover {
            color: #1890ff;
            cursor: pointer;
        }


    }
</style>
