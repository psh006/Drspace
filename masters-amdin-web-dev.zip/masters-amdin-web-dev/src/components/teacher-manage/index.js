import teacherList from './teacher-list'
import teacherSetting from './teacher-setting'
import teacherUpdatePass from './teacher-update-pass'

export default [
    teacherList,
    teacherSetting,
    teacherUpdatePass
]