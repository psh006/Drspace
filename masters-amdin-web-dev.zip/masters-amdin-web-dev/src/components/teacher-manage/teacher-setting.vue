<template>
  <div class="teacher-setting">
    <el-form :model="teacherForm" ref="teacherForm" label-width="95px" style="width:400px;">
      <el-form-item label="姓名" prop="realName"
                    :rules="[{ required: true, message: '请输入姓名', trigger: 'blur' }]">
        <el-input v-model="teacherForm.realName" placeholder="请输入姓名" style="width: 200px" maxlength="10"/>
      </el-form-item>
      <el-form-item label="生日" prop="birthday"
                    :rules="[{ required: true, message: '请选择生日', trigger: 'blur' }]">
        <el-date-picker
                v-model="teacherForm.birthday"
                type="date"
                value-format="yyyy-MM-dd"
                :picker-options="pickerOptions"
                placeholder="选择日期" style="width: 200px">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="头像" prop="avatar"
                    :rules="[{ required: true, message: '请上传头像', trigger: 'blur' }]">
        <el-upload
                class="avatar-uploader"
                :action="$uploadFileUrl"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
          <img v-if="teacherForm.avatar" :src="$getFileUrl+teacherForm.avatar" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过2M，建议图片长宽比为1:1</div>
        </el-upload>
      </el-form-item>
      <el-form-item label="性别" prop="gender"
                    :rules="[{ required: true, message: '请选择性别', trigger: 'blur' }]">
        <el-radio v-model="teacherForm.gender" label="1">男</el-radio>
        <el-radio v-model="teacherForm.gender" label="2">女</el-radio>
      </el-form-item>
      <el-form-item label="教学资质" prop="teacherCertificate"
                    :rules="[{ required: true, message: '请输入教学资质', trigger: 'blur' }]">
        <el-input v-model="teacherForm.teacherCertificate" placeholder="请输入教师资格证号码" maxlength="20"></el-input>
      </el-form-item>
      <el-form-item label="教学特点" prop="teachChara"
                    :rules="[{ required: true, message: '请输入教学特点', trigger: 'blur' }]">
        <el-input v-model="teacherForm.teachChara" placeholder="请输入教学特点" type="textarea" resize="none"
                  maxlength="255"></el-input>
      </el-form-item>
      <el-form-item label="教学经历" prop="teachExper"
                    :rules="[{ required: true, message: '请输入教学经历', trigger: 'blur' }]">
        <el-input v-model="teacherForm.teachExper" placeholder="请输入教学经历" type="textarea" resize="none"
                  maxlength="255"></el-input>
      </el-form-item>
      <el-form-item label="介绍">
        <editor style="width: 600px;height:540px;overflow: auto;" ref="editor"
                class="ql-editor"
                @editor-change="editorChange"
                :content="context"></editor>
      </el-form-item>
      <el-form-item>
        <el-button class="save" type="primary" @click="saveParams('teacherForm')"
                   :loading="status.submit">保存
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import editor from "../common/editor";
  export default {
    name: "teacher-setting",
    components: {
      editor
    },
    data() {
      return {
        teacherForm: {
          teacherId: '',
          realName: '',
          birthday: '',
          gender: "1",
          teacherCertificate: '',
          teachChara: '',
          briefIntroduction: '',
          teachExper: ''
        },
        status: {
          submit: false
        },
        pickerOptions: {
          disabledDate(time) {
            let minYear = 3600 * 1000 * 24 * 365 * 100
            return time.getTime() > Date.now() || time.getTime() < Date.now() - minYear;
          }
        },
        fileList: [],
        imageUrl: '',
        context: '',
      }
    },
    mounted() {
      this.getTeacherInfo();
    },
    methods: {
      //上传文件
      handleAvatarSuccess(res) {
        this.teacherForm.avatar = res.message;
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';
        const isLt2M = file.size / 1024 / 1024 < 2;

        if (!isJPG && !isPNG) {
          this.$message.error('上传头像图片只能是 jpg/png 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!');
        }
        return (isJPG || isPNG) && isLt2M;
      },
      //保存信息
      saveParams(teacherForm) {
        this.$refs[teacherForm].validate((valid) => {
          if (valid) {
            let param = {...this.teacherForm}
            if (param.birthday > this.$util.getNowDate()) {
              this.$message.error('生日不可为未来日期');
              return;
            }
            if (!this.$util.isCnEn(param.realName)) {
              this.$message.error('请输入正确姓名');
              return;
            }
            if (param.teacherCertificate === null || param.teacherCertificate.trim().length === 0) {
              this.$message.error('请输入教师资格证');
              return;
            }
            this.status.submit = true
            //保存信息
            this.$request(param, "/teacher/updateTeacher", (data) => {
              if (data.flag === 200) {
                let user = this.$util.getUser();
                user.empName = param.realName;
                user.avatar = param.avatar;
                this.$store.commit("setSystemUserInfo",user);
                this.$message.success('修改成功');
                this.status.submit = false;
              }
            }, err => {
              console.log(err);
            });
          } else {
            return false;
          }
        });
      },
      //获取用户信息
      getTeacherInfo() {
        let user = this.$util.getUser();
        let teacherId = user.empId;
        this.$request({'teacherId': teacherId}, "/masters/mapper/select/queryTeacherById", (data) => {
          if (data.flag === 200) {
            let teacherInfo = data.list[0];
            this.teacherForm = teacherInfo;
            this.teacherForm.teacherId = teacherId;
            this.teacherForm.gender = teacherInfo.gender + "";
            this.context = teacherInfo.briefIntroduction;
          }
        }, err => {
          console.log(err);
        });
      },
      // 内容改变事件
      editorChange(context) {
        this.teacherForm.briefIntroduction = context;
      },
    }
  }
</script>

<style scoped lang="less">
  .teacher-setting{
    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }

    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 64px;
      height: 64px;
      line-height: 64px;
      text-align: center;
    }

    .avatar {
      width: 64px;
      height: 64px;
      display: block;
    }
  }
  .ql-editor{
    padding: 0 !important;
    margin-top: 0 !important;
  }


</style>