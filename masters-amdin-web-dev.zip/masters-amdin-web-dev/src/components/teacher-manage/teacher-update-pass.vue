<template>
  <div>
    <el-form :model="teacherForm" ref="teacherForm" label-width="95px" style="width:400px;">
      <el-form-item label="旧密码" prop="oldPass"
                    :rules="[{ required: true, message: '请输入旧密码', trigger: 'blur' }]">
        <el-input v-model="teacherForm.oldPass" placeholder="请输入旧密码" type="password" style="width: 200px" maxlength="10"/>
      </el-form-item>
      <el-form-item label="新密码" prop="newPass"
                    :rules="[{ required: true, message: '请输入新密码', trigger: 'blur' }]">
        <el-input v-model="teacherForm.newPass" placeholder="请输入新密码" type="password" style="width: 200px" maxlength="10"/>
      </el-form-item>
      <el-form-item label="确认密码" prop="rePass"
                    :rules="[{ required: true, message: '请确认密码', trigger: 'blur' }]">
        <el-input v-model="teacherForm.rePass" placeholder="请确认密码" type="password" style="width: 200px" maxlength="10"/>
      </el-form-item>
      <el-form-item>
        <el-button class="save" type="primary" @click="saveParams('teacherForm')"
                   :loading="status.submit">确认修改
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: "teacher-update-pass",
    data(){
      return{
        teacherForm:{
          oldPass:'',
          newPass:'',
          rePass:''
        },
        status: {
          submit: false
        },
      }
    },
    methods:{
      saveParams(teacherForm){
        this.$refs[teacherForm].validate((valid) => {
          if (valid) {
            let param = {...this.teacherForm}
            if (param.newPass !== param.rePass) {
              this.$message.error('两次密码不一致');
              return;
            }
            if (param.newPass === param.oldPass) {
              this.$message.error('新密码不可与旧密码相同');
              return;
            }
            this.status.submit = true
            param.loginRole = this.$util.getUser().loginRole;
            this.$request(param, "/login/updateLoginPass", () => {
              this.$message.success("密码已修改，请重新登录");
              this.$util.removeUser();
              this.status.submit = false
              this.$router.push("/login");
            }, err => {
                console.log(err);
                this.status.submit = false
              });
            this.teacherForm = {}
          } else {
            return false;
          }
        });
      }
    }
  }
</script>

<style scoped>

</style>