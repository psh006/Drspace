<template>
    <div class="teacher-list">
        <el-form inline>
            <el-form-item label="入职日期">
                <el-date-picker v-model="timeSelect"
                                type="daterange"
                                value-format="yyyy-MM-dd"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"
                                style="width: 250px"/>
            </el-form-item>
            <el-form-item label="姓名">
                <el-input v-model="searchParams.realName" maxlength="10" clearable placeholder="请输入姓名"
                          style="width: 120px;"/>
            </el-form-item>
            <el-form-item label="岗位">
                <el-select v-model="searchParams.post" style="width: 120px;" clearable placeholder="请选择岗位">
                    <el-option
                            v-for="item in post"
                            :key="item.itemVal"
                            :label="item.itemName"
                            :value="item.itemVal">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="科目">
                <el-select v-model="searchParams.subjectId" style="width: 120px;" clearable placeholder="请选择科目">
                    <el-option
                            v-for="item in subject"
                            :key="item.subjectId"
                            :label="item.subjectName"
                            :value="item.subjectId">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="电话">
                <el-input v-model="searchParams.phone" maxlength="11" clearable placeholder="请输入电话"
                          style="width: 150px;"
                          @input="value=>{searchParams.phone = this.$util.checkNumber(value)}"/>
            </el-form-item>
            <el-form-item label="教龄">
                <el-input v-model="searchParams.teachAge" maxlength="3" clearable placeholder="请输入教龄"
                          style="width: 120px;"
                          @input="value=>{searchParams.teachAge = this.$util.checkNumber(value)}"/>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="handleCurrentChange(1)" :loading="status.getUserListLoading">查询
                </el-button>
                <el-button type="success" @click="showSaveDialog">添加</el-button>
            </el-form-item>
        </el-form>
        <el-table :data="teacherList" v-loading="status.getUserListLoading"
                  style="border: 1px solid #EBEEF5; border-bottom: none">
            <el-table-column label="序号" type="index" min-width="50px" align="center"></el-table-column>
            <el-table-column label="姓名" prop="realName" min-width="100" align="center" show-overflow-tooltip/>
            <el-table-column label="性别" min-width="50" align="center">
                <template slot-scope="scope">
                    <span>{{scope.row.gender==1?'男':'女'}}</span>
                </template>
            </el-table-column>
            <el-table-column label="岗位" min-width="80" align="center">
                <template slot-scope="scope">
                    <span>{{$dict.getItemNameByCodeAndVal("POST", scope.row.post)}}</span>
                </template>
            </el-table-column>
            <el-table-column label="科目" prop="subjectName" min-width="50" align="center"/>
            <el-table-column label="年龄" prop="age" min-width="50" align="center"/>
            <el-table-column label="联系方式" prop="contactInfo" min-width="150" align="center"/>
            <el-table-column label="教龄" prop="teachAge" min-width="50" align="center"/>
            <el-table-column label="入职时间" prop="hiredate" min-width="150" align="center"/>
            <el-table-column label="授课时长" min-width="80" align="center">
                <template slot-scope="scope">
                    <span>{{scope.row.teachingDuration==null || scope.row.teachingDuration.length===0?'0':scope.row.teachingDuration}}小时</span>
                </template>
            </el-table-column>
            <el-table-column label="课程数量" min-width="50" align="center">
                <template slot-scope="scope">
                    <el-button type="text" @click="courseInfo(scope.row.teacherId,scope.row.totalCourse)" title="课程详情"
                               class="course-num">
                        {{scope.row.totalCourse==null || scope.row.totalCourse.length===0?'0':scope.row.totalCourse}}
                    </el-button>
                </template>
            </el-table-column>
            <el-table-column label="所属校区" prop="campusName" min-width="150" align="center" show-overflow-tooltip/>
            <el-table-column label="操作" min-width="200" align="center">
                <template slot-scope="scope">
                    <el-button type="text" @click="openTeacherInfo(scope.row.teacherId)">查看</el-button>
                    <el-button type="text" @click="openTeacherUpdate(scope.row.teacherId)">编辑</el-button>
                    <el-button type="text" @click="openTeacherChat(scope.row.teacherId)">聊天</el-button>
                    <el-button type="text" @click="resetEmpPassword(scope.row.teacherId)">重置密码</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <el-pagination background
                       align="right"
                       layout="total, sizes, prev, pager, next, jumper"
                       :current-page="searchParams.page"
                       :page-sizes="[5, 10, 20, 50]"
                       :page-size="searchParams.limit"
                       :total="teacherListTotal"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange"/>
        <el-dialog :title="dialogTitle" :visible.sync="dialogTeacherVisible" width="700px"
                   @closed="handleResetForm">
            <el-form :model="teacherForm" :inline="true" ref="teacherForm">
                <el-form-item label="姓名" label-width="100px"
                              prop="realName"
                              :rules="[{ required: true, message: '请输入姓名', trigger: 'blur' }]">
                    <el-input v-model="teacherForm.realName" autocomplete="off" style="width: 200px" placeholder="请输入姓名"
                              maxlength="10" :disabled="disabled"/>
                </el-form-item>
                <el-form-item label="性别" label-width="100px"
                              prop="gender"
                              :rules="[{ required: true, message: '请选择性别', trigger: 'blur' }]">
                    <el-select v-model="teacherForm.gender" placeholder="性别" style="width: 200px" :disabled="disabled">
                        <el-option
                                v-for="item in gender"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="生日" label-width="100px"
                              prop="birthday"
                              :rules="[{ required: true, message: '请选择生日', trigger: 'blur' }]">
                    <el-date-picker
                            v-model="teacherForm.birthday"
                            type="date"
                            value-format="yyyy-MM-dd"
                            placeholder="选择日期" style="width: 200px"
                            :disabled="disabled"
                            :picker-options="pickerOptions">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="职称" label-width="100px"
                              prop="post"
                              :rules="[{ required: true, message: '请选择职称', trigger: 'blur' }]">
                    <el-select v-model="teacherForm.post" placeholder="职称" style="width: 200px" :disabled="disabled">
                        <el-option
                                v-for="item in post"
                                :key="item.itemVal"
                                :label="item.itemName"
                                :value="item.itemVal">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="级别" label-width="100px"
                              prop="managerRank" v-if="teacherForm.post == 2"
                              :rules="[{ required: true, message: '请选择级别', trigger: 'blur' }]">
                    <el-select v-model="teacherForm.managerRank" placeholder="级别" style="width: 200px" :disabled="disabled">
                        <el-option value="初级"/>
                        <el-option value="中级"/>
                        <el-option value="高级"/>
                    </el-select>
                </el-form-item>
                <el-form-item label="科目" label-width="100px"
                              prop="subjectId" v-if="teacherForm.post == 1"
                              :rules="[{ required: true, message: '请选择科目', trigger: 'blur' }]">
                    <el-select v-model="teacherForm.subjectId" placeholder="科目" style="width: 200px"
                               :disabled="disabled">
                        <el-option
                                v-for="item in subject"
                                :key="item.subjectId"
                                :label="item.subjectName"
                                :value="item.subjectId">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="联系方式" label-width="100px"
                              prop="contactInfo"
                              :rules="[{ required: true, message: '请输入联系方式', trigger: 'blur' }]">
                    <el-input v-model="teacherForm.contactInfo" autocomplete="off" style="width: 200px"
                              placeholder="请输入联系方式" maxlength="11"
                              @input="value=>{teacherForm.contactInfo = this.$util.checkNumber(value)}"
                              :disabled="disabled"/>
                </el-form-item>
                <el-form-item label="入行时间" label-width="100px"
                              prop="entryDate"
                              :rules="[{ required: true, message: '请选择入行时间', trigger: 'blur' }]">
                    <el-date-picker
                            v-model="teacherForm.entryDate"
                            type="date"
                            value-format="yyyy-MM-dd"
                            placeholder="选择日期" style="width: 200px" :disabled="disabled"
                            :picker-options="pickerEntryOptions">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="入职时间" label-width="100px"
                              prop="hiredate"
                              :rules="[{ required: true, message: '请选择入职时间', trigger: 'blur' }]">
                    <el-date-picker
                            v-model="teacherForm.hiredate"
                            type="date"
                            value-format="yyyy-MM-dd"
                            placeholder="选择日期" style="width: 200px"
                            :disabled="disabled"
                            :picker-options="pickerEntryOptions">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="所属校区" label-width="100px"
                              prop="campusId"
                              :rules="[{ required: true, message: '请选择所属校区', trigger: 'blur' }]">
                    <el-select v-model="teacherForm.campusId" placeholder="所属校区" style="width: 200px"
                               :disabled="disabled">
                        <el-option
                                v-for="item in campus"
                                :key="item.campusId"
                                :label="item.campusName"
                                :value="item.campusId">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="毕业院校" label-width="100px"
                              prop="graduateSchool"
                              :rules="[{ required: true, message: '请输入毕业院校', trigger: 'blur' }]">
                    <el-input v-model="teacherForm.graduateSchool" autocomplete="off" style="width: 200px"
                              placeholder="请输入毕业院校" maxlength="20" :disabled="disabled"/>
                </el-form-item>
                <el-form-item label="教师资格证" label-width="100px"
                              prop="teacherCertificate" v-if="teacherForm.post == 1"
                              :rules="[{ required: true, message: '请输入教师资格证', trigger: 'blur' }]">
                    <el-input v-model="teacherForm.teacherCertificate" autocomplete="off" style="width: 200px"
                              placeholder="请输入教师资格证" maxlength="20" :disabled="disabled"/>
                </el-form-item>
                <el-form-item label="头像" prop="avatar" label-width="100px"
                              :rules="[{ required: true, message: '请上传头像', trigger: 'blur' }]">
                    <el-upload
                            class="avatar-uploader"
                            :action="$uploadFileUrl"
                            :show-file-list="false"
                            :on-success="handleAvatarSuccess"
                            :before-upload="beforeAvatarUpload"
                            :disabled="disabled">
                        <img v-if="teacherForm.avatar" :src="$getFileUrl+teacherForm.avatar" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        <div slot="tip" v-if="!disabled" class="el-upload__tip">只能上传jpg/png文件，且不超过2M，建议图片长宽比为1:1</div>
                    </el-upload>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer" v-if="!disabled">
                <el-button @click="dialogTeacherVisible = false">取 消</el-button>
                <el-button type="danger" @click="deleteTeacher" v-if="isUpdate">删除</el-button>
                <el-button type="primary" @click="saveTeacher('teacherForm')" :load="status.saveTeacherLoading">确 定
                </el-button>
            </div>
        </el-dialog>
        <el-dialog title="课程详情" :visible.sync="dialogCourseInfoVisible" width="60%">
            <div style="display: flex" class="class-info-dialog">
                <div style="width: 45%">
                    <el-table :data="courseList" @row-click="getCourseHour">
                        <el-table-column type="index" label="序号"></el-table-column>
                        <el-table-column property="courseName" label="课程名称" show-overflow-tooltip/>
                        <el-table-column label="课程进度">
                            <template slot-scope="scope">
                                <span>{{scope.row.finishedCourseHour?scope.row.finishedCourseHour:'0'}}/{{scope.row.allCourseHour?scope.row.allCourseHour:'0'}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column property="lecturerName" label="授课老师" show-overflow-tooltip/>
                    </el-table>
                </div>
                <div style="margin-left: 10px;width: 55%">
                    <el-table :data="courseHourList"
                              show-summary
                              :summary-method="getSummaries">
                        <el-table-column type="index" label="序号"/>
                        <el-table-column label="上课时间" width="150">
                            <template slot-scope="scope">
                                <span>{{scope.row.classTime?scope.row.classTime:'未开始'}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="学生人数">
                            <template slot-scope="scope">
                                <span>{{scope.row.courseRecordAmount?scope.row.courseRecordAmount:'0'}}/{{scope.row.applyAmount?scope.row.applyAmount:'0'}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column property="testNumber" label="测验次数">
                            <template slot-scope="scope">
                                <span>{{scope.row.testNumber?scope.row.testNumber:'0'}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column property="accuracy" label="学生正确率">
                            <template slot-scope="scope">
                                <span>{{$util.decimal2Per(scope.row.accuracy)}}%</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="学生平均成绩" width="150">
                            <template slot-scope="scope">
                                <span>{{scope.row.studentAvg?scope.row.studentAvg:'0'}}</span>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "teacher-list",
        data() {
            return {
                timeSelect: [],
                status: {
                    getUserListLoading: false,
                    saveTeacherLoading: false,
                },
                searchParams: {
                    realName: '',
                    post: '',
                    subjectId: '',
                    phone: '',
                    teachAge: '',
                    page: 1,
                    limit: 10
                },
                teacherList: [],
                courseList: [],
                courseHourList: [],
                teacherListTotal: 0,
                dialogTeacherVisible: false,
                dialogCourseInfoVisible: false,
                avatar: '',
                teacherForm: {
                    realName: '',
                    birthday: '',
                    gender: '',
                    post: '',
                    subjectId: '',
                    subjectName: '',
                    contactInfo: '',
                    entryDate: '',
                    hiredate: '',
                    campusId: '',
                    campusName: '',
                    graduateSchool: '',
                    teacherCertificate: '',
                    avatar: '',
                    certificateImg: '',
                    managerRank: ''
                },
                pickerOptions: {
                    disabledDate(time) {
                        let minYear = 3600 * 1000 * 24 * 365 * 100
                        return time.getTime() > Date.now() || time.getTime() < Date.now() - minYear;
                    }
                },
                pickerEntryOptions: {
                    disabledDate(time) {
                        let minYear = 3600 * 1000 * 24 * 365 * 100
                        let maxYear = 3600 * 1000 * 24 * 365
                        return time.getTime() > Date.now() + maxYear || time.getTime() < Date.now() - minYear;
                    }
                },
                post: [],
                gender: [
                    {
                        value: 1,
                        label: '男'
                    },
                    {
                        value: 2,
                        label: '女'
                    }
                ],
                subject: [],
                campus: [],
                disabled: false,
                isUpdate: false,
                teacherId: '',
                dialogTitle: '',
                isClick: true
            }
        },
        mounted() {
            this.getUserList();
            this.querySubject();
            this.queryCampus();
            this.getPost();
        },
        methods: {
            // 当前第几页
            handleCurrentChange(CurrentPage) {
                this.searchParams.page = CurrentPage;
                this.getUserList();
            },
            // 每页几条
            handleSizeChange(pageSize) {
                this.searchParams.limit = pageSize;
                this.handleCurrentChange(1);
            },
            handleAvatarSuccess(res) {
                this.teacherForm.avatar = res.message;
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg';
                const isPNG = file.type === 'image/png';
                const isLt2M = file.size / 1024 / 1024 < 2;

                if (!isJPG && !isPNG) {
                    this.$message.error('上传头像图片只能是 jpg/png 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return (isJPG || isPNG) && isLt2M;
            },
            getUserList() {
                let params = {...this.searchParams};
                if (this.timeSelect && this.timeSelect.length === 2) {
                    params.startTime = this.timeSelect[0];
                    params.endTime = this.timeSelect[1];
                }
                this.status.getUserListLoading = true;
                this.$request(params, "/teacher/queryTeacher", (data) => {
                    this.teacherList = data.list;
                    this.teacherListTotal = data.total;
                    this.status.getUserListLoading = false;
                }, () => {
                    this.status.getUserListLoading = false;
                });
            },
            saveTeacher(teacherForm) {
                this.$refs[teacherForm].validate((valid) => {
                    if (valid) {
                        if (!this.isClick) {
                            this.$message.error('3秒内不可重复点击');
                            return;
                        }
                        let param = {...this.teacherForm}
                        if(param.post == 1){
                            // 教师
                            if (this.teacherForm.teacherCertificate === null || this.teacherForm.teacherCertificate.trim().length === 0) {
                                this.$message.error('请输入教师资格证');
                                return;
                            }
                            param.subjectName = this.getSubjectName(param.subjectId);
                            delete param.managerRank;
                        }else {
                            // 学习管理师
                            delete param.subjectId;
                            delete param.subjectName;
                            delete param.teacherCertificate;
                        }
                        param.campusName = this.getCampusName(param.campusId);
                        if (!this.$util.isPhoneNumber(param.contactInfo)) {
                            this.$message.error('手机号格式不正确');
                            return;
                        }
                        if (this.teacherForm.birthday > this.$util.getNowDate()) {
                            this.$message.error('生日不可为未来日期');
                            return;
                        }
                        if (!this.$util.isCnEn(param.graduateSchool)) {
                            this.$message.error('请输入正确毕业院校');
                            return;
                        }
                        if (!this.$util.isCnEn(param.realName)) {
                            this.$message.error('请输入正确姓名');
                            return;
                        }
                        this.status.saveTeacherLoading = true
                        this.isClick = false;
                        if (this.isUpdate) {
                            param.teacherId = this.teacherId
                            this.$request(param, "/teacher/updateTeacher", (data) => {
                                if (data.flag === 200) {
                                    this.$message.success('修改成功');
                                    this.getUserList();
                                    this.dialogTeacherVisible = false
                                    this.status.saveTeacherLoading = false
                                }
                            }, err => {
                                console.log(err);
                                this.status.saveTeacherLoading = false
                            });

                            setTimeout(() => {
                                this.isClick = true
                            }, 3000);

                            return;
                        }
                        this.$request(param, "/teacher/insertTeacher", (data) => {
                            if (data.flag === 200) {
                                this.$message.success('添加成功');
                                this.getUserList();
                                this.dialogTeacherVisible = false
                                this.status.saveTeacherLoading = false
                            }
                        }, err => {
                            this.status.saveTeacherLoading = false
                        });
                        setTimeout(() => {
                            this.isClick = true
                        }, 3000);
                    } else {
                        this.status.saveTeacherLoading = false
                        setTimeout(() => {
                            this.isClick = true
                        }, 3000);
                        return false;
                    }
                });
            },
            openTeacherInfo(teacherId) {
                this.$request({'teacherId': teacherId}, "/masters/mapper/select/queryTeacherById", (data) => {
                    if (data.flag === 200) {
                        this.dialogTitle = '老师资料'
                        this.isUpdate = false
                        this.disabled = true
                        this.dialogTeacherVisible = true
                        this.$nextTick(() => {
                            this.teacherForm = data.list[0]
                            this.teacherForm.post = data.list[0].post + ""
                        })
                    }
                }, err => {
                    console.log(err);
                });
            },
            openTeacherUpdate(teacherId) {
                this.$request({'teacherId': teacherId}, "/masters/mapper/select/queryTeacherById", (data) => {
                    if (data.flag === 200) {
                        this.dialogTitle = '编辑老师资料'
                        this.teacherId = teacherId
                        this.isUpdate = true
                        this.disabled = false
                        if (this.$util.isEmpty(data.list[0].avatar)) {
                            data.list[0].avatar = '';
                        }
                        this.dialogTeacherVisible = true
                        this.$nextTick(() => {
                            this.teacherForm = data.list[0];
                            this.teacherForm.post = data.list[0].post + ""
                        })

                    }
                }, err => {
                    console.log(err);
                });
            },
            // teacherId
            openTeacherChat(teacherId) {
                this.$store
                    .dispatch('checkoutConversation', `C2C${teacherId}`)
                    .then(() => {
                        this.$store.commit("setShowConversation", true);
                    }).catch(() => {
                    this.$store.commit('showMessage', {
                        message: '该老师可能没有登录过系统',
                        type: 'warning'
                    })
                });
            },
            showSaveDialog() {
                this.dialogTitle = '添加老师'
                this.isUpdate = false
                this.disabled = false
                this.dialogTeacherVisible = true
            },
            querySubject() {
                this.$request({}, "/masters/mapper/select/querySubject", (data) => {
                    if (data.flag === 200) {
                        this.subject = data.list
                    }
                }, err => {
                    console.log(err);
                });
            },
            queryCampus() {
                this.$request({}, "/masters/mapper/select/queryCampus", (data) => {
                    if (data.flag === 200) {
                        this.campus = data.list
                    }
                }, err => {
                    console.log(err);
                });
            },
            getSubjectName(subjectId) {
                let subject = this.subject;
                let subjectName = ''
                for (let item of subject) {
                    if (item.subjectId === subjectId) {
                        subjectName = item.subjectName
                        break;
                    }
                }
                return subjectName;
            },
            getCampusName(campusId) {
                let campus = this.campus;
                let campusName = ''
                for (let item of campus) {
                    if (item.campusId === campusId) {
                        campusName = item.campusName
                        break;
                    }
                }
                return campusName;
            },
            deleteTeacher() {
                let teacherId = this.teacherId;
                if (teacherId === null || teacherId.length === 0) {
                    this.$message.warn('请选择教师');
                    return;
                }
                this.$confirm('是否确定删除?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$request({'teacherId': teacherId}, "/masters/mapper/delete/deleteTeacher", (data) => {
                        if (data.flag === 200) {
                            this.$message.success('删除成功')
                            this.dialogTeacherVisible = false
                            this.getUserList();
                        }
                    }, err => {
                        console.log(err);
                    });
                }).catch((err) => {
                    console.log(err);
                });

            },
            courseInfo(teacherId, totalCourse) {
                if (totalCourse == null || totalCourse === 0) {
                    this.$message.error('无课程');
                    return;
                }
                this.courseHourList = []
                this.$request({'teacherId': teacherId}, "/masters/mapper/select/teacher.queryCourseInfo", (data) => {
                    if (data.flag === 200) {
                        this.dialogCourseInfoVisible = true
                        this.courseList = data.list
                        this.getCourseHour(data.list[0])
                    }
                }, err => {
                    console.log(err);
                });
            },
            getCourseHour(course) {
                let courseId = course.courseId;
                this.$request({"courseId": courseId}, "/masters/mapper/select/queryCourseHourByCourseId", (data) => {
                    if (data.flag === 200) {
                        this.dialogCourseInfoVisible = true
                        this.courseHourList = data.list
                    }
                }, err => {
                    console.log(err);
                });
            },
            getSummaries(param) {
                const {columns, data} = param;
                const sums = [];
                const length = data.length
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '合计';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                            const value = Number(curr);
                            if (!isNaN(value)) {
                                return prev + curr;
                            } else {
                                return prev;
                            }
                        }, 0);
                        if (index === 4) {
                            sums[index] = this.$util.decimal2Per(sums[index] / length) + '%'
                        }
                        if (index === 5) {
                            sums[index] = this.$util.decimal2Per(sums[index] / length / 100)
                        }
                    }
                });
                return sums;
            },
            handleResetForm() {
                this.$refs.teacherForm.resetFields();
            },
            getPost() {
                let postList = this.$dict.getDictByCode('POST');
                this.post = postList;
            },
            resetEmpPassword(teacherId) {
                this.$confirm('您确定要重置密码吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {teacherId: teacherId};
                    let funcId = "/teacher/resetTeacherPassword";
                    this.$request(params, funcId, () => {
                        this.$message.success("重置成功");
                    });
                });
            }
        }
    }
</script>

<style lang="less" scoped>
    .teacher-list {
        .course-num {
            color: #1890ff;
            text-decoration: underline;
            cursor: pointer;
        }

        .avatar-uploader .el-upload {
            border: 1px dashed #d9d9d9;
            border-radius: 6px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .avatar-uploader .el-upload:hover {
            border-color: #409EFF;
        }

        .avatar-uploader-icon {
            font-size: 28px;
            color: #8c939d;
            width: 64px;
            height: 64px;
            line-height: 64px;
            text-align: center;
        }

        .avatar {
            width: 64px;
            height: 64px;
            display: block;
        }

        .class-info-dialog {
            height: 60vh;
            overflow: auto;
        }
    }

</style>