<template>
    <div class="system-menu">
        <div class="left">
            <el-tree :data="list" :props="defaultProps" @node-click="handleNodeClick"
                     node-key="menuId" highlight-current></el-tree>
        </div>
        <div class="right">
            <el-tabs v-model="operationType" type="card" @tab-click="handleClick">
                <el-tab-pane label="修改菜单" name="1"></el-tab-pane>
                <el-tab-pane label="添加同级菜单" name="2"></el-tab-pane>
                <el-tab-pane :disabled="nowMap.isLeaf==='1'" label="添加下级菜单" name="3"></el-tab-pane>
            </el-tabs>
            <div class="form">
                <div style="display: flex;height: 5vh"></div>
                <el-form inline ref="addForm" :model="addPms" class="demo-form-inline" label-width="100px">
                    <el-form-item class="half" label="菜单名称" prop="menuName"
                                  :rules="[{ required: true, message: '请输入菜单名称', trigger: 'blur'}]">
                        <el-input v-model="addPms.menuName" clearable maxlength="10"
                                  @input="value=>{this.addPms.menuName = this.$util.checkCnEnNu(value)}"
                                  class="w200" :disabled="nowMap.menuId===undefined"><!--:readonly="status.isUpdate"-->
                        </el-input>
                    </el-form-item>
                    <el-form-item class="half" label="排序号" prop="sort"
                                  :rules="[{ required: true, message: '请输入排序号', trigger: 'blur'},
                                  {type:'number',min:0, max:100,message: '排序号须在1~100之间', trigger: 'blur'}]">
                        <el-input v-model.number="addPms.sort" clearable
                                  @input="value=>{this.addPms.sort = this.$util.checkNumber(value)}"
                                  class="w200" :disabled="nowMap.menuId===undefined"></el-input>
                    </el-form-item>
                    <el-form-item class="half" label="图标" prop="menuIcon">
                        <!--:rules="[{ required: true, message: '请输入图标', trigger: 'blur'}]"-->
                        <el-input v-model="addPms.menuIcon" clearable maxlength="150"
                                  :rules="[{ required: true, message: '请输入图标', trigger: 'blur'}]"
                                  class="w200" :disabled="nowMap.menuId===undefined"></el-input>
                        <!--:readonly="status.isUpdate"-->
                    </el-form-item>
                    <el-form-item class="half" label="菜单路径" prop="menuUrl">
                        <!--:rules="[{ required: true, message: '请输入菜单路径', trigger: 'blur'}]"-->
                        <el-input v-model="addPms.menuUrl" clearable maxlength="300"
                                  class="w200" :disabled="nowMap.menuId===undefined"></el-input>
                        <!--:readonly="status.isUpdate"-->
                    </el-form-item>
                    <el-form-item class="half" label="是否枝叶" prop="isLeaf"
                                  :rules="[{ required: true, message: '请选择是否枝叶', trigger: 'blur'}]">
                        <el-select class="w200" v-model="addPms.isLeaf" :disabled="nowMap.menuId===undefined">
                            <!-- :disabled="status.isUpdate"-->
                            <el-option label="是" value="1"></el-option>
                            <el-option label="否" value="2"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item class="half" label="是否显示" prop="isDisplay"
                                  :rules="[{ required: true, message: '请选择是否显示', trigger: 'blur'}]">
                        <el-select class="w200" v-model="addPms.isDisplay" :disabled="nowMap.menuId===undefined">
                            <el-option label="是" value="1"></el-option>
                            <el-option label="否" value="2"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item style="width: 100%;justify-content: left;display: flex;margin-left: 30px">
                        <el-button type="primary" :loading="status.saveLoading" @click="save"
                                   :disabled="nowMap.menuId===undefined">保存
                        </el-button>
                        <el-button :loading="status.deleteMenuLoading" @click="deleteMenu"
                                   v-if="operationType === '1'"
                                   :disabled="nowMap.menuId===undefined">删除</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "system-menu",
        data() {
            return {
                list: [],
                defaultProps: {
                    label: 'menuName'
                },
                operationType: "1",
                addPms: {
                    menuName: "",
                    sort: "",
                    menuIcon: "",
                    menuUrl: "",
                    isLeaf: "1",
                    isDisplay: "1"
                },
                getPms: {},
                status: {
                    listLoading: false,
                    isUpdate: true,
                    saveLoading: false,
                    deleteMenuLoading: false
                },
                nowMap: {
                    menuName: "",
                    sort: "",
                    menuIcon: "",
                    menuUrl: "",
                    isLeaf: "1",
                    isDisplay: "1"
                }
            }
        },
        created() {
            this.getData();
        },
        methods: {
            deleteMenu() {
                this.$confirm('确定要删除当前菜单吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.status.deleteMenuLoading = true;
                    this.$request({menuId: this.nowMap.menuId}, "/system/mapper/delete/system.deleteMenuById", () => {
                        this.$message.success("删除成功");
                        this.getData();
                        this.status.deleteMenuLoading = false;
                    }, () => {
                        this.status.deleteMenuLoading = false;
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消操作'
                    });
                });
            },
            save() {
                this.$refs['addForm'].validate((valid) => {
                    if (valid) {
                        this.status.saveLoading = true;
                        switch (this.operationType) {
                            case '1'://修改
                                this.$request(this.addPms, "/system/mapper/update/system.updateMenuById", () => {
                                    this.$message.success("保存成功");
                                    this.getData();
                                    this.status.saveLoading = false;
                                }, () => {
                                    this.status.saveLoading = false;
                                });
                                break;
                            case '2'://添加同级
                                this.addPms.parentId = this.nowMap.parentId;
                                this.addPms["primary.menuId"] = "";
                                this.$request(this.addPms, "/system/mapper/insert/system.insertSysMenu", () => {
                                    this.$message.success("保存成功");
                                    this.getData();
                                    this.status.saveLoading = false;
                                    this.$refs['addForm'].resetFields();
                                }, () => {
                                    this.status.saveLoading = false;
                                });
                                break;
                            case '3'://添加下级
                                this.addPms.parentId = this.nowMap.menuId;
                                this.addPms["primary.menuId"] = "";
                                this.$request(this.addPms, "/system/mapper/insert/system.insertSysMenu", () => {
                                    this.$message.success("保存成功");
                                    this.getData();
                                    this.status.saveLoading = false;
                                    this.$refs['addForm'].resetFields();
                                }, () => {
                                    this.status.saveLoading = false;
                                });
                                break;
                        }
                    }
                });

            },
            getData() {
                if (this.status.listLoading) return;
                this.status.listLoading = true;
                this.$request({display: true}, "/system/querySysMenuList", (data) => {
                    this.list = data.list;
                    this.status.listLoading = false;
                }, () => {
                    this.status.listLoading = false;
                });
            },
            handleClick(data) {
                this.$refs['addForm'].resetFields();
                switch (data.name) {
                    case '1'://修改菜单
                        this.addPms = {...this.nowMap};
                        this.status.isUpdate = true;
                        break;
                    case '2'://添加同级菜单
                        this.status.isUpdate = false;
                        break;
                    case '3'://添加下级菜单
                        this.status.isUpdate = false;
                        break;
                }
            },
            /*选择菜单*/
            handleNodeClick(data) {
                this.$request({menuId: data.menuId}, "/system/mapper/select/system.querySysMenuById", (data) => {
                    let menu = data.list[0];
                    menu.menuIcon = menu.menuIcon === undefined ? '' : menu.menuIcon;
                    menu.isLeaf += '';
                    menu.isDisplay += '';
                    menu.menuUrl = this.$util.isEmpty(menu.menuUrl) ? '' : menu.menuUrl;

                    if (this.operationType === '1') {
                        this.$nextTick(() => {
                            this.addPms = menu;
                        })
                    }
                    this.nowMap = {...menu};
                    this.handleClick({name: "1"});
                    this.operationType = '1';
                }, () => {
                });
            }
        }
    }
</script>

<style lang="less">
    .system-menu {
        display: flex;
        justify-content: space-between;

        .left {
            height: 70vh;
            width: 35%;
            border: 1px #E4E7ED solid;
            overflow: auto;
        }

        .right {
            width: 63%;
            height: 70vh;

            .form {
                border: 1px #E4E7ED solid;
                border-top: 0px;

                .half {
                    width: 45%;
                }
            }
        }

        .w200 {
            width: 150px;
        }

        @media (min-width: 1920px) {
            .w200 {
                width: 200px;
            }
        }
    }
</style>
<style lang="less">
    .system-menu {
        .el-tab-pane {
            padding-top: 0px !important;
        }

        .el-tabs__header {
            margin: 0px !important;
        }

        .form {
            .more-label {
                .el-form-item__label {
                    line-height: 18px !important;
                    text-align: center;
                }
            }

            .el-form-item__label:before { /*不显示必选前面的*号*/
                display: none;
            }
        }

    }
</style>