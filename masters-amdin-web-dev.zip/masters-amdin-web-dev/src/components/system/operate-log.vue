<template>
    <div class="operate-log">
        <el-form inline>
            <el-form-item label="操作人员：">
                <el-select v-model="logTable.operateId" placeholder="请选择">
                    <el-option v-for="item in empList" :key="item.empId" :label="item.empName" :value="item.empId">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="操作时间：">
                <el-date-picker v-model="operateTime" type="daterange" value-format="timestamp" range-separator="至"
                                start-placeholder="开始时间" end-placeholder="结束时间" style="width: 250px"/>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="page(1)" :loading="status.logTableLoading">查询</el-button>
            </el-form-item>
        </el-form>
        <div class="title">
            登录日志
        </div>
        <div class="container">
            <el-table :data="logList" border v-loading="status.logTableLoading" style="width: 100%">
                <el-table-column prop="operateName" label="操作人" min-width="100"></el-table-column>
                <el-table-column prop="operateTime" label="操作时间" min-width="200">
                    <template slot-scope="scope">
                        <span>{{ $util.formatDate(scope.row.operateTime) }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="operateDetails" label="操作详情" min-width="400"></el-table-column>
            </el-table>
            <el-pagination background layout="total, sizes, prev, pager, next, jumper" :current-page="logTable.page"
                           :total="logTableTotal" :page-sizes="[5, 10, 20, 50]" :page-size="logTable.limit"
                           @size-change="limit" @current-change="page"/>
        </div>
    </div>

</template>

<script>
    export default {
        name: "operate-log",
        data() {
            return {
                logList: [],
                logTable: {
                    operateId: "",
                    page: 1,
                    limit: 10
                },
                logTableTotal: 0,
                status: {
                    logTableLoading: false
                },
                empList: [],
                operateTime: []
            }
        },
        created() {
            this.getLogList();
            this.getEmpList();
        },
        methods: {
            getEmpList() {
                this.$request({}, "/system/mapper/select/system.queryEmpList", (data) => {
                    this.empList = data.list;
                });
            },
            getLogList() {
                this.status.logTableLoading = true;
                let params = {...this.logTable};
                if (!this.$util.isEmpty(this.operateTime) && this.operateTime.length === 2) {
                    params.startTime = this.operateTime[0];
                    params.endTime = this.operateTime[1]+this.$store.state.timestamp;
                }
                this.$request(params, "/system/mapper/select/system.queryOperateLog", (data) => {
                    this.status.logTableLoading = false;
                    this.logList = data.list;
                    this.logTableTotal = data.total;
                });
            },
            // 每页几条
            limit(limit) {
                this.logTable.limit = limit;
                this.page(1);
            },
            // 当前第几页
            page(page) {
                this.logTable.page = page;
                this.getLogList();
            }
        }
    }
</script>

<style lang="less" scoped>
    .operate-log {
        .title {
            height: 50px;
            line-height: 50px;
            background-color: #e6f3fc;
            padding-left: 20px;
            font-weight: bold;
            color: #686868;
        }
    }
</style>