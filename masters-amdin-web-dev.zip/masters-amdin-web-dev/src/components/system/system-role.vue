<template>
    <!--系统角色-->
    <div class="system-role">
        <!--角色相关-->
        <div class="role-list">
            <!--角色操作栏-->
            <el-form inline>
                <el-form-item>
                    <el-button type="success" @click="addRole">添加</el-button>
                    <el-button type="primary" @click="updateRole">编辑</el-button>
                    <el-button type="danger" @click="deleteRole">删除</el-button>
                </el-form-item>
            </el-form>
            <!--角色列表-->
            <el-table :data="roleList" border highlight-current-row v-loading="status.getRoleListLoading"
                      @current-change="roleTableCurrentChange">
                <el-table-column type="index" label="序号" width="50"></el-table-column>
                <el-table-column label="角色名称" prop="roleName"></el-table-column>
                <el-table-column label="备注" prop="note" show-overflow-tooltip></el-table-column>
            </el-table>
        </div>
        <!--角色菜单相关-->
        <div class="system-role-menu">
            <el-form inline>
                <el-form-item>
                    <el-button type="primary" :loading="status.saveRoleMenuLoading" @click="saveRoleMenu">
                        保存
                    </el-button>
                </el-form-item>
            </el-form>
            <div class="menu-tree-box" v-loading="status.getAllSystemMenuLoading">
                <el-tree :data="allMenuList" show-checkbox ref="menuTree" node-key="menuId" :props="menuProps"/>
            </div>
        </div>
        <!--添加或修改角色-->
        <el-dialog width="400px"
                   class="public-dialog"
                   :title="addOrUpdateRoleDialogTitle"
                   :visible.sync="status.addOrUpdateRoleDialog"
                   @open="addOrUpdateRoleDialogOpen"
                   @closed="status.addOrUpdateRoleLoading = false">
            <el-form :model="addOrUpdateRoleFormDate"
                     ref="addOrUpdateRoleFormDate"
                     :rules="addOrUpdateRoleRules"
                     label-width="80px">
                <el-form-item label="角色名称" prop="roleName">
                    <el-input v-model="addOrUpdateRoleFormDate.roleName" placeholder="角色名称" maxlength="20"
                              @input="value=>{this.addOrUpdateRoleFormDate.roleName = this.$util.checkCnEnNu(value)}">
                    </el-input>
                </el-form-item>
                <el-form-item label="备注" prop="note">
                    <el-input type="textarea" v-model="addOrUpdateRoleFormDate.note" maxlength="200"
                              placeholder="备注" show-word-limit></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" plain @click="status.addOrUpdateRoleDialog = false">取消</el-button>
                <el-button type="primary" :loading="status.addOrUpdateRoleLoading"
                           @click="addOrUpdateRole">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "system-role",
        data() {
            return {
                roleList: [],
                nowSelectTableRole: null,
                status: {
                    getRoleListLoading: false,
                    addOrUpdateRoleDialog: false,
                    addOrUpdateRoleLoading: false,
                    deleteRoleLoading: false,
                    getAllSystemMenuLoading: false,
                    saveRoleMenuLoading: false
                },
                addOrUpdateRoleDialogTitle: "",
                addOrUpdateRoleFormDate: {
                    roleId: "",
                    roleName: "",
                    note: ""
                },
                addOrUpdateRoleRules: {
                    roleName: [
                        {required: true, message: '请输入角色名称', trigger: 'blur'},
                    ]
                },
                // 系统所有菜单
                allMenuList: [],
                notStyleAllMenuList: [],
                menuProps: {
                    label: "menuName"
                }
            }
        },
        created() {
            this.getRoleList();
            this.getAllSystemMenu();
        },
        methods: {
            // 获取角色列表
            getRoleList() {
                this.status.getRoleListLoading = true;
                this.$request({}, "/system/mapper/select/system.querySysRoleList", (data) => {
                    this.status.getRoleListLoading = false;
                    this.roleList = data.list;
                }, () => {
                    this.status.getRoleListLoading = false;
                });
            },
            // 角色表格单选事件
            roleTableCurrentChange(row) {
                if (row) {
                    this.nowSelectTableRole = row;
                    this.status.getAllSystemMenuLoading = true;
                    this.$request({roleId: row.roleId}, "/system/mapper/select/system.queryMenuLinkByRoleId", (data) => {
                        let roleMenuList = [];
                        for (let menu of data.list) {
                            roleMenuList.push(menu.menuId);
                        }
                        this.$refs.menuTree.setCheckedKeys(roleMenuList);
                        this.status.getAllSystemMenuLoading = false;
                    }, () => {
                        this.status.getAllSystemMenuLoading = false;
                    })
                } else {
                    this.$refs.menuTree.setCheckedKeys([]);
                    this.nowSelectTableRole = null;
                }
            },
            // 添加角色点击事件
            addRole() {
                this.addOrUpdateRoleDialogTitle = "添加角色";
                this.status.addOrUpdateRoleDialog = true;
            },
            // 修改角色点击事件
            updateRole() {
                if (!this.nowSelectTableRole) {
                    this.$message.error("请先选择一个角色");
                    return;
                }
                this.addOrUpdateRoleDialogTitle = "编辑角色";
                this.status.addOrUpdateRoleDialog = true;
            },
            // 添加或修改角色弹窗打开事件
            addOrUpdateRoleDialogOpen() {
                if (this.addOrUpdateRoleDialogTitle === "编辑角色") {
                    this.$nextTick(() => {
                        this.addOrUpdateRoleFormDate = {...this.nowSelectTableRole};
                        this.$refs.addOrUpdateRoleFormDate.clearValidate()
                    });
                } else {
                    this.$nextTick(() => {
                        this.$refs.addOrUpdateRoleFormDate.resetFields();
                    })
                }
            },
            // 添加或修改角色
            addOrUpdateRole() {
                this.$refs.addOrUpdateRoleFormDate.validate((valid) => {
                    if (valid) {
                        let funcId = "/system";
                        switch (this.addOrUpdateRoleDialogTitle) {
                            case "添加角色":
                                funcId += "/insertSysRole";
                                break;
                            case "编辑角色":
                                funcId += "/updateSysRole";
                                break;
                            default:
                                this.$message.error("无效操作");
                                return;
                        }
                        this.status.addOrUpdateRoleLoading = true;
                        let params = {...this.addOrUpdateRoleFormDate};
                        params["primary.roleId"] = "";
                        this.$request(params, funcId, () => {
                            this.$message.success("保存成功");
                            this.getRoleList();
                            this.status.addOrUpdateRoleDialog = false;
                        }, () => {
                            this.status.addOrUpdateRoleLoading = false;
                        })
                    }
                });
            },
            // 删除角色
            deleteRole() {
                if (!this.nowSelectTableRole) {
                    this.$message.warning("请先选择一个角色");
                    return;
                }
                this.$confirm('你确定要删除这个角色?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {...this.nowSelectTableRole};
                    this.status.deleteRoleLoading = true;
                    this.$request(params, "/system/deleteRoleById", () => {
                        this.status.deleteRoleLoading = false;
                        this.$message.success("删除成功");
                        this.getRoleList();
                    }, () => {
                        this.status.deleteRoleLoading = false;
                    });
                }).catch(() => {
                });
            },
            // 查询所有系统菜单
            getAllSystemMenu() {
                this.status.getAllSystemMenuLoading = true;
                this.$request({}, "/system/querySysMenuList", (data) => {
                    this.allMenuList = data.list;
                    this.status.getAllSystemMenuLoading = false;
                }, () => {
                    this.status.getAllSystemMenuLoading = false;
                })
            },
            // 保存角色菜单
            saveRoleMenu() {
                if (!this.nowSelectTableRole) {
                    this.$message.error("请先选择一个角色");
                    return;
                }
                let roleMenu = this.$refs.menuTree.getCheckedKeys().concat(this.$refs.menuTree.getHalfCheckedKeys()).join(",");
                let params = {
                    roleId: this.nowSelectTableRole.roleId,
                    menuIds: roleMenu
                };
                this.status.saveRoleMenuLoading = true;
                this.$request(params, "/system/updateRoleMenuLink", () => {
                    this.status.saveRoleMenuLoading = false;
                    this.$message.success("修改成功");
                }, () => {
                    this.status.saveRoleMenuLoading = false;
                })
            }
        }
    }
</script>

<style lang="less" scoped>
    .system-role {
        display: flex;
        justify-content: space-between;

        .role-list {
            width: 45%;
        }

        .system-role-menu {
            width: 45%;

            .menu-tree-box {
                max-height: 500px;
                overflow: auto;
            }
        }
    }
</style>
