/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/4/22 0022 11:22
 */

import operateLog from './operate-log';
import systemEmp from './system-emp';
import systemMenu from './system-menu';
import systemRole from './system-role';
import systemSector from './system-sector';

export default [
    operateLog, systemEmp, systemMenu, systemRole, systemSector
]
