<template>
    <div class="system-emp">
        <el-form inline>
            <el-form-item label="入职日期">
                <el-date-picker v-model="timeSelect"
                                type="daterange"
                                value-format="yyyy-MM-dd"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"
                                style="width: 250px"/>
            </el-form-item>
            <el-form-item label="员工姓名">
                <el-input v-model="empTable.empName" placeholder="请输入员工姓名" style="width:150px" clearable maxlength="5"></el-input>
            </el-form-item>
            <el-form-item label="所属校区">
                <el-select v-model="empTable.campusId" placeholder="所属校区" style="width: 150px" clearable>
                    <el-option
                            v-for="item in campus"
                            :key="item.campusId"
                            :label="item.campusName"
                            :value="item.campusId">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="page(1)" :loading="status.empTableLoading"
                           icon="el-icon-search">查询</el-button>
                <el-button type="success" class="add-button" @click="showInsertDialog">新增员工</el-button>
            </el-form-item>
        </el-form>
        <div class="container">
            <el-table :data="empList" border v-loading="status.empTableLoading">
                <el-table-column type="index" width="50" label="序号"/>
                <el-table-column prop="loginCode" label="账号" min-width="120"/>
                <el-table-column prop="empName" label="姓名" min-width="120"/>
                <el-table-column prop="gender" label="性别" min-width="120">
                    <template slot-scope="scope">
                        <span>{{ scope.row.gender===1?'男':'女'}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="sectorName" label="部门" min-width="120"/>
                <!--<el-table-column prop="roleName" label="岗位" min-width="120"/>-->
                <el-table-column label="年龄" min-width="120">
                    <template slot-scope="scope">
                        <span>{{ $util.getAge(scope.row.birthday) }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="mobilePhone" label="联系方式" min-width="120"/>
                <el-table-column prop="hiredate" label="入职时间" min-width="150"/>
                <el-table-column prop="graduateSchool" label="毕业院校" min-width="120"/>
                <el-table-column prop="campusName" label="所属校区" min-width="120"/>
                <el-table-column prop="empId" label="操作" min-width="200">
                    <template slot-scope="scope">
                        <el-button type="text" @click="showUpdateDialog(scope.row)">编辑</el-button>
                        <el-button type="text" @click="deleteEmp(scope.row)">删除</el-button>
                        <el-button type="text" @click="resetEmpPassword(scope.row.empId)">重置密码</el-button>
                        <el-button type="text" @click="updateEmpState(scope.row)">{{scope.row.empState == 1 ? '禁用' :
                            '启用'}}
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination background layout="total, sizes, prev, pager, next, jumper" :current-page="empTable.page"
                           :total="empTotal" :page-sizes="[5, 10, 20, 50]" :page-size="empTable.limit"
                           @size-change="limit" @current-change="page" align="right"/>
        </div>
        <el-dialog title="成员信息" :visible.sync="status.isShowEmpDialog" width="450px" @closed="closedEmpDialog">
            <div>
                <el-form :model="empForm" :rules="rules" ref="empForm" label-width="80px">
                    <el-form-item label="账号" prop="loginCode">
                        <el-input v-model="empForm.loginCode" placeholder="请输入成员账号" clearable style="width: 300px"
                                  @input="value=>{this.empForm.loginCode = this.$util.checkNumber(value,true)}"
                                  maxlength="20"></el-input>
                    </el-form-item>
                    <el-form-item label="姓名" prop="empName">
                        <el-input v-model="empForm.empName" placeholder="请输入成员姓名" clearable  style="width: 300px"></el-input>
                    </el-form-item>
                    <el-form-item label="性别"
                                  prop="gender"
                                  :rules="[{ required: true, message: '请选择性别', trigger: 'blur' }]">
                        <el-select v-model="empForm.gender" placeholder="性别" style="width: 300px">
                            <el-option
                                    v-for="item in gender"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="生日"
                                  prop="birthday"
                                  :rules="[{ required: true, message: '请选择生日', trigger: 'blur' }]">
                        <el-date-picker
                                v-model="empForm.birthday"
                                type="date"
                                value-format="yyyy-MM-dd"
                                placeholder="选择日期" style="width: 300px">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item label="联系方式" prop="mobilePhone">
                        <el-input v-model="empForm.mobilePhone" maxlength="11" clearable
                                  @input="value=>{empForm.mobilePhone = this.$util.checkNumber(value)}"
                                  placeholder="请输入手机号码" style="width: 300px"></el-input>
                    </el-form-item>
                    <el-form-item label="部门" prop="sectorId">
                        <el-select v-model="empForm.sectorId" placeholder="请选择所属部门" clearable style="width: 300px">
                            <el-option v-for="item in sectorList" :key="item.sectorId" :label="item.sectorName"
                                       :value="item.sectorId">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <!--<el-form-item label="岗位" prop="roleId">-->
                        <!--<el-select v-model="empForm.roleId" placeholder="请选择所属部门" clearable style="width: 300px">-->
                            <!--<el-option v-for="item in roleList" :key="item.roleId" :label="item.roleName"-->
                                       <!--:value="item.roleId">-->
                            <!--</el-option>-->
                        <!--</el-select>-->
                    <!--</el-form-item>-->
                    <el-form-item label="入职时间"
                                  prop="hiredate"
                                  :rules="[{ required: true, message: '请选择入职时间', trigger: 'blur' }]">
                        <el-date-picker
                                v-model="empForm.hiredate"
                                type="date"
                                value-format="yyyy-MM-dd"
                                placeholder="选择日期"
                                style="width: 300px">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item label="所属校区"
                                  prop="campusId"
                                  :rules="[{ required: true, message: '请选择所属校区', trigger: 'blur' }]">
                        <el-select v-model="empForm.campusId" placeholder="所属校区" style="width: 300px">
                            <el-option
                                    v-for="item in campus"
                                    :key="item.campusId"
                                    :label="item.campusName"
                                    :value="item.campusId">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="毕业院校"
                                  prop="graduateSchool"
                                  :rules="[{ required: true, message: '请输入毕业院校', trigger: 'blur' }]">
                        <el-input v-model="empForm.graduateSchool" autocomplete="off" style="width: 300px"
                                  placeholder="请输入毕业院校" maxlength="20"/>
                    </el-form-item>
                    <el-form-item label="备注信息" prop="note">
                        <el-input type="textarea" v-model="empForm.note" placeholder="备注信息"
                                  maxlength="200" show-word-limit
                                  clearable style="width: 300px"></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="closedEmpDialog">取 消</el-button>
                <el-button type="primary" @click="saveEmp">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "system-emp",
        data() {
            let isName = (rule, value, callback) => {
                let nameReg = /^[\u4E00-\u9FA5.·\u36c3\u4DAE]{2,20}$|^[A-Za-z]{2,20}$/;
                if (!nameReg.test(value)) {
                    return callback(new Error('姓名格式须为2~20个连续的汉字或字母'));
                }
                return callback();
            };
            let validatePhone = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请输入联系电话'));
                } else {
                    if (!this.$util.isPhoneNumber(value)) {
                        callback(new Error('联系电话格式不正确'));
                    }
                    callback();
                }
            };
            return {
                timeSelect: [],
                sectorList: [],
                roleList: [],
                empList: [],
                empTable: {
                    empName: "",
                    sectorId: "",
                    campusId: "",
                    page: 1,
                    limit: 10
                },
                empTotal: 0,
                status: {
                    empTableLoading: false,
                    isShowEmpDialog: false
                },
                empForm: {
                    empId: "",
                    loginCode: "",
                    empName: "",
                    mobilePhone: "",
                    sectorId: "1",
                    roleId: "1",
                    gender: "",
                    birthday: "",
                    hiredate: "",
                    campusId: "",
                    graduateSchool: "",
                    note: ""
                },
                campus: [],
                gender: [
                    {
                        value: 1,
                        label: '男'
                    },
                    {
                        value: 2,
                        label: '女'
                    }
                ],
                rules: {
                    loginCode: [
                        {required: true, message: "请输入成员账号", trigger: "blur"},
                        {min: 6, max: 20, message: "账号长度须在6~20位之间", trigger: "blur"}
                    ],
                    empName: [
                        {required: true, message: "请输入成员姓名", trigger: "blur"},
                        {validator: isName, trigger: 'blur'}
                    ],
                    mobilePhone: [
                        {required: true, message: "请输入手机号码", trigger: "blur"},
                        {required: true, validator: validatePhone, trigger: 'blur'}
                    ],
                    sectorId: [
                        {required: true, message: "请选择部门", trigger: "blur"}
                    ],
                    roleId: [
                        {required: true, message: "请选择岗位", trigger: "blur"}
                    ],
                },
            }
        },
        created() {
            this.getSectorList();
            // this.getRoleList();
            this.getEmpList();
            this.queryCampus();
        },
        methods: {
            getSectorList() {
                this.$request({}, "/system/mapper/select/system.querySectorList", (data) => {
                    this.sectorList = data.list;
                });
            },
            // getRoleList() {
            //     this.$request({}, "/system/mapper/select/system.querySysRoleList", (data) => {
            //         this.roleList = data.list;
            //     });
            // },
            getEmpList() {
                let params = {...this.empTable};
                if (this.timeSelect && this.timeSelect.length === 2) {
                    params.startDate = this.timeSelect[0];
                    params.endDate = this.timeSelect[1];
                }
                this.status.empTableLoading = true;
                this.$request(params, "/system/mapper/select/queryEmpListByCondition", (data) => {
                    this.status.empTableLoading = false;
                    this.empList = data.list;
                    this.empTotal = data.total;
                });
            },
            // 每页几条
            limit(limit) {
                this.empTable.limit = limit;
                this.page(1);
            },
            // 当前第几页
            page(page) {
                this.empTable.page = page;
                this.getEmpList();
            },
            showInsertDialog() {
                this.status.isShowEmpDialog = true;
            },
            closedEmpDialog() {
                this.empForm = {};
                this.$refs.empForm.resetFields();
                this.status.isShowEmpDialog = false
            },
            showUpdateDialog(row) {
                this.empForm = {...row};
                this.status.isShowEmpDialog = true;
            },
            deleteEmp(row) {
                this.$confirm('您确定要删除[' + row.empName + ']吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {empId: row.empId};
                    let funcId = "/system/deleteEmp";
                    this.$request(params, funcId, () => {
                        this.$message.success("删除成功");
                        this.getEmpList();
                    });
                });
            },
            saveEmp() {
                let empForm = this.$refs.empForm;
                empForm.validate((valid) => {
                    if (valid) {
                        let params = this.empForm;
                        if (params.birthday>this.$util.getNowDate()){
                            this.$message.error('生日不可为未来日期');
                            return;
                        }
                        let funcId = "/system/insertEmp";
                        if (!this.$util.isEmpty(params.empId)) {
                            funcId = "/system/updateEmp";
                        }
                        let sector = this.sectorList.find((item)=>{
                            return item.sectorId === params.sectorId;
                        });
                        params.sectorName = sector.sectorName;
                        // let role = this.roleList.find((item)=>{
                        //     return item.roleId === params.roleId;
                        // });
                        // params.roleName = role.roleName;
                        let campus = this.campus.find(item=>{
                            return item.campusId === params.campusId;
                        });
                        params.campusName = campus.campusName;

                        this.$request(params, funcId, () => {
                            this.$message.success("保存成功");
                            this.status.isShowEmpDialog = false;
                            this.getEmpList();
                            this.closedEmpDialog();
                        });
                    } else {
                        return false;
                    }
                });
            },
            updateEmpState(row) {
                let state = row.empState == 1 ? 2 : 1;
                let text = state == 1 ? "启用" : "禁用";
                this.$confirm('您确定要' + text + '此账号吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {empId: row.empId, empState: state};
                    let funcId = "/system/mapper/update/system.updateEmpState";
                    this.$request(params, funcId, () => {
                        this.$message.success(text + "成功");
                        this.getEmpList();
                        if (this.$util.getUser().empId===row.empId){
                            this.$util.removeUser();
                            this.$store.commit("clearTab");
                            this.$router.push("/login");
                        }
                    });
                });
            },
            resetEmpPassword(empId){
                this.$confirm('您确定要重置密码吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {empId: empId};
                    let funcId = "/system/resetEmpPassword";
                    this.$request(params, funcId, () => {
                        this.$message.success("重置成功");
                    });
                });
            },
            queryCampus(){
                this.$request({}, "/masters/mapper/select/queryCampus", (data) => {
                    if (data.flag===200){
                        this.campus = data.list
                    }
                }, err => {
                    console.log(err);
                });
            },
        },
    }
</script>

<style lang="less" scoped>
    .system-emp {
        .title {
            height: 50px;
            line-height: 50px;
            background-color: #e6f3fc;
            padding-left: 20px;
            color: #686868;

            .count {
                font-weight: bold;
            }

            .add-button {
                float: right;
                height: 32px;
                margin: 9px 9px 0px 0px;
            }

            .title-icon {
                color: #1890ff;
                margin-right: 5px;
            }
        }

    }
</style>