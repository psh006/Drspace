<template>
    <div class="system-sector">
        <el-form inline>
            <el-form-item>
                <el-button type="success" class="add-button" @click="showInsertDialog">新增部门</el-button>
            </el-form-item>
        </el-form>
        <div class="container">
            <el-table :data="sectorList" border v-loading="status.sectorTableLoading">
                <el-table-column type="index" width="50" label="序号"></el-table-column>
                <el-table-column prop="sectorName" label="部门名称"></el-table-column>
                <el-table-column prop="remark" label="备注" show-overflow-tooltip></el-table-column>
                <el-table-column prop="operateTime" label="添加时间">
                    <template slot-scope="scope">
                        <span>{{ $util.formatDate(scope.row.operateTime) }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="sectorId" label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" @click="showUpdateDialog(scope.row)">编辑</el-button>
                        <el-button type="text" @click="deleteSector(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination background layout="total, sizes, prev, pager, next, jumper" :current-page="sectorTable.page"
                           :total="sectorTotal" :page-sizes="[5, 10, 20, 50]" :page-size="sectorTable.limit"
                           @size-change="limit" @current-change="page"/>
        </div>
        <el-dialog title="部门信息" :visible.sync="status.isShowSectorDialog" width="400px" @closed="closedSectorDialog">
            <div>
                <el-form :model="sectorForm" :rules="rules" ref="sectorForm" label-width="80px">
                    <el-form-item label="部门名称" prop="sectorName">
                        <el-input v-model="sectorForm.sectorName" placeholder="部门名称" clearable maxlength="20"
                                  @input="value=>{this.sectorForm.sectorName = this.$util.checkCnEnNu(value)}">
                        </el-input>
                    </el-form-item>
                    <el-form-item label="备注" prop="remark">
                        <el-input v-model="sectorForm.remark" placeholder="备注" clearable maxlength="200"
                                  type="textarea" show-word-limit></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="closedSectorDialog">取 消</el-button>
                <el-button type="primary" @click="saveSector">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "system-sector",
        data() {
            var checkSectorName = (rule, value, callback) => {
                let params = {sectorName: value};
                let sectorId = this.sectorForm.sectorId;
                if (!this.$util.isEmpty(this.sectorForm.sectorId)) {
                    params.sectorId = sectorId;
                }
                let funcId = "/system/mapper/select/system.queryEmpSectorByName";
                this.$request(params, funcId, (data) => {
                    let items = data.list;
                    if (!this.$util.isEmpty(items) && items.length > 0) {
                        callback(new Error('部门已存在，请重新输入！'));
                    }else{
                        callback();
                    }
                }, () => {
                    callback(new Error('未知错误，请重试！'));
                });
            };
            return {
                sectorList: [],
                sectorTable: {
                    page: 1,
                    limit: 10
                },
                sectorTotal: 0,
                status: {
                    sectorTableLoading: false,
                    isShowSectorDialog: false
                },
                sectorForm: {
                    sectorId: "",
                    sectorName: "",
                    remark: ""
                },
                rules: {
                    sectorName: [
                        {required: true, message: "请输入部门名称", trigger: "blur"},
                        {validator: checkSectorName, trigger: 'blur'}
                    ]
                },
            }
        },
        created() {
            this.getSectorList();
        },
        methods: {
            getSectorList() {
                this.status.sectorTableLoading = true;
                this.$request(this.sectorTable, "/system/mapper/select/querySectorList", (data) => {
                    this.status.sectorTableLoading = false;
                    this.sectorList = data.list;
                    this.sectorTotal = data.total;
                });
            },
            // 每页几条
            limit(limit) {
                this.sectorTable.limit = limit;
                this.page(1);
            },
            // 当前第几页
            page(page) {
                this.sectorTable.page = page;
                this.getSectorList();
            },
            showInsertDialog() {
                this.status.isShowSectorDialog = true;
            },
            closedSectorDialog() {
                this.sectorForm = {};
                this.$refs.sectorForm.resetFields();
                this.status.isShowSectorDialog = false
            },
            showUpdateDialog(row) {
                this.sectorForm = {...row};
                this.status.isShowSectorDialog = true;
            },
            deleteSector(row) {
                this.$confirm('您确定要删除' + row.sectorName + '吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let params = {sectorId: row.sectorId};
                    let funcId = "/system/mapper/delete/system.deleteEmpSector";
                    this.$request(params, funcId, () => {
                        this.$message.success("删除成功");
                        this.getSectorList();
                    });
                });
            },
            saveSector() {
                let sectorForm = this.$refs.sectorForm;
                sectorForm.validate((valid) => {
                    if (valid) {
                        let params = this.sectorForm;
                        params["primary.sectorId"] = "";
                        let funcId = "/system/mapper/insert/system.insertEmpSector";
                        if (!this.$util.isEmpty(params.sectorId)) {
                            funcId = "/system/mapper/update/system.updateEmpSector";
                        }
                        this.$request(params, funcId, () => {
                            this.$message.success("保存成功");
                            this.status.isShowSectorDialog = false;
                            this.getSectorList();
                            this.closedSectorDialog();
                        }, () => {
                            this.status.isShowSectorDialog = false;
                            this.closedSectorDialog();
                        });
                    } else {
                        return false;
                    }
                });
            }
        }
    }
</script>

<style lang="less" scoped>
    .system-sector {
        .title {
            height: 50px;
            line-height: 50px;
            background-color: #e6f3fc;
            padding-left: 20px;
            color: #686868;

            .count {
                font-weight: bold;
            }

            .add-button {
                float: right;
                height: 32px;
                margin: 9px 9px 0px 0px;
            }

            .title-icon {
                color: #1890ff;
                margin-right: 5px;
            }
        }

    }
</style>