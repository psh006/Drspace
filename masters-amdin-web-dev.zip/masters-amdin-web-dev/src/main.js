import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import './assets/style/theme/index.css'
import Filter from './assets/javascript/filter'
import viewComponents from './components/index'
import util from './assets/javascript/util.js'
import dict from './assets/javascript/dict.js'
import axios from 'axios'
import {
    requestData,
    fileUrl,
    removeFile
} from './assets/javascript/request.js'

window.axios = axios;
Vue.use(viewComponents);
Vue.config.productionTip = false;
Vue.use(ElementUI, {size: 'small'});
Vue.use(Filter);
Vue.prototype.$util = util;
Vue.prototype.$dict = dict;
Vue.prototype.$request = requestData;
Vue.prototype.$removeFile = removeFile;

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app');

fileUrl((data) => {
    Vue.prototype.$baseUrl = data.BASE_URL;
    Vue.prototype.$uploadFileUrl = data.UPLOAD_FILE_URL;
    Vue.prototype.$getFileUrl = data.GET_FILE_URL;
    Vue.prototype.$removeFileUrl = data.REMOVE_FILE_URL;
});