import Vue from 'vue'
import Vuex from 'vuex'
import TIC from "./../assets/TX_api/TIC.min"
import util from "./../assets/javascript/util"
import constData from "./../assets/javascript/const-data"
import {Message, Notification, MessageBox} from "element-ui"
import {requestData} from './../assets/javascript/request.js'

import classroomAnswer from './modules/classroom-answer'
import classroomStudentModules from './modules/classroom-student'

Vue.use(Vuex);


let showMessageInBox = (state, messageType, text) => {
    let d = new Date();
    let time = `${('0' + d.getHours()).substr(-2)}:${('0' + d.getMinutes()).substr(-2)}:${('0' + d.getSeconds()).substr(-2)}`;
    let msg = {
        time: time + ' ',
        send: messageType + ' ',
        content: text
    };
    state.groupMsg.push(msg);
};

let teacherDo = (studentId, messageType, status) => {
    let text = {};
    text.type = messageType;
    text.data = {status};
    const message = window.tim.createTextMessage({
        to: studentId,
        conversationType: window.TIM.TYPES.CONV_C2C,
        payload: {text: JSON.stringify(text)}
    });
    window.tim.sendMessage(message).catch(error => {
        Message.error(error.message);
    });
};

let studentOnStage = (studentId, studentName, roomId) => {
    MessageBox(`确定要让${studentName}上台吗?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
    }).then(() => {
        requestData({roomId, studentId, onStageState: 1}, '/masters/mapper/select/studentStatus.updateStudentStatus', () => {
            Message.success("操作成功");
            teacherDo(studentId, constData.MESSAGE_TYPE_ONSTAGE_STATE, 1);
        });
    }).catch(() => {
    });
};

let resetNoReadTotal = state => {
    let conversationList = [...state.conversationList];
    let total = 0;
    conversationList.map(item => {
        total += item.unreadCount;
    });
    state.notReadTotal = total;
};

export default new Vuex.Store({
    state: {
        // Tab中的菜单数据
        editableTabs: [],
        // Tab中被选中的菜单
        editableTabsValue: "",
        // 二级菜单及其子菜单数据
        menuData: [],

        //TIC本体
        tic: null,
        //TIC用户当前状态
        ticUserStatus: 0,
        //TIC用户
        ticUserInfo: {
            userId: "",
            userSig: ""
        },
        //课堂消息中心
        groupMsg: [],
        //会话相关
        currentConversation: {},
        currentMessageList: [],
        nextReqMessageID: '',
        isCompleted: false, // 当前会话消息列表是否已经拉完了所有消息
        conversationList: [],
        showConversation: false,
        //系统用户是否登录
        systemUserIsLogin: false,
        //系统用户信息
        systemUserInfo: {},
        //未读消息总数
        notReadTotal: 0
    },
    mutations: {
        //设置二级菜单
        setMenuData(state, menuData) {
            state.menuData = menuData;
        },
        //添加页面到Tab栏
        addTab(state, menu) {
            state.editableTabs.push(menu);
            state.editableTabsValue = menu.menuUrl;
        },
        //删除页面到Tab栏
        clearTab(state) {
            state.editableTabs = [];
            state.editableTabsValue = "";
            state.menuData = [];
        },
        //二级菜单被选中函数
        menuSelect(state, path) {
            let menu = state.editableTabs.find(item => {
                return item.menuUrl === path;
            });
            if (util.isEmpty(menu)) {
                for (let [index, menuItem] of state.menuData.entries()) {
                    if (menuItem.isLeaf === 2) {
                        for (let [childrenIndex, children] of menuItem.children.entries()) {
                            if (children.menuUrl === path) {
                                menu = menuItem.children[childrenIndex];
                                break;
                            }
                        }
                    } else {
                        if (menuItem.menuUrl === path) {
                            menu = state.menuData[index];
                            break;
                        }
                    }
                }
                state.editableTabs.push(menu);
            }
            state.editableTabsValue = menu.menuUrl;
        },
        //删除Tab栏
        removeTab(state, menu) {
            let tabs = state.editableTabs;
            let activeName = state.editableTabsValue;
            if (menu === activeName) {
                tabs.forEach((tab, index) => {
                    if (tab.menuUrl === menu) {
                        let nextTab = tabs[index + 1] || tabs[index - 1];
                        if (nextTab) {
                            activeName = nextTab.menuUrl;
                        }
                    }
                });
            }
            state.editableTabsValue = activeName;
            state.editableTabs = tabs.filter(tab => tab.menuUrl !== menu)
        },
        //TIC初始化
        initTic(state, success_callback) {
            state.tic = null;
            state.tic = new TIC({});
            state.tic.init(constData.SDK_APP_ID, res => {
                if (res.code) {
                    console.error(constData.MESSAGE_TYPE_SYSTEM + "初始化失败,错误码" + res.code + ",失败原因" + res.desc);
                } else {
                    state.ticUserStatus = constData.USER_STATUS_UNLOGIN;
                    success_callback && success_callback();
                }
            });
        },
        //改变TIC用户状态
        toggleTicUserStatus(state, status) {
            state.ticUserStatus = status
        },
        //直播间消息插入
        insertGroupMsg(state, msg) {
            state.groupMsg.push(msg);
        },
        //直播间消息清理
        clearGroupMsg(state) {
            state.groupMsg = [];
        },
        // 设置回话列表
        setConversationList(state, conversationList) {
            state.conversationList = conversationList;
        },
        // 设置TIC用户信息
        setTicUserInfo(state, ticUserInfo) {
            state.ticUserInfo.userId = ticUserInfo.userId;
            state.ticUserInfo.userSig = ticUserInfo.userSig;
        },
        /**
         * 更新当前会话
         * 调用时机: 切换会话时
         * @param {Object} state
         * @param {Conversation} conversation
         */
        updateCurrentConversation(state, conversation) {
            state.currentConversation = conversation;
            state.currentMessageList = [];
            state.nextReqMessageID = '';
            state.isCompleted = false
        },
        /**
         * 将消息插入当前会话列表
         * 调用时机：收/发消息事件触发时
         * @param {Object} state
         * @param {Message[]|Message} data
         * @returns
         */
        pushCurrentMessageList(state, data) {
            if (Array.isArray(data)) {
                let privateList = [];
                for (let item of data) {
                    //只要文本自定义消息
                    if (item.type === window.TIM.TYPES.MSG_TEXT && item.payload.text.includes('{"type":')) {
                        let nowConversationID = state.currentConversation.conversationID;
                        if (nowConversationID === item.conversationID && JSON.parse(item.payload.text).type === constData.MESSAGE_TYPE_PRIVATE) {
                            window.tim.setMessageRead({conversationID: nowConversationID});
                        } else if (JSON.parse(item.payload.text).type !== constData.MESSAGE_TYPE_PRIVATE) {
                            window.tim.setMessageRead({conversationID: nowConversationID});
                        }
                        resetNoReadTotal(state);
                        let message = JSON.parse(item.payload.text);
                        switch (message.type) {
                            case constData.MESSAGE_TYPE_PRIVATE:
                                privateList.push(item);
                                break;
                            case constData.MESSAGE_TYPE_GROUP:
                                showMessageInBox(state, message.type, message.fromUserName + ": " + message.text);
                                break;
                            case constData.MESSAGE_TYPE_HAND:
                                Notification({
                                    title: '有同学举手',
                                    message: `${message.data.studentName}想要举手上台`,
                                    duration: 3000,
                                    offset: 40,
                                    onClick: () => {
                                        studentOnStage(message.data.studentId, message.data.studentName, message.data.roomId);
                                    }
                                });
                                break;
                            case constData.MESSAGE_TYPE_STUDENT_ANSWER:
                                if (state.classroomAnswer.answering) {
                                    let studentAnsweringListSet = new Set(state.classroomAnswer.studentAnsweringList);
                                    studentAnsweringListSet.add(message.data);
                                    state.classroomAnswer.studentAnsweringList = [...studentAnsweringListSet];
                                    let studentAnsweringList = JSON.parse(JSON.stringify(state.classroomAnswer.studentAnsweringList));
                                    let rightList = [];
                                    let optionMap = new Map();
                                    for (let item of studentAnsweringList) {
                                        if (optionMap.has(item.answer)) {
                                            optionMap.set(item.answer, optionMap.get(item.answer) + 1);
                                        } else {
                                            optionMap.set(item.answer, 1);
                                        }
                                        if (state.classroomAnswer.rightAnswer === item.answer) {
                                            rightList.push(item)
                                        }
                                    }
                                    let item = [];
                                    for (let [key, value] of optionMap.entries()) {
                                        item[key] = value;
                                    }
                                    state.classroomAnswer.choiceResultData = [item];
                                    state.classroomAnswer.accuracy = ((rightList.length / studentAnsweringList.length) * 100).toFixed(2)
                                }
                                break;
                        }
                    }
                }
                if (privateList.length > 0) {
                    if (!state.currentConversation.conversationID) {
                        return;
                    }
                    state.currentMessageList = [...state.currentMessageList, ...privateList];
                }
            } else if (data.conversationID === state.currentConversation.conversationID) {
                {
                    state.currentMessageList = [...state.currentMessageList, data]
                }
            }

        },
        //控制聊天窗口
        setShowConversation(state, boolean) {
            state.showConversation = boolean;
        },
        // 设置用户
        setSystemUserInfo(state, systemUserInfo) {
            state.systemUserIsLogin = true;
            state.systemUserInfo = systemUserInfo;
        },
        // 移除用户
        removeSystemUserInfo(state) {
            state.systemUserIsLogin = false;
            state.systemUserInfo = {};
        },
    },
    actions: {
        /**
         * 获取消息列表
         * 调用时机：打开某一会话时或下拉获取历史消息时
         * @param {Object} context
         * @param {String} conversationID
         */
        getMessageList(context, conversationID) {
            if (context.state.isCompleted) {
                Message.info("已经没有更多消息了");
                return
            }
            const {nextReqMessageID, currentMessageList} = context.state;
            window.tim.getMessageList({conversationID, nextReqMessageID, count: 15}).then(imReponse => {
                resetNoReadTotal(context.state);
                // 更新messageID，续拉时要用到
                context.state.nextReqMessageID = imReponse.data.nextReqMessageID;
                context.state.isCompleted = imReponse.data.isCompleted;
                // 更新当前消息列表，从头部插入
                context.state.currentMessageList = [...imReponse.data.messageList, ...currentMessageList];
            })
        },
        /**
         * 切换会话
         * 调用时机：切换会话时
         * @param {Object} context
         * @param {String} conversationID
         */
        checkoutConversation(context, conversationID) {
            // 1.切换会话前，将切换前的会话进行已读上报
            if (context.state.currentConversation.conversationID) {
                const prevConversationID = context.state.currentConversation.conversationID;
                window.tim.setMessageRead({conversationID: prevConversationID})
            }
            // 2.待切换的会话也进行已读上报
            window.tim.setMessageRead({conversationID});
            // 3. 获取会话信息
            return window.tim.getConversationProfile(conversationID).then(({data}) => {
                resetNoReadTotal(context.state);
                // 3.1 更新当前会话
                context.commit('updateCurrentConversation', data.conversation);
                // 3.2 获取消息列表
                context.dispatch('getMessageList', conversationID);
                return Promise.resolve()
            })
        }
    },
    modules: {
        classroomAnswer,
        classroomStudentModules
    }
})
