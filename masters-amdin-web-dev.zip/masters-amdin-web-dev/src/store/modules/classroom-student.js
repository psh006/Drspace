/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/6/8 0008 13:40
 */

// import util from "./../../assets/javascript/util"


const classroomStudentModules = {
    state: {
        studentListDialog: false,
        studentList: [],
        roomId:""
    },
    mutations: {
        setStudentListDialog(state, boolean) {
            state.studentListDialog = boolean;
        },
        setRoomId(state, roomId) {
            state.roomId = roomId;
        },
        setStudentList(state,studentList) {
            state.studentList = studentList
        }
    },
    actions: {}
};

export default classroomStudentModules