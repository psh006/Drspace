/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/6/4 0004 13:56
 */

const classroomAnswerModules = {
        state: {
            //当前是否正在答题
            answering: false,
            //学生们的答案
            studentAnsweringList: [],
            //正确答案
            rightAnswer: "",
            //正确率
            accuracy: "0.00",
            choiceResultData:[]
        },
        mutations: {
            setAnswering(state, boolean) {
                state.answering = boolean;
            },
            setRightAnswer(state, rightAnswer) {
                state.rightAnswer = rightAnswer;
            },
            clearStudentAnsweringList(state) {
                state.studentAnsweringList = [];
            },
            clearChoiceResultData(state) {
                state.choiceResultData=[];
            }
        },
        actions: {}
    };

export default classroomAnswerModules