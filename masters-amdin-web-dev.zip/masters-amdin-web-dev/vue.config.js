const path = require('path');
function resolve(dir) {
    return path.join(__dirname, dir)
}

module.exports = {
    publicPath: process.env.NODE_ENV === 'production' ? '/masters-admin-web/' : '/',
    outputDir: 'masters-admin-web',
    devServer: {
        port: 8082,
    },
    chainWebpack: config => {
        // 自定义路径
        config.resolve.alias
            .set('@', resolve('src'))
            .set('assets', resolve('src/assets'))
            .set('components', resolve('src/components'))
    }
};
