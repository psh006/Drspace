package com.yunyun.shop.api.pojo.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.dto
 * @createTime 2020-06-28 17:20
 */
@Data
public class HistoryRefundOrderResult implements Serializable {

    /**
     * 退款时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "退款时间")
    private Date refundTime;

    /**
     * 订单号
     */
    @ApiModelProperty(value = "订单号")
    private String orderId;

    /**
     * 订单详情号
     */
    @ApiModelProperty(value = "订单详情号")
    private String orderDetailId;

    /**
     * 物品图片
     */
    @ApiModelProperty(value = "物品图片")
    private String goodsImage;

    /**
     * 物品名称
     */
    @ApiModelProperty(value = "物品名称")
    private String goodsName;

    /**
     * 总金额
     */
    @ApiModelProperty(value = "总金额")
    private String orderDetailAmount;

    /**
     * 实付金额
     */
    @ApiModelProperty(value = "实付金额")
    private String detailPayAmountReal;

    /**
     * 收货人姓名
     */
    @ApiModelProperty(value = "收货人姓名")
    private String receiptName;

    /**
     * 收货人手机号
     */
    @ApiModelProperty(value = "收货人手机号")
    private String receiptPhone;

    /**
     * 支付方式 PAY_METHOD
     */
    @ApiModelProperty(value = "支付方式 PAY_METHOD")
    private String payMethod;

    /**
     * 配送方式
     */
    @ApiModelProperty(value = "配送方式")
    private String logisticsName;

    /**
     * 退款原因
     */
    @ApiModelProperty(value = "退款原因")
    private String refundReason;

    /**
     * 退款方式
     */
    @ApiModelProperty(value = "退款方式")
    private String refundMethod;
}
