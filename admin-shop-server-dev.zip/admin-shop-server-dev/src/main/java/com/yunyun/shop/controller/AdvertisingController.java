package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.entity.Advertising;
import com.yunyun.shop.api.pojo.vo.AdvertisingRequestVo;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.pojo.vo.UpdateState;
import com.yunyun.shop.api.service.AdvertisingService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-30 14:24
 */
@Api(tags = "广告管理")
@RequestMapping("/advertising")
@RestController
public class AdvertisingController {

    @Autowired
    private AdvertisingService advertisingService;

    /**
     * @description 条件查询广告列表
     * @auther PuYaDong
     * @date 2020-06-30 14:41
     * @param advertisingRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.Advertising>>
     */
    @ApiOperation("条件查询广告列表")
    @GetMapping("/find")
    public ResultBody<List<Advertising>> find(AdvertisingRequestVo advertisingRequestVo) {
        return ResultBody.ok(advertisingService.findAdvertising(advertisingRequestVo));
    }

    /**
     * @description 添加广告
     * @auther PuYaDong
     * @date 2020-06-30 14:41
     * @param advertising
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("添加广告")
    @PostMapping("/add")
    public ResultBody add(@RequestBody @Validated Advertising advertising) {
        return advertisingService.insert(advertising) > 0 ?
                ResultBody.ok().msg("添加成功") : ResultBody.failed("添加失败");
    }

    /**
     * @description 修改广告
     * @auther PuYaDong
     * @date 2020-06-30 14:41
     * @param advertising
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("修改广告")
    @PostMapping("/update")
    public ResultBody update(@RequestBody @Validated Advertising advertising) {
        return advertisingService.updateByPrimaryKey(advertising) > 0 ?
                ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * @description 修改广告显示隐藏
     * @auther PuYaDong
     * @date 2020-06-30 14:41
     * @param updateState
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("修改广告显示隐藏")
    @PostMapping("/updateAdState")
    public ResultBody updateAdState(@RequestBody @Validated UpdateState updateState) {
        return advertisingService.updateAdState(updateState.getId(),updateState.getState()) > 0 ?
                ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * @description 删除广告
     * @auther PuYaDong
     * @date 2020-06-30 14:41
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("删除广告")
    @PostMapping("/delete")
    public ResultBody delete(@RequestBody @Validated OperateIdVo operateIdVo) {
        return advertisingService.deleteByPrimaryKey(operateIdVo.getId()) > 0 ?
                ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }


}
