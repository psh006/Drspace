package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.entity.RefundAddress;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.service.RefundAddressService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description 售后退货地址接口
 * @createTime 2020-06-28 09:33
 */
@Api(tags = "售后退货地址")
@RequestMapping("/refundAddress")
@RestController
public class RefundAddressController {

    @Autowired
    private RefundAddressService refundAddressService;

    /**
     * @description 获取所有售后收货地址
     * @auther PuYaDong
     * @date 2020-06-28 09:39
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.awt.List>
     */
    @ApiOperation("获取所有售后收货地址")
    @GetMapping("/all")
    public ResultBody<List<RefundAddress>> all(){
        return ResultBody.ok(refundAddressService.all());
    }

    /**
     * @description 添加售后收货地址
     * @auther PuYaDong
     * @date 2020-06-28 09:58
     * @param refundAddress
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("添加售后收货地址")
    @PostMapping("/add")
    public ResultBody add(@RequestBody @Validated RefundAddress refundAddress){
        return refundAddressService.insert(refundAddress) > 0 ? ResultBody.ok().msg("添加成功"):ResultBody.failed("添加失败");
    }

    /**
     * @description 删除售后收货地址
     * @auther PuYaDong
     * @date 2020-06-28 11:02
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("删除售后收货地址")
    @PostMapping("/delete")
    public ResultBody delete(@RequestBody @Validated OperateIdVo operateIdVo){
        return refundAddressService.deleteByPrimaryKey(operateIdVo.getId()) > 0 ?
                ResultBody.ok().msg("删除成功"):ResultBody.failed("删除失败");
    }

}
