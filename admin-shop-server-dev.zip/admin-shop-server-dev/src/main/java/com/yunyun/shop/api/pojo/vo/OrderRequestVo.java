package com.yunyun.shop.api.pojo.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import springfox.documentation.annotations.ApiIgnore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-11 14:23
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderRequestVo extends PageParams implements Serializable {

    /**
     * 订单编号
     */
    @ApiModelProperty(value="订单编号")
    private String orderId;

    /**
     * 订单状态，ORDER_STATE
     */
    @ApiModelProperty(value="订单状态，ORDER_STATE",example = "")
    private Integer orderState;

    /**
     * 收货人姓名
     */
    @ApiModelProperty(value="收货人姓名，模糊查询")
    private String receiptName;

    /**
     * 收货电话
     */
    @ApiModelProperty(value="收货电话")
    private String receiptPhone;

    /**
     * 收货地址
     */
    @ApiModelProperty(value="收货地址，模糊查询")
    private String receiptAddress;

    /**
     * 物流公司编号
     */
    @ApiModelProperty(value="物流公司编号")
    private String logisticsId;

    /**
     * 客户姓名
     */
    @ApiModelProperty(value="客户姓名(模糊查询)")
    private String customerName;

    /**
     * 客户昵称
     */
    @ApiModelProperty(value="客户昵称(模糊查询)")
    private String customerNickName;

    /**
     * 客户电话
     */
    @ApiModelProperty(value="客户电话")
    private String customerPhone;

    /**
     * 是否删除，YES_NO（仅做软删除）
     */
    @ApiModelProperty(value="是否删除，YES_NO 1已删除 2未删除", example = "2")
    private Integer isDelete;

    private static final long serialVersionUID = 1L;
}
