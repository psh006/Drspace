package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.api.pojo.entity.RefundOrder;
import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author PuYaDong
 * @description 历史退款订单
 * @createTime 2020-06-28 17:13
 */
@Data
public class HistoryRefundOrderQuery extends PageParams implements Serializable {

    /**
     *订单编号
     */
    @ApiModelProperty(value = "订单编号")
    private String orderId;

    /**
     *退款状态
     */
    @ApiModelProperty(value = "退款状态")
    private Integer refundState;

    /**
     *退款方式
     */
    @ApiModelProperty(value = "退款方式")
    public Integer refundMethod;

    /**
     * 收货人姓名
     */
    @ApiModelProperty(value = "收货人姓名")
    public String receiptName;

    /**
     * 收货人手机号
     */
    @ApiModelProperty(value = "收货人手机号")
    public String receiptPhone;
}
