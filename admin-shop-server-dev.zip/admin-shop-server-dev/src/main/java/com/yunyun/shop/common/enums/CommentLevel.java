package com.yunyun.shop.common.enums;

public enum CommentLevel {
    FAVORABLE_COMMENTS(1,"好评"),
    MIDDLE_EVALUATION(2,"中评"),
    NEGATIVE_COMMENT(3,"差评");

    private int code;
    private String desc;

    CommentLevel(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
