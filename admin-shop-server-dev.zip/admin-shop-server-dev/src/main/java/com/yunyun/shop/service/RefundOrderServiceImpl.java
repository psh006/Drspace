package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.RefundOrderDetailDto;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.entity.PayRecord;
import com.yunyun.shop.api.pojo.entity.RefundOrder;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.api.pojo.vo.RefundOrderRequestVo;
import com.yunyun.shop.api.service.RefundOrderService;
import com.yunyun.shop.common.util.BeanConvertUtils;
import com.yunyun.shop.mapper.OrderDetailMapper;
import com.yunyun.shop.mapper.PayRecordMapper;
import com.yunyun.shop.mapper.RefundOrderMapper;
import com.yunyun.shop.mapper.RefundRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author lxl
 * @Classname RefundOrderServiceImpl
 * @Description TODO
 * @Date 2020/6/19 16:27
 */
@Service
public class RefundOrderServiceImpl implements RefundOrderService {

    @Autowired
    private RefundOrderMapper refundOrderMapper;

    @Autowired
    private OrderDetailMapper orderDetailMapper;

    @Autowired
    private RefundRecordMapper refundRecordMapper;

    @Autowired
    private PayRecordMapper payRecordMapper;


    /**
     * @Description: 查询退款订单
     * @params: [refundOrderRequestVo]
     * @return: java.util.List<com.yunyun.shop.api.pojo.entity.RefundOrder>
     * @Author: lxl
     * @Date : 2020/6/19 16:29
     */
    @Override
    public PageInfo<RefundOrder> queryRefundOrder(RefundOrderRequestVo refundOrderRequestVo) {
        //查询出子订单状态为退款中的订单
        List<RefundOrder> refundOrderList = refundOrderMapper.queryRefundOrdering();
        if (refundOrderList.isEmpty()) {
            return new PageInfo<>();
        }
        //取出子订单编号列表
        List<String> orderDetailIds =
                refundOrderList.stream().map(RefundOrder::getOrderDetailId).collect(Collectors.toList());

        refundOrderRequestVo.setOrderDetailIds(orderDetailIds);
        PageHelper.startPage(refundOrderRequestVo.getPage(), refundOrderRequestVo.getLimit());
        //查询退款订单
        List<RefundOrder> refundOrders = refundOrderMapper.queryRefundOrder(refundOrderRequestVo);
        for (RefundOrder refundOrder : refundOrderList) {
            for (RefundOrder order : refundOrders) {
                if (refundOrder.getOrderDetailId().equals(order.getOrderDetailId())) {
                    order.setDetailPayAmountReal(refundOrder.getDetailPayAmountReal());
                    order.setDetailGoodsAmount(refundOrder.getDetailGoodsAmount());
                    order.setGoodsSpec(refundOrder.getGoodsSpec());
                    order.setDetailFreightAmount(refundOrder.getDetailFreightAmount());
                    order.setOrderDetailAmount(refundOrder.getOrderDetailAmount());
                    order.setGoodsCover(refundOrder.getGoodsCover());
                    order.setGoodsName(refundOrder.getGoodsName());
                    order.setPayMethod(refundOrder.getPayMethod());
                }
            }
        }
        return new PageInfo<>(refundOrders);
    }

    @Override
    public RefundOrderDetailDto queryRefundOrderDetail(String orderDetailId) {
        OrderDetail orderDetail = orderDetailMapper.selectByPrimaryKey(orderDetailId);
        RefundOrderDetailDto refundOrderDetailDto = BeanConvertUtils.convertBean(orderDetail, RefundOrderDetailDto.class);
        String refundId = refundOrderDetailDto.getRefundId();
        String payId = refundOrderDetailDto.getPayId();
        //退款详情
        if (refundId != null) {
            RefundRecord refundRecord = refundRecordMapper.selectByPrimaryKey(refundId);
            refundOrderDetailDto.setRefundRecord(refundRecord);
        }
        //支付详情
        if (payId != null){
            PayRecord payRecord = payRecordMapper.selectByPrimaryKey(payId);
            refundOrderDetailDto.setPayRecord(payRecord);
        }
        return refundOrderDetailDto;
    }

}
