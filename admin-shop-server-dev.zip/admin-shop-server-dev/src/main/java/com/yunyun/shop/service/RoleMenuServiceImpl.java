package com.yunyun.shop.service;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.api.pojo.entity.RoleMenu;
import com.yunyun.shop.mapper.RoleMenuMapper;
import com.yunyun.shop.api.service.RoleMenuService;
/**
 *
 * @Classname RoleMenuServiceImpl
 * @Description TODO
 * @Date 2020/6/24 10:33
 * @author lxl
 */
@Service
public class RoleMenuServiceImpl implements RoleMenuService{

    @Resource
    private RoleMenuMapper roleMenuMapper;

    @Override
    public int deleteByPrimaryKey(String roleId) {
        return roleMenuMapper.deleteByPrimaryKey(roleId);
    }

    @Override
    public int insert(RoleMenu record) {
        return roleMenuMapper.insert(record);
    }

}
