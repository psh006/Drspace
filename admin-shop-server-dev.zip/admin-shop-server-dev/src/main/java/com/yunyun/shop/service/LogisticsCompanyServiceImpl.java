package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.vo.LogisticsRequestVo;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import javax.validation.constraints.NotBlank;

import com.yunyun.shop.api.pojo.entity.LogisticsCompany;
import com.yunyun.shop.mapper.LogisticsCompanyMapper;
import com.yunyun.shop.api.service.LogisticsCompanyService;

import java.util.Date;
import java.util.List;

@Service
public class LogisticsCompanyServiceImpl implements LogisticsCompanyService {

    @Resource
    private LogisticsCompanyMapper logisticsCompanyMapper;

    @Override
    public int deleteByPrimaryKey(String logisticsId) {
        return logisticsCompanyMapper.deleteByPrimaryKey(logisticsId);
    }

    @Override
    public ResultBody insert(LogisticsCompany logisticsCompany) {
        //判断物流公司是否已存在
        String logisticsCode = logisticsCompany.getLogisticsCode();
        String logisticsName = logisticsCompany.getLogisticsName();
        LogisticsRequestVo logisticsRequestVo = new LogisticsRequestVo();
        logisticsRequestVo.setLogisticsName(logisticsName);
        List<LogisticsCompany> logisticsCompanies = logisticsCompanyMapper.queryLogisticsExist(logisticsRequestVo);
        if (logisticsCompanies != null && !logisticsCompanies.isEmpty()){
            return ResultBody.failed("请检查物流公司名称是否已重复");
        }
        logisticsRequestVo.setLogisticsName(null);
        logisticsRequestVo.setLogisticsCode(logisticsCode);
        logisticsCompanies = logisticsCompanyMapper.queryLogisticsExist(logisticsRequestVo);
        if (logisticsCompanies != null && !logisticsCompanies.isEmpty()){
            return ResultBody.failed("请检查物流公司代码是否已重复");
        }
        //执行添加操作
        String idStr = IdWorker.getIdStr();
        logisticsCompany.setLogisticsId(idStr);
        EmpUserDetail user = AuthHelper.getUser();
        logisticsCompany.setOperateId(user.getEmpId());
        logisticsCompany.setOperateName(user.getEmpName());
        logisticsCompany.setOperateTime(new Date());
        int i = logisticsCompanyMapper.insert(logisticsCompany);
        return i>0? ResultBody.ok().msg("添加成功"):ResultBody.failed("添加失败");
    }

    @Override
    public LogisticsCompany selectByPrimaryKey(String logisticsId) {
        return logisticsCompanyMapper.selectByPrimaryKey(logisticsId);
    }

    @Override
    public ResultBody updateByPrimaryKey(LogisticsCompany logisticsCompany) {
        //判断物流公司是否已存在
        String logisticsId = logisticsCompany.getLogisticsId();
        String logisticsCode = logisticsCompany.getLogisticsCode();
        String logisticsName = logisticsCompany.getLogisticsName();
        LogisticsRequestVo logisticsRequestVo = new LogisticsRequestVo();
        logisticsRequestVo.setLogisticsName(logisticsName);
        logisticsRequestVo.setLogisticsId(logisticsId);
        List<LogisticsCompany> logisticsCompanies = logisticsCompanyMapper.queryLogisticsExist(logisticsRequestVo);
        if (logisticsCompanies != null && !logisticsCompanies.isEmpty()){
            return ResultBody.failed("请检查物流公司名称是否已重复");
        }
        logisticsRequestVo.setLogisticsName(null);
        logisticsRequestVo.setLogisticsCode(logisticsCode);
        logisticsCompanies = logisticsCompanyMapper.queryLogisticsExist(logisticsRequestVo);
        if (logisticsCompanies != null && !logisticsCompanies.isEmpty()){
            return ResultBody.failed("请检查物流公司代码是否已重复");
        }
        int update = logisticsCompanyMapper.updateByPrimaryKey(logisticsCompany);
        return update>0?ResultBody.ok().msg("修改成功"):ResultBody.failed("修改成功");
    }

    @Override
    public List<LogisticsCompany> find() {
        return logisticsCompanyMapper.find();
    }

    @Override
    public List<LogisticsCompany> queryLogisticsCompany(LogisticsRequestVo logisticsRequestVo) {
        return logisticsCompanyMapper.queryLogisticsCompany(logisticsRequestVo);
    }
}

