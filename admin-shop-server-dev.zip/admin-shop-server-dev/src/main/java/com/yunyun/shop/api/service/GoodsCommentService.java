package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.CommentsInfo;
import com.yunyun.shop.api.pojo.entity.GoodsComment;
import com.yunyun.shop.api.pojo.dto.GoodsCommentDTO;
import com.yunyun.shop.api.pojo.vo.GoodsCommentRequestVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *
 * @Classname GoodsCommentService
 * @Description TODO
 * @Date 2020/6/15 9:34
 * @author lxl
 */
public interface GoodsCommentService{


    int deleteByPrimaryKey(String commentId);

    int insert(GoodsComment record);

    GoodsComment selectByPrimaryKey(String commentId);

    int updateByPrimaryKey(GoodsComment record);

    PageInfo<GoodsCommentDTO> queryComment(GoodsCommentRequestVo goodsCommentRequestVo);

    PageInfo<CommentsInfo> queryCommentsInfo(GoodsCommentRequestVo goodsCommentRequestVo);

    int updateIsTop(@Param("commentId") String commentId);

    int updateNoTop(@Param("commentId") String commentId);

    int updateIsDeleteMany(@Param("commentIds") List<String> commentIds);

    int updateNoDeleteMany(@Param("commentIds") List<String> commentIds);

    int deleteManyComments(@Param("commentIds") List<String> commentIds);

    PageInfo<CommentsInfo> queryCommentsIsDelete(GoodsCommentRequestVo goodsCommentRequestVo);
    }
