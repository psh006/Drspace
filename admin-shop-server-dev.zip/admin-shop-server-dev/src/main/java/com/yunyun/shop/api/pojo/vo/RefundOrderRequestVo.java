package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * @author lxl
 * @Classname RefundOrderRequestVo
 * @Description TODO
 * @Date 2020/6/19 14:57
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class RefundOrderRequestVo extends PageParams  implements Serializable {
    /**
     *订单编号
     */
    @ApiModelProperty(value = "订单编号")
    private String orderId;

    /**
     *退款状态
     */
    @ApiModelProperty(value = "退款状态")
    private Integer refundState;

    /**
     *退款方式
     */
    @ApiModelProperty(value = "退款方式")
    public Integer refundMethod;

    /**
     *姓名
     */
    @ApiModelProperty(value = "姓名")
    public String customerName;

    /**
     *手机号
     */
    @ApiModelProperty(value = "手机号")
    public String customerPhone;

    /**
     * 子订单编号列表
     */
    @ApiModelProperty(value = "子订单编号列表")
    public List<String> orderDetailIds;

}
