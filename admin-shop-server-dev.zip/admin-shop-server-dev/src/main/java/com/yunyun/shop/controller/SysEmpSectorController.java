package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.entity.EmpSector;
import com.yunyun.shop.api.service.EmpSectorService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author PuYaDong
 * @description 部门接口
 * @createTime 2020-06-24 10:18
 */
@Api(tags = "部门接口")
@RestController
@RequestMapping("/sysSector")
public class SysEmpSectorController {

    @Autowired
    private EmpSectorService empSectorService;

    /**
     * @description 查询部门列表
     * @auther PuYaDong
     * @date 2020-06-24 10:28
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.EmpSector>>
     */
    @ApiOperation("查询部门列表")
    @GetMapping("/list")
    public ResultBody<List<EmpSector>> list(){
        return ResultBody.ok(empSectorService.list());
    }
}
