package com.yunyun.shop.api.service;

import java.util.List;


import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.api.pojo.vo.SysRoleRequestVo;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-12 10:37
 */
public interface SysRoleService {


    int deleteByPrimaryKey(String roleId);

    int insert(SysRole record);

    SysRole selectByPrimaryKey(String roleId);

    int updateByPrimaryKey(SysRole record);


    List<SysRole> queryUserRoles(String userId);

    PageInfo<SysRole> selectRoles(SysRoleRequestVo sysRoleRequestVo);

    int deleteRole(SysRoleRequestVo sysRoleRequestVo);

     int roleAndMenu(SysRoleRequestVo sysRoleRequestVo);

}

