package com.yunyun.shop.common.enums;

public enum GoodsProperty {
    //热卖
    BEST_SELLERS(1,"热卖"),
    //折扣
    DISCOUNT(2,"折扣");

    private int code;
    private String desc;

    GoodsProperty(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
