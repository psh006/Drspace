package com.yunyun.shop.common.enums;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.common.enums
 * @createTime 2020-06-12 10:19
 */
public enum UserState {
    NORMAL(1), DISABLE(2), TO_BE_REVIEWED(3);
    private final int value;

    private UserState(int value) {
        this.value = value;
    }

    public static UserState valueOf(int value) {
        switch (value) {
            case 1:
                return NORMAL;
            case 2:
                return DISABLE;
            case 3:
                return TO_BE_REVIEWED;
            default:
                return TO_BE_REVIEWED;
        }
    }

    public int getValue() {
        return value;
    }
}
