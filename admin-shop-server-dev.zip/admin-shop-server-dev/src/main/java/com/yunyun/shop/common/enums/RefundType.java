package com.yunyun.shop.common.enums;

public enum RefundType {
    //仅退款
    REFUND_ONLY(1,"仅退款"),
    //退款退货
    REFUND_RETURN(2,"退款退货");

    private int code;
    private String desc;

    RefundType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
