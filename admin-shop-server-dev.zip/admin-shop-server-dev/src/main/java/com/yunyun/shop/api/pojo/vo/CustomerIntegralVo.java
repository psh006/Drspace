package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @program: shop
 * @description: 积分管理
 * @author: CheGuangQuan
 * @create: 2020-07-01 11:09
 **/
@Data
public class CustomerIntegralVo {
    @ApiModelProperty(value = "途径")
    private int integralRecordType;

    @ApiModelProperty(value = "积分变动数值")
    private int integralValue;

    @ApiModelProperty(value = "剩余可用积分")
    private int integralBalance;

    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    @ApiModelProperty(value="昵称")
    private String customerNickName;

    @ApiModelProperty(value="姓名")
    private String customerName;

    @ApiModelProperty(value="手机号")
    private String customerPhone;

    @ApiModelProperty(value="客户等级编号")
    private String customerLevelId;

    @ApiModelProperty(value="客户等级名称")
    private String customerLevelName;
}