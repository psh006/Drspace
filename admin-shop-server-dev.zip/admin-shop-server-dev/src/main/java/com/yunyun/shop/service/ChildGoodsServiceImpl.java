package com.yunyun.shop.service;

import cn.hutool.crypto.SecureUtil;
import com.yunyun.shop.api.pojo.entity.ChildGoods;
import com.yunyun.shop.api.pojo.entity.ParentGoods;
import com.yunyun.shop.api.service.ParentGoodsService;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import com.yunyun.shop.mapper.ChildGoodsMapper;
import com.yunyun.shop.api.service.ChildGoodsService;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.service
 * @createTime 2020-06-16 11:02
 */
@Transactional(rollbackFor = Exception.class)
@Service
public class ChildGoodsServiceImpl implements ChildGoodsService {

    @Resource
    private ChildGoodsMapper childGoodsMapper;

    @Lazy
    @Autowired
    private ParentGoodsService parentGoodsService;

    @Override
    public int deleteByPrimaryKey(String goodsId) {
        return childGoodsMapper.deleteByPrimaryKey(goodsId);
    }

    @Override
    public int insert(ChildGoods record) {
        // 存子商品
        int isUpdate = childGoodsMapper.insert(record);
        refreshParentGoods(record.getParentGoodsId());
        return isUpdate;
    }

    @Override
    public int updateByPrimaryKey(ChildGoods record) {
        int isInsert = childGoodsMapper.updateByPrimaryKey(record);
        refreshParentGoods(record.getParentGoodsId());
        return isInsert;
    }

    /**
     * @param parentGoodsId
     * @return void
     * @description 刷新主商品信息
     * @auther PuYaDong
     * @date 2020-06-16 18:01
     */
    private void refreshParentGoods(String parentGoodsId) {
        // 更新主商品信息
        ParentGoods parentGoods = parentGoodsService.selectByPrimaryKey(parentGoodsId);
        List<ChildGoods> childGoodsList = childGoodsMapper
                .queryChildGoodsByParentGoodsId(parentGoodsId);
        if (childGoodsList.size() > 0) {
            // 库存总和
            int sumStock = childGoodsList.stream()
                    .parallel()
                    .filter(goods -> goods.getGoodsStock() != null)
                    .mapToInt(ChildGoods::getGoodsStock)
                    .sum();
            // 最低价格
            OptionalDouble minPrice = childGoodsList.stream()
                    .parallel()
                    .filter(goods -> goods.getGoodsPrice() != null)
                    .mapToDouble(goods -> goods.getGoodsPrice().doubleValue())
                    .filter(goodsPrice -> goodsPrice != 0)
                    .min();
            // 最高价格
            OptionalDouble maxPrice = childGoodsList.stream()
                    .parallel()
                    .filter(goods -> goods.getGoodsPrice() != null)
                    .mapToDouble(goods -> goods.getGoodsPrice().doubleValue())
                    .filter(goodsPrice -> goodsPrice != 0)
                    .max();
            parentGoods.setGoodsStockSum(sumStock);
            parentGoods.setGoodsPriceMin(BigDecimal.valueOf(minPrice.orElse(0)));
            parentGoods.setGoodsPriceMax(BigDecimal.valueOf(maxPrice.orElse(0)));
            parentGoodsService.refreshParentGoods(parentGoods);
        }
    }

    /**
     * @param parentGoodsId
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.ChildGoods>
     * @description 根据主商品查询所有子商品
     * @auther PuYaDong
     * @date 2020-06-16 15:26
     */
    @Override
    public List<ChildGoods> queryGoodsStock(String parentGoodsId) {
        return childGoodsMapper.queryGoodsStock(parentGoodsId);
    }

    /**
     * @param parentGoodsId
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.ChildGoods>
     * @description 根据主商品查询所有子商品
     * @auther PuYaDong
     * @date 2020-06-16 15:26
     */
    @Override
    public List<ChildGoods> queryChildGoodsByParentGoodsId(String parentGoodsId) {
        return childGoodsMapper.queryChildGoodsByParentGoodsId(parentGoodsId);
    }

    /**
     * @param childGoodsList
     * @return int
     * @description 批量添加子物品
     * @auther PuYaDong
     * @date 2020-06-17 10:34
     */
    @Override
    public int batchInsert(List<ChildGoods> childGoodsList) {
        String parentGoodsId = childGoodsList.get(0).getParentGoodsId();
        ParentGoods parentGoods = parentGoodsService.selectByPrimaryKey(parentGoodsId);
        if(parentGoods == null){
            throw new AlertException("添加失败，主物品不存在");
        }
        childGoodsList = childGoodsList.stream()
                .parallel()
                .peek(childGoods -> {
                    childGoods.setGoodsCategoryId(parentGoods.getGoodsCategoryId());
                    childGoods.setGoodsCategoryName(parentGoods.getGoodsCategoryName());
                    childGoods.setGoodsId(IdWorker.getIdStr());
                    childGoods.setGoodsSpecMd5(SecureUtil.md5(childGoods.getGoodsSpec()));
                    childGoods.setOperateId(AuthHelper.getUserId());
                    childGoods.setOperateName(AuthHelper.getUser().getEmpName());
                    childGoods.setOperateTime(new Date());
                }).collect(Collectors.toList());
        int isInsert = childGoodsMapper.batchInsert(childGoodsList);
        // 刷新主商品信息
        refreshParentGoods(childGoodsList.get(0).getParentGoodsId());
        return isInsert;
    }

    /**
     * @param childGoodsList
     * @return int
     * @description 编辑添加子物品
     * @auther PuYaDong
     * @date 2020-06-17 10:35
     */
    @Override
    public int updateBatch(List<ChildGoods> childGoodsList) {
        String parentGoodsId = childGoodsList.get(0).getParentGoodsId();
        ParentGoods parentGoods = parentGoodsService.selectByPrimaryKey(parentGoodsId);
        if(parentGoods == null){
            throw new AlertException("编辑失败，主物品不存在");
        }
        childGoodsList = childGoodsList.stream()
                .parallel()
                .peek(childGoods -> {
                    childGoods.setGoodsCategoryId(parentGoods.getGoodsCategoryId());
                    childGoods.setGoodsCategoryName(parentGoods.getGoodsCategoryName());
                }).collect(Collectors.toList());

        int isUpdate = childGoodsMapper.updateBatch(childGoodsList);
        // 刷新主物品信息
        refreshParentGoods(childGoodsList.get(0).getParentGoodsId());
        return isUpdate;
    }

    /**
     * @description 根据主物品id删除子物品
     * @auther PuYaDong
     * @date 2020-06-23 15:45
     * @param parentGoodsId
     * @return int
     */
    @Override
    public int deleteByParentGoodsId(String parentGoodsId) {
        return childGoodsMapper.deleteByParentGoodsId(parentGoodsId);
    }
}

