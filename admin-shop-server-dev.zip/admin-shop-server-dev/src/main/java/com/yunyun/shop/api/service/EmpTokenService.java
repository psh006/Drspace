package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.EmpToken;
import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-12 09:57
 */
public interface EmpTokenService {

    int insert(EmpToken record);

    EmpToken selectByPrimaryKey(String empId, Integer loginType);

    void deleteByEmpIdAndLoginType(String empId, Integer loginType);

    /**
     * @description 删除员工所有token
     * @auther PuYaDong
     * @date 2020-06-24 13:09
     * @param empId
     * @return int
     */
    int deleteByEmpId(String empId);
}

