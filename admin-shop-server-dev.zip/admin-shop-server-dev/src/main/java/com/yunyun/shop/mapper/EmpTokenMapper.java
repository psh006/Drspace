package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.EmpToken;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-12 15:55
 */
public interface EmpTokenMapper {
    int deleteByPrimaryKey(@Param("empId") String empId, @Param("loginType") Integer loginType);

    int insert(EmpToken record);

    EmpToken selectByPrimaryKey(@Param("empId") String empId, @Param("loginType") Integer loginType);

    int deleteByEmpId(String empId);
}