package com.yunyun.shop.api.service;

import java.util.List;
import com.yunyun.shop.api.pojo.entity.PayRecord;
public interface PayRecordService{


    int deleteByPrimaryKey(String payId);

    int insert(PayRecord record);

    PayRecord selectByPrimaryKey(String payId);

    int updateByPrimaryKey(PayRecord record);

    int updateBatch(List<PayRecord> list);

    int batchInsert(List<PayRecord> list);

}
