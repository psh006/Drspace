package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.Message;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-13 17:24
 */
public interface MessageService {

    void add();
}
