package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.GoodsCategory;
import com.yunyun.shop.api.pojo.vo.GoodsCategoryResultVo;
import com.yunyun.shop.common.model.ResultBody;

import java.util.List;

public interface GoodsCategoryService{


    int deleteByPrimaryKey(String goodsCategoryId);

    ResultBody insert(GoodsCategory goodsCategory);

    GoodsCategory selectByPrimaryKey(String goodsCategoryId);

    ResultBody updateByPrimaryKey(GoodsCategory record);

    /**
     * 显示/隐藏商品分类
     * @auther CheGuangQuan
     * @date 2020/6/15 15:39
     * @param goodsCategoryList
     * @return int
    */
    int showGoodsCategory(int isDisplay,List<String> goodsCategoryList);

    /**
     * 查询所有分类
     * @auther CheGuangQuan
     * @date 2020/6/15
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.vo.GoodsCategoryResultVo>
    */
    List<GoodsCategoryResultVo> queryGoodsCategoryList();

    /**
     * 批量删除分类
     * @auther CheGuangQuan
     * @date 2020/6/17 15:33
     * @param goodsCategoryList
     * @return int
    */
    int deleteGoodsCategory(List<String> goodsCategoryList);
}
