package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.CustomerIntegralDto;
import com.yunyun.shop.api.pojo.vo.CustomerIntegralVo;
import com.yunyun.shop.api.pojo.vo.IntegralRecordRequestVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.yunyun.shop.api.pojo.entity.CustomerIntegral;
import com.yunyun.shop.mapper.CustomerIntegralMapper;
import com.yunyun.shop.api.service.CustomerIntegralService;
@Service
public class CustomerIntegralServiceImpl implements CustomerIntegralService{

    @Resource
    private CustomerIntegralMapper customerIntegralMapper;

    @Override
    public int deleteByPrimaryKey(String recordId) {
        return customerIntegralMapper.deleteByPrimaryKey(recordId);
    }

    @Override
    public int insert(CustomerIntegral record) {
        return customerIntegralMapper.insert(record);
    }

    @Override
    public CustomerIntegral selectByPrimaryKey(String recordId) {
        return customerIntegralMapper.selectByPrimaryKey(recordId);
    }

    @Override
    public int updateByPrimaryKey(CustomerIntegral record) {
        return customerIntegralMapper.updateByPrimaryKey(record);
    }

    @Override
    public int updateBatch(List<CustomerIntegral> list) {
        return customerIntegralMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<CustomerIntegral> list) {
        return customerIntegralMapper.batchInsert(list);
    }

    @Override
    public PageInfo<CustomerIntegralVo> selectList(CustomerIntegralDto customerIntegralDto) {
        PageHelper.startPage(customerIntegralDto.getPage(),customerIntegralDto.getLimit());
        List<CustomerIntegralVo> customerIntegralVoList = customerIntegralMapper.selectList(customerIntegralDto);
        return new PageInfo<>(customerIntegralVoList);
    }

    /**
     * @param integralRecordRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.CustomerIntegral>
     * @description 分页查询客户的积分记录
     * @auther PuYaDong
     * @date 2020-07-03 15:59
     */
    @Override
    public PageInfo<CustomerIntegral> queryCustomerIntegralRecord(IntegralRecordRequestVo integralRecordRequestVo) {
        PageHelper.startPage(integralRecordRequestVo.getPage(),integralRecordRequestVo.getLimit());
        List<CustomerIntegral> list = customerIntegralMapper.selectByCustomerId(integralRecordRequestVo.getCustomerId());
        return new PageInfo<>(list);
    }

}
