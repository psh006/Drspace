package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.vo.EmpRequestVo;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.pojo.vo.UpdateStateVo;

import java.util.Date;
import java.util.List;

public interface EmpBaseService {

    /**
     * @description 删除员工
     * @auther PuYaDong
     * @date 2020-06-24 13:06
     * @param empId
     * @return int
     */
    int deleteByPrimaryKey(String empId);

    int insert(EmpBase record);

    EmpBase selectByPrimaryKey(String empId);

    int updateByPrimaryKey(EmpBase record);

    int updateBatch(List<EmpBase> list);

    int batchInsert(List<EmpBase> list);

    EmpBase login(String loginCode);

    /**
     * @description 员工分页搜索列表
     * @auther PuYaDong
     * @date 2020-06-19 16:27
     * @param empRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.EmpBase>
     */
    PageInfo<EmpBase> findEmpListPage(EmpRequestVo empRequestVo);

    /**
     * @description 添加员工信息
     * @auther PuYaDong
     * @date 2020-06-19 16:55
     * @param empBase
     * @return int
     */
    int add(EmpBase empBase);

    /**
     * @description 修改员工信息
     * @auther PuYaDong
     * @date 2020-06-19 16:55
     * @param empBase
     * @return int
     */
    int update(EmpBase empBase);

    /**
     * @description 修改状态
     * @auther PuYaDong
     * @date 2020-06-24 10:04
     * @param updateStateVo
     * @return int
     */
    int updateState(UpdateStateVo updateStateVo);

    /**
     * @description 重置密码
     * @auther PuYaDong
     * @date 2020-06-24 10:04
     * @param operateIdVo
     * @return int
     */
    int resetPassword(OperateIdVo operateIdVo);

    /**
     * @description 更新最后一次登录时间
     * @auther PuYaDong
     * @date 2020-06-24 12:09
     * @param empId
     * @return int
     */
    int refreshLastLoginTime(String empId);

    /**
     * @description 登录账号是否存在，排除自己
     * @auther PuYaDong
     * @date 2020-06-29 14:02
     * @param empBase
     * @return boolean true-已存在 false-不存在
     */
    boolean isLoginCodeExist(EmpBase empBase);
}

