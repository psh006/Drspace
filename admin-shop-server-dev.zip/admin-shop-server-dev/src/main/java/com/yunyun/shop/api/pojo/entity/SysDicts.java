package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.List;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

/**
 * @description 数据字典表
 * @author PuYaDong
 * @createTime 2020-06-13 15:35
 */
@ApiModel(value="数据字典表")
@Data
public class SysDicts implements Serializable {
    /**
    * 字典编号
    */
    @NotBlank(groups = {Update.class}, message = "字典编号不能为空")
    @ApiModelProperty(value="字典编号")
    private String dictId;

    /**
    * 字典标识
    */
    @Length(min = 1, max = 20, message = "字典标识长度须在1~20个字之间")
    @ApiModelProperty(value="字典标识")
    private String dictCode;

    /**
    * 字典名称
    */
    @Length(min = 1, max = 20, message = "字典名称长度须在1~20个字之间")
    @ApiModelProperty(value="字典名称")
    private String dictName;

    /**
    * 备注
    */
    @Max(value = 150, message = "备注不能超过150字")
    @ApiModelProperty(value="备注")
    private String dictNote;

    /**
     * 字典子项
     */
    @ApiModelProperty(value="字典子项", readOnly = true)
    private List<SysDictItems> dictItems;

    private static final long serialVersionUID = 1L;
}