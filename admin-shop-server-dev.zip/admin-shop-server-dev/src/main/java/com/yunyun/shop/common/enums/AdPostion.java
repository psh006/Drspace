package com.yunyun.shop.common.enums;

public enum AdPostion {
    //首页
    HOME_PAGE(1,"首页"),
    //商城
    SHOPPING_MALL(2,"商城");

    private int code;
    private String desc;

    AdPostion(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
