package com.yunyun.shop.common.enums;

import javax.print.DocFlavor;

public enum MessageState {
    //未读
    UNREAD(1,"未读"),
    //已读
    READ(2,"已读");
    private int code;
    private String desc;

    MessageState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
