package com.yunyun.shop.controller;

import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.UploadUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author zzd
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-22 10:02
 */
@Api(tags = "图片上传")
@RestController
@RequestMapping("/uploadFile")
public class UploadController {

    @Value("${file.path}")
    private String dirPath;

    /**
     * @description 图片上传
     * @auther zzd
     * @date 2020-06-22 10:17
     * @param file
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("图片上传")
    @PostMapping("/uploadImg")
    public ResultBody<String> uploadImg(@RequestBody MultipartFile file) throws IOException {
        Boolean img = UploadUtil.checkImg(file);
        if (img){
            return ResultBody.ok(UploadUtil.upload(file,dirPath));
        }else {
            return ResultBody.failed("请上传bmp/gif/jpg/png格式的图片");
        }
    }

    /**
     * @description deleteFile
     * @auther PuYaDong
     * @date 2020-07-01 11:33
     * @param url
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("图片删除")
    @GetMapping("/deleteImg")
    public ResultBody deleteFile( String url){
        Boolean aBoolean = UploadUtil.deleteFile(dirPath, url);
        return aBoolean ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }

    /**
     * @description 图片下载(预留)
     * @auther PuYaDong
     * @date 2020-07-01 11:33
     * @param url
     * @param response
     * @return void
     */
    @ApiOperation("图片下载(预留)")
    @GetMapping("/downloadImg")
    public void downloadFile(String url, HttpServletResponse response) throws IOException{
        UploadUtil.download(url,response);
    }
}
