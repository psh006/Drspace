package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
    * 商品表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-GoodsBase")
@Data
public class GoodsBase implements Serializable {
    /**
    * 商品编号
    */
    @ApiModelProperty(value="商品编号")
    private String goodsId;

    /**
    * 商品名称
    */
    @ApiModelProperty(value="商品名称")
    private String goodsName;

    /**
    * 商品描述
    */
    @ApiModelProperty(value="商品描述")
    private String goodsDescription;

    /**
    * 关联商品类别编号
    */
    @ApiModelProperty(value="关联商品类别编号")
    private String goodsCategoryId;

    /**
    * 关联商品类别名称
    */
    @ApiModelProperty(value="关联商品类别名称")
    private String goodsCategoryName;

    /**
    * 关联主商品编号
    */
    @ApiModelProperty(value="关联主商品编号")
    private String parentGoodsId;

    /**
    * 商品规格，json字符串
    */
    @ApiModelProperty(value="商品规格，json字符串")
    private String goodsSpec;

    /**
    * 单价
    */
    @ApiModelProperty(value="单价")
    private BigDecimal goodsPrice;

    /**
    * 库存
    */
    @ApiModelProperty(value="库存")
    private Integer goodsStock;

    /**
    * 库存预警触发条件，INT
    */
    @ApiModelProperty(value="库存预警触发条件，INT")
    private Integer goodsStockWarn;

    /**
    * 单件重量
    */
    @ApiModelProperty(value="单件重量")
    private BigDecimal goodsWeight;

    /**
    * 单件体积
    */
    @ApiModelProperty(value="单件体积")
    private BigDecimal goodsVolume;

    /**
    * 商品封面
    */
    @ApiModelProperty(value="商品封面")
    private String goodsCover;

    /**
    * 商品图片，多个以逗号隔开
    */
    @ApiModelProperty(value="商品图片，多个以逗号隔开")
    private String goodsImage;

    /**
    * 上架状态，PUT_STATE（PUT_UP,PUT_DOWN）
    */
    @ApiModelProperty(value="上架状态，PUT_STATE（PUT_UP,PUT_DOWN）")
    private Integer putState;

    /**
    * 上架时间
    */
    @ApiModelProperty(value="上架时间")
    private Date putTime;

    /**
    * 商品属性，GOODS_PROPERTY
    */
    @ApiModelProperty(value="商品属性，GOODS_PROPERTY")
    private Integer goodsProperty;

    /**
    * 是否包邮，YES_NO
    */
    @ApiModelProperty(value="是否包邮，YES_NO")
    private Integer isPinkage;

    /**
    * 可发快递编号，多个用逗号隔开
    */
    @ApiModelProperty(value="可发快递编号，多个用逗号隔开")
    private String goodsLogistics;

    /**
    * 是否可退款，YES_NO
    */
    @ApiModelProperty(value="是否可退款，YES_NO")
    private Integer isCanRefund;

    /**
    * 运费模板编号
    */
    @ApiModelProperty(value="运费模板编号")
    private String freightTemplateId;

    /**
    * 商品详情
    */
    @ApiModelProperty(value="商品详情")
    private String goodsDetail;

    /**
    * 商品参数
    */
    @ApiModelProperty(value="商品参数")
    private String goodsParams;

    /**
    * 真实销量
    */
    @ApiModelProperty(value="真实销量")
    private Integer salesVolumeReal;

    /**
    * 起始销量
    */
    @ApiModelProperty(value="起始销量")
    private Integer salesVolumeStart;

    /**
    * 虚拟销量
    */
    @ApiModelProperty(value="虚拟销量")
    private Integer salesVolumeVirtual;

    /**
    * 是否在WEB商城显示，YES_NO
    */
    @ApiModelProperty(value="是否在WEB商城显示，YES_NO")
    private Integer isShowWeb;

    /**
    * 是否在APP商城显示，YES_NO
    */
    @ApiModelProperty(value="是否在APP商城显示，YES_NO")
    private Integer isShowApp;

    /**
    * 是否在公众号/小程序商城显示，YES_NO
    */
    @ApiModelProperty(value="是否在公众号/小程序商城显示，YES_NO")
    private Integer isShowWechat;

    /**
    * 是否删除，YES_NO（删除后将进入到回收站）
    */
    @ApiModelProperty(value="是否删除，YES_NO（删除后将进入到回收站）")
    private Integer isDelete;

    /**
    * 删除时间
    */
    @ApiModelProperty(value="删除时间")
    private Date deleteTime;

    /**
    * 操作人id
    */
    @ApiModelProperty(value="操作人id")
    private String operateId;

    /**
    * 操作人姓名
    */
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 修改时间
    */
    @ApiModelProperty(value="修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}