package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
 *
 * @Classname RoleMenu
 * @Description TODO
 * @Date 2020/6/24 10:33
 * @author lxl
 */
/**
    * 角色菜单关联表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-RoleMenu")
@Data
public class RoleMenu implements Serializable {
    /**
    * 角色编号
    */
    @ApiModelProperty(value="角色编号")
    private String roleId;

    /**
    * 菜单编号
    */
    @ApiModelProperty(value="菜单编号")
    private String menuId;

    private static final long serialVersionUID = 1L;
}