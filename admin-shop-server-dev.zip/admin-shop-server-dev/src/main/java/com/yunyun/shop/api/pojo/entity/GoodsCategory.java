package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
    * 商品类别表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-GoodsCategory")
@Data
public class GoodsCategory implements Serializable {
    /**
    * 类别编号
    */
    @ApiModelProperty(value="类别编号")
    private String goodsCategoryId;

    /**
    * 类别名称
    */
    @ApiModelProperty(value="类别名称")
    private String goodsCategoryName;

    /**
    * 图标
    */
    @ApiModelProperty(value="图标")
    private String goodsCategoryIcon;

    /**
    * 排序
    */
    @ApiModelProperty(value="排序")
    private Integer sort;

    /**
    * 是否枝叶 YES_NO 1是2否
    */
    @ApiModelProperty(value="是否枝叶 YES_NO 1是2否")
    private Integer isLeaf;

    /**
    * 父级Id
    */
    @ApiModelProperty(value="父级Id")
    private String parentId;

    /**
    * 显示状态 SHOW_STATE
    */
    @ApiModelProperty(value="显示状态 SHOW_STATE")
    private Integer isDisplay;

    /**
    * 操作人id
    */
    @ApiModelProperty(value="操作人id")
    private String operateId;

    /**
    * 操作人姓名
    */
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 修改时间
    */
    @ApiModelProperty(value="修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}