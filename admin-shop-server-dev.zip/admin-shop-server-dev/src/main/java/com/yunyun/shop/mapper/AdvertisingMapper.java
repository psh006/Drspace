package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.Advertising;
import com.yunyun.shop.api.pojo.vo.AdvertisingRequestVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-30 14:00
 */
public interface AdvertisingMapper {
    int deleteByPrimaryKey(String adId);

    int insert(Advertising record);

    int updateByPrimaryKey(Advertising record);

    List<Advertising> query(AdvertisingRequestVo advertisingRequestVo);

    int updateAdState(@Param("adId") String adId,@Param("adState") Integer adState);
}