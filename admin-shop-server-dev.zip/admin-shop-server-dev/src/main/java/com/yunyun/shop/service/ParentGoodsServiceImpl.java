package com.yunyun.shop.service;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.dto.GoodsIdNameDto;
import com.yunyun.shop.api.pojo.entity.ChildGoods;
import com.yunyun.shop.api.pojo.entity.GoodsBase;
import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;
import com.yunyun.shop.api.service.ChildGoodsService;
import com.yunyun.shop.common.enums.PutState;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.common.util.StringUtils;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import com.yunyun.shop.mapper.ParentGoodsMapper;
import com.yunyun.shop.api.pojo.entity.ParentGoods;
import com.yunyun.shop.api.service.ParentGoodsService;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

@Transactional(rollbackFor = Exception.class)
@Service
public class ParentGoodsServiceImpl implements ParentGoodsService {

    @Resource
    private ParentGoodsMapper parentGoodsMapper;
    @Resource
    private ChildGoodsService childGoodsService;

    @Override
    public int deleteByPrimaryKey(String parentGoodsId) {
        return parentGoodsMapper.deleteByPrimaryKey(parentGoodsId);
    }

    @Override
    public ParentGoods selectByPrimaryKey(String parentGoodsId) {
        ParentGoods parentGoods = parentGoodsMapper.selectByPrimaryKey(parentGoodsId);
        if (parentGoods == null) {
            throw new AlertException("查询失败，物品不存在");
        }
        // 查询子物品
        parentGoods.setChildGoodsList(childGoodsService.queryChildGoodsByParentGoodsId(parentGoodsId));
        return parentGoods;
    }

    /**
     * @param parentGoods
     * @return int
     * @description 修改主物品
     * @auther PuYaDong
     * @date 2020-06-23 15:41
     */
    @Override
    public int updateByPrimaryKey(ParentGoods parentGoods) {
        // 查询原数据
        ParentGoods oldParentGoods = parentGoodsMapper.selectByPrimaryKey(parentGoods.getParentGoodsId());
        if (oldParentGoods == null) {
            throw new AlertException("修改失败，修改物品不存在");
        }
        parentGoodsMapper.updateByPrimaryKey(parentGoods);

        // 重新设置主物品编号
        List<ChildGoods> childGoodsList = parentGoods.getChildGoodsList().stream()
                .peek(goods -> goods.setParentGoodsId(parentGoods.getParentGoodsId()))
                .collect(Collectors.toList());
        if (!childGoodsList.isEmpty()) {
            if (oldParentGoods.getGoodsSpecItems().equals(parentGoods.getGoodsSpecItems())) {
                // 规格未被修改，则判断goodsId是否存在，存在的编辑，不存在的添加
                // 检查子商品规格是否符合规范
                checkSpec(parentGoods.getGoodsSpecItems(), parentGoods.getChildGoodsList());

                // 需要添加的子物品
                List<ChildGoods> updateChildGoodsList = childGoodsList.stream()
                        .parallel()
                        .filter(childGoods -> StringUtils.isNotBlank(childGoods.getGoodsId()))
                        .collect(Collectors.toList());
                if (updateChildGoodsList.size() > 0) {
                    childGoodsService.updateBatch(updateChildGoodsList);
                }

                // 需要修改的子物品
                List<ChildGoods> insertChildGoodsList = childGoodsList.stream()
                        .parallel()
                        .filter(childGoods -> StringUtils.isBlank(childGoods.getGoodsId()))
                        .collect(Collectors.toList());
                if (insertChildGoodsList.size() > 0) {
                    childGoodsService.batchInsert(insertChildGoodsList);
                }
            } else {
                // 规格被修改了，则删除原物品下所有子商品
                childGoodsService.deleteByParentGoodsId(parentGoods.getParentGoodsId());
                // 然后重新添加
                // 检查子商品规格是否符合规范
                checkSpec(parentGoods.getGoodsSpecItems(), parentGoods.getChildGoodsList());

                childGoodsService.batchInsert(childGoodsList);
            }
        }
        return 1;
    }

    @Override
    public PageInfo<ParentGoods> findInPage(GoodsRequestVo goodsRequestVo) {
        PageHelper.startPage(goodsRequestVo.getPage(), goodsRequestVo.getLimit());
        List<ParentGoods> goodsBaseList = parentGoodsMapper.queryGoodsList(goodsRequestVo);
        PageInfo<ParentGoods> pageInfo = new PageInfo<>(goodsBaseList);
        return pageInfo;
    }

    @Override
    public int deleteSeveralGoods(List<String> goodsIds) {
        return parentGoodsMapper.deleteSeveralGoods(goodsIds);
    }

    @Override
    public int deleteLogicGoodsById(List<String> goodsIds) {
        return parentGoodsMapper.deleteLogicGoodsById(goodsIds);
    }

    @Override
    public PageInfo<ParentGoods> selectRecycleGoods(GoodsRequestVo goodsRequestVo) {
        PageHelper.startPage(goodsRequestVo.getPage(), goodsRequestVo.getLimit());
        List<ParentGoods> goodsBaseList = parentGoodsMapper.selectRecycleGoods(goodsRequestVo);
        PageInfo<ParentGoods> pageInfo = new PageInfo<>(goodsBaseList);
        return pageInfo;
    }

    @Override
    public int recoverGoods(List<String> goodsIds) {
        return parentGoodsMapper.recoverGoods(goodsIds);
    }

    @Override
    public int putGoods(int putState, List<String> goodsIds) {
        return parentGoodsMapper.putGoods(putState, goodsIds);
    }

    /**
     * @param parentGoods
     * @return int
     * @description 添加主商品
     * @auther PuYaDong
     * @date 2020-06-16 11:50
     */
    @Override
    public int add(ParentGoods parentGoods) {
        // 基础信息
        parentGoods.setParentGoodsId(IdWorker.getIdStr());
        EmpUserDetail user = AuthHelper.getUser();
        parentGoods.setOperateId(user.getEmpId());
        parentGoods.setOperateName(user.getEmpName());
        parentGoods.setOperateTime(new Date());

        // 检查主商品规格
        int isInsertParent = parentGoodsMapper.insert(parentGoods);

        List<ChildGoods> childGoodsList = parentGoods.getChildGoodsList();
        int isInsertChild = 1;
        if (!childGoodsList.isEmpty()) {
            // 检查子商品规格是否符合规范
            checkSpec(parentGoods.getGoodsSpecItems(), parentGoods.getChildGoodsList());

            // 给每个子物品设置主物品编号
            childGoodsList = childGoodsList.stream()
                    .parallel()
                    .peek(childGoods -> {
                        childGoods.setParentGoodsId(parentGoods.getParentGoodsId());
                    }).collect(Collectors.toList());

            isInsertChild = childGoodsService.batchInsert(childGoodsList);
        }
        return (isInsertParent > 0 && isInsertChild > 0) ? 1 : 0;

    }

    /**
     * @param parentGoods
     * @return int
     * @description 刷新主商品信息
     * @auther PuYaDong
     * @date 2020-06-22 19:06
     */
    @Override
    public int refreshParentGoods(ParentGoods parentGoods) {
        return parentGoodsMapper.refreshParentGoods(parentGoods);
    }

    /**
     * @param parentGoodsId
     * @return com.yunyun.shop.common.model.ResultBody
     * @description 复制商品
     * @auther PuYaDong
     * @date 2020-06-24 16:02
     */
    @Override
    public int copyGoods(String parentGoodsId) {
        // 查询要复制的物品
        ParentGoods parentGoods = this.selectByPrimaryKey(parentGoodsId);

        if (parentGoods == null) {
            throw new AlertException("复制失败，物品不存在");
        }
        // 设置副本物品信息
        if (parentGoods.getParentGoodsName().length() > 40) {
            throw new AlertException("复制失败，原主物品名称过长");
        }
        parentGoods.setParentGoodsName(parentGoods.getParentGoodsName() + "(副本)");
        parentGoods.setPutTime(null);
        parentGoods.setPutState(PutState.PUT_DOWN.getCode());

        return this.add(parentGoods);
    }

    /**
     * @return java.util.List<com.yunyun.shop.api.pojo.dto.GoodsIdNameDto>
     * @description 获取编号和名称物品列表
     * @auther PuYaDong
     * @date 2020-07-02 14:24
     */
    @Override
    public List<GoodsIdNameDto> getGoodsIdNameList() {
        return parentGoodsMapper.getGoodsIdNameList();
    }

    /**
     * @param
     * @return void
     * @description 检查规格格式
     * @auther PuYaDong
     * @date 2020-06-23 15:51
     */
    private void checkSpec(String goodsSpecItems, List<ChildGoods> childGoodsList) {
        try {
            Map goodsSpecItemsMap = JSON.parseObject(goodsSpecItems, Map.class);
            List<Map> goodsSpecList = childGoodsList.stream()
                    .map(childGoods -> JSON.parseObject(childGoods.getGoodsSpec(), Map.class))
                    .collect(Collectors.toList());
            // 判断子商品规格是否重复
            long count1 = goodsSpecList.stream()
                    .distinct()
                    .count();
            if (count1 < goodsSpecList.size()) {
                throw new AlertException("子商品保存失败，子商品规格重复");
            }
            // 判断每个子物品的物品规格格式
            goodsSpecList
                    .forEach(map -> {
                        // 从主物品规格中循环
                        goodsSpecItemsMap.forEach((key, value) -> {
                            String param = (String) map.get(key);
                            map.remove(key);
                            if (StringUtils.isNotBlank(param)) {
                                // 查询主物品规格下有没有改具体规格
                                long count2 = ((List<String>) value).stream()
                                        .filter(s -> s.equals(param))
                                        .count();
                                if (count2 == 0) {
                                    throw new AlertException("子商品保存失败，商品规格不存在");
                                }
                            } else {
                                throw new AlertException("子商品保存失败，商品规格不存在");
                            }
                        });
                        if (!map.isEmpty()) {
                            throw new AlertException("子商品保存失败，商品规格不存在");
                        }
                    });
        } catch (Exception ex) {
            if (ex instanceof AlertException) {
                throw ex;
            }
            throw new AlertException("保存失败，规格格式错误");
        }
    }

}

