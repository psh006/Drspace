package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-19 11:44
 **/
@Data
public class OperateIdVo implements Serializable {
    /**
     * 操作编号
     */
    @NotBlank(message = "操作编号不能为空")
    @ApiModelProperty(value="操作编号")
    private String id;
}