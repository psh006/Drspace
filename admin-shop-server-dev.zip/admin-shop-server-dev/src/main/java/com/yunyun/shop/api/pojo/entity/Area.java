package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
    * 地区码表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-Area")
@Data
public class Area implements Serializable {
    /**
    * 地区编号
    */
    @ApiModelProperty(value="地区编号")
    private String areaId;

    /**
    * 地区代码
    */
    @ApiModelProperty(value="地区代码")
    private String areaCode;

    /**
    * 地区名称
    */
    @ApiModelProperty(value="地区名称")
    private String areaName;

    /**
    * 地区级别（1:省,2:市,3:区,4:街道）
    */
    @ApiModelProperty(value="地区级别（1:省,2:市,3:区,4:街道）")
    private Integer level;

    /**
    * 关联员工编号
    */
    @ApiModelProperty(value="关联员工编号")
    private String parentAreaCode;

    private static final long serialVersionUID = 1L;
}
