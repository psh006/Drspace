package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-30 14:37
 */
@Data
public class AdvertisingRequestVo implements Serializable {

    /**
     * 广告标题
     */
    @ApiModelProperty(value="广告标题")
    private String adTitle;

    /**
     * 广告位置，AD_POSITION
     */
    @ApiModelProperty(value="广告位置，AD_POSITION")
    private Integer adPosition;
}
