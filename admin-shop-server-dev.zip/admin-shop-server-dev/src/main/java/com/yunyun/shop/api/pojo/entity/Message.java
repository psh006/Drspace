package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@ApiModel(value = "com-yunyun-shop-api-pojo-entity-Message")
@Data
@Entity(name="t_message")
public class Message implements Serializable {
    /**
     * 消息编号
     */
    @Id
    @ApiModelProperty(value = "消息编号")
    private String messageId;

    /**
     * 消息分类，MESSAGE_TYPE
     */
    @Column
    @ApiModelProperty(value = "消息分类，MESSAGE_TYPE")
    private Integer messageType;

    /**
     * 消息状态，MESSAGE_STATE
     */
    @Column
    @ApiModelProperty(value = "消息状态，MESSAGE_STATE")
    private Integer messageState;

    /**
     * 消息内容
     */
    @Column
    @ApiModelProperty(value = "消息内容")
    private String messageInfo;

    /**
     * 关联员工编号
     */
    @Column
    @ApiModelProperty(value = "关联员工编号")
    private String empId;

    /**
     * 关联订单编号
     */
    @Column
    @ApiModelProperty(value = "关联订单编号")
    private String orderId;

    /**
     * 操作人编号
     */
    @Column
    @ApiModelProperty(value = "操作人编号")
    private String operateId;

    /**
     * 操作人姓名
     */
    @Column
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @Column
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 更新时间
     */
    @Column
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}
