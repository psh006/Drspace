package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.vo.OrderRequestVo;
import com.yunyun.shop.api.service.OrderBaseService;
import com.yunyun.shop.common.enums.YesOrNo;
import com.yunyun.shop.common.exception.AlertException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.yunyun.shop.mapper.OrderBaseMapper;
import org.springframework.transaction.annotation.Transactional;

/**
 * @description com.yunyun.shop.service
 * @author PuYaDong
 * @createTime 2020-06-11 12:53
 */
@Service
@Slf4j
@Transactional(rollbackFor = Exception.class)
public class OrderBaseServiceImpl implements OrderBaseService {

    @Resource
    private OrderBaseMapper orderBaseMapper;

    @Override
    public int deleteByPrimaryKey(String orderId) {
        return orderBaseMapper.deleteByPrimaryKey(orderId);
    }

    @Override
    public int insert(OrderBase record) {
        return orderBaseMapper.insert(record);
    }

    @Override
    public OrderBase selectByPrimaryKey(String orderId) {
        return orderBaseMapper.selectByPrimaryKey(orderId);
    }

    @Override
    public int updateByPrimaryKey(OrderBase record) {
        return orderBaseMapper.updateByPrimaryKey(record);
    }

    @Override
    public int updateBatch(List<OrderBase> list) {
        return orderBaseMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<OrderBase> list) {
        return orderBaseMapper.batchInsert(list);
    }

    /**
     * @description 分页查询
     * @auther PuYaDong
     * @date 2020-06-11 14:33
     * @param orderRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.vo.entity.OrderBase>
     */
    @Override
    public PageInfo<OrderBase> findOrderListPage(OrderRequestVo orderRequestVo) {
        PageHelper.startPage(orderRequestVo.getPage(),orderRequestVo.getLimit());
        List<OrderBase> orderBaseList = orderBaseMapper.query(orderRequestVo);
        return new PageInfo<>(orderBaseList);
    }
}
