package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.EmpBase;

import java.util.Date;
import java.util.List;

import com.yunyun.shop.api.pojo.vo.EmpRequestVo;
import com.yunyun.shop.api.pojo.vo.UpdateStateVo;
import org.apache.ibatis.annotations.Param;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-12 09:14
 */
public interface EmpBaseMapper {
    int deleteByPrimaryKey(String empId);

    int insert(EmpBase record);

    EmpBase selectByPrimaryKey(String empId);

    int updateByPrimaryKey(EmpBase record);

    int updateBatch(List<EmpBase> list);

    int batchInsert(@Param("list") List<EmpBase> list);

    EmpBase selectByLoginCode(String loginCode);

    List<EmpBase> query(EmpRequestVo empRequestVo);

    int updateState(UpdateStateVo updateStateVo);

    int updateLoginPass(@Param("empId") String empId,@Param("loginPass") String loginPass);

    int updateLastLoginTime(@Param("empId") String empId,@Param("lastLoginTime") Date lastLoginTime);

    int isLoginCodeExist(EmpBase empBase);
}