package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.HistoryRefundOrderResult;
import com.yunyun.shop.api.pojo.dto.RefundOrderDetailDto;
import com.yunyun.shop.api.pojo.entity.RefundOrder;
import com.yunyun.shop.api.pojo.vo.HistoryRefundOrderQuery;
import com.yunyun.shop.api.pojo.vo.RefundOrderRequestVo;
import com.yunyun.shop.api.service.RefundOrderService;
import com.yunyun.shop.api.service.RefundRecordService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author lxl
 * @Classname RefundOrderController
 * @Description 退款controller
 * @Date 2020/6/19 14:53
 */
@RestController
@RequestMapping("/refundOrder")
@Api(tags = "退款订单")
public class RefundOrderController {

    @Autowired
    private RefundOrderService refundOrderService;

    @Autowired
    private RefundRecordService refundRecordService;

    /**
     *
     * @Description: 
     * @params: [refundOrderRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.RefundOrder>>
     * @Author: lxl
     * @Date : 2020/6/19 17:00
     */
    @ApiOperation(value = "查询退款订单")
    @PostMapping("/queryRefundOder")
    public ResultBody<List<RefundOrder>> queryRefundOder(@RequestBody RefundOrderRequestVo refundOrderRequestVo) {
        PageInfo<RefundOrder> refundOrderPageInfo = refundOrderService.queryRefundOrder(refundOrderRequestVo);
        return ResultBody.ok(refundOrderPageInfo.getList(), refundOrderPageInfo.getTotal());
    }

    /**
     * 查询退款订单详情
     * @auther CheGuangQuan
     * @date 2020/6/24 11:03
     * @param orderDetailId
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.entity.OrderDetail>
    */
    @ApiOperation(value = "查询退款订单详情")
    @GetMapping("/queryRefundOrderDetail")
    public ResultBody<RefundOrderDetailDto> queryRefundOrderDetail(@RequestParam String orderDetailId){
        RefundOrderDetailDto refundOrderDetailDto = refundOrderService.queryRefundOrderDetail(orderDetailId);
        return ResultBody.ok(refundOrderDetailDto);
    }

    /**
     * @description 查询历史退款订单
     * @auther PuYaDong
     * @date 2020-06-28 17:11
     * @param
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("查询历史退款订单")
    @GetMapping("/queryHistory")
    public ResultBody<List<HistoryRefundOrderResult>> getHistory(HistoryRefundOrderQuery historyRefundOrderQuery){
        PageInfo<HistoryRefundOrderResult> pageInfo= refundRecordService.queryHistory(historyRefundOrderQuery);
        return ResultBody.ok(pageInfo.getList(),pageInfo.getTotal());
    }

}
