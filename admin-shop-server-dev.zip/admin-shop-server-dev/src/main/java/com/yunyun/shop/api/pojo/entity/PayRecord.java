package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
    * 支付记录表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-PayRecord")
@Data
public class PayRecord implements Serializable {
    /**
    * 支付编号
    */
    @ApiModelProperty(value="支付编号")
    private String payId;

    /**
    * 客户编号
    */
    @ApiModelProperty(value="客户编号")
    private String customerId;

    /**
    * 关联订单编号
    */
    @ApiModelProperty(value="关联订单编号")
    private String orderId;

    /**
    * 关联子订单编号
    */
    @ApiModelProperty(value="关联子订单编号")
    private String orderDetailId;

    /**
    * 支付方式，PAY_METHOD
    */
    @ApiModelProperty(value="支付方式，PAY_METHOD")
    private Integer payMethod;

    /**
    * 支付状态，PAY_STATE
    */
    @ApiModelProperty(value="支付状态，PAY_STATE")
    private Integer payState;

    /**
    * 支付流水号
    */
    @ApiModelProperty(value="支付流水号")
    private String paySerialNum;

    /**
    * 支付反馈
    */
    @ApiModelProperty(value="支付反馈")
    private String payFeedback;

    /**
    * 支付反馈时间
    */
    @ApiModelProperty(value="支付反馈时间")
    private Date payFeedbackTime;

    /**
    * 应付金额（折扣后四舍五入）
    */
    @ApiModelProperty(value="应付金额（折扣后四舍五入）")
    private BigDecimal sumAmount;

    /**
    * 实付金额（两位小数）
    */
    @ApiModelProperty(value="实付金额（两位小数）")
    private BigDecimal realAmount;

    /**
    * 优惠金额
    */
    @ApiModelProperty(value="优惠金额")
    private BigDecimal discountAmount;

    /**
    * 是否存在退款，YES_NO
    */
    @ApiModelProperty(value="是否存在退款，YES_NO")
    private Integer isRefund;

    /**
    * 退款状态，REFUND_STATE
    */
    @ApiModelProperty(value="退款状态，REFUND_STATE")
    private Integer refundState;

    /**
    * 退款金额
    */
    @ApiModelProperty(value="退款金额")
    private BigDecimal refundAmount;

    /**
    * 支付备注
    */
    @ApiModelProperty(value="支付备注")
    private String payNote;

    /**
    * 操作人编号
    */
    @ApiModelProperty(value="操作人编号")
    private String operateId;

    /**
    * 操作人姓名
    */
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 更新时间
    */
    @ApiModelProperty(value="更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}