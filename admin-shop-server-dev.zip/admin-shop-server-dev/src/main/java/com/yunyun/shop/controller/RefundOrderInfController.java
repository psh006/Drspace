package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.vo.AgreeRefundVo;
import com.yunyun.shop.api.pojo.vo.RefundAddress;
import com.yunyun.shop.api.service.RefundOrderInfService;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @description 同意退款时展示的信息
 * @author zzd
 * @date 2020-06-19 09:28
 */
@Api(tags = "退款订单")
@RestController
@RequestMapping("/refundOrder")
public class RefundOrderInfController {
    @Autowired
    private RefundOrderInfService refundOrderInfService;

    /**
     * @description 获取售后收货地址
     * @auther zzd
     * @date 2020-06-19 09:27
     * @param
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("获取售后收货地址")
    @GetMapping("/afterSalesReceivingAddress")
    public ResultBody<List<RefundAddress>> afterSalesReceivingAddress(){
        return ResultBody.ok(refundOrderInfService.afterSalesReceivingAddress());
    }

    /**
     * @description 根据子订单编号获取订单信息
     * @auther zzd
     * @date 2020-06-19 11:23
     * @param orderDetailId
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("根据子订单编号获取订单信息")
    @GetMapping("/orderInf")
    public ResultBody orderInf(String orderDetailId){
        return ResultBody.ok(refundOrderInfService.getOderInfByOrderId(orderDetailId));
    }

    /**
     * @description 根据子订单编号获取退款信息
     * @auther zzd
     * @date 2020-06-19 12:12
     * @param orderDetailId
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("根据子订单编号获取退款信息")
    @GetMapping("/orderDetailInf")
    public ResultBody orderDetailInf(String orderDetailId){
        return ResultBody.ok(refundOrderInfService.orderDetailInf(orderDetailId));
    }

    /**
     * @description 退款处理-同意/拒绝/批量同意/批量拒绝
     * @auther zzd
     * @date 2020-06-19 14:06
     * @param ()
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("退款处理-同意/拒绝/批量同意/批量拒绝")
    @PostMapping("/refundProcessing")
    public ResultBody refundProcessing(@RequestBody @Validated List<AgreeRefundVo> agreeRefundVoList){
        int i=refundOrderInfService.refundProcessing(agreeRefundVoList);
        if (i>0){
            return ResultBody.ok("处理成功");
        }else {
            return ResultBody.failed("处理失败");
        }
    }

    @ApiOperation("退款订单-历史订单")
    @GetMapping("/historyOrder")
    public ResultBody historyOrder() {
        return null;
    }
}
