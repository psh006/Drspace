package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author PuYaDong
 * @description 编辑客户等级状态
 * @createTime 2020-06-29 15:12
 */
@Data
public class UpdateState implements Serializable {

    /**
     * 编号
     */
    @NotBlank(message = "编号不能为空")
    @ApiModelProperty(value="编号")
    private String id;

    /**
     * 状态
     */
    @NotNull(message = "状态不能为空")
    @ApiModelProperty(value="状态")
    private Integer state;
}
