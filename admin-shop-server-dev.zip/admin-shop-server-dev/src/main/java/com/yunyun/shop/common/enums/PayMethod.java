package com.yunyun.shop.common.enums;

public enum PayMethod {
    //微信
    WECHAT(1,"微信"),
    //支付宝
    ALIPAY(2,"支付宝");
    private int code;
    private String desc;

    PayMethod(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
