package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
    * 商品评价表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-GoodsComment")
@Data
public class GoodsComment implements Serializable {
    /**
    * 评价编号
    */
    @ApiModelProperty(value="评价编号")
    private String commentId;

    /**
    * 评价级别，COMMENT_LEVEL
    */
    @ApiModelProperty(value="评价级别，COMMENT_LEVEL")
    private Integer commentLevel;

    /**
    * 评价内容
    */
    @ApiModelProperty(value="评价内容")
    private String commentContent;

    /**
    * 评价时间
    */
    @ApiModelProperty(value="评价时间")
    private Date commentTime;

    /**
    * 评价人，客户编号
    */
    @ApiModelProperty(value="评价人，客户编号")
    private String customerId;

    /**
    * 关联订单编号
    */
    @ApiModelProperty(value="关联订单编号")
    private String orderId;

    /**
    * 关联子订单编号
    */
    @ApiModelProperty(value="关联子订单编号")
    private String orderDetailId;

    /**
    * 关联子商品编号
    */
    @ApiModelProperty(value="关联子商品编号")
    private String goodsId;

    /**
    * 关联主商品编号
    */
    @ApiModelProperty(value="关联主商品编号")
    private String parentGoodsId;

    /**
    * 是否置顶 YES_NO
    */
    @ApiModelProperty(value="是否置顶 YES_NO")
    private Integer isTop;

    /**
    * 置顶时间
    */
    @ApiModelProperty(value="置顶时间")
    private Date topTime;

    /**
    * 是否删除，YES_NO
    */
    @ApiModelProperty(value="是否删除，YES_NO")
    private Integer isDelete;

    /**
    * 删除时间
    */
    @ApiModelProperty(value="删除时间")
    private Date deleteTime;

    /**
    * 更新时间
    */
    @ApiModelProperty(value="更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}