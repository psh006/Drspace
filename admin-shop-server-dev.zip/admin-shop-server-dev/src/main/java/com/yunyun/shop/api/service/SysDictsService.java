package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysDictItems;
import com.yunyun.shop.api.pojo.entity.SysDicts;
import com.yunyun.shop.common.model.PageParams;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-13 15:35
 */
public interface SysDictsService {

    /**
     * @description 获取字典信息
     * @auther PuYaDong
     * @date 2020-06-13 15:44
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.SysDicts>
     */
    List<SysDicts> getAllDict();

    /**
     * @description 字典分页查询
     * @auther PuYaDong
     * @date 2020-06-18 15:26
     * @param pageParams
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.SysDicts>
     */
    PageInfo<SysDicts> page(PageParams pageParams);

    /**
     * @description 添加字典
     * @auther PuYaDong
     * @date 2020-06-18 16:40
     * @param sysDicts
     * @return int
     */
    int add(SysDicts sysDicts);

    /**
     * @description 修改字典
     * @auther PuYaDong
     * @date 2020-06-18 16:40
     * @param sysDicts
     * @return int
     */
    int update(SysDicts sysDicts);

    /**
     * @description 删除字典
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     * @param dictId
     * @return int
     */
    int delete(String dictId);

    /**
     * @description 添加字典子项
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     * @param sysDictItems
     * @return int
     */
    int addDictItem(SysDictItems sysDictItems);

    /**
     * @description 修改字典子项
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     * @param sysDictItems
     * @return int
     */
    int updateDictItem(SysDictItems sysDictItems);

    /**
     * @description 删除字典子项
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     * @param itemId
     * @return int
     */
    int deleteDictItem(String itemId);

    /**
     * @description 检查字典是否存在
     * @auther PuYaDong
     * @date 2020-06-23 16:18
     * @param sysDicts
     * @return boolean true: 唯一的 false: 已存在
     */
    boolean isDictUnique(SysDicts sysDicts);

    /**
     * @description 检查字典子项值是否存在
     * @auther PuYaDong
     * @date 2020-06-23 16:18
     * @param sysDictItems
     * @return boolean true: 唯一的 false: 已存在
     */
    boolean isDictItemUnique(SysDictItems sysDictItems);
}
