package com.yunyun.shop.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * spring.resources.add-mappings=false  为静态资源设置默认处理
 * spring.mvc.throw-exception-if-no-handler-found=true
 * 这样可以将自定义全局404异常方便Restful使用
 * 但是spring.resources.add-mappings=false会导致swagger也不能访问。
 *
 * @author PuYaDong
 * @createTime 2020-06-24 16:04
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/doc.html")
                .addResourceLocations("classpath:/META-INF/resources/", "/static", "/public");

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
}
