package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.vo.AdvertisingRequestVo;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.api.pojo.entity.Advertising;
import com.yunyun.shop.mapper.AdvertisingMapper;
import com.yunyun.shop.api.service.AdvertisingService;

import java.util.Date;
import java.util.List;

/**
 * @description com.yunyun.shop.service
 * @author PuYaDong
 * @createTime 2020-06-30 14:00
 */
@Service
public class AdvertisingServiceImpl implements AdvertisingService{

    @Resource
    private AdvertisingMapper advertisingMapper;

    @Override
    public int deleteByPrimaryKey(String adId) {
        return advertisingMapper.deleteByPrimaryKey(adId);
    }

    @Override
    public int insert(Advertising record) {
        record.setAdId(IdWorker.getIdStr());
        EmpUserDetail user = AuthHelper.getUser();
        record.setOperateId(user.getEmpId());
        record.setOperateName(user.getEmpName());
        record.setOperateTime(new Date());
        return advertisingMapper.insert(record);
    }

    @Override
    public int updateByPrimaryKey(Advertising record) {
        return advertisingMapper.updateByPrimaryKey(record);
    }

    /**
     * @param advertisingRequestVo
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.Advertising>
     * @description 查询广告
     * @auther PuYaDong
     * @date 2020-06-30 14:43
     */
    @Override
    public List<Advertising> findAdvertising(AdvertisingRequestVo advertisingRequestVo) {
        return advertisingMapper.query(advertisingRequestVo);
    }

    /**
     * @param adId
     * @param adState
     * @return int
     * @description 修改显示隐藏
     * @auther PuYaDong
     * @date 2020-06-30 14:43
     */
    @Override
    public int updateAdState(String adId, Integer adState) {
        return advertisingMapper.updateAdState(adId,adState);
    }

}
