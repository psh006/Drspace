package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.api.pojo.vo.AgreeRefundVo;
import com.yunyun.shop.api.pojo.vo.RefundAddress;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface RefundOrderInfServiceMapper {
    /**
     * @description 获取收获地址
     * @auther zzd
     * @date 2020-06-19 10:03
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.vo.RefundAddress>
     */
    List<RefundAddress> queryRefundAddress();

    /**
     * @description 根据订单编号获取订单信息
     * @auther zzd
     * @date 2020-06-19 13:41
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.entity.OrderBase
     */
    OrderDetail queryOrderInfByOrderId(String orderDetailId);

    /**
     * @description 根据子订单编号获取退款信息
     * @auther zzd
     * @date 2020-06-19 13:41
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.entity.OrderDetail
     */
    RefundRecord orderDetailInf(String orderDetailId);

    /**
     * @description 退款处理-同意/拒绝/批量同意/批量拒绝
     * @auther zzd
     * @date 2020-06-19 14:40
     * @param agreeRefundVoList
     * @return int
     */
    int refundProcessing(@Param("agreeRefundVoList")List<AgreeRefundVo> agreeRefundVoList);

    /**
     * @description 同意退款后修改子订单状态
     * @auther zzd
     * @date 2020-06-28 17:19
     * @param agreeRefundVo
     * @return int
     */
    int updateOrderDetailState(AgreeRefundVo agreeRefundVo);
}
