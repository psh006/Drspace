package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
    * 订单详情表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-OrderDetail")
@Data
public class OrderDetail implements Serializable {
    /**
    * 子订单编号
    */
    @ApiModelProperty(value="子订单编号")
    private String orderDetailId;

    /**
    * 关联订单编号
    */
    @ApiModelProperty(value="关联订单编号")
    private String orderId;

    /**
    * 关联商品编号
    */
    @ApiModelProperty(value="关联商品编号")
    private String goodsId;

    /**
    * 关联客户编号
    */
    @ApiModelProperty(value="关联客户编号")
    private String customerId;

    /**
    * 子订单状态，ORDER_DETAIL_STATE
    */
    @ApiModelProperty(value="子订单状态，ORDER_DETAIL_STATE")
    private Integer orderDetailState;

    /**
    * 商品数量
    */
    @ApiModelProperty(value="商品数量")
    private Integer detailGoodsCount;

    /**
    * 子订单总金额，应付金额
    */
    @ApiModelProperty(value="子订单总金额，应付金额")
    private BigDecimal orderDetailAmount;

    /**
    * 商品金额
    */
    @ApiModelProperty(value="商品金额")
    private BigDecimal detailGoodsAmount;

    /**
    * 运费
    */
    @ApiModelProperty(value="运费")
    private BigDecimal detailFreightAmount;

    /**
    * 实付金额
    */
    @ApiModelProperty(value="实付金额")
    private BigDecimal detailPayAmountReal;

    /**
    * 优惠金额
    */
    @ApiModelProperty(value="优惠金额")
    private BigDecimal detailDiscountAmount;

    /**
    * 支付编号
    */
    @ApiModelProperty(value="支付编号")
    private String payId;

    /**
    * 物流公司编号
    */
    @ApiModelProperty(value="物流公司编号")
    private String logisticsId;

    /**
    * 物流公司名称
    */
    @ApiModelProperty(value="物流公司名称")
    private String logisticsName;

    /**
     * 发货时间
     */
    @ApiModelProperty(value="发货时间")
    private Date logisticsDeliveryTime;

    /**
    * 快递单号
    */
    @ApiModelProperty(value="快递单号")
    private String logisticsNumber;

    /**
    * 退款编号
    */
    @ApiModelProperty(value="退款编号")
    private String refundId;

    /**
    * 退货物流公司编号
    */
    @ApiModelProperty(value="退货物流公司编号")
    private String refundLogisticsId;

    /**
    * 退货物流公司名称
    */
    @ApiModelProperty(value="退货物流公司名称")
    private String refundLogisticsName;


    /**
     * 退货发货时间
     */
    @ApiModelProperty(value="退货发货时间")
    private Date refundDeliveryTime;

    /**
    * 退货快递单号
    */
    @ApiModelProperty(value="退货快递单号")
    private String refundLogisticsNumber;

    /**
    * 收货人姓名-此时变为发货人
    */
    @ApiModelProperty(value="收货人姓名-此时变为发货人")
    private String receiptName;

    /**
    * 收货电话-此时变为发货人
    */
    @ApiModelProperty(value="收货电话-此时变为发货人")
    private String receiptPhone;

    /**
    * 收货地址-此时变为发货人
    */
    @ApiModelProperty(value="收货地址-此时变为发货人")
    private String receiptAddress;

    /**
    * 邮编-此时变为发货人
    */
    @ApiModelProperty(value="邮编-此时变为发货人")
    private String receiptPostcode;

    /**
     * 备注-此时变为发货人
     */
    @ApiModelProperty(value="备注-此时变为发货人")
    private String receiptNote;

    /**
    * 操作人编号
    */
    @ApiModelProperty(value="操作人编号")
    private String operateId;

    /**
    * 操作人姓名
    */
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 更新时间
    */
    @ApiModelProperty(value="更新时间")
    private Date updateTime;


    @ApiModelProperty(value="支付方式")
    private Integer payMethod;

    private static final long serialVersionUID = 1L;
}
