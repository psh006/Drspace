package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.Area;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AreaMapper {
    int deleteByPrimaryKey(String areaId);

    int insert(Area record);

    Area selectByPrimaryKey(String areaId);

    int updateByPrimaryKey(Area record);

    /**
     * 查询省
     * @return
     */
    List<Area> selectAllList();

    /**
     * 根据省获取市  根据市获取县
     * @return
     */
    List<Area> selectCityCounty(Area area);
}
