package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.CustomerBase;
import com.yunyun.shop.api.pojo.vo.CustomerRequestVo;
import com.yunyun.shop.api.pojo.vo.UpdateCustomer;

import java.util.List;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-29 16:29
 */
public interface CustomerBaseMapper {
    int deleteByPrimaryKey(String customerId);

    int insert(CustomerBase record);

    CustomerBase selectByPrimaryKey(String customerId);

    int updateByPrimaryKey(CustomerBase record);

    List<CustomerBase> query(CustomerRequestVo customerRequestVo);

    int updateCustomerLevelAndNote(UpdateCustomer updateCustomer);
}