package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.HistoryRefundOrderResult;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.vo.HistoryRefundOrderQuery;
import com.yunyun.shop.mapper.OrderDetailMapper;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.mapper.RefundRecordMapper;
import com.yunyun.shop.api.service.RefundRecordService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class RefundRecordServiceImpl implements RefundRecordService{

    @Resource
    private RefundRecordMapper refundRecordMapper;
    @Resource
    private OrderDetailMapper orderdetailmapper;


    @Override
    public int deleteByPrimaryKey(String refundId) {
        return refundRecordMapper.deleteByPrimaryKey(refundId);
    }

    @Override
    public int insert(RefundRecord record) {
        return refundRecordMapper.insert(record);
    }

    @Override
    public RefundRecord selectByPrimaryKey(String refundId) {
        return refundRecordMapper.selectByPrimaryKey(refundId);
    }

    @Override
    public int updateByPrimaryKey(RefundRecord record) {
        return refundRecordMapper.updateByPrimaryKey(record);
    }

    @Override
    public Boolean refund(String orderId) {//退款
        //查询订单子表数据
        List<OrderDetail> listdetail = orderdetailmapper.orderdetailList(orderId);
        List<RefundRecord> list = new ArrayList<>();
        for (OrderDetail item : listdetail) {
            RefundRecord refundrecord = new RefundRecord();
            refundrecord.setRefundId(UUID.randomUUID().toString().substring(0,10));
            refundrecord.setCustomerId(item.getCustomerId());
            refundrecord.setOrderId(item.getOrderId());
            refundrecord.setOrderDetailId(item.getOrderDetailId());
            refundrecord.setRefundAmount(item.getDetailPayAmountReal());
            refundrecord.setRefundReason("");//退款原因
            refundrecord.setOperateTime(new Date());
            list.add(refundrecord);
        }
        int row = refundRecordMapper.refund(list);//新增退款信息
        List<OrderDetail> listdet = new ArrayList<>();
        for (RefundRecord item : list) {
            OrderDetail orde = new OrderDetail();
            //修改订单子表状态
            orde.setOrderDetailId(item.getOrderDetailId());
            orde.setOrderDetailState(8);// 8->"已退款"
            orde.setPayId(item.getRefundId());//退款编号
            listdet.add(orde);
        }
        row = orderdetailmapper.updateBatch(listdet);//改变订单子表的数据（状态等）
        if (row > 0) {
            return true;
        }
        return false;
    }

    /**
     * @param historyRefundOrderQuery
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.dto.HistoryRefundOrderResult>
     * @description 分页查询退款记录
     * @auther PuYaDong
     * @date 2020-06-28 17:39
     */
    @Override
    public PageInfo<HistoryRefundOrderResult> queryHistory(HistoryRefundOrderQuery historyRefundOrderQuery) {
        PageHelper.startPage(historyRefundOrderQuery.getPage(),historyRefundOrderQuery.getLimit());
        List<HistoryRefundOrderResult> list = refundRecordMapper.queryHistory(historyRefundOrderQuery);
        PageInfo<HistoryRefundOrderResult> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

}
