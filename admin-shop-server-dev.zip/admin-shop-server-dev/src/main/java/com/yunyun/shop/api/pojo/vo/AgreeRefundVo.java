package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.*;
import java.math.BigDecimal;

/**
 * @author zzd
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-19 14:11
 */

@Data
public class AgreeRefundVo {
    @ApiModelProperty(value = "退款编号")
    private String refundId;

    @ApiModelProperty(value = "退款金额")
    private BigDecimal refundAmount;

    @ApiModelProperty(value = "备注")
    private String remarks;

    @ApiModelProperty(value = "退款状态" , required = true)
    @NotNull(message = "退款状态不能为空")
    private Integer refundState;

    @ApiModelProperty(value = "拒绝原因")
    private String refuseReason;

    @ApiModelProperty(value = "退货地址")
    private String refundAddressId;

    @ApiModelProperty(value = "子订单编号")
    private String orderDetailId;
}
