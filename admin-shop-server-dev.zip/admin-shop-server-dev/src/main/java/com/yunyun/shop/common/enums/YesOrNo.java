package com.yunyun.shop.common.enums;

/**
 * @ClassName: YesOrNo
 * @Description:
 * @Author: HuiLiao
 * @Date: 2020/4/5 21:06
 */
public enum YesOrNo {
    YES(1), NO(2);
    private final int value;
    private YesOrNo(int value) {
        this.value = value;
    }
    public static YesOrNo valueOf(int value) {
        switch(value) {
            case 1:
                return YES;
            case 2:
                return NO;
            default:
                return NO;
        }
    }

    public int getValue() {
        return value;
    }
}
