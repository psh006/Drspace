package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author lxl
 * @Classname RefundOrder
 * @Description TODO
 * @Date 2020/6/19 15:11
 */

@ApiModel("退款订单实体")
@Data
public class RefundOrder implements Serializable {

    /**
     * 订单编号
     */
    @ApiModelProperty(value="订单编号")
    private String orderId;

    /**
     * 退款记录编号
     */
    @ApiModelProperty(value="退款记录编号")
    private String refundId;

    /**
     * 子订单编号
     */
    @ApiModelProperty(value="子订单编号")
    private String orderDetailId;

    /**
     * 退款状态，REFUND_STATE
     */
    @ApiModelProperty(value="退款状态，REFUND_STATE")
    private Integer refundState;

    /**
     * 关联客户编号
     */
    @ApiModelProperty(value="关联客户编号")
    private String customerId;

    /**
     * 姓名
     */
    @ApiModelProperty(value="姓名")
    private String customerName;

    /**
     * 电话
     */
    @ApiModelProperty(value="电话")
    private String customerPhone;

    /**
     * 申请时间
     */
    @ApiModelProperty(value="申请时间")
    private Date operateTime;

    /**
     * 物品图
     */
    @ApiModelProperty(value="物品图")
    private String goodsCover;

    /**
     * 物品名称
     */
    @ApiModelProperty(value="物品名称")
    private String goodsName;


    /**
     * 订单总金额（商品总金额+运费）
     */
    @ApiModelProperty(value="订单总金额（商品总金额+运费）")
    private BigDecimal orderDetailAmount;


    /**
     *  运费
     */
    @ApiModelProperty(value="运费")
    private BigDecimal detailFreightAmount;

   /**
     *  商品金额
     */
    @ApiModelProperty(value="商品金额")
    private BigDecimal detailGoodsAmount;



    /**
     * 实付金额（订单总金额-优惠金额）
     */
    @ApiModelProperty(value="实付金额（订单总金额-优惠金额）")
    private BigDecimal detailPayAmountReal;


    /**
     * 支付方式
     */
    @ApiModelProperty(value="支付方式")
    private Integer payMethod;




    /**
     * 退款原因
     */
    @ApiModelProperty(value="退款原因")
    private String refundReason;


    /**
     * 规格
     */
    @ApiModelProperty(value="规格")
    private String goodsSpec;
    

    /**
     *
     * 退款方式
     */
    @ApiModelProperty(value = "退款方式")
    private Integer refundMethod;



    private static final long serialVersionUID = 1L;
}
