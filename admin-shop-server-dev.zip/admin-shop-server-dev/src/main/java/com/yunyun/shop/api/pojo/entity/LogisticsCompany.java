package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @description 物流公司表
 * @author PuYaDong
 * @createTime 2020-06-16 15:04
 */
@ApiModel(value = "物流公司实体")
@Data
public class LogisticsCompany implements Serializable {
    /**
     * 物流公司编号
     */
    @ApiModelProperty(value = "物流公司编号")
    private String logisticsId;

    /**
     * 物流公司名称
     */
    @NotBlank(message = "物流公司名称不可为空")
    @ApiModelProperty(value = "物流公司名称")
    private String logisticsName;

    /**
     * 物流公司代码
     */
    @NotBlank(message = "物流公司代码不可为空")
    @ApiModelProperty(value = "物流公司代码")
    private String logisticsCode;

    /**
     * 排序
     */
    @NotNull(message = "排序不可为空")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 操作人编号
     */
    @ApiModelProperty(value = "操作人编号")
    private String operateId;

    /**
     * 操作人姓名
     */
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}