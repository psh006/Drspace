package com.yunyun.shop.api.service;

    import com.yunyun.shop.api.pojo.entity.ChildGoods;

    import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-16 11:02
 */
public interface ChildGoodsService {


    int deleteByPrimaryKey(String goodsId);

    int insert(ChildGoods record);

    int updateByPrimaryKey(ChildGoods record);
    /**
     * 通过父商品查询子商品
     * @auther CheGuangQuan
     * @date 2020/6/16 13:38
     * @param parentGoodsId
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.ChildGoods>
     */
    List<ChildGoods> queryGoodsStock(String parentGoodsId);

    /**
     * @description 根据主商品查询所有子商品
     * @auther PuYaDong
     * @date 2020-06-16 15:26
     * @param parentGoodsId
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.ChildGoods>
     */
    List<ChildGoods> queryChildGoodsByParentGoodsId(String parentGoodsId);

    /**
     * @description 批量添加子物品
     * @auther PuYaDong
     * @date 2020-06-17 10:34
     * @param childGoodsList
     * @return int
     */
    int batchInsert(List<ChildGoods> childGoodsList);

    /**
     * @description 编辑添加子物品
     * @auther PuYaDong
     * @date 2020-06-17 10:35
     * @param childGoodsList
     * @return int
     */
    int updateBatch(List<ChildGoods> childGoodsList);

    /**
     * @description 根据主物品id删除子物品
     * @auther PuYaDong
     * @date 2020-06-23 15:45
     * @param parentGoodsId
     * @return int
     */
    int deleteByParentGoodsId(String parentGoodsId);
}

