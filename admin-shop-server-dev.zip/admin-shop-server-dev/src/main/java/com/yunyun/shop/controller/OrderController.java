package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.Area;
import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.pojo.vo.OrderRequestVo;
import com.yunyun.shop.api.service.*;
import com.yunyun.shop.common.enums.YesOrNo;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-11 13:14
 */
@Api(tags = "订单")
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderBaseService orderBaseService;

    @Autowired
    private OrderDetailService orderDetailService;

    @Autowired
    private LogisticsCompanyService logisticsCompanyService;

    @Autowired
    private RefundRecordService refundRecordService;

    @Autowired
    private AreaService areaService;

    /**
     * @description 根据id查询订单
     * @auther PuYaDong
     * @date 2020-06-11 13:17
     * @param orderId
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.vo.entity.OrderBase>
     */
    @ApiOperation(value = "根据id查询订单")
    @ApiImplicitParam(name = "orderId",value = "1",required = true)
    @GetMapping("/info")
    public ResultBody<OrderBase> info(String orderId){
        return ResultBody.ok(orderBaseService.selectByPrimaryKey(orderId));
}

    /**
     * @description 订单分页查询
     * @auther PuYaDong
     * @date 2020-06-11 14:18
     * @param orderRequestVo 搜索参数
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     */
    @ApiOperation(value = "订单分页查询")
    @PostMapping("/find")
    public ResultBody<List<OrderBase>> find(@RequestBody OrderRequestVo orderRequestVo){
        orderRequestVo.setIsDelete(YesOrNo.NO.getValue());
        PageInfo<OrderBase> pageInfo = orderBaseService.findOrderListPage(orderRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @description 查询回收站中的订单
     * @auther PuYaDong
     * @date 2020-06-16 14:29
     * @param orderRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.OrderBase>>
     */
    @ApiOperation(value = "查询回收站中的订单")
    @PostMapping("/queryRecycleOrder")
    public ResultBody<List<OrderBase>> queryRecycleOrder(@RequestBody OrderRequestVo orderRequestVo){
        orderRequestVo.setIsDelete(YesOrNo.YES.getValue());
        PageInfo<OrderBase> pageInfo = orderBaseService.findOrderListPage(orderRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @description
     * @auther Loveclear
     * @date 2020-06-11 18:09
     * @param orderbase
     * @return message(消息)
     */
    @ApiOperation(value = "单条订单的修改")
    @PostMapping("/goUpdate")
    public ResultBody goUpdate(@RequestBody OrderBase orderbase){
        int rowtotle = orderBaseService.updateByPrimaryKey(orderbase);
        if (rowtotle>0) {
            return ResultBody.ok();
        }
        return ResultBody.failed();
    }

    /**
     * @description 查询发货的数据(发货弹出框)
     * @auther Loveclear
     * @date 2020-06-12 09:39
     * @param orderId 搜索参数
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation(value = "查询发货的数据(发货弹出框)")
    @GetMapping("/deliverGoodsinfo")
    public ResultBody deliverGoodsinfo(String orderId){
        ResultBody reresultbody = new ResultBody();
        //查询订单子表数据
        reresultbody.data(orderDetailService.orderdetailList(orderId));
        //查询物流公司数据
        reresultbody.put("LogisticsCompany", logisticsCompanyService.find());
        //查询订单主表的数据
        reresultbody.put("OrderBase",orderBaseService.selectByPrimaryKey(orderId));
        return ResultBody.ok(reresultbody);
    }

    /**
     * @description 发货
     * @auther Loveclear
     * @date 2020-06-12 10:55
     * @param orderdetail 参数
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     */
    @ApiOperation(value = "发货（可以进行批量操作）")
    @PostMapping("/deliverGoods")
    public ResultBody deliverGoods(@RequestBody List<OrderDetail> orderdetail){
        int row = orderDetailService.updateBatch(orderdetail);
        if (row>0) {
            return ResultBody.ok();
        }
        return ResultBody.failed();
    }

    /**
     * @description 退款
     * @auther Loveclear
     * @date 2020-06-12 15:55
     * @param operateIdVo 订单(主表)ID
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation(value = "退款（可以进行批量操作）")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "orderId",value = "主订单Id",required = true,dataType = "orderDetail")
    )
    @PostMapping("/refund")
    public ResultBody refund(@RequestBody @Validated OperateIdVo operateIdVo){
        OrderBase row = orderBaseService.selectByPrimaryKey(operateIdVo.getId());
        if (row == null) {//订单不存在
            return ResultBody.failed("此订单不存在,不能退款");
        }
        boolean bool = refundRecordService.refund(operateIdVo.getId());
        if (bool) {
            return ResultBody.ok();
        }
        return ResultBody.failed();
    }

    /**
     * @description 省 市 县 联动
     * @auther Loveclear
     * @date 2020-06-18 17:35
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     */
    @ApiOperation(value = "获取省")
    @PostMapping("/chinaProvince")
    public ResultBody chinaProvince(){
        return ResultBody.ok(areaService.selectAllList());
    }

    /**
     * @description 根据省获取市 根据市获取县 必填参数：areaCode": "130600","level": 3,
     * @auther Loveclear
     * @date 2020-06-18 17:50
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     */
    @ApiOperation(value = "根据省获取市  根据市获取县")
    @PostMapping("/chinaCityCounty")
    public ResultBody chinaCityCounty(@RequestBody Area area){
        return ResultBody.ok(areaService.selectCityCounty(area));
    }
}
