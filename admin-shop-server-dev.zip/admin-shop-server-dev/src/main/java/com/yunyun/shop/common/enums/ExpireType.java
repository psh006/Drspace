package com.yunyun.shop.common.enums;

public enum ExpireType {
    EFFECTIVE_AFTER_RECEIVING(1,"领取后生效"),
    FIXED_TIME(2,"固定时间");
    private int code;
    private String desc;

    ExpireType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}

