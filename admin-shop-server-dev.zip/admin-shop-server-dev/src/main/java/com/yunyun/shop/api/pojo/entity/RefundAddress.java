package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author PuYaDong
 * @description 售后地址管理表
 * @createTime 2020-06-28 09:28
 */
@ApiModel(value = "售后地址实体")
@Data
public class RefundAddress implements Serializable {
    /**
     * 地址编号
     */
    @ApiModelProperty(value = "地址编号")
    private String receiptAddressId;

    /**
     * 收货人姓名
     */
    @NotBlank(message = "收货人姓名不能为空")
    @Length(max = 20, message = "收货人姓名不能超过20个字")
    @ApiModelProperty(value = "收货人姓名")
    private String receiptName;

    /**
     * 收货电话
     */
    @NotBlank(message = "收货电话不能为空")
    @Pattern(regexp = "^[1](([3|5|8][\\d])|([4][4,5,6,7,8,9])|([6][2,5,6,7])|([7][^9])|([9][1,8,9]))[\\d]{8}$" +
            "|^[0][1-9]{2,3}-[0-9]{5,10}$" +
            "|^[1-9]{1}[0-9]{5,8}$",message = "收货电话格式错误")
    @ApiModelProperty(value = "收货电话")
    private String receiptPhone;

    /**
     * 收货地址
     */
    @NotBlank(message = "收货地址不能为空")
    @Length(max = 50, message = "收货地址不能超过50个字")
    @ApiModelProperty(value = "收货地址")
    private String receiptAddress;

    /**
     * 邮编
     */
    @NotBlank(message = "邮编不能为空")
    @Pattern(regexp = "[1-9]\\d{5}",message = "邮编格式错误")
    @ApiModelProperty(value = "邮编")
    private String receiptPostcode;

    /**
     * 是否默认 YES_NO 1是 2否
     */
    @NotNull(message = "是否默认不能为空")
    @Range(min = 1, max = 2, message = "是否默认参数错误")
    @ApiModelProperty(value = "是否默认 YES_NO 1是 2否")
    private Integer isDefault;

    /**
     * 操作人编号
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人编号")
    private String operateId;

    /**
     * 操作人姓名
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 更新时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}