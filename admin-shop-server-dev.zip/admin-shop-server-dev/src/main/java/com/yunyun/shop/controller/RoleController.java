package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.api.pojo.vo.SysRoleRequestVo;
import com.yunyun.shop.api.service.RoleMenuService;
import com.yunyun.shop.api.service.SysRoleService;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author lxl
 * @Classname RoleController
 * @Description 角色
 * @Date 2020/6/24 10:34
 */
@Api(tags = "角色管理")
@RestController
@RequestMapping("/role")
public class RoleController {


    @Autowired
    private SysRoleService sysRoleService;


    /**
     * @Description: 分页查询角色和关联菜单
     * @params: [sysRoleRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.SysRole>>
     * @Author: lxl
     * @Date : 2020/6/24 11:11
     */
    @ApiOperation(value = "分页查询角色和关联菜单")
    @PostMapping("/queryRoles")
    public ResultBody<List<SysRole>> queryRoles(@RequestBody SysRoleRequestVo sysRoleRequestVo) {
        PageInfo<SysRole> sysRolePageInfo = sysRoleService.selectRoles(sysRoleRequestVo);
        return ResultBody.ok(sysRolePageInfo.getList(), sysRolePageInfo.getTotal());
    }


    /**
     * @Description: 查询角色和关联菜单通过id
     * @params: [sysRoleRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.SysRole>>
     * @Author: lxl
     * @Date : 2020/6/24 11:11
     */
    @ApiOperation(value = "查询角色和关联菜单通过id")
    @PostMapping("/queryRoleById")
    public ResultBody<SysRole> queryRoleById(@RequestBody SysRoleRequestVo sysRoleRequestVo) {
        SysRole sysRole = sysRoleService.selectByPrimaryKey(sysRoleRequestVo.getRoleId());
        return ResultBody.ok(sysRole);
    }


    /**
     * @Description: 新增角色
     * @params: [sysRoleRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.SysRole>>
     * @Author: lxl
     * @Date : 2020/6/24 11:11
     */
    @ApiOperation(value = "新增角色")
    @PostMapping("/insertRole")
    public ResultBody insertRole(@RequestBody @Validated(Insert.class) SysRole sysRole) {
        int insert = sysRoleService.insert(sysRole);
        return insert > 0 ? ResultBody.ok().msg("添加成功") : ResultBody.failed("添加失败");
    }

    /**
     * @Description: 修改角色
     * @params: [sysRoleRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.SysRole>>
     * @Author: lxl
     * @Date : 2020/6/24 11:11
     */
    @ApiOperation(value = "修改角色")
    @PostMapping("/updateRole")
    public ResultBody updateRole(@RequestBody @Validated(Update.class) SysRole sysRole) {
        int update = sysRoleService.updateByPrimaryKey(sysRole);
        return update > 0 ? ResultBody.ok().msg("编辑成功") : ResultBody.failed("编辑失败");
    }


    /**
     * @Description: 删除角色
     * @params: [sysRoleRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.SysRole>>
     * @Author: lxl
     * @Date : 2020/6/24 11:11
     */
    @ApiOperation(value = "删除角色")
    @PostMapping("/deleteRole")
    public ResultBody deleteRole(@RequestBody SysRoleRequestVo sysRoleRequestVo) {
        int i = sysRoleService.deleteRole(sysRoleRequestVo);
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }


    @ApiOperation(value = "角色菜单关联")
    @PostMapping("/roleAndMenu")
    public ResultBody roleAndMenu(@RequestBody SysRoleRequestVo sysRoleRequestVo) {
        int i = sysRoleService.roleAndMenu(sysRoleRequestVo);
        return i > 0 ? ResultBody.ok().msg("保存成功") : ResultBody.failed("保存失败");
    }
}
