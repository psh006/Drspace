package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysParams;
import com.yunyun.shop.api.pojo.vo.SysParamRequestVo;

import java.util.List;

/**
 *
 * @Classname SysParamsService
 * @Description TODO
 * @Date 2020/6/23 13:56
 * @author lxl
 */
public interface SysParamsService{

    int deleteByPrimaryKey(String paramId);

    int insert(SysParams record);

    SysParams selectByPrimaryKey(String paramId);

    int updateByPrimaryKey(SysParams record);

    PageInfo<SysParams> querySyParams(SysParamRequestVo sysParamVo);

    int updateSysParamList(List<SysParams> sysParamsList);

    List<SysParams> selectSysParamListList();
}
