package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * @description com.yunyun.shop.api.pojo.entity
 * @author PuYaDong
 * @createTime 2020-06-24 10:25
 */
/**
    * 员工部门表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-EmpSector")
@Data
public class EmpSector implements Serializable {
    /**
    * 部门编号
    */
    @ApiModelProperty(value="部门编号")
    private String sectorId;

    /**
    * 部门名称
    */
    @ApiModelProperty(value="部门名称")
    private String sectorName;

    /**
    * 备注
    */
    @ApiModelProperty(value="备注")
    private String note;

    /**
    * 操作人编号
    */
    @ApiModelProperty(value="操作人编号")
    private String operateId;

    /**
    * 操作人姓名
    */
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 更新时间
    */
    @ApiModelProperty(value="更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}