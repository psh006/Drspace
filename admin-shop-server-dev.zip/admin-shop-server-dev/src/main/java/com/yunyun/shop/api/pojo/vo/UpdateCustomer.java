package com.yunyun.shop.api.pojo.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-30 10:19
 */
@ApiModel(value = "修改客户信息")
@Data
public class UpdateCustomer {

    /**
     * 客户编号
     */
    @NotBlank(message = "客户编号不能为空")
    @ApiModelProperty(value = "客户编号")
    private String customerId;

    /**
     * 客户等级编号
     */
    @NotBlank(message = "客户等级不能为空")
    @ApiModelProperty(value = "客户等级编号")
    private String customerLevelId;

    /**
     * 客户等级名称
     */
    @JsonIgnore
    @ApiModelProperty(value="客户等级名称")
    private String customerLevelName;

    /**
     * 备注
     */
    @Length(max = 200, message = "备注不能超过两百字")
    @ApiModelProperty(value = "备注")
    private String note;
}
