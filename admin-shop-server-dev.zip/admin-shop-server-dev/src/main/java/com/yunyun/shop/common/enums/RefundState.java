package com.yunyun.shop.common.enums;

public enum RefundState {
    PENDING(1,"待处理"),
    REFUNDING(2,"退款中"),
    REFUSE_REFUND(3,"拒绝退款"),
    REFUSE_SUCCESSFUL(4,"退款成功"),
    REFUSE_FAILED(5,"退款失败");
    private int code;
    private String desc;

    RefundState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
