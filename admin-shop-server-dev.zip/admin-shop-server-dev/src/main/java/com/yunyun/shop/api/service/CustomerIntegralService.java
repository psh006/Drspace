package com.yunyun.shop.api.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.CustomerIntegralDto;
import com.yunyun.shop.api.pojo.entity.CustomerIntegral;
import com.yunyun.shop.api.pojo.vo.CustomerIntegralVo;
import com.yunyun.shop.api.pojo.vo.IntegralRecordRequestVo;

public interface CustomerIntegralService{


    int deleteByPrimaryKey(String recordId);

    int insert(CustomerIntegral record);

    CustomerIntegral selectByPrimaryKey(String recordId);

    int updateByPrimaryKey(CustomerIntegral record);

    int updateBatch(List<CustomerIntegral> list);

    int batchInsert(List<CustomerIntegral> list);

    PageInfo<CustomerIntegralVo> selectList(CustomerIntegralDto customerIntegralDto);

    /**
     * @description 分页查询客户的积分记录
     * @auther PuYaDong
     * @date 2020-07-03 15:59
     * @param integralRecordRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.CustomerIntegral>
     */
    PageInfo<CustomerIntegral> queryCustomerIntegralRecord(IntegralRecordRequestVo integralRecordRequestVo);
}
