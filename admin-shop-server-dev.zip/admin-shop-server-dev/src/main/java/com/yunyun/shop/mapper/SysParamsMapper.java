package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.SysParams;
import com.yunyun.shop.api.pojo.vo.SysParamRequestVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 *
 * @Classname SysParamsMapper
 * @Description TODO
 * @Date 2020/6/23 13:56
 * @author lxl
 */
@Mapper
public interface SysParamsMapper {

    int deleteByPrimaryKey(String paramId);

    int insert(SysParams record);

    SysParams selectByPrimaryKey(String paramId);

    int updateByPrimaryKey(SysParams record);

    List<SysParams> querySysParams(SysParamRequestVo sysParamVo);

    int updateSysParamList(List<SysParams> list);

    List<SysParams> selectSysParamListList();
}