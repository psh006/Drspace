package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.entity.LogisticsCompany;
import com.yunyun.shop.api.pojo.vo.LogisticsRequestVo;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.service.LogisticsCompanyService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-16 15:07
 */
@Api(tags = "物流公司")
@RestController
@RequestMapping("/logisticsCompany")
public class LogisticsCompanyController {

    @Autowired
    private LogisticsCompanyService logisticsCompanyService;

    /**
     * @description 所有物流公司
     * @auther PuYaDong
     * @date 2020-06-16 15:10
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>>
     */
    @ApiOperation("所有物流公司")
    @GetMapping("/all")
    public ResultBody<List<LogisticsCompany>> all(){
        return ResultBody.ok(logisticsCompanyService.find());
    }

    /**
     * 条件查询物流公司
     * @auther CheGuangQuan
     * @date 2020/6/22 14:33
     * @param logisticsRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>>
    */
    @ApiOperation("条件查询物流公司")
    @PostMapping("/queryLogisticsCompany")
    public ResultBody<List<LogisticsCompany>> queryLogisticsCompany(@RequestBody LogisticsRequestVo logisticsRequestVo){
        return ResultBody.ok(logisticsCompanyService.queryLogisticsCompany(logisticsRequestVo));
    }

    /**
     * 新增物流公司
     * @auther CheGuangQuan
     * @date 2020/6/22 14:33
     * @param logisticsCompany
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>>
     */
    @ApiOperation("新增物流公司")
    @PostMapping("/insertLogisticsCompany")
    public ResultBody insertLogisticsCompany(@RequestBody @Validated LogisticsCompany logisticsCompany){
        return logisticsCompanyService.insert(logisticsCompany);
    }

    /**
     * 删除物流公司
     * @auther CheGuangQuan
     * @date 2020/6/22 14:33
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>>
     */
    @ApiOperation("删除物流公司")
    @PostMapping("/deleteLogisticsCompany")
    public ResultBody deleteLogisticsCompany(@RequestBody OperateIdVo operateIdVo){
        String id = operateIdVo.getId();
        int i = logisticsCompanyService.deleteByPrimaryKey(id);
        return i>0?ResultBody.ok().msg("删除成功"):ResultBody.failed("删除失败");
    }

    /**
     * 修改物流公司
     * @auther CheGuangQuan
     * @date 2020/6/22 14:33
     * @param logisticsCompany
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>>
     */
    @ApiOperation("修改物流公司")
    @PostMapping("/updateLogisticsCompany")
    public ResultBody updateLogisticsCompany(@RequestBody LogisticsCompany logisticsCompany){
        return logisticsCompanyService.updateByPrimaryKey(logisticsCompany);
    }


}
