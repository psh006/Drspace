package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.OrderDetail;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OrderDetailMapper {
    int deleteByPrimaryKey(String orderDetailId);

    int insert(OrderDetail record);

    OrderDetail selectByPrimaryKey(String orderDetailId);

    int updateByPrimaryKey(OrderDetail record);

    //跟据订单ID查询所有商品信息
    List<OrderDetail> orderdetailList(String orderId);

    //批量修改（发货）
    int updateBatch(@Param("orderdetail") List<OrderDetail> orderdetail);
}