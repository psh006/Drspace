package com.yunyun.shop.cache;

import com.yunyun.shop.api.pojo.entity.SysDicts;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author: pandong
 * @description: 数据缓存配置
 * @createTime: 2019-12-19 10:05
 */
@Component
public class DataCache {

    @Resource(name = "dataRedisTemplate")
    private RedisTemplate<String, Object> dataRedisTemplate;

    public Object getTemp(String key) {
        String innerKey = getCacheKey(key);
        return dataRedisTemplate.opsForValue().get(innerKey);
    }

    public void setTemp(String key,Object val) {
        setTemp(key, val, 10);
    }

    public void setTemp(String key, Object val, int expire) {
        String innerKey = getCacheKey(key);
        dataRedisTemplate.opsForValue().set(innerKey, val, expire, TimeUnit.MINUTES);
    }

    public void lPushOrder(String key, Object val) {
        String innerKey = getCacheKey(key);
        dataRedisTemplate.opsForList().leftPush(innerKey, val);
    }

    public Object rPopOrder(String key) {
        String innerKey = getCacheKey(key);
        return dataRedisTemplate.opsForList().rightPop(innerKey);
    }


    private String getCacheKey(String key) {
        return DigestUtils.md5DigestAsHex(key.getBytes());
    }

}
