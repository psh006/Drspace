package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.entity.SysMenu;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.service.SysMenuService;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-19 09:51
 **/
@Api(tags = "系统菜单")
@RequestMapping("/sysMenu")
@RestController
public class SysMenuController {
    @Autowired
    private SysMenuService sysMenuService;

    /**
     * 查询所有菜单
     *
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List   <   com.yunyun.shop.api.pojo.entity.SysMenu>>
     * @auther CheGuangQuan
     * @date 2020/6/19 10:50
     */
    @ApiOperation("查询所有菜单")
    @GetMapping("/queryAll")
    public ResultBody<List<SysMenu>> queryAll() {
        return sysMenuService.queryAll();
    }

    /**
     * 修改菜单
     *
     * @param sysMenu
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/19 10:52
     */
    @ApiOperation("修改菜单")
    @PostMapping("/updateMenu")
    public ResultBody updateMenu(@RequestBody @Validated(Update.class) SysMenu sysMenu) {
        int i = sysMenuService.updateByPrimaryKey(sysMenu);
        return i > 0 ? ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * 添加菜单
     *
     * @param sysMenu
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/19 10:52
     */
    @ApiOperation("添加菜单")
    @PostMapping("/insertMenu")
    public ResultBody insertMenu(@RequestBody @Validated(Insert.class) SysMenu sysMenu) {
        int insert = sysMenuService.insert(sysMenu);
        return insert > 0 ? ResultBody.ok().msg("添加成功") : ResultBody.failed("添加失败");
    }

    /**
     * 删除菜单
     *
     * @param
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/19 10:52
     */
    @ApiOperation("删除菜单")
    @PostMapping("/deleteMenu")
    public ResultBody deleteMenu(@RequestBody @Validated OperateIdVo operateIdVo) {
        int delete = sysMenuService.deleteMenu(operateIdVo);
        return delete > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }

    /**
     * 通过角色查询菜单
     * @auther CheGuangQuan
     * @date 2020/6/30 15:46
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.SysMenu>>
    */
    @ApiOperation("通过角色查询菜单")
    @GetMapping("/selectMenuByRole")
    public ResultBody<List<SysMenu>> selectMenuByRole(){
        return sysMenuService.selectMenuByRole();
    }
}