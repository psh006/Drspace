package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-16 13:46
 **/
@Data
public class GoodsCategoryVo implements Serializable {
    /**
     * 类别编号
     */
    @ApiModelProperty(value="类别编号")
    private String goodsCategoryId;
}