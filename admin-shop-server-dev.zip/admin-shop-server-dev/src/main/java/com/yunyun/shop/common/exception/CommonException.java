package com.yunyun.shop.common.exception;

/**
 * 功能描述: 通用异常
 *
 * @author pyd
 * @date 2020-04-22
 */
public class CommonException extends RuntimeException {

    private static final long serialVersionUID = 3655050728585279326L;

    private int code;

    public CommonException() {

    }

    public CommonException(String msg) {
        super(msg);
    }

    public CommonException(int code, String msg) {
        super(msg);
        this.code = code;
    }

    public CommonException(int code, String msg, Throwable cause) {
        super(msg, cause);
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }


}