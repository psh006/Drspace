package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.GoodsIdNameDto;
import com.yunyun.shop.api.pojo.entity.ChildGoods;
import com.yunyun.shop.api.pojo.entity.ParentGoods;
import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;
import com.yunyun.shop.common.model.ResultBody;

import java.util.List;

public interface ParentGoodsService {


    int deleteByPrimaryKey(String parentGoodsId);

    ParentGoods selectByPrimaryKey(String parentGoodsId);

    /**
     * @description 修改主物品
     * @auther PuYaDong
     * @date 2020-06-23 15:41
     * @param parentGoods
     * @return int
     */
    int updateByPrimaryKey(ParentGoods parentGoods);

    /**
     * 分页查询商品
     * @auther CheGuangQuan
     * @date 2020/6/17 14:16
     * @param goodsRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.ParentGoods>
    */
    PageInfo<ParentGoods> findInPage(GoodsRequestVo goodsRequestVo);

    /**
     * 批量删除商品
     * @auther CheGuangQuan
     * @date 2020/6/17 14:16
     * @param goodsIds
     * @return int
    */
    int deleteSeveralGoods(List<String> goodsIds);

    /**
     * 逻辑删除商品
     * @auther CheGuangQuan
     * @date 2020/6/17 14:16
     * @param goodsIds
     * @return int
    */
    int deleteLogicGoodsById(List<String> goodsIds);

    /**
     * 查询回收站商品
     * @auther CheGuangQuan
     * @date 2020/6/17 14:15
     * @param goodsRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.ParentGoods>
    */
    PageInfo<ParentGoods> selectRecycleGoods(GoodsRequestVo goodsRequestVo);

    /**
     * 批量恢复商品
     * @auther CheGuangQuan
     * @date 2020/6/17 14:15
     * @param goodsIds
     * @return int
    */
    int recoverGoods(List<String> goodsIds);

    /**
     * 上架/下架商品
     *
     * @param goodsIds
     * @return int
     * @auther CheGuangQuan
     * @date 2020/6/15 13:04
     */
    int putGoods(int putState, List<String> goodsIds);


    /**
     * @description 添加主商品
     * @auther PuYaDong
     * @date 2020-06-16 11:50
     * @param parentGoods
     * @return int
     */
    int add(ParentGoods parentGoods);

    /**
     * @description 刷新主商品信息
     * @auther PuYaDong
     * @date 2020-06-22 19:06
     * @param parentGoods
     * @return int
     */
    int refreshParentGoods(ParentGoods parentGoods);

    /**
     * @description 复制商品
     * @auther PuYaDong
     * @date 2020-06-24 16:02
     * @param parentGoodsId
     * @return com.yunyun.shop.common.model.ResultBody
     */
    int copyGoods(String parentGoodsId);

    /**
     * @description 获取编号和名称物品列表
     * @auther PuYaDong
     * @date 2020-07-02 14:24
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.dto.GoodsIdNameDto>
     */
    List<GoodsIdNameDto> getGoodsIdNameList();
}

