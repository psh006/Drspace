package com.yunyun.shop.common.enums;

public enum MessageType {
    //系统消息
    SYSTEM_MESSAGES(1,"系统消息"),
    //订单消息
    ORDER_MESSAGES(2,"订单消息"),
    //退款消息
    REFUND_MESSAGES(3,"退款消息");
    private int code;
    private String desc;

    MessageType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
