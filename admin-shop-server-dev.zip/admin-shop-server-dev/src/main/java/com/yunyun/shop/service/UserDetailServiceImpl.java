package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.api.service.EmpBaseService;
import com.yunyun.shop.api.service.SysRoleService;
import com.yunyun.shop.common.util.BeanConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author PuYaDong
 * @description 登录获取用户实现类
 * @createTime 2020-06-12 09:03
 */
@Service
public class UserDetailServiceImpl implements UserDetailsService {

    @Autowired
    private EmpBaseService empBaseService;

    @Autowired
    private SysRoleService sysRoleService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // 根据用户名查询用户
        // 扩展时从多张用户表(员工、客户)查
        EmpBase emp = empBaseService.login(username);
        if(emp == null){
            throw new UsernameNotFoundException("用户不存在");
        }
        // 如需扩展，建议扩展EmpUserDetail,只需实现UserDetail即可
        // 将id和name统一为(empId,customerId) -> userId, (empName,customerName) -> name
        // 针对不同的用户类型单独赋值
        EmpUserDetail empUserDetail = BeanConvertUtils.convertBean(emp, EmpUserDetail.class);

        // 查询用户角色权限
        List<SysRole> roles = sysRoleService.queryUserRoles(emp.getEmpId());
        empUserDetail.setSysRoleList(roles);

        return empUserDetail;
    }
}
