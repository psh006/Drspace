package com.yunyun.shop.api.pojo.dto;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author zzd
 * @description com.yunyun.shop.api.pojo.dto
 * @createTime 2020-06-24 16:48
 */
@Data
@ApiModel(value = "历史退款查询条件")
public class HistoryRefundQuery extends PageParams {
    @ApiModelProperty(value = "开始日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startDate;

    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endDate;

    @ApiModelProperty(value="子订单编号")
    private String orderDetailId;

    @ApiModelProperty(value="退款方式")
    private Integer refundMethod;

    @ApiModelProperty(value="收货人姓名")
    private String receiptName;

    @ApiModelProperty(value="收货人手机号")
    private String receiptPhone;
}
