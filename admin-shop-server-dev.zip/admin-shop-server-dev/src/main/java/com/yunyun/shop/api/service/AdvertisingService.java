package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.Advertising;
import com.yunyun.shop.api.pojo.vo.AdvertisingRequestVo;
import com.yunyun.shop.common.model.ResultBody;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-30 14:00
 */
public interface AdvertisingService {


    int deleteByPrimaryKey(String adId);

    int insert(Advertising record);

    int updateByPrimaryKey(Advertising record);

    /**
     * @description 查询广告
     * @auther PuYaDong
     * @date 2020-06-30 14:43
     * @param advertisingRequestVo
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.Advertising>
     */
    List<Advertising> findAdvertising(AdvertisingRequestVo advertisingRequestVo);

    /**
     * @description 修改显示隐藏
     * @auther PuYaDong
     * @date 2020-06-30 14:43
     * @param adId
     * @param adState
     * @return int
     */
    int updateAdState(String adId, Integer adState);
}
