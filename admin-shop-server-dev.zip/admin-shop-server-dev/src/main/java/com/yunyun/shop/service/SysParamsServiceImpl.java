package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.vo.SysParamRequestVo;
import com.yunyun.shop.common.util.IdWorker;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.mapper.SysParamsMapper;
import com.yunyun.shop.api.pojo.entity.SysParams;
import com.yunyun.shop.api.service.SysParamsService;

import java.util.List;

/**
 *
 * @Classname SysParamsServiceImpl
 * @Description TODO
 * @Date 2020/6/23 13:56
 * @author lxl
 */
@Service
public class SysParamsServiceImpl implements SysParamsService{

    @Resource
    private SysParamsMapper sysParamsMapper;

    @Override
    public int deleteByPrimaryKey(String paramId) {
        return sysParamsMapper.deleteByPrimaryKey(paramId);
    }

    @Override
    public int insert(SysParams record) {
        record.setParamId(IdWorker.getIdStr());
        return sysParamsMapper.insert(record);
    }

    @Override
    public SysParams selectByPrimaryKey(String paramId) {
        return sysParamsMapper.selectByPrimaryKey(paramId);
    }

    @Override
    public int updateByPrimaryKey(SysParams record) {
        return sysParamsMapper.updateByPrimaryKey(record);
    }




    /**
     *
     * @Description: 分页查询系统参数
     * @params: [sysParamVo]
     * @return: com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.SysParams>
     * @Author: lxl
     * @Date : 2020/6/23 14:27
     */
    @Override
    public PageInfo<SysParams> querySyParams(SysParamRequestVo sysParamVo) {
        PageHelper.startPage(sysParamVo.getPage(), sysParamVo.getLimit());
        List<SysParams> sysParams = sysParamsMapper.querySysParams(sysParamVo);
        return new PageInfo<>(sysParams);
    }

    @Override
    public int updateSysParamList(List<SysParams> sysParamsList) {
        return sysParamsMapper.updateSysParamList(sysParamsList);
    }

    @Override
    public List<SysParams> selectSysParamListList() {
        return sysParamsMapper.selectSysParamListList();
    }

}
