package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.vo.OrderRequestVo;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-11 14:57
 */
public interface OrderBaseService {
    int deleteByPrimaryKey(String orderId);

    int insert(OrderBase record);

    OrderBase selectByPrimaryKey(String orderId);

    int updateByPrimaryKey(OrderBase record);

    int updateBatch(List<OrderBase> list);

    int batchInsert(List<OrderBase> list);

    PageInfo<OrderBase> findOrderListPage(OrderRequestVo orderRequestVo);
}
