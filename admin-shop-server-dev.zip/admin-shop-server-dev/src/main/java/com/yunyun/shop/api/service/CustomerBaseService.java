package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.CustomerBase;
import com.yunyun.shop.api.pojo.vo.CustomerRequestVo;
import com.yunyun.shop.api.pojo.vo.UpdateCustomer;
import com.yunyun.shop.common.model.ResultBody;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-29 16:29
 */
public interface CustomerBaseService {


    int deleteByPrimaryKey(String customerId);

    int insert(CustomerBase record);

    CustomerBase selectByPrimaryKey(String customerId);

    int updateByPrimaryKey(CustomerBase record);

    /**
     * @description 条件分页查询会员信息
     * @auther PuYaDong
     * @date 2020-06-30 09:39
     * @param customerRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.CustomerBase>
     */
    PageInfo<CustomerBase> findCustomerListPage(CustomerRequestVo customerRequestVo);

    /**
     * @description 修改等级和备注
     * @auther PuYaDong
     * @date 2020-06-30 09:52
     * @param updateCustomer
     * @return int
     */
    int updateCustomerLevelAndNote(UpdateCustomer updateCustomer);
}
