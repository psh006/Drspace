package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.OrderDetail;

import java.util.List;

public interface OrderDetailService{


    int deleteByPrimaryKey(String orderDetailId);

    int insert(OrderDetail record);

    OrderDetail selectByPrimaryKey(String orderDetailId);

    int updateByPrimaryKey(OrderDetail record);

    /**
     * 跟据订单ID查询所有商品信息
     * @param orderId
     * @return
     */
    List<OrderDetail> orderdetailList(String orderId);

    /**
     * 批量修改（发货）
     * @param orderdetail
     * @return
     */
    int updateBatch(List<OrderDetail> orderdetail);
}
