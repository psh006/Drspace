package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.SysMenu;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SysMenuMapper {
    int deleteByPrimaryKey(String menuId);

    int insert(SysMenu record);

    SysMenu selectByPrimaryKey(String menuId);

    int updateByPrimaryKey(SysMenu record);

    int updateBatch(List<SysMenu> list);

    int batchInsert(@Param("list") List<SysMenu> list);

    List<SysMenu> queryAll();

    int deleteMenu(String id);

    List<String> selectSubMenu(@Param("menuIds") List<String> menuIds);

    List<SysMenu> selectMenuByRole(String roleId);
}