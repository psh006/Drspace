package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.ChildGoods;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-16 13:52
 */
public interface ChildGoodsMapper {
    int deleteByPrimaryKey(String goodsId);

    int insert(ChildGoods record);

    int updateByPrimaryKey(ChildGoods record);

    List<ChildGoods> queryGoodsStock(String parentGoodsId);

    List<ChildGoods> queryChildGoodsByParentGoodsId(@Param("parentGoodsId") String parentGoodsId);

    int batchInsert(@Param("list") List<ChildGoods> list);

    int updateBatch(@Param("list") List<ChildGoods> list);

    int deleteByParentGoodsId(String parentGoodsId);
}