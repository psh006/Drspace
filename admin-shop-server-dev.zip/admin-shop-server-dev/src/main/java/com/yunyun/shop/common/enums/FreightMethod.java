package com.yunyun.shop.common.enums;

public enum FreightMethod {
    //按件数
    BY_PIECE(1,"按件数"),
    //按重量
    BY_WEIGHT(2,"按重量"),
    //按体积
    BY_VOLUME(3,"按体积");

    private int code;
    private String desc;

    FreightMethod(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
