package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-19 16:22
 */
@Data
@ApiModel(value = "员工管理分页搜索参数")
public class EmpRequestVo extends PageParams implements Serializable {

    /**
     * 员工姓名
     */
    @ApiModelProperty(value = "员工姓名(模糊查询)")
    private String empName;

    /**
     * 员工状态，USER_STATE
     */
    @ApiModelProperty(value = "员工状态，USER_STATE")
    private Integer empState;

    /**
     * 登录账号，手机号或邮箱
     */
    @ApiModelProperty(value = "登录账号，手机号或邮箱")
    private String loginCode;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String mobilePhone;

    /**
     * 性别，GENDER
     */
    @ApiModelProperty(value = "性别，GENDER")
    private Integer gender;

    /**
     * 部门编号
     */
    @ApiModelProperty(value = "部门编号")
    private String sectorId;

    /**
     * 角色编号
     */
    @ApiModelProperty(value = "角色编号")
    private String roleId;
}
