package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.api.pojo.entity.GoodsBase;
import com.yunyun.shop.mapper.GoodsBaseMapper;
import com.yunyun.shop.api.service.GoodsBaseService;

import java.util.List;

@Service
public class GoodsBaseServiceImpl implements GoodsBaseService{

    @Resource
    private GoodsBaseMapper goodsBaseMapper;

    @Override
    public int deleteByPrimaryKey(String goodsId) {
        return goodsBaseMapper.deleteByPrimaryKey(goodsId);
    }

    @Override
    public int insert(GoodsBase record) {
        return goodsBaseMapper.insert(record);
    }

    @Override
    public GoodsBase selectByPrimaryKey(String goodsId) {
        return goodsBaseMapper.selectByPrimaryKey(goodsId);
    }

    @Override
    public int updateByPrimaryKey(GoodsBase record) {
        return goodsBaseMapper.updateByPrimaryKey(record);
    }

    @Override
    public PageInfo<GoodsBase> findInPage(GoodsRequestVo goodsRequestVo) {
        PageHelper.startPage(goodsRequestVo.getPage(),goodsRequestVo.getLimit());
        List<GoodsBase> goodsBaseList = goodsBaseMapper.queryGoodsList(goodsRequestVo);
        PageInfo<GoodsBase> pageInfo = new PageInfo<>(goodsBaseList);
        return pageInfo;
    }

    @Override
    public int deleteSeveralGoods(List<String> goodsIds) {
        return goodsBaseMapper.deleteSeveralGoods(goodsIds);
    }

    @Override
    public int deleteLogicGoodsById(List<String> goodsIds) {
        return goodsBaseMapper.deleteLogicGoodsById(goodsIds);
    }

    @Override
    public PageInfo<GoodsBase> selectRecycleGoods(GoodsRequestVo goodsRequestVo) {
        PageHelper.startPage(goodsRequestVo.getPage(),goodsRequestVo.getLimit());
        List<GoodsBase> goodsBaseList = goodsBaseMapper.selectRecycleGoods(goodsRequestVo);
        PageInfo<GoodsBase> pageInfo = new PageInfo<>(goodsBaseList);
        return pageInfo;
    }

    @Override
    public int recoverGoods(List<String> goodsIds) {
        return goodsBaseMapper.recoverGoods(goodsIds);
    }

}
