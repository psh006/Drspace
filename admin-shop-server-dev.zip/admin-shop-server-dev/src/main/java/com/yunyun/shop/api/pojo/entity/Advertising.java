package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * @description 广告实体
 * @author PuYaDong
 * @createTime 2020-06-30 14:00
 */
@ApiModel(value="广告实体")
@Data
public class Advertising implements Serializable {
    /**
    * 广告编号
    */
    @ApiModelProperty(value="广告编号")
    private String adId;

    /**
    * 广告标题
    */
    @ApiModelProperty(value="广告标题")
    private String adTitle;

    /**
     * 广告图片
     */
    @ApiModelProperty(value="广告图片")
    private String adImage;

    /**
    * 广告位置，AD_POSITION
    */
    @ApiModelProperty(value="广告位置，AD_POSITION")
    private Integer adPosition;

    /**
    * 显示状态，SHOW_STATE
    */
    @ApiModelProperty(value="显示状态，SHOW_STATE")
    private Integer adState;

    /**
    * 关联商品编号
    */
    @ApiModelProperty(value="关联商品编号")
    private String goodsId;

    /**
     * 排序
     */
    @ApiModelProperty(value="排序")
    private Integer sort;

    /**
    * 操作人编号
    */
    @JsonIgnore
    @ApiModelProperty(value="操作人编号")
    private String operateId;

    /**
     * 操作人姓名
     */
    @JsonIgnore
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @JsonIgnore
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 更新时间
    */
    @JsonIgnore
    @ApiModelProperty(value="更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}