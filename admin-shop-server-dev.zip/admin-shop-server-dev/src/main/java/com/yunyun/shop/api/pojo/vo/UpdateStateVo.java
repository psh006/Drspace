package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-24 09:59
 */
@Data
public class UpdateStateVo implements Serializable {

    /**
     * 员工编号
     */
    @NotBlank(message = "员工编号不能为空")
    @ApiModelProperty(value="员工编号")
    private String empId;

    /**
     * 员工状态，USER_STATE
     */
    @NotNull(message = "员工状态不能为空")
    @ApiModelProperty(value="员工状态，USER_STATE")
    private Integer empState;
}
