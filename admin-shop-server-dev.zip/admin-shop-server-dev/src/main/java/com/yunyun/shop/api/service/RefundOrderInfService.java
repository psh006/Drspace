package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.api.pojo.vo.AgreeRefundVo;
import com.yunyun.shop.api.pojo.vo.RefundAddress;
import com.yunyun.shop.common.model.ResultBody;

import java.util.List;
import java.util.Map;

/**
 * 退款订单
 */
public interface RefundOrderInfService {
    /**
     * 同意退款，获取收货地址
     * @param
     * @return
     */
    List<RefundAddress> afterSalesReceivingAddress();

    /**
     * @description 获取订单信息
     * @auther zzd
     * @date 2020-06-19 11:41
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.entity.OrderBase
     */
    OrderDetail getOderInfByOrderId(String orderDetailId);

    /**
     * @description  根据子订单编号获取退款单信息
     * @auther zzd
     * @date 2020-06-19 13:40
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.entity.OrderDetail
     */
    RefundRecord orderDetailInf(String orderDetailId);

    /**
     * @description 退款处理-同意/拒绝/批量同意/批量拒绝
     * @auther zzd
     * @date 2020-06-19 14:18
     * @param agreeRefundVoList
     * @return java.lang.Object
     */
    int refundProcessing(List<AgreeRefundVo> agreeRefundVoList);
}
