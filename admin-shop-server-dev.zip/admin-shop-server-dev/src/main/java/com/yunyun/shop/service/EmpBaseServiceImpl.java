package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.vo.EmpRequestVo;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.pojo.vo.UpdateStateVo;
import com.yunyun.shop.api.service.EmpBaseService;
import com.yunyun.shop.api.service.EmpTokenService;
import com.yunyun.shop.common.enums.UserState;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.mapper.EmpBaseMapper;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Transactional(rollbackFor = Exception.class)
@Service
public class EmpBaseServiceImpl implements EmpBaseService {

    @Resource
    private EmpBaseMapper empBaseMapper;

    @Autowired
    private EmpTokenService empTokenService;

    /**
     * @description 删除员工
     * @auther PuYaDong
     * @date 2020-06-24 13:06
     * @param empId
     * @return int
     */
    @Override
    public int deleteByPrimaryKey(String empId) {
        // TODO: 删除关联关系
        empTokenService.deleteByEmpId(empId);
        return empBaseMapper.deleteByPrimaryKey(empId);
    }

    @Override
    public int insert(EmpBase record) {
        return empBaseMapper.insert(record);
    }

    @Override
    public EmpBase selectByPrimaryKey(String empId) {
        return empBaseMapper.selectByPrimaryKey(empId);
    }

    @Override
    public int updateByPrimaryKey(EmpBase record) {
        return empBaseMapper.updateByPrimaryKey(record);
    }

    @Override
    public int updateBatch(List<EmpBase> list) {
        return empBaseMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<EmpBase> list) {
        return empBaseMapper.batchInsert(list);
    }

    @Override
    public EmpBase login(String loginCode) {
        return empBaseMapper.selectByLoginCode(loginCode);
    }

    /**
     * @param empRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.EmpBase>
     * @description 员工分页搜索列表
     * @auther PuYaDong
     * @date 2020-06-19 16:27
     */
    @Override
    public PageInfo<EmpBase> findEmpListPage(EmpRequestVo empRequestVo) {
        PageHelper.startPage(empRequestVo.getPage(),empRequestVo.getLimit());
        List<EmpBase> orderBaseList = empBaseMapper.query(empRequestVo);
        return new PageInfo<>(orderBaseList);
    }

    /**
     * @param empBase
     * @return void
     * @description 添加员工信息
     * @auther PuYaDong
     * @date 2020-06-19 16:55
     */
    @Override
    public int add(EmpBase empBase) {
        // 判断账号是否存在
        if(this.isLoginCodeExist(empBase)){
            throw new AlertException("添加失败，账号已存在");
        }
        empBase.setEmpId(IdWorker.getIdStr());
        // 设置默认可用
        empBase.setEmpState(UserState.NORMAL.getValue());
        // 设置操作信息
        EmpUserDetail user = AuthHelper.getUser();
        empBase.setOperateId(user.getEmpId());
        empBase.setOperateName(user.getEmpName());
        empBase.setOperateTime(new Date());
        // 密码加密
        String originalPassword = "123456";
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        empBase.setLoginPass(bCryptPasswordEncoder.encode(originalPassword));
        return empBaseMapper.insert(empBase);
    }

    /**
     * @param empBase
     * @return void
     * @description 修改员工信息
     * @auther PuYaDong
     * @date 2020-06-19 16:55
     */
    @Override
    public int update(EmpBase empBase) {
        // 判断账号是否存在
        if(this.isLoginCodeExist(empBase)){
            throw new AlertException("修改失败，账号已存在");
        }
        return empBaseMapper.updateByPrimaryKey(empBase);
    }

    /**
     * @param updateStateVo
     * @return void
     * @description 修改状态
     * @auther PuYaDong
     * @date 2020-06-24 10:04
     */
    @Override
    public int updateState(UpdateStateVo updateStateVo) {
        return empBaseMapper.updateState(updateStateVo);
    }

    /**
     * @param operateIdVo
     * @return void
     * @description 重置密码
     * @auther PuYaDong
     * @date 2020-06-24 10:04
     */
    @Override
    public int resetPassword(OperateIdVo operateIdVo) {
        String originalPassword = "123456";
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String encodeOriginalPassword = bCryptPasswordEncoder.encode(originalPassword);
        return empBaseMapper.updateLoginPass(operateIdVo.getId(), encodeOriginalPassword);
    }

    /**
     * @param empId
     * @return int
     * @description 更新最后一次登录时间
     * @auther PuYaDong
     * @date 2020-06-24 12:09
     */
    @Override
    public int refreshLastLoginTime(String empId) {
        return empBaseMapper.updateLastLoginTime(empId,new Date());
    }

    /**
     * @param empBase
     * @return boolean true-已存在 false-不存在
     * @description 登录账号是否存在，排除自己
     * @auther PuYaDong
     * @date 2020-06-29 14:02
     */
    @Override
    public boolean isLoginCodeExist(EmpBase empBase) {
        return empBaseMapper.isLoginCodeExist(empBase) > 0;
    }
}

