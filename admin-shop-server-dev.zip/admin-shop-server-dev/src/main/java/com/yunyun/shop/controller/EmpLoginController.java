package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.entity.EmpToken;
import com.yunyun.shop.api.pojo.vo.LoginRequestVo;
import com.yunyun.shop.api.service.EmpBaseService;
import com.yunyun.shop.api.service.EmpTokenService;
import com.yunyun.shop.common.constants.CommonConstants;
import com.yunyun.shop.common.enums.LoginType;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.BeanConvertUtils;
import com.yunyun.shop.cache.LoginCache;
import com.yunyun.shop.util.AuthHelper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.UUID;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-11 17:41
 */
@Api(tags = "员工登录")
@RestController
public class EmpLoginController {

    @Resource(name = "userDetailServiceImpl")
    private UserDetailsService userDetailsService;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    private EmpTokenService empTokenService;

    @Autowired
    private EmpBaseService empBaseService;

    @Autowired
    private LoginCache loginCache;

    /**
     * @param loginRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.EmpUser>
     * @description 员工登录
     * @auther PuYaDong
     * @date 2020-06-12 15:47
     */
    @ApiOperation("登录")
    @PostMapping("/empLogin")
    public ResultBody<EmpUserDetail> empLogin(@RequestBody @Validated LoginRequestVo loginRequestVo)
            throws AuthenticationException {

        if (loginRequestVo.getLoginType() == null) {
            loginRequestVo.setLoginType(LoginType.PC.getValue());
        }

        // 登录生成token
        EmpUserDetail empUserDetail = generateToken(loginRequestVo.getLoginCode(), loginRequestVo.getLoginPass(),
                loginRequestVo.getLoginType());

        // 清除之前的token
        EmpToken oldToken = empTokenService.selectByPrimaryKey(empUserDetail.getEmpId(), loginRequestVo.getLoginType());
        if (oldToken != null) {
            loginCache.delete(oldToken.getLoginToken());
        }
        empTokenService.deleteByEmpIdAndLoginType(empUserDetail.getEmpId(), loginRequestVo.getLoginType());

        // 添加token记录
        EmpToken empToken = new EmpToken();
        empToken.setEmpId(empUserDetail.getEmpId());
        empToken.setLoginType(loginRequestVo.getLoginType());
        empToken.setLoginToken(empUserDetail.getLoginToken());
        empToken.setLoginTime(new Date());

        empTokenService.insert(empToken);

        // 刷新最后一次登录时间
        empBaseService.refreshLastLoginTime(empUserDetail.getEmpId());

        return ResultBody.ok(empUserDetail);
    }

    /**
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 退出登录
     * @auther PuYaDong
     * @date 2020-06-12 17:04
     */
    @ApiOperation("登出")
    @PostMapping("/empLogout")
    public ResultBody<Void> empLogout(HttpServletRequest request) {
        // 删除数据库中的token
        EmpUserDetail empUserDetail = AuthHelper.getUser();
        if (empUserDetail != null) {
            // 登录类型，默认PC端
            int loginType = empUserDetail.getLoginType() == null ?
                    LoginType.PC.getValue() : empUserDetail.getLoginType();
            // 清除token
            empTokenService.deleteByEmpIdAndLoginType(empUserDetail.getEmpId(), loginType);
        }

        // 删除缓存中的token
        String authHeader = request.getHeader(CommonConstants.TOKEN_HEADER);
        if (authHeader != null && authHeader.startsWith(CommonConstants.TOKEN_PREFIX)) {
            final String authToken = authHeader.substring(CommonConstants.TOKEN_PREFIX.length());
            if (authToken != null && loginCache.isLogin(authToken)) {
                loginCache.delete(authToken);
            }
        }
        return ResultBody.ok();
    }

    /**
     * 登陆与授权.
     *
     * @param loginCode .
     * @param loginPass .
     * @return
     */
    private EmpUserDetail generateToken(String loginCode, String loginPass, int loginType) {
        UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken(loginCode, loginPass);
        // Perform the security
        final Authentication authentication = authenticationManager.authenticate(upToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        // Reload password post-security so we can generate token
        final EmpUserDetail empUserDetail = (EmpUserDetail) userDetailsService.loadUserByUsername(loginCode);
        // 持久化的redis
        String token = UUID.randomUUID().toString();
        empUserDetail.setLoginToken(token);
        empUserDetail.setLoginType(loginType);
        empUserDetail.setLoginPass(null);
        loginCache.setUserInfo(token, BeanConvertUtils.convertBean(empUserDetail, EmpBase.class));
        // TODO: 权限列表
        // loginCache.setUserMenuList(token,empUserDetail.getSysRoleList());
        return empUserDetail;
    }
}
