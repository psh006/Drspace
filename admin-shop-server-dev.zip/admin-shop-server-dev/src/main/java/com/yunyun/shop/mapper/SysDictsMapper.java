package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.SysDicts;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-13 15:35
 */
public interface SysDictsMapper {

    List<SysDicts> selectAll();

    int insert(SysDicts sysDicts);

    int delete(String dictId);

    int update(SysDicts sysDicts);

    int isDictUnique(SysDicts sysDicts);
}