package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;

/**
 * @author PuYaDong
 * @description 子物品表
 * @createTime 2020-06-16 13:52
 */
@ApiModel(value = "子物品实体")
@Data
public class ChildGoods implements Serializable {
    /**
     * 物品编号
     */
    @ApiModelProperty(value = "物品编号")
    private String goodsId;

    /**
     * 物品名称
     */
    @Length(groups = {Insert.class, Update.class}, min = 1, max = 40, message = "物品名称须在1~40个字数之间")
    @ApiModelProperty(value = "物品名称")
    private String goodsName;

    /**
     * 物品描述
     */
    @Length(groups = {Insert.class, Update.class}, max = 200, message = "物品描述不超过200字")
    @ApiModelProperty(value = "物品描述")
    private String goodsDescription;

    /**
     * 关联物品类别编号
     */
    @ApiModelProperty(value = "关联物品类别编号", readOnly = true)
    private String goodsCategoryId;

    /**
     * 关联物品类别名称
     */
    @ApiModelProperty(value = "关联物品类别名称", readOnly = true)
    private String goodsCategoryName;

    /**
     * 关联主物品编号
     */
    @ApiModelProperty(value = "关联主物品编号")
    private String parentGoodsId;

    /**
     * 物品规格md5值
     */
    @ApiModelProperty(value = "物品规格md5值",readOnly = true)
    private String goodsSpecMd5;

    /**
     * 物品规格，json字符串
     */
    @NotBlank(groups = {Insert.class, Update.class}, message = "物品规格不能为空")
    @ApiModelProperty(value = "物品规格")
    private String goodsSpec;

    /**
     * 单价
     */
    @ApiModelProperty(value = "单价")
    private BigDecimal goodsPrice;

    /**
     * 库存
     */
    @Range(groups = {Insert.class, Update.class}, min = 0, message = "库存数量须大于等于0")
    @ApiModelProperty(value = "库存")
    private Integer goodsStock;

    /**
     * 库存预警触发条件，INT
     */
    @Range(groups = {Insert.class, Update.class}, min = 0, message = "库存预警触发条件须大于等于0")
    @ApiModelProperty(value = "库存预警触发条件，INT")
    private Integer goodsStockWarn;

    /**
     * 真实销量
     */
    @ApiModelProperty(value = "真实销量", readOnly = true)
    private Integer salesVolumeReal;

    /**
     * 单件重量
     */
    @ApiModelProperty(value = "单件重量")
    private BigDecimal goodsWeight;

    /**
     * 单件体积
     */
    @ApiModelProperty(value = "单件体积")
    private BigDecimal goodsVolume;

    /**
     * 物品封面
     */
    /*@NotBlank(groups = {Insert.class, Update.class},message = "物品封面不能为空")*/
    @ApiModelProperty(value = "物品封面")
    private String goodsCover;

    /**
     * 物品图片，多个以逗号隔开
     */
    @ApiModelProperty(value = "物品图片，多个以逗号隔开")
    private String goodsImage;

    /**
     * 操作人id
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人id")
    private String operateId;

    /**
     * 操作人姓名
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 修改时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    /**
     * 逻辑删除 YES_NO 1是 2否
     */
    @JsonIgnore
    @ApiModelProperty(value = "逻辑删除 YES_NO 1是 2否")
    private Integer isDelete;

    private static final long serialVersionUID = 1L;
}