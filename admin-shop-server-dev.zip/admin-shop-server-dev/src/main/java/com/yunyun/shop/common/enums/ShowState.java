package com.yunyun.shop.common.enums;

public enum ShowState {
    //显示
    DISPLAY(1,"显示"),
    //隐藏
    HIDE(2,"隐藏");

    private int code;
    private String desc;

    ShowState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
