package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

/**
 * @description 数据字典子实体
 * @author PuYaDong
 * @createTime 2020-06-13 15:41
 */
@ApiModel(value="数据字典子实体")
@Data
public class SysDictItems implements Serializable {
    /**
    * 子项编号
    */
    @ApiModelProperty(value="子项编号")
    private String itemId;

    /**
    * 字典编号
    */
    @NotBlank(message = "字典编号不能为空")
    @ApiModelProperty(value="字典编号")
    private String dictId;

    /**
    * 子项名称
    */
    @NotBlank(message = "子项名称不能为空")
    @Length(max = 120, message = "子项名称不能超过120个字符")
    @ApiModelProperty(value="子项名称")
    private String itemName;

    /**
    * 子项值
    */
    @NotBlank(message = "子项值不能为空")
    @Length(max = 120, message = "子项值不能超过120个字符")
    @ApiModelProperty(value="子项值")
    private String itemVal;

    /**
    * 子项排序
    */
    @Max(value = 9999,message = "排序不能超过9999")
    @ApiModelProperty(value="子项排序")
    private Integer itemSort;

    /**
    * 备注
    */
    @Length(max = 150,message = "备注不能超过150个字")
    @ApiModelProperty(value="备注")
    private String itemNote;

    private static final long serialVersionUID = 1L;
}