package com.yunyun.shop.common.enums;

public enum IntegralRecordType {
    SYSTEM_GIFT(1,"系统赠送"),
    SHOPPING_REWARDS(2,"购物奖励"),
    REDEEM_COUPONS(3,"兑换优惠券"),
    OFFSET_CASH(4,"抵扣现金");
    private int code;
    private String desc;

    IntegralRecordType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
