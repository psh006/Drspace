package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @description 客户实体
 * @author PuYaDong
 * @createTime 2020-06-29 16:29
 */
@ApiModel(value="客户实体")
@Data
public class CustomerBase implements Serializable {
    /**
    * 客户编号
    */
    @ApiModelProperty(value="客户编号")
    private String customerId;

    /**
    * 昵称
    */
    @ApiModelProperty(value="昵称")
    private String customerNickName;

    /**
    * 头像
    */
    @ApiModelProperty(value="头像")
    private String customerHeadImg;

    /**
    * openID
    */
    @ApiModelProperty(value="openID")
    private String openId;

    /**
    * 姓名
    */
    @ApiModelProperty(value="姓名")
    private String customerName;

    /**
    * 手机号
    */
    @ApiModelProperty(value="手机号")
    private String customerPhone;

    /**
    * 性别，GENDER
    */
    @ApiModelProperty(value="性别，GENDER")
    private Integer customerGender;

    /**
    * 出生日期，年月日
    */
    @ApiModelProperty(value="出生日期，年月日")
    private Date customerBirthday;

    /**
    * customer_address
    */
    @ApiModelProperty(value="customer_address")
    private String customerAddress;

    /**
    * 客户等级编号
    */
    @ApiModelProperty(value="客户等级编号")
    private String customerLevelId;

    /**
    * 客户等级名称
    */
    @ApiModelProperty(value="客户等级名称")
    private String customerLevelName;

    /**
    * 总下单量
    */
    @ApiModelProperty(value="总下单量")
    private Integer orderCount;

    /**
    * 总消费金额
    */
    @ApiModelProperty(value="总消费金额")
    private BigDecimal expendCount;

    /**
    * 总积分
    */
    @ApiModelProperty(value="总积分")
    private Integer integralTotal;

    /**
    * 剩余积分
    */
    @ApiModelProperty(value="剩余积分")
    private Integer integralBalance;

    /**
    * 备注
    */
    @ApiModelProperty(value="备注")
    private String note;

    /**
    * 操作人id
    */
    @JsonIgnore
    @ApiModelProperty(value="操作人id")
    private String operateId;

    /**
    * 操作人姓名
    */
    @JsonIgnore
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @JsonIgnore
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 修改时间
    */
    @JsonIgnore
    @ApiModelProperty(value="修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}