package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.CommentsInfo;
import com.yunyun.shop.api.pojo.dto.GoodsCommentDTO;
import com.yunyun.shop.api.pojo.vo.CommentIdVo;
import com.yunyun.shop.api.pojo.vo.GoodsCommentRequestVo;
import com.yunyun.shop.api.service.GoodsCommentService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author lxl
 * @Classname GoodsCommentController
 * @Description TODO
 * @Date 2020/6/15 10:15
 */

@Api(tags = "商品评价")
@RestController
@RequestMapping("/goodsComment")
public class GoodsCommentController {

    @Autowired
    private GoodsCommentService goodsCommentService;


    /**
     * @Description: 商品评价
     * @params: [goodsCommentRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.dto.GoodsCommentDTO>>
     * @Author: lxl
     * @Date : 2020/6/16 10:29
     */
    @ApiOperation("商品评价")
    @PostMapping("/queryCommentList")
    public ResultBody<List<GoodsCommentDTO>> queryCommentList(@RequestBody GoodsCommentRequestVo goodsCommentRequestVo) {
        PageInfo<GoodsCommentDTO> pageInfo = goodsCommentService.queryComment(goodsCommentRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }


    /**
     * @Description: 评价详情查看
     * @params: [goodsCommentRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.CommentsInfo>>
     * @Author: lxl
     * @Date : 2020/6/17 11:20
     */
    @ApiOperation("回收站查看")
    @PostMapping("/queryCommentsIsDelete")
    public ResultBody<List<CommentsInfo>> queryCommentsIsDelete(@RequestBody GoodsCommentRequestVo goodsCommentRequestVo) {
        PageInfo<CommentsInfo> commentsInfoPageInfo = goodsCommentService.queryCommentsIsDelete(goodsCommentRequestVo);
        return ResultBody.ok(commentsInfoPageInfo.getList(), commentsInfoPageInfo.getTotal());
    }


    /**
     * @Description: 评价详情查看
     * @params: [goodsCommentRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.CommentsInfo>>
     * @Author: lxl
     * @Date : 2020/6/17 11:20
     */
    @ApiOperation("评价详情")
    @PostMapping("/queryCommentInfo")
    public ResultBody<List<CommentsInfo>> queryCommentInfo(@RequestBody GoodsCommentRequestVo goodsCommentRequestVo) {
        PageInfo<CommentsInfo> commentsInfoPageInfo = goodsCommentService.queryCommentsInfo(goodsCommentRequestVo);
        return ResultBody.ok(commentsInfoPageInfo.getList(), commentsInfoPageInfo.getTotal());
    }

    /**
     *
     * @Description:  置顶评价
     * @params: [commentId]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/17 15:20
     */
    @ApiOperation(value = "置顶评价")
    @PostMapping("/isTop")
    public ResultBody isTop(@RequestBody  CommentIdVo CommentIdVo) {
        String commentId = CommentIdVo.getCommentId();
        if (commentId == null || commentId.isEmpty()) {
            return ResultBody.failed("请选择要置顶的评价");
        }
        int i = goodsCommentService.updateIsTop(commentId);
        return i > 0 ? ResultBody.ok().msg("置顶成功") : ResultBody.failed("置顶失败");
    }


    /**
     *
     * @Description:  取消置顶评价
     * @params: [commentId]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/17 15:20
     */
    @ApiOperation(value = "取消置顶评价")
    @PostMapping("/noTop")
    public ResultBody noTop(@RequestBody CommentIdVo CommentIdVo) {
        String commentId = CommentIdVo.getCommentId();
        if (commentId == null || commentId.isEmpty()) {
            return ResultBody.failed("请选择要取消置顶的评价");
        }
        int i = goodsCommentService.updateNoTop(commentId);
        return i > 0 ? ResultBody.ok().msg("取消置顶成功") : ResultBody.failed("取消置顶失败");
    }


    /**
     *
     * @Description:  批量放入回收站
     * @params: [commentId]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/17 15:20
     */
    @ApiOperation(value = "批量放入回收站")
    @PostMapping("/updateIsDeleteMany")
    public ResultBody updateIsDeleteMany(@RequestBody   CommentIdVo CommentIdVo) {
        List<String> commentIds = CommentIdVo.getCommentIds();
        if (commentIds == null || commentIds.isEmpty()) {
            return ResultBody.failed("请选择要删除的物品");
        }
        int i = goodsCommentService.updateIsDeleteMany(commentIds);
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }


    /**
     *
     * @Description:  批量恢复
     * @params: [commentId]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/17 15:20
     */
    @ApiOperation(value = "批量恢复")
    @PostMapping("/updateNoDeleteMany")
    public ResultBody updateNoDeleteMany(@RequestBody  CommentIdVo CommentIdVo) {
        List<String> commentIds = CommentIdVo.getCommentIds();
        if (commentIds == null || commentIds.isEmpty()) {
            return ResultBody.failed("请选择要删除的物品");
        }
        int i = goodsCommentService.updateNoDeleteMany(commentIds);
        return i > 0 ? ResultBody.ok().msg("恢复成功") : ResultBody.failed("恢复失败");
    }


    /**
     *
     * @Description:  批量删除
     * @params: [commentId]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/17 15:20
     */
    @ApiOperation(value = "批量删除")
    @PostMapping("/deleteManyComments")
    public ResultBody deleteManyComments(@RequestBody  CommentIdVo CommentIdVo) {
        List<String> commentIds = CommentIdVo.getCommentIds();
        if (commentIds == null || commentIds.isEmpty()) {
            return ResultBody.failed("请选择要删除的物品");
        }
        int i = goodsCommentService.deleteManyComments(commentIds);
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }


}
