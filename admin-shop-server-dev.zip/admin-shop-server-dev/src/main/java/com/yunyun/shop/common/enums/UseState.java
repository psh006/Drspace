package com.yunyun.shop.common.enums;

public enum UseState {
    ENABLE(1,"启用"),
    DISABLE(2,"禁用");
    private int code;
    private String desc;

    UseState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
