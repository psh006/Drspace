package com.yunyun.shop.common.enums;

/**
 * @ClassName: LoginTypeEnum
 * @Author: chenjialun
 * @Date: 2020/4/11 21:58
 */
public enum LoginType {
    ANDROID_PHONE(1), ANDROID_PAD(2), IOS_PHONE(3), IOS_PAD(4), PC(5);
    private final int value;

    private LoginType(int value) {
        this.value = value;
    }

    public static LoginType valueOf(int value) {
        switch (value) {
            case 1:
                return ANDROID_PHONE;
            case 2:
                return ANDROID_PAD;
            case 3:
                return IOS_PHONE;
            case 4:
                return IOS_PAD;
            case 5:
                return PC;
            default:
                return PC;
        }
    }

    public int getValue() {
        return value;
    }
}
