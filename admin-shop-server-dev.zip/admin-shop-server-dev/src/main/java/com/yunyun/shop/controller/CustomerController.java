package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.CustomerBase;
import com.yunyun.shop.api.pojo.vo.CustomerRequestVo;
import com.yunyun.shop.api.pojo.vo.UpdateCustomer;
import com.yunyun.shop.api.service.CustomerBaseService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description 会员信息接口
 * @createTime 2020-06-29 16:29
 */
@Api(tags = "会员信息")
@RequestMapping("/customer")
@RestController
public class CustomerController {

    @Autowired
    private CustomerBaseService customerBaseService;

    /**
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.CustomerBase>>
     * @description 条件分页查询会员信息
     * @auther PuYaDong
     * @date 2020-06-29 16:32
     */
    @ApiOperation("条件分页查询会员信息")
    @GetMapping("/find")
    public ResultBody<List<CustomerBase>> find(CustomerRequestVo customerRequestVo) {
        PageInfo<CustomerBase> pageInfo = customerBaseService.findCustomerListPage(customerRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @param
     * @return com.yunyun.shop.common.model.ResultBody
     * @description 修改会员信息
     * @auther PuYaDong
     * @date 2020-06-29 17:29
     */
    @ApiOperation("修改会员等级和备注")
    @PostMapping("/updateCustomerLevelAndNote")
    public ResultBody updateCustomerLevelAndNote(@RequestBody @Validated UpdateCustomer updateCustomer) {
        return customerBaseService.updateCustomerLevelAndNote(updateCustomer) > 0 ?
                ResultBody.ok().msg("成功") : ResultBody.failed("失败");
    }
}
