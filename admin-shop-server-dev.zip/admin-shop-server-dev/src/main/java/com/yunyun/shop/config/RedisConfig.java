package com.yunyun.shop.config;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;

/**
 * @author: pandong
 * @description: 登录缓存初始化配置
 * @createTime: 2019-12-19 10:02
 */

@Configuration
public class RedisConfig {

    @Value("${spring.redis.lettuce.pool.maxTotal}")
    private int maxTotal;
    @Value("${spring.redis.lettuce.pool.minIdle}")
    private int minIdle;
    @Value("${spring.redis.lettuce.pool.maxWaitMillis}")
    private int maxWaitMillis;
    @Value("${spring.redis.lettuce.pool.maxIdle}")
    private int maxIdle;

    @Value("${spring.redis.redis-login.database}")
    private int redisLoginDatabase;
    @Value("${spring.redis.redis-login.host}")
    private String redisLoginHost;
    @Value("${spring.redis.redis-login.port}")
    private int redisLoginPort;
    @Value("${spring.redis.redis-login.password}")
    private String redisLoginPassword;
    @Value("${spring.redis.redis-login.timeout}")
    private Long redisLoginTimeout;

    @Value("${spring.redis.redis-data.database}")
    private int redisDataDatabase;
    @Value("${spring.redis.redis-data.host}")
    private String redisDataHost;
    @Value("${spring.redis.redis-data.port}")
    private int redisDataPort;
    @Value("${spring.redis.redis-data.password}")
    private String redisDataPassword;
    @Value("${spring.redis.redis-data.timeout}")
    private Long redisDataTimeout;

    public GenericObjectPoolConfig createPoolConfig() {
        GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
        genericObjectPoolConfig.setMaxTotal(maxTotal);
        genericObjectPoolConfig.setMinIdle(minIdle);
        genericObjectPoolConfig.setMaxIdle(maxIdle);
        genericObjectPoolConfig.setMaxWaitMillis(maxWaitMillis);
        return genericObjectPoolConfig;
    }

    public RedisTemplate createRedisTemplate(RedisStandaloneConfiguration configuration, Long timeout) {

        LettucePoolingClientConfiguration.LettucePoolingClientConfigurationBuilder builder = LettucePoolingClientConfiguration.builder();
        builder.poolConfig(createPoolConfig());
        builder.commandTimeout(Duration.ofSeconds(timeout));

        LettuceConnectionFactory connectionFactory = new LettuceConnectionFactory(configuration, builder.build());
        connectionFactory.afterPropertiesSet();
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);

        GenericJackson2JsonRedisSerializer jackson2JsonRedisSerializer = new GenericJackson2JsonRedisSerializer();
        redisTemplate.setValueSerializer(jackson2JsonRedisSerializer);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();
        return redisTemplate;
    }

    @Bean(name = "loginRedisTemplate")
    public RedisTemplate loginRedisTemplate() {
        RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration();
        configuration.setDatabase(redisLoginDatabase);
        configuration.setHostName(redisLoginHost);
        configuration.setPassword(redisLoginPassword);
        configuration.setPort(redisLoginPort);
        return createRedisTemplate(configuration, redisLoginTimeout);
    }

    @Bean(name = "dataRedisTemplate")
    public RedisTemplate dataRedisTemplate() {
        RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration();
        configuration.setDatabase(redisDataDatabase);
        configuration.setHostName(redisDataHost);
        configuration.setPassword(redisDataPassword);
        configuration.setPort(redisDataPort);
        return createRedisTemplate(configuration, redisDataTimeout);
    }
}
