package com.yunyun.shop.api.pojo;

import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.common.enums.UserState;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo
 * @createTime 2020-06-12 09:08
 */
@Data
public class EmpUserDetail implements UserDetails {

    /**
     * 员工编号
     */
    @ApiModelProperty(value="员工编号")
    private String empId;

    /**
     * 员工姓名
     */
    @ApiModelProperty(value="员工姓名")
    private String empName;

    /**
     * 员工状态，USER_STATE
     */
    @ApiModelProperty(value="员工状态，USER_STATE")
    private Integer empState;

    /**
     * 登录账号，手机号或邮箱
     */
    @ApiModelProperty(value="登录账号，手机号或邮箱")
    private String loginCode;

    /**
     * 登录密码
     */
    @ApiModelProperty(value="登录密码")
    private String loginPass;

    /**
     * 手机号
     */
    @ApiModelProperty(value="手机号")
    private String mobilePhone;

    /**
     * 头像
     */
    @ApiModelProperty(value="头像")
    private String headImg;

    /**
     * 性别，GENDER
     */
    @ApiModelProperty(value="性别，GENDER")
    private Integer gender;

    /**
     * 出生日期，年月日
     */
    @ApiModelProperty(value="出生日期，年月日")
    private Date birthday;

    /**
     * 部门编号
     */
    @ApiModelProperty(value="部门编号")
    private String sectorId;

    /**
     * 部门名称
     */
    @ApiModelProperty(value="部门名称")
    private String sectorName;

    /**
     * 角色编号
     */
    @ApiModelProperty(value="角色编号")
    private String roleId;

    /**
     * 角色名称
     */
    @ApiModelProperty(value="角色名称")
    private String roleName;

    /**
     * 备注
     */
    @ApiModelProperty(value="备注")
    private String note;

    /**
     * 最近登录时间
     */
    @ApiModelProperty(value="最近登录时间")
    private Date lastLoginTime;

    /**
     * 登录token
     */
    @ApiModelProperty(value="登录token")
    private String loginToken;

    /**
     * 登录类型，LOGIN_TYPE
     */
    @ApiModelProperty("登录类型，LOGIN_TYPE")
    private Integer loginType;

    /**
     * 角色列表
     */
    @ApiModelProperty(value="角色列表")
    private List<SysRole> sysRoleList;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> auths = new ArrayList<>();
        List<SysRole> roles = this.getSysRoleList();
        for (SysRole role : roles) {
            auths.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleId()));
        }
        return auths;
    }

    @Override
    public String getPassword() {
        return this.loginPass;
    }

    @Override
    public String getUsername() {
        return this.loginCode;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.empState == UserState.NORMAL.getValue();
    }
}
