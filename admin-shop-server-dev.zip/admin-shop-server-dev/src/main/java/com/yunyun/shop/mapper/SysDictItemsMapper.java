package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.SysDictItems;

import java.util.List;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-13 15:41
 */
public interface SysDictItemsMapper {

    List<SysDictItems> selectAll();

    int update(SysDictItems sysDictItems);

    int delete(String itemId);

    int insert(SysDictItems sysDictItems);

    int deleteByDictId(String dictId);

    int isDictItemUnique(SysDictItems sysDictItems);
}