package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.vo.GoodsCategoryResultVo;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.mapper.GoodsCategoryMapper;
import com.yunyun.shop.api.pojo.entity.GoodsCategory;
import com.yunyun.shop.api.service.GoodsCategoryService;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GoodsCategoryServiceImpl implements GoodsCategoryService{

    @Resource
    private GoodsCategoryMapper goodsCategoryMapper;

    @Override
    public int deleteByPrimaryKey(String goodsCategoryId) {
        return goodsCategoryMapper.deleteByPrimaryKey(goodsCategoryId);
    }

    @Override
    public ResultBody insert(GoodsCategory goodsCategory) {
        //判断排序是否存在
        List<GoodsCategory> categorys = goodsCategoryMapper.selectBySort(goodsCategory);
        if (categorys != null && !categorys.isEmpty()){
            return ResultBody.failed("该排序已存在");
        }
        String id = IdWorker.getIdStr();
        EmpUserDetail user = AuthHelper.getUser();
        goodsCategory.setGoodsCategoryId(id);
        goodsCategory.setOperateId(user.getEmpId());
        goodsCategory.setOperateName(user.getEmpName());
        goodsCategory.setOperateTime(new Date());
        return goodsCategoryMapper.insert(goodsCategory)>0?ResultBody.ok().msg("添加成功") : ResultBody.failed("添加失败");
    }

    @Override
    public GoodsCategory selectByPrimaryKey(String goodsCategoryId) {
        return goodsCategoryMapper.selectByPrimaryKey(goodsCategoryId);
    }

    @Override
    public ResultBody updateByPrimaryKey(GoodsCategory goodsCategory) {
        //判断排序是否存在
        List<GoodsCategory> categorys = goodsCategoryMapper.selectBySort(goodsCategory);
        if (categorys != null && !categorys.isEmpty()){
                return ResultBody.failed("该排序已存在");
        }
        return goodsCategoryMapper.updateByPrimaryKey(goodsCategory)>0?ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    @Override
    public int showGoodsCategory(int isDisplay,List<String> goodsCategoryList) {
        return goodsCategoryMapper.showGoodsCategory(isDisplay,goodsCategoryList);
    }

    @Override
    public List<GoodsCategoryResultVo> queryGoodsCategoryList() {
        List<GoodsCategoryResultVo> goodsCategoryList = goodsCategoryMapper.queryGoodsCategoryList();
        //过滤出所有一级分类
        List<GoodsCategoryResultVo> firstLevelCategory = goodsCategoryList
                .stream()
                .filter(goodsCate -> goodsCate.getParentId() == null||"0".equals(goodsCate.getParentId().trim()))
                .collect(Collectors.toList());
        goodsCategoryList.removeAll(firstLevelCategory);
        return formatGoodsCategory(firstLevelCategory,goodsCategoryList);
    }

    @Override
    public int deleteGoodsCategory(List<String> goodsCategoryList) {
        return goodsCategoryMapper.deleteGoodsCategory(goodsCategoryList);
    }

    /**
     * 格式化分类
     * @auther CheGuangQuan
     * @date 2020/6/15 17:59
     * @param parentCategory
     * @param allCategory
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.vo.GoodsCategoryResultVo>>
     */
    public List<GoodsCategoryResultVo> formatGoodsCategory(List<GoodsCategoryResultVo> parentCategory,List<GoodsCategoryResultVo> allCategory){
        parentCategory.forEach(category->{
            String categoryId = category.getGoodsCategoryId()+"";
            List<GoodsCategoryResultVo> secondLevel = allCategory.stream().filter(c -> categoryId.equals(c.getParentId())).collect(Collectors.toList());
            category.setChildren(secondLevel);
            if (secondLevel != null && !secondLevel.isEmpty()){
                formatGoodsCategory(secondLevel,allCategory);
            }
        });
        return parentCategory;
    }

}
