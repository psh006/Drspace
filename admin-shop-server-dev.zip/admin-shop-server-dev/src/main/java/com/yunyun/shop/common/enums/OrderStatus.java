package com.yunyun.shop.common.enums;

/**
 * @ClassName: OrderStatus
 * @Description:
 * @Author: HuiLiao
 * @Date: 2020/4/5 21:27
 */
public enum OrderStatus {
    //待支付
    UNPAID(1,"待支付"),
    //未发货
    NOT_YET_SHIPPED(2,"未发货"),
    //部分发货
    PART_OF_THE_SHIPMENT(3,"部分发货"),
    //待收货
    WAIT_FOR_RECEIVING(4,"待收货"),
    //已签收
    HAVE_BEEN_SIGNED(5,"已签收"),
    //已完成
    COMPLETED(6,"已完成"),
    //已取消
    CANCELLED(7,"已取消"),
    //部分退款
    PARTIAL_REFUND(8,"部分退款"),
    // 退款中
    REFUNDING(9,"退款中"),
    // 已退款
    REFUNDED(10,"已退款");
    //退款中
    //REFUBDIBG(9),

    private int code;
    private String desc;

    OrderStatus(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }
}
