package com.yunyun.shop.service;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.mapper.OrderDetailMapper;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.service.OrderDetailService;

import java.util.List;

@Service
public class OrderDetailServiceImpl implements OrderDetailService{

    @Resource
    private OrderDetailMapper orderDetailMapper;

    @Override
    public int deleteByPrimaryKey(String orderDetailId) {
        return orderDetailMapper.deleteByPrimaryKey(orderDetailId);
    }

    @Override
    public int insert(OrderDetail record) {
        return orderDetailMapper.insert(record);
    }

    @Override
    public OrderDetail selectByPrimaryKey(String orderDetailId) {
        return orderDetailMapper.selectByPrimaryKey(orderDetailId);
    }

    @Override
    public int updateByPrimaryKey(OrderDetail record) {
        return orderDetailMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<OrderDetail> orderdetailList(String orderId) {//跟据订单ID查询所有商品信息
        /*List<OrderDetail> list = orderDetailMapper.orderdetailList(orderId);
        if (list.size()>0) {//数据校验
            return list;
        }*/
        return orderDetailMapper.orderdetailList(orderId);
    }

    @Override
    public int updateBatch(List<OrderDetail> orderdetail) {
        return orderDetailMapper.updateBatch(orderdetail);
    }

}
