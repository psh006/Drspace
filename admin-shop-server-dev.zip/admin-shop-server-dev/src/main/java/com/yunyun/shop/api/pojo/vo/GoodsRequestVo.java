package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.PositiveOrZero;
import java.io.Serializable;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-12 11:46
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class GoodsRequestVo extends PageParams implements Serializable {

    /**
     * 商品名称
     */
    @ApiModelProperty(value="商品名称")
    private String goodsName;

    /**
     * 关联商品类别编号
     */
    @ApiModelProperty(value="关联商品类别编号")
    private String goodsCategoryId;

    /**
     * 商品属性，GOODS_PROPERTY
     */
    @ApiModelProperty(value="商品属性，GOODS_PROPERTY")
    private Integer goodsProperty;

    /**
     * 上架状态，PUT_STATE（PUT_UP,PUT_DOWN）
     */
    @ApiModelProperty(value="上架状态，PUT_STATE（PUT_UP,PUT_DOWN）")
    private Integer putState;
}