package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.Insert;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-06-11 17:58
 */
@Data
public class LoginRequestVo implements Serializable {

    /**
     * 账号
     */
    @ApiModelProperty(value="账号")
    @NotBlank(message = "账号不能为空")
    private String loginCode;

    /**
     * 密码
     */
    @ApiModelProperty(value="密码")
    @NotBlank(message = "密码不能为空")
    private String loginPass;

    /**
     * 登录类型
     */
    @ApiModelProperty(value="登录类型")
    private Integer loginType;

}
