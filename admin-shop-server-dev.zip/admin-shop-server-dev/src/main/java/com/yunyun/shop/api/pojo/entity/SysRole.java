package com.yunyun.shop.api.pojo.entity;

import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 *
 * @Classname SysRole
 * @Description TODO
 * @Date 2020/6/24 10:31
 * @author lxl
 */

/**
 * 角色表
 */
@ApiModel(value = "com-yunyun-shop-api-pojo-entity-SysRole")
@Data
public class SysRole implements Serializable {
    /**
     * 角色编号
     */
    @NotNull(groups = {Update.class}, message = "编号不能为空")
    @ApiModelProperty(value = "角色编号")
    private String roleId;

    /**
     * 角色名称
     */
    @NotNull(groups = {Insert.class, Update.class}, message = "角色名称不能为空")
    @ApiModelProperty(value = "角色名称")
    private String roleName;

    /**
     * 菜单权限，多个以逗号隔开
     */
    @ApiModelProperty(value = "菜单权限，多个以逗号隔开")
    private String menuIds;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String note;

    private static final long serialVersionUID = 1L;
}