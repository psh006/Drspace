package com.yunyun.shop.cache;

import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.entity.SysDicts;
import com.yunyun.shop.api.pojo.entity.SysMenu;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author: pandong
 * @description: 登录缓存配置
 * @createTime: 2019-12-19 09:58
 */

@Component
public class LoginCache {

    @Resource(name = "loginRedisTemplate")
    private RedisTemplate<String, Object> loginRedisTemplate;

    /**
     * token有效期
     */
    private final static Long EXPIRATION = 60L * 12;

    /**
     * 用户信息
     */
    private final static String USER_INFO = "USER_INFO";

    /**
     * 用户菜单
     */
    private final static String USER_MENU = "USER_MENU";

    /**
     * 用户权限
     */
    private final static String USER_MENU_API = "USER_MENU_API";

    public EmpBase getUserInfo(String loginToken) {
        return (EmpBase)get(loginToken, USER_INFO);
    }

    public SysMenu getUserMenuList( String loginToken) {
        return (SysMenu)get(loginToken, USER_MENU);
    }

    public void  setUserInfo(String loginToken,  EmpBase empBase) {
        set(loginToken, USER_INFO, empBase);
    }

    public void  setUserMenuList(String loginToken, List<SysMenu> userMenuList) {
        set(loginToken, USER_MENU, userMenuList);
    }

    public void delete(String loginToken) {
        loginRedisTemplate.delete(getCacheKey(loginToken, USER_INFO));
        loginRedisTemplate.delete(getCacheKey(loginToken, USER_MENU));
        loginRedisTemplate.delete(getCacheKey(loginToken, USER_MENU_API));
    }

    public boolean isLogin(String token) {
        return get(token, USER_INFO) != null;
    }

    private Object get(String token, String type) {
        String key = getCacheKey(token, type);
        return loginRedisTemplate.opsForValue().get(key);
    }

    private void  set(String token, String type, Object val) {
        String key = getCacheKey(token, type);
        loginRedisTemplate.opsForValue().set(key, val, EXPIRATION, TimeUnit.MINUTES);
    }

    private String getCacheKey(String token, String type) {
        return DigestUtils.md5DigestAsHex((type + token).getBytes());
    }
}
