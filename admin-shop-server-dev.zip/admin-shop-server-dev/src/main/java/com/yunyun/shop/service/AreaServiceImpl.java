package com.yunyun.shop.service;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.mapper.AreaMapper;
import com.yunyun.shop.api.pojo.entity.Area;
import com.yunyun.shop.api.service.AreaService;

import java.util.List;

@Service
public class AreaServiceImpl implements AreaService{

    @Resource
    private AreaMapper areaMapper;

    @Override
    public int deleteByPrimaryKey(String areaId) {
        return areaMapper.deleteByPrimaryKey(areaId);
    }

    @Override
    public int insert(Area record) {
        return areaMapper.insert(record);
    }

    @Override
    public Area selectByPrimaryKey(String areaId) {
        return areaMapper.selectByPrimaryKey(areaId);
    }

    @Override
    public int updateByPrimaryKey(Area record) {
        return areaMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<Area> selectAllList() {
        List<Area> list = areaMapper.selectAllList();
        if (list.size() > 0) {
            return list;
        }
        return null;
    }

    @Override
    public List<Area> selectCityCounty(Area area) {
        List<Area> list = areaMapper.selectCityCounty(area);
        if (list.size() > 0) {
            return list;
        }
        return null;
    }

}
