package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author PuYaDong
 * @description 会员信息查询
 * @createTime 2020-06-30 09:30
 */
@ApiModel(value="客户分页条件查询参数")
@Data
public class CustomerRequestVo extends PageParams implements Serializable {

    /**
     * 客户姓名
     */
    @ApiModelProperty(value="客户姓名")
    private String customerName;

    /**
     * 客户电话
     */
    @ApiModelProperty(value="客户电话")
    private String customerPhone;

    /**
     * 客户等级编号
     */
    @ApiModelProperty(value="客户等级编号")
    private String customerLevelId;
}
