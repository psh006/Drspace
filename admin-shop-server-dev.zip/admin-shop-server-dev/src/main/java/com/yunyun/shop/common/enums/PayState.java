package com.yunyun.shop.common.enums;

public enum PayState {
    UNPAID(1,"待支付"),
    IN_PAYMENT(2,"支付中"),
    PAYMENT_SUCCESSFUL(3,"支付成功"),
    PAYMENT_FAILURE(4,"支付成功");
    private int code;
    private String desc;

    PayState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
