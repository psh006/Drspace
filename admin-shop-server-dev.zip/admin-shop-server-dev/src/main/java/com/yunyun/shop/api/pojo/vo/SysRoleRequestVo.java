package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author lxl
 * @Classname SysRoleRequestVo
 * @Description TODO
 * @Date 2020/6/24 11:00
 */
@Data
public class SysRoleRequestVo extends PageParams implements Serializable {

    private static final long serialVersionUID = 1145329055079413798L;
    @ApiModelProperty(value = "角色编号")
    private String roleId;

    @ApiModelProperty(value = "菜单编号集合")
    private List<String> menuIds;

    @ApiModelProperty(value = "菜单编号")
    private String menuId;


}
