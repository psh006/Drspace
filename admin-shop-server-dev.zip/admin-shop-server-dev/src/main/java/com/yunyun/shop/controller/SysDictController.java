package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysDictItems;
import com.yunyun.shop.api.pojo.entity.SysDicts;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.service.SysDictsService;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.PageParams;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-13 15:32
 */
@Api(tags = "数据字典")
@RequestMapping("/sysDict")
@RestController
public class SysDictController {

    @Autowired
    private SysDictsService sysDictsService;

    /**
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.SysDicts>>
     * @description 所有字典列表
     * @auther PuYaDong
     * @date 2020-06-13 16:17
     */
    @ApiOperation("所有数据字典")
    @GetMapping("/all")
    public ResultBody<List<SysDicts>> all() {
        return ResultBody.ok(sysDictsService.getAllDict());
    }

    /**
     * @param pageParams
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 字典分页
     * @auther PuYaDong
     * @date 2020-06-18 15:13
     */
    @ApiOperation("分页查询字典")
    @GetMapping("/page")
    public ResultBody<List<SysDicts>> page(PageParams pageParams) {
        PageInfo<SysDicts> pageInfo = sysDictsService.page(pageParams);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @param sysDicts
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 添加字典
     * @auther PuYaDong
     * @date 2020-06-18 15:06
     */
    @ApiOperation("添加字典")
    @PostMapping("/add")
    public ResultBody<Void> add(@RequestBody @Validated(Insert.class) SysDicts sysDicts) {
        return sysDictsService.add(sysDicts) > 0 ? ResultBody.ok() : ResultBody.failed("添加失败");
    }

    /**
     * @param sysDicts
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 修改字典
     * @auther PuYaDong
     * @date 2020-06-18 15:13
     */
    @ApiOperation("修改字典")
    @PostMapping("/update")
    public ResultBody<Void> update(@RequestBody @Validated(Update.class) SysDicts sysDicts) {
        return sysDictsService.update(sysDicts) > 0 ? ResultBody.ok() : ResultBody.failed("修改失败");
    }

    /**
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 删除字典
     * @auther PuYaDong
     * @date 2020-06-18 15:13
     */
    @ApiOperation("删除字典")
    @PostMapping("/delete")
    public ResultBody<Void> delete(@RequestBody @Validated OperateIdVo operateIdVo) {
        return sysDictsService.delete(operateIdVo.getId()) > 0 ? ResultBody.ok() : ResultBody.failed("删除失败");
    }

    /**
     * @param sysDictItems
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 添加字典子项
     * @auther PuYaDong
     * @date 2020-06-18 15:16
     */
    @ApiOperation("添加字典子项")
    @PostMapping("/addDictItem")
    public ResultBody<Void> addDictItem(@RequestBody @Validated(Insert.class) SysDictItems sysDictItems) {
        return sysDictsService.addDictItem(sysDictItems) > 0 ? ResultBody.ok() : ResultBody.failed("添加失败");
    }

    /**
     * @param sysDictItems
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 修改字典子项
     * @auther PuYaDong
     * @date 2020-06-18 15:16
     */
    @ApiOperation("修改字典子项")
    @PostMapping("/updateDictItem")
    public ResultBody<Void> updateDictItem(@RequestBody @Validated(Insert.class) SysDictItems sysDictItems) {
        return sysDictsService.updateDictItem(sysDictItems) > 0 ? ResultBody.ok() : ResultBody.failed("修改失败");
    }

    /**
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 删除字典子项
     * @auther PuYaDong
     * @date 2020-06-18 15:16
     */
    @ApiOperation("删除字典子项")
    @PostMapping("/deleteDictItem")
    public ResultBody<Void> deleteDictItem(@RequestBody @Validated OperateIdVo operateIdVo) {
        return sysDictsService.deleteDictItem(operateIdVo.getId()) > 0 ? ResultBody.ok() : ResultBody.failed("删除失败");
    }

}
