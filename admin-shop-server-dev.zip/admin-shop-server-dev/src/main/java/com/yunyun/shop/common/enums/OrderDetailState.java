package com.yunyun.shop.common.enums;

public enum OrderDetailState {
    //待支付
    UNPAID(1,"待支付"),
    //未发货
    NOT_YET_SHIPPED(2,"未发货"),
    //待收货
    WAIT_FOR_RECEIVING(3,"待收货"),
    //已签收
    HAVE_BEEN_SIGNED(4,"已签收"),
    //已完成
    COMPLETED(5,"已完成"),
    //已取消
    CANCELLED(6,"已取消"),
    // 退款中
    REFUNDING(7,"退款中"),
    // 已退款
    REFUNDED(8,"已退款");

    private int code;
    private String desc;

    OrderDetailState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
