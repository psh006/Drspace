package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @description 客户等级实体
 * @author PuYaDong
 * @createTime 2020-06-29 14:41
 */
@ApiModel(value = "客户等级实体")
@Data
public class CustomerLevel implements Serializable {
    /**
     * 等级编号
     */
    @NotBlank(groups = Update.class, message = "等级名称不能为空")
    @ApiModelProperty(value = "等级编号")
    private String customLevelId;

    /**
     * 等级名称
     */
    @NotBlank(message = "等级名称不能为空")
    @ApiModelProperty(value = "等级名称")
    private String customLevelName;

    /**
     * 等级权重
     */
    @NotNull(message = "等级权重不能为空")
    @ApiModelProperty(value = "等级权重")
    private Integer customLevelAuth;

    /**
     * 升级条件，实际消费金额满%元
     */
    @NotNull(message = "升级条件不能为空")
    @Range(min = 0, max = 9999999999L, message = "升级条件超过最大范围")
    @ApiModelProperty(value = "升级条件，实际消费金额满%元")
    private Long customLevelCondition;

    /**
     * 折扣率，0~10，9.5为9.5折，0不打折
     */
    @NotNull(message = "折扣率不能为空")
    @Range(min = 0, max = 10, message = "折扣率应在0~10之间")
    @ApiModelProperty(value = "折扣率，0~10，9.5为9.5折，0不打折")
    private BigDecimal customLevelDiscount;

    /**
     * 等级启用状态，USE_STATE
     */
    @NotNull(message = "启用状态不能为空")
    @Range(min = 1, max = 2, message = "启用状态错误")
    @ApiModelProperty(value = "等级启用状态，USE_STATE")
    private Integer customLevelState;

    /**
     * 操作人id
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人id")
    private String operateId;

    /**
     * 操作人姓名
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 修改时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}