package com.yunyun.shop.common.model;

import com.yunyun.shop.common.constants.CommonConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @author pyd
 * @description 分页参数
 * @createTime 2020-04-22 10:25
 */
@Data
public class PageParams implements Serializable {

    /**
     * 第几页
     */
    @ApiModelProperty(value = "第几页", example = "1")
    private Integer page = CommonConstants.DEFAULT_PAGE;

    /**
     * 每页多少条
     */
    @ApiModelProperty(value = "每页多少条", example = "10")
    private Integer limit = CommonConstants.DEFAULT_LIMIT;

    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startDate;

    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endDate;
}
