package com.yunyun.shop.api.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.dto
 * @createTime 2020-07-02 14:21
 */
@ApiModel("商品编号名称实体")
@Data
public class GoodsIdNameDto implements Serializable {

    /**
     * 商品编号
     */
    @ApiModelProperty(name = "商品编号")
    private String parentGoodsId;

    /**
     * 商品名称
     */
    @ApiModelProperty(name = "商品名称")
    private String parentGoodsName;
}
