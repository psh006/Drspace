package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.RefundAddress;

import java.util.List;

/**
 * @description com.yunyun.shop.api.service
 * @author PuYaDong
 * @createTime 2020-06-28 09:28
 */
public interface RefundAddressService{


    int deleteByPrimaryKey(String receiptAddressId);

    int insert(RefundAddress record);

    /**
     * @description 获取所有收货地址
     * @auther PuYaDong
     * @date 2020-06-28 09:54
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.RefundAddress>
     */
    List<RefundAddress> all();

    /**
     * @param refundAddress
     * @return boolean true-存在 false-不存在
     * @description 收货地址是否唯一
     * @auther PuYaDong
     * @date 2020-06-28 15:22
     */
    boolean isExistAddress(RefundAddress refundAddress);

}
