package com.yunyun.shop.api.service;

import java.util.List;
import com.yunyun.shop.api.pojo.entity.SysMenu;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.common.model.ResultBody;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-12 10:26
 */
public interface SysMenuService {


    int deleteByPrimaryKey(String menuId);

    int insert(SysMenu record);

    SysMenu selectByPrimaryKey(String menuId);

    int updateByPrimaryKey(SysMenu record);

    int updateBatch(List<SysMenu> list);

    int batchInsert(List<SysMenu> list);

    /**
     * 查询所有菜单
     * @auther CheGuangQuan
     * @date 2020/6/19 9:58
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.SysMenu>>
    */
    ResultBody<List<SysMenu>> queryAll();

    /**
     * 删除菜单
     * @auther CheGuangQuan
     * @date 2020/6/19 11:48
     * @param operateIdVo
     * @return int
    */
    int deleteMenu(OperateIdVo operateIdVo);

    ResultBody<List<SysMenu>> selectMenuByRole();
}



