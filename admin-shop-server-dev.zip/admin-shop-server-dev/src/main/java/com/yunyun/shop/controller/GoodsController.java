package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.GoodsIdNameDto;
import com.yunyun.shop.api.pojo.entity.ChildGoods;
import com.yunyun.shop.api.pojo.entity.ParentGoods;
import com.yunyun.shop.api.pojo.vo.GoodsIdVo;
import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.service.ChildGoodsService;
import com.yunyun.shop.api.service.ParentGoodsService;
import com.yunyun.shop.common.enums.PutState;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @program: shop
 * @description: 物品管理接口
 * @author: CheGuangQuan
 * @create: 2020-06-12 11:17
 **/
@Api(tags = "物品管理")
@RestController
@RequestMapping("/goods")
public class GoodsController {

    @Autowired
    private ParentGoodsService parentGoodsService;

    @Autowired
    private ChildGoodsService childGoodsService;

    /**
     * @param parentGoodsId
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.entity.GoodsBase>
     * @auther CheGuangQuan
     * @date 2020/6/12 11:26
     */
    @ApiOperation(value = "根据id查询物品")
    @ApiImplicitParam(name = "parentGoodsId", value = "1", required = true)
    @GetMapping("/queryGoodsById")
    public ResultBody<ParentGoods> queryGoodsById(@RequestParam String parentGoodsId) {
        return ResultBody.ok(parentGoodsService.selectByPrimaryKey(parentGoodsId));
    }

    /**
     * @param goodsRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "根据根据条件分页查询物品")
    @PostMapping("/queryGoodsList")
    public ResultBody<List<ParentGoods>> queryGoodsList(@RequestBody GoodsRequestVo goodsRequestVo) {
        PageInfo<ParentGoods> pageInfo = parentGoodsService.findInPage(goodsRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.entity.GoodsBase>
     * @auther CheGuangQuan
     * @date 2020/6/12 11:26
     */
    @ApiOperation(value = "根据id删除物品(物理删除)")
    @ApiImplicitParam(name = "goodsId", value = "1", required = true)
    @PostMapping("/deleteGoodsById")
    public ResultBody deleteGoodsById(@RequestBody @Validated OperateIdVo operateIdVo) {
        int i = parentGoodsService.deleteByPrimaryKey(operateIdVo.getId());
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");

    }

    /**
     * @param goodsIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/12 14:57
     */
    @ApiOperation(value = "批量删除物品(物理删除)")
    @ApiImplicitParam(name = "goodsIds", value = "1,2,3,4", required = true)
    @PostMapping("/deleteSeveralGoods")
    public ResultBody deleteSeveralGoods(@RequestBody @Validated GoodsIdVo goodsIdVo) {
        List<String> goodsList = goodsIdVo.getGoodsIds();
        int i = parentGoodsService.deleteSeveralGoods(goodsList);
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }

    /**
     * @param goodsIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/12 14:59
     */
    @ApiOperation(value = "批量删除物品(逻辑删除)")
    @ApiImplicitParam(name = "goodsIds", value = "1,2,3,4", required = true)
    @PostMapping("/deleteLogicGoodsById")
    public ResultBody deleteLogicGoodsById(@RequestBody @Validated GoodsIdVo goodsIdVo) {
        List<String> goodsList = goodsIdVo.getGoodsIds();
        int i = parentGoodsService.deleteLogicGoodsById(goodsList);
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }

    /**
     * @param goodsRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "根据根据条件分页查询物品回收站")
    @PostMapping("/selectRecycleGoods")
    public ResultBody<List<ParentGoods>> selectRecycleGoods(@RequestBody GoodsRequestVo goodsRequestVo) {
        PageInfo<ParentGoods> pageInfo = parentGoodsService.selectRecycleGoods(goodsRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @param goodsIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/12 14:59
     */
    @ApiOperation(value = "批量恢复物品")
    @ApiImplicitParam(name = "goodsIds", value = "[1,2,3,4]", required = true)
    @PostMapping("/recoverGoods")
    public ResultBody recoverGoods(@RequestBody @Validated GoodsIdVo goodsIdVo) {
        List<String> goodsList = goodsIdVo.getGoodsIds();
        int i = parentGoodsService.recoverGoods(goodsList);
        return i > 0 ? ResultBody.ok().msg("恢复成功") : ResultBody.failed("恢复失败");
    }

    /**
     * @param goodsIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/12 14:59
     */
    @ApiOperation(value = "上架物品")
    @ApiImplicitParam(name = "goodsIds", value = "1,2,3,4", required = true)
    @PostMapping("/putUpGoods")
    public ResultBody
    putUpGoods(@RequestBody @Validated GoodsIdVo goodsIdVo) {
        List<String> goodsList = goodsIdVo.getGoodsIds();
        parentGoodsService.putGoods(PutState.PUT_UP.getCode(), goodsList);
        return ResultBody.ok().msg("上架成功");
    }

    /**
     * @param goodsIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/12 14:59
     */
    @ApiOperation(value = "下架物品")
    @ApiImplicitParam(name = "goodsIds", value = "1,2,3,4", required = true)
    @PostMapping("/putDownGoods")
    public ResultBody putDownGoods(@RequestBody @Validated GoodsIdVo goodsIdVo) {
        List<String> goodsList = goodsIdVo.getGoodsIds();
        parentGoodsService.putGoods(PutState.PUT_DOWN.getCode(), goodsList);
        return ResultBody.ok().msg("下架成功");
    }

    /**
     * @param parentGoodsId
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/12 14:59
     */
    @ApiOperation(value = "物品库存列表")
    @ApiImplicitParam(name = "parentGoodsId", value = "1", required = true)
    @GetMapping("/queryGoodsStock")
    public ResultBody<List<ChildGoods>> queryGoodsStock(@RequestParam String parentGoodsId) {
        List<ChildGoods> goodsStockList = childGoodsService.queryGoodsStock(parentGoodsId);
        return ResultBody.ok(goodsStockList);
    }

    /**
     * @param parentGoods
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 录入主物品
     * @auther PuYaDong
     * @date 2020-06-16 11:09
     */
    @ApiOperation(value = "录入主物品")
    @PostMapping("/add")
    public ResultBody add(@RequestBody @Validated(value = {Insert.class}) ParentGoods parentGoods) {
        return parentGoodsService.add(parentGoods) > 0 ? ResultBody.ok().msg("录入成功") : ResultBody.failed("录入失败");
    }

    /**
     * @param parentGoods
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 修改主物品
     * @auther PuYaDong
     * @date 2020-06-16 12:23
     */
    @ApiOperation(value = "修改主物品")
    @PostMapping("/update")
    public ResultBody update(@RequestBody @Validated(value = {Update.class}) ParentGoods parentGoods) {
        return parentGoodsService.updateByPrimaryKey(parentGoods) > 0 ? ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * @description 复制物品
     * @auther PuYaDong
     * @date 2020-06-28 09:24
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("复制物品")
    @PostMapping("/copyGoods")
    public ResultBody copyGoods(@RequestBody OperateIdVo operateIdVo) {
        return parentGoodsService.copyGoods(operateIdVo.getId()) > 0 ? ResultBody.ok().msg("复制成功") : ResultBody.failed("复制失败");
    }

    /**
     * @description 获取编号和名称物品列表
     * @auther PuYaDong
     * @date 2020-07-02 14:24
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.dto.GoodsIdNameDto>>
     */
    @ApiOperation(value = "获取编号和名称物品列表",notes = "用于关联广告等")
    @GetMapping("/getGoodsIdNameList")
    public ResultBody<List<GoodsIdNameDto>> getGoodsIdNameList() {
        return ResultBody.ok(parentGoodsService.getGoodsIdNameList());
    }

}