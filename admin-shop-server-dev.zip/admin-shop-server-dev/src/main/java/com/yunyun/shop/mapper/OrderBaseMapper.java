package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.vo.OrderRequestVo;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-11 12:53
 */
@Mapper
public interface OrderBaseMapper {
    int deleteByPrimaryKey(String orderId);

    int insert(OrderBase record);

    OrderBase selectByPrimaryKey(String orderId);

    int updateByPrimaryKey(OrderBase record);

    int updateBatch(List<OrderBase> list);

    int batchInsert(@Param("list") List<OrderBase> list);

    List<OrderBase> query(OrderRequestVo orderRequestVo);
}