package com.yunyun.shop.common.util;

import com.yunyun.shop.common.exception.AlertException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.io.*;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author zzd
 * @description com.yunyun.shop.common.util
 * @createTime 2020-06-23 09:42
 */
@Slf4j
public class UploadUtil {

    /**
     * @param file
     * @return java.lang.Boolean
     * @description 检查是否是 bmp/gif/jpg/png图片
     * @auther zzd
     * @date 2020-06-23 09:50
     */
    public static Boolean checkImg(MultipartFile file) {
        if (file.isEmpty()) {
            return false;
        } else {
            try {
                Image image = ImageIO.read(file.getInputStream());
                return image != null;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    /**
     * @param uploadFile
     * @return java.lang.String
     * @description 图片上传
     * @auther zzd
     * @date 2020-06-23 09:55
     */
    public static String upload(MultipartFile uploadFile, String dirPath) throws IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd/");
        //构建文件上传所要保存的"文件夹路径"--这里是相对路径，保存到项目根路径的文件夹下
        String format = sdf.format(new Date());
        //存放上传文件的文件夹
        File file = new File(dirPath + format);
        if(!file.isDirectory()){
            //递归生成文件夹
            file.mkdirs();
        }
        //获取原始的名字  original:最初的，起始的  方法是得到原来的文件名在客户机的文件系统名称
        String oldName = uploadFile.getOriginalFilename();
        String newName = UUID.randomUUID().toString() + oldName.substring(oldName.lastIndexOf("."),oldName.length());
        //构建真实的文件路径
        File newFile = new File(file.getAbsolutePath() + File.separator + newName);
        //转存文件到指定路径，如果文件名重复的话，将会覆盖掉之前的文件,这里是把文件上传到 “绝对路径”
        uploadFile.transferTo(newFile);
        String filePath = "/upload/" + format + newName;
        return filePath;
    }

    /**
     * @param "http://10.168.1.148:8080/upload/2020/6/23/1592897372738ChMkJlbK5pqIcV7dAAQDU4JGja0AALKWgKa4WUABANr295.jpg"
     * @return Boolean
     * @description 删除文件
     * @auther zzd
     * @date 2020-06-24 17:08
     */
    public static Boolean deleteFile(String dirPath, String url) {
        if (StringUtils.isNotBlank(url)) {
            String relPath = dirPath + url;
            Boolean flag = false;
            File file = new File(relPath);
            if (file.isFile() && file.exists()) {
                file.delete();
                flag = true;
            }
            return flag;
        } else {
            return true;
        }

    }

    /**
     * @param imgPath
     * @param response
     * @return void
     * @description 下载图片
     * @auther zzd
     * @date 2020-06-28 16:31
     */
    public static void download(String imgPath, HttpServletResponse response) throws IOException  {
        File file = new File(imgPath);

        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));

        OutputStream fileOutputStream = response.getOutputStream();
        ByteArrayOutputStream output = new ByteArrayOutputStream();

        response.reset();
        response.setContentType("application/octet-stream");
        response.setCharacterEncoding("UTF-8");

        response.setHeader("Content-disposition", "attachment; filename=" + (imgPath.substring(imgPath.lastIndexOf("/") + 1, imgPath.length())));

        byte[] buffer = new byte[1024];
        int length;

        while ((length = dataInputStream.read(buffer)) > 0) {
            output.write(buffer, 0, length);
        }
        fileOutputStream.write(output.toByteArray());
        dataInputStream.close();
        fileOutputStream.close();
    }


}
