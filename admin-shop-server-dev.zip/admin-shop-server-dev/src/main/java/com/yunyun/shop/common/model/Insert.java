package com.yunyun.shop.common.model;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.common.model
 * @createTime 2020-06-11 14:08
 */
public interface Insert {
}
