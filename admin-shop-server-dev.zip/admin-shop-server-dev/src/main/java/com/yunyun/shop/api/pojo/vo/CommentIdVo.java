package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-15 16:27
 **/
@Data
public class CommentIdVo implements Serializable {
    /**
     * 评价编号
     */
    @ApiModelProperty(value="评价编号列表")
    private List<String> commentIds;

    /**
     * 评价编号
     */
    @ApiModelProperty(value="评价编号")
    private String commentId;
}