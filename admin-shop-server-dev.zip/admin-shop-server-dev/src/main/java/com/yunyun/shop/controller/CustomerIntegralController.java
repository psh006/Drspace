package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.CustomerIntegralDto;
import com.yunyun.shop.api.pojo.entity.CustomerIntegral;
import com.yunyun.shop.api.pojo.vo.CustomerIntegralVo;
import com.yunyun.shop.api.pojo.vo.IntegralRecordRequestVo;
import com.yunyun.shop.api.service.CustomerIntegralService;
import com.yunyun.shop.common.model.ResultBody;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @program: shop
 * @description: 积分管理
 * @author: CheGuangQuan
 * @create: 2020-07-01 11:14
 **/
@Api(tags = "积分管理")
@RequestMapping("/customerIntegral")
@RestController
public class CustomerIntegralController {

    @Autowired
    private CustomerIntegralService customerIntegralService;


    /**
     * 条件分页查询积分管理列表
     * @auther CheGuangQuan
     * @date 2020/7/1 11:23
     * @param customerIntegralDto
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.vo.CustomerIntegralVo>>
    */
    @ApiOperation("条件分页查询积分管理列表")
    @PostMapping("/selectList")
    public ResultBody<List<CustomerIntegralVo>> selectList(@RequestBody CustomerIntegralDto customerIntegralDto){
        PageInfo<CustomerIntegralVo> info = customerIntegralService.selectList(customerIntegralDto);
        return ResultBody.ok(info.getList(), info.getTotal());
    }

    /**
     * @description 分页查询客户的积分记录
     * @auther PuYaDong
     * @date 2020-07-03 15:59
     * @param integralRecordRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.CustomerIntegral>>
     */
    @ApiOperation("分页查询客户的积分记录")
    @GetMapping("/customerIntegralRecord")
    public ResultBody<List<CustomerIntegral>> queryCustomerIntegralRecord(
            @Validated IntegralRecordRequestVo integralRecordRequestVo
    ){
        PageInfo<CustomerIntegral> info = customerIntegralService.queryCustomerIntegralRecord(integralRecordRequestVo);
        return ResultBody.ok(info.getList(), info.getTotal());
    }
}