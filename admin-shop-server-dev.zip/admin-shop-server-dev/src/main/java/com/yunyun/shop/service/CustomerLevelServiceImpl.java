package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.vo.UpdateState;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import com.yunyun.shop.mapper.CustomerLevelMapper;
import com.yunyun.shop.api.pojo.entity.CustomerLevel;
import com.yunyun.shop.api.service.CustomerLevelService;

import java.util.Date;
import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.service
 * @createTime 2020-06-29 14:41
 */
@Service
public class CustomerLevelServiceImpl implements CustomerLevelService {

    @Resource
    private CustomerLevelMapper customerLevelMapper;

    @Override
    public int deleteByPrimaryKey(String customLevelId) {
        return customerLevelMapper.deleteByPrimaryKey(customLevelId);
    }

    @Override
    public int insert(CustomerLevel record) {
        // 判断等级是否存在
        if(this.isLevelNameExist(record.getCustomLevelId(),record.getCustomLevelName())){
            throw new AlertException("添加失败，等级名称已存在");
        }
        record.setCustomLevelId(IdWorker.getIdStr());
        EmpUserDetail user = AuthHelper.getUser();
        record.setOperateId(user.getEmpId());
        record.setOperateName(user.getEmpName());
        record.setOperateTime(new Date());
        return customerLevelMapper.insert(record);
    }

    @Override
    public int updateByPrimaryKey(CustomerLevel record) {
        // 判断等级是否存在
        if(this.isLevelNameExist(record.getCustomLevelId(),record.getCustomLevelName())){
            throw new AlertException("修改失败，等级名称已存在");
        }
        return customerLevelMapper.updateByPrimaryKey(record);
    }

    /**
     * @param state
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.CustomerLevel>
     * @description 条件查询客户等级
     * @auther PuYaDong
     * @date 2020-06-29 15:18
     */
    @Override
    public List<CustomerLevel> queryLevel(Integer state) {
        return customerLevelMapper.selectByState(state);
    }

    /**
     * @param updateState
     * @return int
     * @description 根据id修改状态
     * @auther PuYaDong
     * @date 2020-06-29 15:22
     */
    @Override
    public int updateStateById(UpdateState updateState) {
        return customerLevelMapper.updateStateById(updateState.getId(), updateState.getState());
    }

    /**
     * @param customLevelId
     * @param customLevelName
     * @return int
     * @description 等级名称是否存在
     * @auther PuYaDong
     * @date 2020-06-29 16:03
     */
    @Override
    public boolean isLevelNameExist(String customLevelId, String customLevelName) {
        return customerLevelMapper.isLevelNameExist(customLevelId, customLevelName) > 0;
    }

    /**
     * @param customerLevelId
     * @return java.lang.String
     * @description 根据等级id获取等级名称
     * @auther PuYaDong
     * @date 2020-06-30 10:13
     */
    @Override
    public String selectLevelNameById(String customerLevelId) {
        return customerLevelMapper.selectLevelNameById(customerLevelId);
    }

}
