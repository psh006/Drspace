package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.CommentsInfo;
import com.yunyun.shop.api.pojo.entity.GoodsBase;
import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GoodsBaseMapper {
    int deleteByPrimaryKey(String goodsId);

    int insert(GoodsBase record);

    GoodsBase selectByPrimaryKey(String goodsId);

    int updateByPrimaryKey(GoodsBase record);

    List<GoodsBase> queryGoodsList(GoodsRequestVo goodsRequestVo);

    int deleteSeveralGoods(@Param("goodsIdList") List<String> goodsIdList);

    int deleteLogicGoodsById(@Param("goodsIdList") List<String> goodsIdList);

    List<GoodsBase> selectRecycleGoods(GoodsRequestVo goodsRequestVo);

    int recoverGoods(@Param("goodsIdList") List<String> goodsIds);


}