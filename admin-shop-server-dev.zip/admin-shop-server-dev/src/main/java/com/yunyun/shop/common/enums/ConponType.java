package com.yunyun.shop.common.enums;

public enum ConponType {
    FULL_REDUCTION(1,"满减券"),
    COUPON(2,"折扣券"),
    DEDUCTION_VOUCHER(3,"抵扣券");
    private int code;
    private String desc;

    ConponType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
