package com.yunyun.shop.api.pojo.entity;

import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 *
 * @Classname SysParams
 * @Description 系统参数
 * @Date 2020/6/23 13:56
 * @author lxl
 */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-SysParams")
@Data
public class SysParams implements Serializable {

    private static final long serialVersionUID = 8027292119102546453L;
    /**
    * 参数编号
    */
    @NotBlank(groups = Update.class,message = "参数编号不能为空")
    @ApiModelProperty(value="参数编号")
    private String paramId;

    /**
    * 参数名称
    */
    @NotNull(groups = {Insert.class,Update.class},message = "参数名称不能为空")
    @Length(min = 1,max = 100,message = "参数名称不能超过规定长度")
    @ApiModelProperty(value="参数名称")
    private String paramName;

    /**
    * 参数值
    */
    @NotNull(groups = {Insert.class,Update.class},message = "参数值不能为空")
    @ApiModelProperty(value="参数值")
    private String val;

    /**
    * 备注
    */
    @ApiModelProperty(value="备注")
    private String note;

}