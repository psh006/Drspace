package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.CustomerLevel;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-29 14:41
 */
public interface CustomerLevelMapper {
    int deleteByPrimaryKey(String customLevelId);

    int insert(CustomerLevel record);

    int updateByPrimaryKey(CustomerLevel record);

    List<CustomerLevel> selectByState(@Param("customLevelState") Integer customLevelState);

    int updateStateById(@Param("customLevelId") String customLevelId,@Param("customLevelState") Integer state);

    int isLevelNameExist(@Param("customLevelId")String customLevelId,@Param("customLevelName") String customLevelName);

    String selectLevelNameById(String customerLevelId);
}