package com.yunyun.shop.api.pojo.entity;

import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.List;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 系统菜单表
 */
@ApiModel(value = "com-yunyun-shop-api-pojo-entity-SysMenu")
@Data
public class SysMenu implements Serializable {
    /**
     * 菜单编号
     */
    @NotBlank(groups = Update.class,message = "菜单编号不可为空")
    @ApiModelProperty(value = "菜单编号")
    private String menuId;

    /**
     * 菜单名称
     */
    @NotBlank(groups = {Update.class, Insert.class},message = "菜单名称不可为空")
    @ApiModelProperty(value = "菜单名称")
    private String menuName;

    /**
     * 链接
     */
    @NotBlank(groups = {Update.class, Insert.class},message = "链接不可为空")
    @ApiModelProperty(value = "链接")
    private String menuUrl;

    /**
     * 图标
     */
    @ApiModelProperty(value = "图标")
    private String menuIcon;

    /**
     * 是否显示
     */
    @NotNull(groups = {Update.class, Insert.class},message = "是否显示不可为空")
    @ApiModelProperty(value = "是否显示")
    private Integer isDisplay;

    /**
     * 是否枝叶
     */
    @NotNull(groups = {Update.class, Insert.class},message = "是否枝叶不可为空")
    @ApiModelProperty(value = "是否枝叶")
    private Integer isLeaf;

    /**
     * 父级ID
     */
    @NotBlank(groups = {Update.class, Insert.class},message = "父级ID不可为空")
    @ApiModelProperty(value = "父级ID")
    private String parentId;

    /**
     * 排序
     */
    @NotNull(groups = {Update.class, Insert.class},message = "排序不可为空")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 子菜单
     */
    @ApiModelProperty(value = "子菜单")
    private List<SysMenu> children;

    private static final long serialVersionUID = 1L;
}