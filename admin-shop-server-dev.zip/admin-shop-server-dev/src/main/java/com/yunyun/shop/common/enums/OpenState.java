package com.yunyun.shop.common.enums;

public enum OpenState {
    OPEN(1,"开启"),
    CLOSE(2,"关闭");
    private int code;
    private String desc;

    OpenState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
