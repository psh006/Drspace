package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.LogisticsCompany;
import com.yunyun.shop.api.pojo.vo.LogisticsRequestVo;
import com.yunyun.shop.common.model.ResultBody;

import java.util.List;

public interface LogisticsCompanyService {


    int deleteByPrimaryKey(String logisticsId);

    ResultBody insert(LogisticsCompany record);

    LogisticsCompany selectByPrimaryKey(String logisticsId);

    ResultBody updateByPrimaryKey(LogisticsCompany record);

    /**
     * 查询物流公司全部信息
     *
     * @return
     */
    List<LogisticsCompany> find();

    /**
     * 条件查询物流公司
     * @auther CheGuangQuan
     * @date 2020/6/22 14:33
     * @param logisticsRequestVo
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>
    */
    List<LogisticsCompany> queryLogisticsCompany(LogisticsRequestVo logisticsRequestVo);
}

