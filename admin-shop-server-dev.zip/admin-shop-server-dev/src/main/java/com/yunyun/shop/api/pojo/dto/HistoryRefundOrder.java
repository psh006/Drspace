package com.yunyun.shop.api.pojo.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zzd
 * @description com.yunyun.shop.api.pojo.dto
 * @createTime 2020-06-24 16:14
 */
@Data
@ApiModel(value = "历史退款订单")
public class HistoryRefundOrder {

    @ApiModelProperty(value = "退款时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @ApiModelProperty(value="子订单编号")
    private String orderDetailId;

    @ApiModelProperty(value="凭证图")
    private String refundVoucher;

    @ApiModelProperty(value="物品图")
    private String goodsCover;

    @ApiModelProperty(value="商品名称")
    private String goodsName;

    @ApiModelProperty(value="子订单总金额")
    private BigDecimal orderDetailAmount;

    @ApiModelProperty(value="实付金额")
    private BigDecimal detailPayAmountReal;

    @ApiModelProperty(value="收货人姓名")
    private String receiptName;

    @ApiModelProperty(value="收货人手机号")
    private String receiptPhone;

    @ApiModelProperty(value = "支付方式")
    private int payMethod;

    @ApiModelProperty(value="物流公司编号，配送方式")
    private String logisticsId;

    @ApiModelProperty(value="退款原因")
    private String refundReason;

    @ApiModelProperty(value="退款方式")
    private Integer refundMethod;
}
