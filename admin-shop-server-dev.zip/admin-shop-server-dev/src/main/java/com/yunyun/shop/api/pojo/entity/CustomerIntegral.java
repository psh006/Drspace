package com.yunyun.shop.api.pojo.entity;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 客户积分记录表
 */
@ApiModel(value = "客户积分记录实体")
@Data
public class CustomerIntegral implements Serializable {
    /**
     * 记录编号
     */
    @ApiModelProperty(value = "记录编号")
    private String recordId;

    /**
     * 客户编号
     */
    @ApiModelProperty(value = "客户编号")
    private String customerId;

    /**
     * 积分记录类型，途径，INTEGRAL_RECORD_TYPE
     */
    @ApiModelProperty(value = "积分记录类型，途径，INTEGRAL_RECORD_TYPE")
    private Integer integralRecordType;

    /**
     * 积分变动数值
     */
    @ApiModelProperty(value = "积分变动数值")
    private Integer integralValue;

    /**
     * 剩余可用积分
     */
    @ApiModelProperty(value = "剩余可用积分")
    private Integer integralBalance;

    /**
     * 积分变动备注
     */
    @ApiModelProperty(value = "积分变动备注")
    private String integralNote;

    /**
     * 若商品积分，记录订单id
     */
    @ApiModelProperty(value = "若商品积分，记录订单id")
    private String integralOrderId;

    /**
     * 操作人id
     */
    @ApiModelProperty(value = "操作人id")
    private String operateId;

    /**
     * 操作人姓名
     */
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 修改时间
     */
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}