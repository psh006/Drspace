package com.yunyun.shop.common.enums;

public enum CanExpress {
    //顺丰
    SF_EXPRESS(1,"顺丰"),
    //圆通
    YTO_EXPRESS(2,"圆通"),
    //中通
    ZTO_EXPRESS(3,"中通"),
    //申通
    TO_EXPRESS(4,"申通"),
    //韵达
    YUNDA_EXPRESS(5,"韵达"),
    //天天
    TT_EXPRESS(6,"天天"),
    //邮政
    EMS_EXPRESS(7,"邮政"),
    //百世
    BS_EXPRESS(8,"百世"),
    //德邦
    DB_EXPRESS(9,"德邦"),
    //京东
    JD_EXPRESS(10,"京东");

    private int code;
    private String desc;

    CanExpress(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
