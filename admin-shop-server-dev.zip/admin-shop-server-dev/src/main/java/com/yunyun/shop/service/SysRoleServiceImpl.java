package com.yunyun.shop.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.RoleMenu;
import com.yunyun.shop.api.pojo.vo.SysRoleRequestVo;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.mapper.RoleMenuMapper;
import com.yunyun.shop.mapper.SysMenuMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import com.yunyun.shop.mapper.SysRoleMapper;
import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.api.service.SysRoleService;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.service
 * @createTime 2020-06-12 10:37
 */
@Service
public class SysRoleServiceImpl implements SysRoleService {

    @Resource
    private SysRoleMapper sysRoleMapper;

    @Resource
    private RoleMenuMapper roleMenuMapper;

    @Resource
    private SysMenuMapper sysMenuMapper;

    @Override
    public int deleteByPrimaryKey(String roleId) {
        return sysRoleMapper.deleteByPrimaryKey(roleId);
    }

    @Override
    public int insert(SysRole record) {
        record.setRoleId(IdWorker.getIdStr());
        return sysRoleMapper.insert(record);
    }

    @Override
    public SysRole selectByPrimaryKey(String roleId) {
        return sysRoleMapper.selectByPrimaryKey(roleId);
    }

    @Override
    public int updateByPrimaryKey(SysRole record) {
        return sysRoleMapper.updateByPrimaryKey(record);
    }


    /**
     * @param empId
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.SysRole>
     * @description 查询用户的角色
     * @auther PuYaDong
     * @date 2020-06-12 10:54
     */
    @Override
    public List<SysRole> queryUserRoles(String empId) {
        return sysRoleMapper.selectRoleByUserId(empId);
    }

    /**
     *
     * @Description: 查询角色列表
     * @params: [sysRoleRequestVo]
     * @return: com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.SysRole>
     * @Author: lxl
     * @Date : 2020/6/24 16:18
     */
    @Override
    public PageInfo<SysRole> selectRoles(SysRoleRequestVo sysRoleRequestVo) {
        PageHelper.startPage(sysRoleRequestVo.getPage(), sysRoleRequestVo.getLimit());
        List<SysRole> sysRoles = sysRoleMapper.selectRoles(sysRoleRequestVo);
        return new PageInfo<>(sysRoles);
    }

    /**
     *
     * @Description: 删除角色
     * @params: [sysRoleRequestVo]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/24 16:19
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int deleteRole(SysRoleRequestVo sysRoleRequestVo) {
        int i = sysRoleMapper.deleteByPrimaryKey(sysRoleRequestVo.getRoleId());
        int i1 = roleMenuMapper.deleteByPrimaryKey(sysRoleRequestVo.getRoleId());
        return (i + i1);
    }


    /**
     *
     * @Description:  关联角色菜单
     * @params: [sysRoleRequestVo]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/24 16:19
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int roleAndMenu(SysRoleRequestVo sysRoleRequestVo) {
        //删除掉原来的菜单
        String roleId = sysRoleRequestVo.getRoleId();
        int i1 = roleMenuMapper.deleteByPrimaryKey(roleId);
        List<String> menuIds = sysRoleRequestVo.getMenuIds();
        //去掉父级菜单
        List<String> subMenu = sysMenuMapper.selectSubMenu(menuIds);
        String s = StringUtils.join(subMenu, ",");
        //插入新增的菜单
        List list = new ArrayList<>();
        for (String menuId : menuIds) {
            RoleMenu roleMenu = new RoleMenu();
            roleMenu.setMenuId(menuId);
            roleMenu.setRoleId(roleId);
            list.add(roleMenu);
        }
        //更新角色表中的menuIds
        sysRoleRequestVo.setMenuId(s);
        sysRoleMapper.updateMenuIds(sysRoleRequestVo);
        int i = roleMenuMapper.batchInsert(list);
        return (i + i1);
    }

}

