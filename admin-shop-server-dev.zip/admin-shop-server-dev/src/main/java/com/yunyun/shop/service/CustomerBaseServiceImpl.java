package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.vo.CustomerRequestVo;
import com.yunyun.shop.api.pojo.vo.UpdateCustomer;
import com.yunyun.shop.api.service.CustomerLevelService;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.util.StringUtils;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.mapper.CustomerBaseMapper;
import com.yunyun.shop.api.pojo.entity.CustomerBase;
import com.yunyun.shop.api.service.CustomerBaseService;

import java.util.List;

/**
 * @description com.yunyun.shop.service
 * @author PuYaDong
 * @createTime 2020-06-29 16:29
 */
@Service
public class CustomerBaseServiceImpl implements CustomerBaseService{

    @Resource
    private CustomerBaseMapper customerBaseMapper;

    @Resource
    private CustomerLevelService customerLevelService;

    @Override
    public int deleteByPrimaryKey(String customerId) {
        return customerBaseMapper.deleteByPrimaryKey(customerId);
    }

    @Override
    public int insert(CustomerBase record) {
        return customerBaseMapper.insert(record);
    }

    @Override
    public CustomerBase selectByPrimaryKey(String customerId) {
        return customerBaseMapper.selectByPrimaryKey(customerId);
    }

    @Override
    public int updateByPrimaryKey(CustomerBase record) {
        return customerBaseMapper.updateByPrimaryKey(record);
    }

    /**
     * @param customerRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.CustomerBase>
     * @description 条件分页查询会员信息
     * @auther PuYaDong
     * @date 2020-06-30 09:39
     */
    @Override
    public PageInfo<CustomerBase> findCustomerListPage(CustomerRequestVo customerRequestVo) {
        PageHelper.startPage(customerRequestVo.getPage(),customerRequestVo.getLimit());
        List<CustomerBase>  customerBaseList = customerBaseMapper.query(customerRequestVo);
        PageInfo<CustomerBase> pageInfo = new PageInfo<>(customerBaseList);
        return pageInfo;
    }

    /**
     * @param updateCustomer
     * @return int
     * @description 修改等级和备注
     * @auther PuYaDong
     * @date 2020-06-30 09:52
     */
    @Override
    public int updateCustomerLevelAndNote(UpdateCustomer updateCustomer) {
        // 根据等级id获取等级名称
        String customerLevelName = customerLevelService.selectLevelNameById(updateCustomer.getCustomerLevelId());
        if(StringUtils.isBlank(customerLevelName)){
            throw new AlertException("修改失败，会员等级不存在");
        }
        updateCustomer.setCustomerLevelName(customerLevelName);

        return customerBaseMapper.updateCustomerLevelAndNote(updateCustomer);
    }

}
