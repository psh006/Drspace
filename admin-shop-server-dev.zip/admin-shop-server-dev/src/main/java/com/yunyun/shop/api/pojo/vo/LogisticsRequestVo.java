package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @program: shop
 * @description: 物流请求
 * @author: CheGuangQuan
 * @create: 2020-06-22 14:27
 **/
@Data
public class LogisticsRequestVo implements Serializable {

    /**
     * 物流公司编号
     */
    @ApiModelProperty(value = "物流公司编号")
    private String logisticsId;

    /**
     * 物流公司名称
     */
    @ApiModelProperty(value = "物流公司名称")
    private String logisticsName;

    /**
     * 物流公司代码
     */
    @ApiModelProperty(value = "物流公司代码")
    private String logisticsCode;
}