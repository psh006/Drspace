package com.yunyun.shop.service;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.yunyun.shop.mapper.PayRecordMapper;
import com.yunyun.shop.api.pojo.entity.PayRecord;
import com.yunyun.shop.api.service.PayRecordService;
@Service
public class PayRecordServiceImpl implements PayRecordService{

    @Resource
    private PayRecordMapper payRecordMapper;

    @Override
    public int deleteByPrimaryKey(String payId) {
        return payRecordMapper.deleteByPrimaryKey(payId);
    }

    @Override
    public int insert(PayRecord record) {
        return payRecordMapper.insert(record);
    }

    @Override
    public PayRecord selectByPrimaryKey(String payId) {
        return payRecordMapper.selectByPrimaryKey(payId);
    }

    @Override
    public int updateByPrimaryKey(PayRecord record) {
        return payRecordMapper.updateByPrimaryKey(record);
    }

    @Override
    public int updateBatch(List<PayRecord> list) {
        return payRecordMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<PayRecord> list) {
        return payRecordMapper.batchInsert(list);
    }

}
