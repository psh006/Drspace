package com.yunyun.shop.api.pojo.dto;

import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.entity.PayRecord;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-24 11:13
 **/
@Data
public class RefundOrderDetailDto extends OrderDetail implements Serializable {
    /**
     * 退款详情
     */
    @ApiModelProperty(value="退款详情")
    private RefundRecord refundRecord;

    /**
     * 支付详情
     */
    @ApiModelProperty(value="支付详情")
    private PayRecord payRecord;
}