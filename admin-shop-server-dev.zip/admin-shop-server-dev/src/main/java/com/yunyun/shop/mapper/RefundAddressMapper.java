package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.RefundAddress;

import java.util.List;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-28 09:28
 */
public interface RefundAddressMapper {
    int deleteByPrimaryKey(String receiptAddressId);

    int insert(RefundAddress record);

    List<RefundAddress> selectAll();

    int isExistAddress(RefundAddress refundAddress);

    int setNotDefault();
}