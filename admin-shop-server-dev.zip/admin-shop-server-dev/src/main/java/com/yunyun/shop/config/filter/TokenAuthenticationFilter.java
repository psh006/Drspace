package com.yunyun.shop.config.filter;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.entity.SysMenu;
import com.yunyun.shop.common.constants.CommonConstants;
import com.yunyun.shop.common.util.BeanConvertUtils;
import com.yunyun.shop.cache.LoginCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @description token过滤器
 * @author PuYaDong
 * @date 2020-06-13 15:26
 */
@Component
public class TokenAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private LoginCache loginCache;

    /**
     * token filter.
     *
     * @param request     .
     * @param response    .
     * @param filterChain .
     */
    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        String authHeader = request.getHeader(CommonConstants.TOKEN_HEADER);
        if (authHeader != null && authHeader.startsWith(CommonConstants.TOKEN_PREFIX)) {
            final String authToken = authHeader.substring(CommonConstants.TOKEN_PREFIX.length());
            if (authToken != null && loginCache.isLogin(authToken)) {
                EmpBase userInfo = loginCache.getUserInfo(authToken);
                if (userInfo != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                    // TODO: 权限列表
                    SysMenu userMenuList = loginCache.getUserMenuList(authToken);
                    EmpUserDetail empUserDetail = BeanConvertUtils.convertBean(userInfo, EmpUserDetail.class);
                    empUserDetail.setSysRoleList(new ArrayList<>());
                    UserDetails userDetails = empUserDetail;
                    //可以校验token和username是否有效，目前由于token对应loginCode存在redis，都以默认都是有效的
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                }
            }
        }

        filterChain.doFilter(request, response);
    }
}
