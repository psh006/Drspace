package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.vo
 * @createTime 2020-07-06 11:33
 */
@Data
public class IntegralRecordRequestVo extends PageParams implements Serializable {

    /**
     * 客户编号
     */
    @NotBlank(message = "客户id不能为空")
    @ApiModelProperty(value = "客户编号")
    private String customerId;
}
