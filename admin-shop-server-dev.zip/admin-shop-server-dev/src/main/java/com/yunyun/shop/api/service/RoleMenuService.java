package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.RoleMenu;
    /**
 *
 * @Classname RoleMenuService
 * @Description TODO
 * @Date 2020/6/24 10:33
 * @author lxl
 */
public interface RoleMenuService{


    int deleteByPrimaryKey(String roleId);

    int insert(RoleMenu record);

}
