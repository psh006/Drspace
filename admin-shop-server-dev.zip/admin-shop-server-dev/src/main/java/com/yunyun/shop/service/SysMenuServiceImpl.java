package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import lombok.val;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

import com.yunyun.shop.mapper.SysMenuMapper;
import com.yunyun.shop.api.pojo.entity.SysMenu;
import com.yunyun.shop.api.service.SysMenuService;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.service
 * @createTime 2020-06-12 10:26
 */
@Service
public class SysMenuServiceImpl implements SysMenuService {

    @Resource
    private SysMenuMapper sysMenuMapper;

    @Override
    public int deleteByPrimaryKey(String menuId) {
        return sysMenuMapper.deleteByPrimaryKey(menuId);
    }

    @Override
    public int insert(SysMenu record) {
        String idStr = IdWorker.getIdStr();
        record.setMenuId(idStr);
        return sysMenuMapper.insert(record);
    }

    @Override
    public SysMenu selectByPrimaryKey(String menuId) {
        return sysMenuMapper.selectByPrimaryKey(menuId);
    }

    @Override
    public int updateByPrimaryKey(SysMenu record) {
        return sysMenuMapper.updateByPrimaryKey(record);
    }

    @Override
    public int updateBatch(List<SysMenu> list) {
        return sysMenuMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<SysMenu> list) {
        return sysMenuMapper.batchInsert(list);
    }

    @Override
    public ResultBody<List<SysMenu>> queryAll() {
        List<SysMenu> allMenu = sysMenuMapper.queryAll();
        return ResultBody.ok(formatMenu(allMenu));
    }

    @Override
    public int deleteMenu(OperateIdVo operateIdVo) {
        String id = operateIdVo.getId();
        return sysMenuMapper.deleteMenu(id);
    }

    @Override
    public ResultBody<List<SysMenu>> selectMenuByRole() {
        EmpUserDetail user = AuthHelper.getUser();
        String roleId = user.getRoleId();
        //通过角色回去全部菜单
        List<SysMenu> allMenu = sysMenuMapper.selectMenuByRole(roleId);
        //取出所有父级菜单
        return ResultBody.ok(formatMenu(allMenu));
    }

    /**
     * 格式化菜单
     * @auther CheGuangQuan
     * @date 2020/6/19 10:34
     * @param allMenu
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.SysMenu>
    */
    public List<SysMenu> formatMenu(List<SysMenu> allMenu){
        //取出所有父级菜单
        List<SysMenu> parentMenu = allMenu.stream().filter(menu -> "0".equals(menu.getParentId())).collect(Collectors.toList());
        allMenu.removeAll(parentMenu);
        //取出所有自己菜单
        parentMenu.forEach(sysMenu -> {
            String menuId = sysMenu.getMenuId()+"";
            List<SysMenu> childMenu = allMenu.stream().filter(menu -> menuId.equals(menu.getParentId())).collect(Collectors.toList());
            allMenu.removeAll(childMenu);
            sysMenu.setChildren(childMenu);
        });
        return parentMenu;
    }

}



