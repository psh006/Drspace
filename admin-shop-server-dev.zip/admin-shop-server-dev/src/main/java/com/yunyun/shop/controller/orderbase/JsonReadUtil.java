package com.yunyun.shop.controller.orderbase;


import com.alibaba.fastjson.JSON;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.Map;

/**
 * json文件的读取工具类
 * Loveclear
 * 2020/06/18 15:28
 */
public class JsonReadUtil {
    private static final Logger logger = LogManager.getLogger(JsonReadUtil.class);

    /**
     * 读取json文件
     * @param jsonFile json文件名
     * @return 返回json字符串
     */
    public String readJsonFile(File jsonFile) {
        String jsonStr = "";
        logger.info("————开始读取" + jsonFile.getPath() + "文件————");
        try {
            //File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile), "utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            logger.info("————读取" + jsonFile.getPath() + "文件结束!————");
            return jsonStr;
        } catch (Exception e) {
            logger.info("————读取" + jsonFile.getPath() + "文件出现异常，读取失败!————");
            e.printStackTrace();
            return null;
        }
    }
    //将读取的json文件数据转换为Map
    private Map<String,String> JsonReadOk(File jsonFile){
        String jsonStr = this.readJsonFile(jsonFile);
        Map jsonMap = (Map) JSON.parse(jsonStr);
        return jsonMap;
    }

    public static void main(String[] args) {
        JsonReadUtil test = new JsonReadUtil();
        File file = new File("D:\\admin-shop-server\\src\\main\\java\\com\\yunyun\\shop\\controller\\package.json");
        Map<String,String> map = test.JsonReadOk(file);
        /*while (true){

        }*/
        //map.get("china");
       // System.out.println();
    }
}
