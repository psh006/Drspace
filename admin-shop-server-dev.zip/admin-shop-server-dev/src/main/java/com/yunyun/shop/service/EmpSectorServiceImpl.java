package com.yunyun.shop.service;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.mapper.EmpSectorMapper;
import com.yunyun.shop.api.pojo.entity.EmpSector;
import com.yunyun.shop.api.service.EmpSectorService;

import java.util.List;

/**
 * @description com.yunyun.shop.service
 * @author PuYaDong
 * @createTime 2020-06-24 10:25
 */
@Service
public class EmpSectorServiceImpl implements EmpSectorService{

    @Resource
    private EmpSectorMapper empSectorMapper;

    @Override
    public int deleteByPrimaryKey(String sectorId) {
        return empSectorMapper.deleteByPrimaryKey(sectorId);
    }

    @Override
    public int insert(EmpSector record) {
        return empSectorMapper.insert(record);
    }

    @Override
    public EmpSector selectByPrimaryKey(String sectorId) {
        return empSectorMapper.selectByPrimaryKey(sectorId);
    }

    @Override
    public int updateByPrimaryKey(EmpSector record) {
        return empSectorMapper.updateByPrimaryKey(record);
    }

    /**
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.EmpSector>
     * @description 部门列表
     * @auther PuYaDong
     * @date 2020-06-24 10:29
     */
    @Override
    public List<EmpSector> list() {
        return empSectorMapper.selectAll();
    }

}
