package com.yunyun.shop.common.enums;

/**
 * @program: shop
 * @description: 商品上架状态
 * @author: CheGuangQuan
 * @create: 2020-06-15 12:37
 **/
public enum PutState {
    PUT_UP(1,"上架"),
    PUT_DOWN(2,"下架");
    private int code;
    private String desc;

    PutState(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}