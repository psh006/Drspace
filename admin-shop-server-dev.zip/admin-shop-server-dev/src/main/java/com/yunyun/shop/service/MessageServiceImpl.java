package com.yunyun.shop.service;
import java.util.Date;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.lang.UUID;
import com.yunyun.shop.api.pojo.entity.Message;
import com.yunyun.shop.api.service.MessageService;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.mapper.MessageDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.IdGenerator;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.service
 * @createTime 2020-06-13 17:20
 */
@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageDao messageDao;

    @Override
    public void add(){
        Message message = new Message();
        message.setMessageId(IdWorker.getIdStr());
        message.setMessageType(0);
        message.setMessageState(0);
        message.setMessageInfo("");
        message.setEmpId("");
        message.setOrderId("");
        message.setOperateId("");
        message.setOperateName("");
        message.setOperateTime(new Date());
        message.setUpdateTime(new Date());

        messageDao.save(message);
    }

}
