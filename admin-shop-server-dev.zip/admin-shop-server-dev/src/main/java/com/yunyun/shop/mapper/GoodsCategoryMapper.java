package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.GoodsCategory;
import com.yunyun.shop.api.pojo.vo.GoodsCategoryResultVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GoodsCategoryMapper {
    int deleteByPrimaryKey(String goodsCategoryId);

    int insert(GoodsCategory record);

    GoodsCategory selectByPrimaryKey(String goodsCategoryId);

    int updateByPrimaryKey(GoodsCategory record);

    int showGoodsCategory(@Param("isDisplay") int isDisplay, @Param("goodsCategoryList") List<String> goodsCategoryList);

    List<GoodsCategoryResultVo> queryGoodsCategoryList();

    int deleteGoodsCategory(@Param("goodsCategoryList")List<String> goodsCategoryList);

    List<GoodsCategory> selectBySort(GoodsCategory goodsCategory);
}