package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.EmpSector;

import java.util.List;

/**
 * @description com.yunyun.shop.mapper
 * @author PuYaDong
 * @createTime 2020-06-24 10:25
 */
public interface EmpSectorMapper {
    int deleteByPrimaryKey(String sectorId);

    int insert(EmpSector record);

    EmpSector selectByPrimaryKey(String sectorId);

    int updateByPrimaryKey(EmpSector record);

    List<EmpSector> selectAll();
}