package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 售后地址管理表
 */
@Data
public class RefundAddress {
    @ApiModelProperty(value = "地址编号")
    private String receiptAddressId;

    @ApiModelProperty(value = "收货人姓名")
    private String receiptName;

    @ApiModelProperty(value = "收货人电话")
    private String receiptPhone;

    @ApiModelProperty(value = "收货地址")
    private String receiptAddress;

    @ApiModelProperty(value = "邮编")
    private String receiptPostcode;

    @ApiModelProperty(value = "是否默认")
    private int isDefault;

    @ApiModelProperty(value = "操作人编号")
    private String operateId;

    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    @Override
    public String toString() {
        return "RefundAddress{" +
                "receiptAddressId='" + receiptAddressId + '\'' +
                ", receiptName='" + receiptName + '\'' +
                ", receiptPhone='" + receiptPhone + '\'' +
                ", receiptAddress='" + receiptAddress + '\'' +
                ", receiptPostcode='" + receiptPostcode + '\'' +
                ", isDefault=" + isDefault +
                ", operateId='" + operateId + '\'' +
                ", operateName='" + operateName + '\'' +
                ", operateTime=" + operateTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
