package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.CustomerLevel;
import com.yunyun.shop.api.pojo.vo.UpdateState;
import com.yunyun.shop.common.model.ResultBody;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-29 14:41
 */
public interface CustomerLevelService {


    int deleteByPrimaryKey(String customLevelId);

    int insert(CustomerLevel record);

    int updateByPrimaryKey(CustomerLevel record);

    /**
     * @description 条件查询客户等级
     * @auther PuYaDong
     * @date 2020-06-29 15:18
     * @param state
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.CustomerLevel>
     */
    List<CustomerLevel> queryLevel(Integer state);

    /**
     * @description 根据id修改状态
     * @auther PuYaDong
     * @date 2020-06-29 15:22
     * @param updateState
     * @return int
     */
    int updateStateById(UpdateState updateState);

    /**
     * @description 等级名称是否存在
     * @auther PuYaDong
     * @date 2020-06-29 16:03
     * @param customLevelId
     * @param customLevelName
     * @return int
     */
    boolean isLevelNameExist(String customLevelId, String customLevelName);

    /**
     * @description 根据等级id获取等级名称
     * @auther PuYaDong
     * @date 2020-06-30 10:13
     * @param customerLevelId
     * @return java.lang.String
     */
    String selectLevelNameById(String customerLevelId);
}
