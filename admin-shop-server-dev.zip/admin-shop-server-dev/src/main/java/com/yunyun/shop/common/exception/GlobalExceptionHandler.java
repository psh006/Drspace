package com.yunyun.shop.common.exception;

import com.yunyun.shop.common.constants.ErrorCode;
import com.yunyun.shop.common.model.ResultBody;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.fileupload.FileUploadBase;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author PuYaDong
 * @description 通用异常处理
 * @date 2020-06-11 11:25
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * @param ex
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 数据校验异常
     * @auther PuYaDong
     * @date 2020-06-18 09:44
     */
    @ExceptionHandler({MethodArgumentNotValidException.class})
    public static ResultBody handleValidException(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        FieldError fieldError = bindingResult.getFieldError();
        log.error("数据校验异常:{}({})", fieldError.getDefaultMessage(), fieldError.getField());
        ErrorCode code = ErrorCode.ALERT;
        return ResultBody.failed().flag(code.getCode()).msg(fieldError.getDefaultMessage());
    }

    /**
     * 功能描述: 数据绑定异常
     *
     * @param ex
     * @return com.thunder.common.model.ResultBody
     */
    @ExceptionHandler({BindException.class})
    public static ResultBody handleBindException(BindException ex) {
        //校验 除了 requestbody 注解方式的参数校验 对应的 bindingresult 为 BeanPropertyBindingResult
        FieldError fieldError = ex.getBindingResult().getFieldError();
        log.error("必填校验异常:{}({})", fieldError.getDefaultMessage(), fieldError.getField());
        ErrorCode code = ErrorCode.ALERT;
        return ResultBody.failed().flag(code.getCode()).msg(fieldError.getDefaultMessage());
    }

    /**
     * @param ex
     * @return org.springframework.web.servlet.ModelAndView
     * @description 上传文件超过了限制大小异常
     * @auther PuYaDong
     * @date 2020-06-23 10:33
     */
    @ExceptionHandler({MaxUploadSizeExceededException.class})
    public static ResultBody uploadException(MaxUploadSizeExceededException ex) throws IOException {
        ErrorCode code = ErrorCode.ALERT;
        double maxMBUploadSize = (double) Math.round((ex.getMaxUploadSize() / (1024 * 1024)) * 100) / 100.0;
        return ResultBody.failed().flag(code.getCode()).msg("最大上传文件为 " + maxMBUploadSize + "M，上传文件大小超出限制!");
    }

    /**
     * @param ex
     * @return org.springframework.web.servlet.ModelAndView
     * @description 上传文件超过了限制大小异常
     * @auther PuYaDong
     * @date 2020-06-23 10:33
     */
    @ExceptionHandler({FileUploadBase.FileSizeLimitExceededException.class})
    public static ResultBody uploadException(FileUploadBase.FileSizeLimitExceededException ex) throws IOException {
        ErrorCode code = ErrorCode.ALERT;
        double maxMBUploadSize = (double) Math.round((ex.getPermittedSize() / (1024 * 1024)) * 100) / 100.0;
        return ResultBody.failed().flag(code.getCode()).msg("最大上传文件为 " + maxMBUploadSize + "M，上传文件大小超出限制!");
    }

    /**
     * 自定义异常
     *
     * @param ex
     * @param request
     * @param response
     * @return
     */
    @ExceptionHandler({CommonException.class})
    public static ResultBody commonException(Exception ex, HttpServletRequest request, HttpServletResponse response) {
        ResultBody resultBody = resolveException(ex, request.getRequestURI());
        response.setStatus(resultBody.getHttpStatus());
        return resultBody;
    }

    /**
     * 其他异常
     *
     * @param ex
     * @param request
     * @param response
     * @return
     */
    @ExceptionHandler({Exception.class})
    public static ResultBody exception(Exception ex, HttpServletRequest request, HttpServletResponse response) {
        ResultBody resultBody = resolveException(ex, request.getRequestURI());
        response.setStatus(resultBody.getHttpStatus());
        return resultBody;
    }

    /**
     * 静态解析异常。可以直接调用
     *
     * @param ex
     * @return
     */
    public static ResultBody resolveException(Exception ex, String path) {
        ErrorCode code = ErrorCode.ERROR;
        int httpStatus = HttpStatus.INTERNAL_SERVER_ERROR.value();
        String message = ex.getMessage();
        String superClassName = ex.getClass().getSuperclass().getName();
        String className = ex.getClass().getName();
        log.error("==> message:{}", ex.getMessage());
        if (className.contains("UsernameNotFoundException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.USERNAME_NOT_FOUND;
        } else if (className.contains("BadCredentialsException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.BAD_CREDENTIALS;
        } else if (className.contains("AccountExpiredException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.ACCOUNT_EXPIRED;
        } else if (className.contains("LockedException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.ACCOUNT_LOCKED;
        } else if (className.contains("DisabledException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.ACCOUNT_DISABLED;
        } else if (className.contains("CredentialsExpiredException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.CREDENTIALS_EXPIRED;
        } else if (className.contains("InsufficientAuthenticationException") || className.contains("AuthenticationCredentialsNotFoundException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.UNAUTHORIZED;
        } else if (className.contains("InvalidGrantException")) {
            code = ErrorCode.ALERT;
            if ("Bad credentials".contains(message)) {
                code = ErrorCode.BAD_CREDENTIALS;
            } else if ("User is disabled".contains(message)) {
                code = ErrorCode.ACCOUNT_DISABLED;
            } else if ("User account is locked".contains(message)) {
                code = ErrorCode.ACCOUNT_LOCKED;
            }
        } else if (className.contains("InvalidScopeException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.INVALID_SCOPE;
        } else if (className.contains("InvalidTokenException")) {
            httpStatus = HttpStatus.UNAUTHORIZED.value();
            code = ErrorCode.INVALID_TOKEN;
        } else if (className.contains("InvalidRequestException")) {
            httpStatus = HttpStatus.BAD_REQUEST.value();
            code = ErrorCode.INVALID_REQUEST;
        } else if (className.contains("RedirectMismatchException")) {
            code = ErrorCode.REDIRECT_URI_MISMATCH;
        } else if (className.contains("UserDeniedAuthorizationException")) {
            code = ErrorCode.ACCESS_DENIED;
        } else if (className.contains("HttpMessageNotReadableException")
                || className.contains("TypeMismatchException")
                || className.contains("MissingServletRequestParameterException")) {
            httpStatus = HttpStatus.BAD_REQUEST.value();
            code = ErrorCode.BAD_REQUEST;
        } else if (className.contains("NoHandlerFoundException")) {
            httpStatus = HttpStatus.NOT_FOUND.value();
            code = ErrorCode.NOT_FOUND;
        } else if (className.contains("HttpRequestMethodNotSupportedException")) {
            httpStatus = HttpStatus.METHOD_NOT_ALLOWED.value();
            code = ErrorCode.METHOD_NOT_ALLOWED;
        } else if (className.contains("HttpMediaTypeNotAcceptableException")) {
            httpStatus = HttpStatus.BAD_REQUEST.value();
            code = ErrorCode.MEDIA_TYPE_NOT_ACCEPTABLE;
        } else if (className.contains("MethodArgumentNotValidException")) {
            BindingResult bindingResult = ((MethodArgumentNotValidException) ex).getBindingResult();
            code = ErrorCode.ALERT;
            return ResultBody.failed().flag(code.getCode()).msg(bindingResult.getFieldError().getDefaultMessage());
        } else if (className.contains("IllegalArgumentException")) {
            //参数错误
            code = ErrorCode.ALERT;
            httpStatus = HttpStatus.BAD_REQUEST.value();
            log.error("==> message:{}", ex.getMessage());
        } else if (className.contains("AlertException")) {
            code = ErrorCode.ALERT;
        }else {
            log.error("==> exception:", ex);
        }
        return buildBody(ex, code, path, httpStatus);
    }

    /**
     * 构建返回结果对象
     *
     * @param ex
     * @return
     */
    private static ResultBody buildBody(Exception ex, ErrorCode resultCode, String path, int httpStatus) {
        if (resultCode == null) {
            resultCode = ErrorCode.ERROR;
        }
        ResultBody resultBody = ResultBody.failed().flag(resultCode.getCode()).msg(ex.getMessage()).path(path).httpStatus(httpStatus);
        return resultBody;
    }
}
