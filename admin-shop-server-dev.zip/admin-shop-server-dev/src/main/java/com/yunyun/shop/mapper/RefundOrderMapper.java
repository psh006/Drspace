package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.RefundOrder;
import com.yunyun.shop.api.pojo.vo.RefundOrderRequestVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 *
 * @Classname GoodsCommentMapper
 * @Description TODO
 * @Date 2020/6/15 9:34
 * @author lxl
 */
@Mapper
public interface RefundOrderMapper {

    List<RefundOrder> queryRefundOrder(RefundOrderRequestVo refundOrderRequestVo);


    List<RefundOrder> queryRefundOrdering();
}