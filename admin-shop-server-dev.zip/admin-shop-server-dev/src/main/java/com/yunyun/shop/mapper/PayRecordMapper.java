package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.PayRecord;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PayRecordMapper {
    int deleteByPrimaryKey(String payId);

    int insert(PayRecord record);

    PayRecord selectByPrimaryKey(String payId);

    int updateByPrimaryKey(PayRecord record);

    int updateBatch(List<PayRecord> list);

    int batchInsert(@Param("list") List<PayRecord> list);
}