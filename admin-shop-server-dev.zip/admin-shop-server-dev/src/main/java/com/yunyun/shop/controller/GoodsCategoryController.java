package com.yunyun.shop.controller;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-15 14:35
 **/

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.api.pojo.entity.GoodsCategory;
import com.yunyun.shop.api.pojo.vo.GoodsCategoryResultVo;
import com.yunyun.shop.api.pojo.vo.GoodsCategoryVo;
import com.yunyun.shop.api.service.GoodsCategoryService;
import com.yunyun.shop.common.enums.YesOrNo;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @program: shop
 * @description: 物品分类管理
 * @author: CheGuangQuan
 * @create: 2020-06-12 11:17
 **/
@Api(tags = "物品分类管理")
@RestController
@RequestMapping("/goodsCategory")
public class GoodsCategoryController {

    @Autowired
    private GoodsCategoryService goodsCategoryService;

    /**
     * @param goodsCategoryId
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.entity.GoodsBase>
     * @auther CheGuangQuan
     * @date 2020/6/12 11:26
     */
    @ApiOperation(value = "根据id查询物品分类")
    @ApiImplicitParam(name = "goodsCategoryId", value = "1", required = true)
    @GetMapping("/queryGoodsCategoryById")
    public ResultBody<GoodsCategory> queryGoodsCategoryById(@RequestParam String goodsCategoryId){
        return ResultBody.ok(goodsCategoryService.selectByPrimaryKey(goodsCategoryId));
    }

    /**
     * @param goodsCategory
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List               <               com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "新增分类")
    @PostMapping("/insertGoodsCategory")
    public ResultBody insertGoodsCategory(@RequestBody GoodsCategory goodsCategory) {
        return goodsCategoryService.insert(goodsCategory);
    }

    /**
     * @param goodsCategory
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List               <               com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "修改分类")
    @PostMapping("/updateGoodsCategory")
    public ResultBody updateGoodsCategory(@RequestBody GoodsCategory goodsCategory) {
        return goodsCategoryService.updateByPrimaryKey(goodsCategory);
    }

    /**
     * @param goodsCategoryVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List               <               com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "删除分类")
    @PostMapping("/deleteGoodsCategory")
    public ResultBody deleteGoodsCategory(@RequestBody GoodsCategoryVo goodsCategoryVo) {
        String goodsCategoryId = goodsCategoryVo.getGoodsCategoryId();
        String[] goodsCategoryArray = goodsCategoryId.split(",");
        List<String> goodsCategoryList = Arrays.asList(goodsCategoryArray);
        int i = goodsCategoryService.deleteGoodsCategory(goodsCategoryList);
        return i > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }

    /**
     * @param goodsCategoryId
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List               <               com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "显示分类")
    @GetMapping("/showGoodsCategory")
    public ResultBody showGoodsCategory(@RequestParam("goodsCategoryId")String goodsCategoryId){
        String[] goodsCategoryArray = goodsCategoryId.split(",");
        List<String> goodsCategoryList = Arrays.asList(goodsCategoryArray);
        goodsCategoryService.showGoodsCategory(YesOrNo.YES.getValue(),goodsCategoryList);
        return ResultBody.ok().msg("显示成功");
    }

    /**
     * @param goodsCategoryId
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List               <               com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "隐藏分类")
    @GetMapping("/hideGoodsCategory")
    public ResultBody hideGoodsCategory(@RequestParam("goodsCategoryId")String goodsCategoryId){
        String[] goodsCategoryArray = goodsCategoryId.split(",");
        List<String> goodsCategoryList = Arrays.asList(goodsCategoryArray);
        goodsCategoryService.showGoodsCategory(YesOrNo.NO.getValue(),goodsCategoryList);
        return ResultBody.ok().msg("隐藏成功");
    }

    /**
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List               <               com.yunyun.shop.api.pojo.entity.GoodsBase>>
     * @auther CheGuangQuan
     * @date 2020/6/12 14:09
     */
    @ApiOperation(value = "查询所有分类")
    @PostMapping("/queryGoodsCategoryList")
    public ResultBody<List<GoodsCategoryResultVo>> queryGoodsCategoryList(){
        List<GoodsCategoryResultVo> goodsCategoryList= goodsCategoryService.queryGoodsCategoryList();
        return ResultBody.ok(goodsCategoryList);
    }

}