package com.yunyun.shop.api.pojo.dto;

import com.yunyun.shop.api.pojo.entity.OrderBase;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.pojo.dto
 * @createTime 2020-06-23 10:24
 */
@Data
public class OrderDto extends OrderBase implements Serializable {

    /**
     * 客户姓名
     */
    @ApiModelProperty(value="客户姓名")
    private String customerName;

    /**
     * 客户昵称
     */
    @ApiModelProperty(value="客户昵称")
    private String customerNickName;

    /**
     * 客户电话
     */
    @ApiModelProperty(value="客户电话")
    private String customerPhone;
}
