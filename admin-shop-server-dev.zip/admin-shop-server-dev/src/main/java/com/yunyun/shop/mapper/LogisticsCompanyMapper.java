package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.LogisticsCompany;
import com.yunyun.shop.api.pojo.vo.LogisticsRequestVo;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-16 15:04
 */
public interface LogisticsCompanyMapper {
    int deleteByPrimaryKey(String logisticsId);

    int insert(LogisticsCompany record);

    LogisticsCompany selectByPrimaryKey(String logisticsId);

    int updateByPrimaryKey(LogisticsCompany record);

    /**
     * 查询物流公司全部信息
     *
     * @return
     */
    List<LogisticsCompany> find();

    /**
     * 条件查询物流公司
     * @auther CheGuangQuan
     * @date 2020/6/22
     * @param logisticsRequestVo
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>
    */
    List<LogisticsCompany> queryLogisticsCompany(LogisticsRequestVo logisticsRequestVo);

    /**
     * 判断物流是否已添加
     * @auther CheGuangQuan
     * @date 2020/6/22 17:41
     * @param logisticsRequestVo
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.LogisticsCompany>
    */
    List<LogisticsCompany> queryLogisticsExist(LogisticsRequestVo logisticsRequestVo);
}