package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.dto.CustomerIntegralDto;
import com.yunyun.shop.api.pojo.entity.CustomerIntegral;
import java.util.List;

import com.yunyun.shop.api.pojo.vo.CustomerIntegralVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CustomerIntegralMapper {
    int deleteByPrimaryKey(String recordId);

    int insert(CustomerIntegral record);

    CustomerIntegral selectByPrimaryKey(String recordId);

    int updateByPrimaryKey(CustomerIntegral record);

    int updateBatch(List<CustomerIntegral> list);

    int batchInsert(@Param("list") List<CustomerIntegral> list);

    List<CustomerIntegralVo> selectList(CustomerIntegralDto customerIntegralDto);

    List<CustomerIntegral> selectByCustomerId(String customerId);
}