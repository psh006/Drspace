package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * @description com.yunyun.shop.api.pojo.entity
 * @author PuYaDong
 * @createTime 2020-06-12 15:55
 */

/**
 * 员工登录token表
 */
@ApiModel(value = "com-yunyun-shop-api-pojo-entity-EmpToken")
@Data
public class EmpToken implements Serializable {
    /**
     * 用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String empId;

    /**
     * 登录类型 LOGIN_TYPE
     */
    @ApiModelProperty(value = "登录类型 LOGIN_TYPE")
    private Integer loginType;

    /**
     * token
     */
    @ApiModelProperty(value = "token")
    private String loginToken;

    /**
     * 登录时间
     */
    @ApiModelProperty(value = "登录时间")
    private Date loginTime;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String loginNote;

    private static final long serialVersionUID = 1L;
}