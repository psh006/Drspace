package com.yunyun.shop.controller;

import com.yunyun.shop.api.pojo.entity.CustomerLevel;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.pojo.vo.UpdateState;
import com.yunyun.shop.api.service.CustomerLevelService;
import com.yunyun.shop.common.enums.UseState;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-29 14:43
 */
@Api(tags = "会员等级管理")
@RequestMapping("/customerLevel")
@RestController
public class CustomerLevelController {

    @Autowired
    private CustomerLevelService customerLevelService;

    /**
     * @description 查询等级
     * @auther PuYaDong
     * @date 2020-06-29 15:00
     * @param useState
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.CustomerLevel>>
     */
    @ApiOperation("条件查询等级")
    @ApiImplicitParam(name = "useState",value = "启用状态 USE_STATE" )
    @GetMapping("/queryLevel")
    public ResultBody<List<CustomerLevel>> queryLevel(Integer useState){
        return ResultBody.ok(customerLevelService.queryLevel(useState));
    }

    /**
     * @description 查询等级
     * @auther PuYaDong
     * @date 2020-06-29 15:00
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.CustomerLevel>>
     */
    @ApiOperation("可用等级列表(下拉选择栏)")
    @GetMapping("/list")
    public ResultBody<List<CustomerLevel>> list(){
        return ResultBody.ok(customerLevelService.queryLevel(UseState.ENABLE.getCode()));
    }

    /**
     * @description 新增等级
     * @auther PuYaDong
     * @date 2020-06-29 15:08
     * @param customerLevel
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("新增等级")
    @PostMapping("/add")
    public ResultBody add(@RequestBody @Validated(Insert.class) CustomerLevel customerLevel){
        return customerLevelService.insert(customerLevel) > 0 ?
                ResultBody.ok().msg("添加成功") : ResultBody.failed("添加失败");
    }

    /**
     * @description 编辑等级
     * @auther PuYaDong
     * @date 2020-06-29 15:08
     * @param customerLevel
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("修改等级")
    @PostMapping("/update")
    public ResultBody update(@RequestBody @Validated(Update.class) CustomerLevel customerLevel){
        return customerLevelService.updateByPrimaryKey(customerLevel) > 0 ?
                ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * @description 编辑等级状态
     * @auther PuYaDong
     * @date 2020-06-29 15:08
     * @param updateState
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("修改等级状态")
    @PostMapping("/updateState")
    public ResultBody updateState(@RequestBody @Validated UpdateState updateState){
        return customerLevelService.updateStateById(updateState) > 0 ?
                ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * @description 删除等级
     * @auther PuYaDong
     * @date 2020-06-29 15:32
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody
     */
    @ApiOperation("删除等级")
    @PostMapping("/delete")
    public ResultBody delete(@RequestBody @Validated OperateIdVo operateIdVo){
        return customerLevelService.deleteByPrimaryKey(operateIdVo.getId()) > 0 ?
                ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }
}
