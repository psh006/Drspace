package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.CommentsInfo;
import com.yunyun.shop.api.pojo.dto.GoodsCommentDTO;
import com.yunyun.shop.api.pojo.vo.GoodsCommentRequestVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import com.yunyun.shop.mapper.GoodsCommentMapper;
import com.yunyun.shop.api.pojo.entity.GoodsComment;
import com.yunyun.shop.api.service.GoodsCommentService;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author lxl
 * @Classname GoodsCommentServiceImpl
 * @Description TODO
 * @Date 2020/6/15 9:34
 */
@Service
public class GoodsCommentServiceImpl implements GoodsCommentService {

    @Resource
    private GoodsCommentMapper goodsCommentMapper;

    @Override
    public int deleteByPrimaryKey(String commentId) {
        return goodsCommentMapper.deleteByPrimaryKey(commentId);
    }

    @Override
    public int insert(GoodsComment record) {
        return goodsCommentMapper.insert(record);
    }

    @Override
    public GoodsComment selectByPrimaryKey(String commentId) {
        return goodsCommentMapper.selectByPrimaryKey(commentId);
    }

    @Override
    public int updateByPrimaryKey(GoodsComment record) {
        return goodsCommentMapper.updateByPrimaryKey(record);
    }


    /**
     * @Description: 查询物品评价
     * @params: * @param goodsCommentRequestVo
     * @return: PageInfo<GoodsCommentDTO>
     * @Author: lxl
     * @Date : 2020/6/16 10:08
     */
    @Override
    public PageInfo<GoodsCommentDTO> queryComment(GoodsCommentRequestVo goodsCommentRequestVo) {
        //先查询出评价表中的商品id
        List<GoodsCommentDTO> comments = goodsCommentMapper.queryGoodsId();
        if (comments.size() == 0) {
            return new PageInfo<>();
        }
        List<String> goodsIds = comments.stream().map(GoodsCommentDTO::getParentGoodsId).collect(Collectors.toList());
        goodsCommentRequestVo.setGoodsIdList(goodsIds);
        PageHelper.startPage(goodsCommentRequestVo.getPage(), goodsCommentRequestVo.getLimit());
        //查询物品信息
        List<GoodsCommentDTO> goodsCommentDTOList = goodsCommentMapper.queryComments(goodsCommentRequestVo);
        //查询商品的好评
        List<GoodsCommentDTO> goodComment = goodsCommentMapper.countGoodComment();
        //查询商品的中评
        List<GoodsCommentDTO> midComment = goodsCommentMapper.countMidComment();


        for (GoodsCommentDTO commentDTO : goodsCommentDTOList) {
            //好评
            for (GoodsCommentDTO goodsCommentDTO : goodComment) {
                if (goodsCommentDTO.getParentGoodsId().equals(commentDTO.getParentGoodsId())) {
                    commentDTO.setGoodComment(goodsCommentDTO.getGoodComment());
                }
            }
            //总评价
            for (GoodsCommentDTO goodsCommentDTO : comments) {
                if (goodsCommentDTO.getParentGoodsId().equals(commentDTO.getParentGoodsId())) {
                    commentDTO.setTotalComment(goodsCommentDTO.getTotalComment());
                }
            }
            //中评
            for (GoodsCommentDTO goodsCommentDTO : midComment) {
                if (goodsCommentDTO.getParentGoodsId().equals(commentDTO.getParentGoodsId())) {
                    commentDTO.setMidComment(goodsCommentDTO.getMidComment());
                }
            }

            //差评
            int bad = 0;
            commentDTO.setGoodComment(commentDTO.getGoodComment() == null ? 0 : commentDTO.getGoodComment());
            commentDTO.setMidComment(commentDTO.getMidComment() == null ? 0 : commentDTO.getMidComment());
            commentDTO.setTotalComment(commentDTO.getTotalComment() == null ? 0 : commentDTO.getTotalComment());
            int good = commentDTO.getGoodComment();
            int mid = commentDTO.getMidComment();
            int total = commentDTO.getTotalComment();
            bad = total - good - mid;
            commentDTO.setBadComment(bad);
        }


        return new PageInfo<>(goodsCommentDTOList);
    }


    /**
     * @Description: 评价详情
     * @params: [goodsCommentRequestVo]
     * @return: com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.CommentsInfo>
     * @Author: lxl
     * @Date : 2020/6/17 11:16
     */
    @Override
    public PageInfo<CommentsInfo> queryCommentsInfo(GoodsCommentRequestVo goodsCommentRequestVo) {
        PageHelper.startPage(goodsCommentRequestVo.getPage(), goodsCommentRequestVo.getLimit());
        //查询出评价
        List<CommentsInfo> commentsInfos = goodsCommentMapper.queryCommentsInfoByLevel(goodsCommentRequestVo);
        if (commentsInfos.size() == 0) {
            return new PageInfo<>();
        }
        common(commentsInfos);
        return new PageInfo<>(commentsInfos);
    }


    /**
     * @Description: 置顶
     * @params: [commentId]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/17 15:15
     */
    @Override
    public int updateIsTop(String commentId) {
        return goodsCommentMapper.updateIsTop(commentId);
    }

    /**
     * @Description: 取消置顶
     * @params: [commentId]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/17 15:15
     */
    @Override
    public int updateNoTop(String commentId) {
        return goodsCommentMapper.updateNoTop(commentId);
    }

    /**
     * @Description: 批量删除
     * @params: [commentIds]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/17 15:16
     */
    @Override
    public int updateIsDeleteMany(List<String> commentIds) {
        return goodsCommentMapper.updateIsDeleteMany(commentIds);
    }

    /**
     * @Description: 批量恢复
     * @params: [commentIds]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/17 15:16
     */
    @Override
    public int updateNoDeleteMany(List<String> commentIds) {
        return goodsCommentMapper.updateNoDeleteMany(commentIds);
    }

    /**
     * @Description: 批量真删除
     * @params: [commentIds]
     * @return: int
     * @Author: lxl
     * @Date : 2020/6/17 15:16
     */
    @Override
    public int deleteManyComments(List<String> commentIds) {
        return goodsCommentMapper.deleteManyComments(commentIds);
    }


    /**
     * @Description: 查看回收站
     * @params: [goodsCommentRequestVo]
     * @return: java.util.List<com.yunyun.shop.api.pojo.entity.CommentsInfo>
     * @Author: lxl
     * @Date : 2020/6/17 16:40
     */
    @Override
    public PageInfo<CommentsInfo> queryCommentsIsDelete(GoodsCommentRequestVo goodsCommentRequestVo) {
        PageHelper.startPage(goodsCommentRequestVo.getPage(), goodsCommentRequestVo.getLimit());
        //查询出评价
        List<CommentsInfo> commentsInfos = goodsCommentMapper.queryCommentsIsDelete(goodsCommentRequestVo);
        if (commentsInfos.size() == 0) {
            return new PageInfo<>();
        }
        common(commentsInfos);
        return new PageInfo<>(commentsInfos);
    }

    /**
     * @Description: 回收站和评价详情公共方法
     * @params: [commentsInfos]
     * @return: void
     * @Author: lxl
     * @Date : 2020/6/19 9:39
     */
    public void common(List<CommentsInfo> commentsInfos) {
        //取出具体商品id
        List<String> goodsIds = commentsInfos.stream().map(CommentsInfo::getGoodsId).distinct().collect(Collectors.toList());
        //查询出商品的规格
        List<CommentsInfo> goodsInfo = goodsCommentMapper.queryGoodsInfo(goodsIds);
        //取出子订单id
        List<String> orderIds = commentsInfos.stream().map(CommentsInfo::getOrderDetailId).collect(Collectors.toList());
        //查询出订单的运费
        List<CommentsInfo> freightAmount = goodsCommentMapper.queryFreightAmount(orderIds);

        //放入商品规格
        for (CommentsInfo commentsInfo : commentsInfos) {
            for (CommentsInfo info : goodsInfo) {
                if (commentsInfo.getGoodsId().equals(info.getGoodsId())) {
                    commentsInfo.setGoodsSpec(info.getGoodsSpec());
                }
            }
            //放入运费，总金额
            for (CommentsInfo info : freightAmount) {
                if (commentsInfo.getOrderDetailId().equals(info.getOrderDetailId())) {
                    commentsInfo.setDetailFreightAmount(info.getDetailFreightAmount());
                    commentsInfo.setDetailPayAmountReal(info.getDetailPayAmountReal());
                }
            }
        }
    }


}
