package com.yunyun.shop.api.pojo.vo;

import lombok.Data;

@Data
public class UserInfoRequestVo {
    private String userId;
    private String userName;
}
