package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysParams;
import com.yunyun.shop.api.pojo.vo.SysParamRequestVo;
import com.yunyun.shop.api.service.SysParamsService;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author lxl
 * @Classname SysParamController
 * @Description 系统参数
 * @Date 2020/6/23 14:03
 */
@Api(tags = "系统参数")
@RestController
@RequestMapping("/sysParam")
public class SysParamController {
    @Autowired
    private SysParamsService service;


    /**
     * @Description: 分页查询系统参数
     * @params: [sysParamRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody<java.util.List   <   com.yunyun.shop.api.pojo.entity.SysParams>>
     * @Author: lxl
     * @Date : 2020/6/23 14:36
     */
    @ApiOperation(value = "分页查询系统参数")
    @PostMapping("/querySysParam")
    public ResultBody<List<SysParams>> querySysParam(@RequestBody SysParamRequestVo sysParamRequestVo) {
        PageInfo<SysParams> info = service.querySyParams(sysParamRequestVo);
        return ResultBody.ok(info.getList(), info.getTotal());
    }

    /**
     * @Description: 删除系统参数
     * @params: [sysParamRequestVo]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/23 15:25
     */
    @ApiOperation(value = "删除系统参数")
    @PostMapping("/deleteSysParam")
    public ResultBody deleteSysParam(@RequestBody SysParamRequestVo sysParamRequestVo) {
        int delete = service.deleteByPrimaryKey(sysParamRequestVo.getParamId());
        return delete > 0 ? ResultBody.ok().msg("删除成功") : ResultBody.failed("删除失败");
    }

    /**
     * @Description: 新增系统参数
     * @params: [sysParams]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/23 17:24
     */
    @ApiOperation(value = "新增系统参数")
    @PostMapping("/insertSysParam")
    public ResultBody insertSysParam(@RequestBody @Validated(Insert.class) SysParams sysParams) {
        int insert = service.insert(sysParams);
        return insert > 0 ? ResultBody.ok().msg("新增成功") : ResultBody.failed("新增失败");
    }

    /**
     * @Description: 修改系统参数
     * @params: [sysParams]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/23 17:24
     */
    @ApiOperation(value = "修改系统参数")
    @PostMapping("/updateSysParam")
    public ResultBody updateSysParam(@RequestBody @Validated(Update.class) SysParams sysParams) {
        int insert = service.updateByPrimaryKey(sysParams);
        return insert > 0 ? ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * @Description: 查询系统参数通过id
     * @params: [sysParams]
     * @return: com.yunyun.shop.common.model.ResultBody
     * @Author: lxl
     * @Date : 2020/6/23 17:24
     */
    @ApiOperation(value = "查询系统参数通过id")
    @PostMapping("/selectSysParamById")
    public ResultBody<SysParams> insertSysParam(@RequestBody SysParamRequestVo requestVo) {
        SysParams sysParams = service.selectByPrimaryKey(requestVo.getParamId());
        return ResultBody.ok(sysParams);
    }

    /**
     * 批量修改系统参数
     *
     * @param sysParamsList
     * @return com.yunyun.shop.common.model.ResultBody
     * @auther CheGuangQuan
     * @date 2020/6/30 10:30
     */
    @ApiOperation(value = "批量修改系统参数")
    @PostMapping("/updateSysParamList")
    public ResultBody updateSysParamList(@RequestBody List<SysParams> sysParamsList) {
        int update = service.updateSysParamList(sysParamsList);
        return update > 0 ? ResultBody.ok().msg("修改成功") : ResultBody.failed("修改失败");
    }

    /**
     * 查询所有系统参数
     * @auther CheGuangQuan
     * @date 2020/7/1 9:20
     * @param
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List<com.yunyun.shop.api.pojo.entity.SysParams>>
    */
    @ApiOperation(value = "查询所有系统参数")
    @GetMapping("/selectSysParamListList")
    public ResultBody<List<SysParams>> selectSysParamListList(){
        List<SysParams> sysParamsList = service.selectSysParamListList();
        return ResultBody.ok(sysParamsList);
    }
}
