package com.yunyun.shop.util;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.common.util.BeanConvertUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Map;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.util
 * @createTime 2020-06-12 09:40
 */
public class AuthHelper {

    /**
     * @description 获取登录用户信息
     * @auther PuYaDong
     * @date 2020-06-12 16:51
     * @param
     * @return com.yunyun.shop.api.pojo.EmpUser
     */
    public static EmpUserDetail getUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            if (authentication instanceof UsernamePasswordAuthenticationToken){
                // 表单登录 username password ,session认证方式
                if (authentication.getPrincipal() instanceof EmpUserDetail) {
                    return (EmpUserDetail) authentication.getPrincipal();
                }
                if (authentication.getPrincipal() instanceof Map) {
                    return BeanConvertUtils.mapToObject((Map) authentication.getPrincipal(), EmpUserDetail.class);
                }
            }else {
                return null;
            }

        }
        return null;
    }

    /**
     * @description 获取登录用户id
     * @auther PuYaDong
     * @date 2020-06-12 16:51
     * @param
     * @return java.lang.String
     */
    public static String getUserId() {
        return getUser().getEmpId();
    }
}
