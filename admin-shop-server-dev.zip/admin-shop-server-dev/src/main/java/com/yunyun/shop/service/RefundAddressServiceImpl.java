package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.EmpUserDetail;
import com.yunyun.shop.common.enums.YesOrNo;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.util.AuthHelper;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.api.pojo.entity.RefundAddress;
import com.yunyun.shop.mapper.RefundAddressMapper;
import com.yunyun.shop.api.service.RefundAddressService;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @description com.yunyun.shop.service
 * @author PuYaDong
 * @createTime 2020-06-28 09:28
 */
@Transactional(rollbackFor = Exception.class)
@Service
public class RefundAddressServiceImpl implements RefundAddressService{

    @Resource
    private RefundAddressMapper refundAddressMapper;

    @Override
    public int deleteByPrimaryKey(String receiptAddressId) {
        return refundAddressMapper.deleteByPrimaryKey(receiptAddressId);
    }

    @Override
    public int insert(RefundAddress record) {
        // 1. 检查收获地址是否重复
        if (this.isExistAddress(record)) {
            throw new AlertException("添加失败，售后收货地址已存在");
        }
        // 2. 如果新增的售后地址是默认的，则置其他售后地址不是默认
        if(record.getIsDefault() == YesOrNo.YES.getValue()){
            refundAddressMapper.setNotDefault();
        }
        // 3. 执行添加
        record.setReceiptAddressId(IdWorker.getIdStr());
        EmpUserDetail user = AuthHelper.getUser();
        record.setOperateId(user.getEmpId());
        record.setOperateName(user.getEmpName());
        record.setOperateTime(new Date());
        return refundAddressMapper.insert(record);
    }

    /**
     * @description 获取所有收货地址
     * @auther PuYaDong
     * @date 2020-06-28 09:54
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.RefundAddress>
     */
    @Override
    public List<RefundAddress> all() {
        return refundAddressMapper.selectAll();
    }

    /**
     * @param refundAddress
     * @return boolean true-存在 false-不存在
     * @description 收货地址是否唯一
     * @auther PuYaDong
     * @date 2020-06-28 15:22
     */
    @Override
    public boolean isExistAddress(RefundAddress refundAddress) {
        return refundAddressMapper.isExistAddress(refundAddress) > 0;
    }

}
