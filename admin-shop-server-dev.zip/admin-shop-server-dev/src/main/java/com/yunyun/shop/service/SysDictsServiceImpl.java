package com.yunyun.shop.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.SysDictItems;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.model.PageParams;
import com.yunyun.shop.common.util.IdWorker;
import com.yunyun.shop.mapper.SysDictItemsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yunyun.shop.api.pojo.entity.SysDicts;
import com.yunyun.shop.mapper.SysDictsMapper;
import com.yunyun.shop.api.service.SysDictsService;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @description com.yunyun.shop.service
 * @author PuYaDong
 * @createTime 2020-06-13 15:35
 */
@Service
public class SysDictsServiceImpl  implements SysDictsService{

    @Autowired
    private SysDictsMapper sysDictsMapper;

    @Autowired
    private SysDictItemsMapper sysDictItemsMapper;

    /**
     * @description 获取字典信息
     * @auther PuYaDong
     * @date 2020-06-13 15:54
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.SysDicts>
     */
    @Override
    public List<SysDicts> getAllDict() {
        // 查询所有字典
        List<SysDicts> sysDicts = sysDictsMapper.selectAll();
        // 查询所有字典子项
        List<SysDictItems> sysDictItems = sysDictItemsMapper.selectAll();
        // 封装
        sysDicts = sysDicts.stream()
                .parallel()
                .peek(dict -> {
                    List<SysDictItems> dictItems = sysDictItems.stream()
                            .parallel()
                            .filter(dictItem -> dict.getDictId().equals(dictItem.getDictId()))
                            .sorted(Comparator.comparing(SysDictItems::getItemSort))
                            .collect(Collectors.toList());
                    dict.setDictItems(dictItems);
                }).collect(Collectors.toList());
        return sysDicts;
    }

    /**
     * @param pageParams
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.SysDicts>
     * @description 字典分页查询
     * @auther PuYaDong
     * @date 2020-06-18 15:26
     */
    @Override
    public PageInfo<SysDicts> page(PageParams pageParams) {
        PageHelper.startPage(pageParams.getPage(),pageParams.getLimit());
        List<SysDicts> sysDictsList = sysDictsMapper.selectAll();
        PageInfo<SysDicts> sysDictsPageInfo = new PageInfo<>(sysDictsList);
        // 查询所有字典子项
        List<SysDictItems> sysDictItems = sysDictItemsMapper.selectAll();
        // 封装
        sysDictsList = sysDictsList.stream()
                .peek(dict -> {
                    List<SysDictItems> dictItems = sysDictItems.stream()
                            .filter(dictItem -> dict.getDictId().equals(dictItem.getDictId()))
                            .sorted(Comparator.comparing(SysDictItems::getItemSort))
                            .collect(Collectors.toList());
                    dict.setDictItems(dictItems);
                }).collect(Collectors.toList());
        sysDictsPageInfo.setList(sysDictsList);
        return sysDictsPageInfo;
    }

    /**
     * @param sysDicts
     * @return int
     * @description 添加字典
     * @auther PuYaDong
     * @date 2020-06-18 16:40
     */
    @Override
    public int add(SysDicts sysDicts) {
        if (!this.isDictUnique(sysDicts)) {
            throw new AlertException("字典名称或代码已存在");
        }
        sysDicts.setDictId(IdWorker.getIdStr());
        return sysDictsMapper.insert(sysDicts);
    }

    /**
     * @param sysDicts
     * @return int
     * @description 修改字典
     * @auther PuYaDong
     * @date 2020-06-18 16:40
     */
    @Override
    public int update(SysDicts sysDicts) {
        if (!this.isDictUnique(sysDicts)) {
            throw new AlertException("字典名称或代码已存在");
        }
        return sysDictsMapper.update(sysDicts);
    }

    /**
     * @param dictId
     * @return int
     * @description 删除字典
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     */
    @Override
    public int delete(String dictId) {
        sysDictItemsMapper.deleteByDictId(dictId);
        return sysDictsMapper.delete(dictId);
    }

    /**
     * @param sysDictItems
     * @return int
     * @description 添加字典子项
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     */
    @Override
    public int addDictItem(SysDictItems sysDictItems) {
        if (!this.isDictItemUnique(sysDictItems)) {
            throw new AlertException("子项名称或值已存在");
        }
        sysDictItems.setItemId(IdWorker.getIdStr());
        return sysDictItemsMapper.insert(sysDictItems);
    }

    /**
     * @param sysDictItems
     * @return int
     * @description 修改字典子项
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     */
    @Override
    public int updateDictItem(SysDictItems sysDictItems) {
        if (!this.isDictItemUnique(sysDictItems)) {
            throw new AlertException("子项名称或值已存在");
        }
        return sysDictItemsMapper.update(sysDictItems);
    }

    /**
     * @param itemId
     * @return int
     * @description 删除字典子项
     * @auther PuYaDong
     * @date 2020-06-18 16:41
     */
    @Override
    public int deleteDictItem(String itemId) {
        return sysDictItemsMapper.delete(itemId);
    }

    /**
     * @param sysDicts
     * @return boolean
     * @description 检查字典是否存在
     * @auther PuYaDong
     * @date 2020-06-23 16:18
     */
    @Override
    public boolean isDictUnique(SysDicts sysDicts) {
        return sysDictsMapper.isDictUnique(sysDicts) == 0;
    }

    /**
     * @param sysDictItems
     * @return boolean
     * @description 检查字典子项是否存在
     * @auther PuYaDong
     * @date 2020-06-23 16:18
     */
    @Override
    public boolean isDictItemUnique(SysDictItems sysDictItems) {
        return sysDictItemsMapper.isDictItemUnique(sysDictItems) == 0;
    }

}
