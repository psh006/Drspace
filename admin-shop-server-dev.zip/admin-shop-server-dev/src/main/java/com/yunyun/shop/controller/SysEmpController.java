package com.yunyun.shop.controller;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.EmpBase;
import com.yunyun.shop.api.pojo.vo.EmpRequestVo;
import com.yunyun.shop.api.pojo.vo.OperateIdVo;
import com.yunyun.shop.api.pojo.vo.UpdateStateVo;
import com.yunyun.shop.api.service.EmpBaseService;
import com.yunyun.shop.common.model.ResultBody;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.controller
 * @createTime 2020-06-19 16:14
 */
@Api(tags = "员工管理")
@RestController
@RequestMapping("/sysEmp")
public class SysEmpController {

    @Autowired
    private EmpBaseService empBaseService;

    /**
     * @param empRequestVo
     * @return com.yunyun.shop.common.model.ResultBody<java.util.List < com.yunyun.shop.api.pojo.entity.EmpBase>>
     * @description 员工分页搜索列表
     * @auther PuYaDong
     * @date 2020-06-19 16:27
     */
    @ApiOperation("员工分页搜索列表")
    @GetMapping("/find")
    public ResultBody<List<EmpBase>> find(EmpRequestVo empRequestVo) {
        PageInfo<EmpBase> pageInfo = empBaseService.findEmpListPage(empRequestVo);
        return ResultBody.ok(pageInfo.getList(), pageInfo.getTotal());
    }

    /**
     * @param empId
     * @return com.yunyun.shop.common.model.ResultBody<com.yunyun.shop.api.pojo.entity.EmpBase>
     * @description 根据编号查询员工信息
     * @auther PuYaDong
     * @date 2020-06-19 16:45
     */
    @ApiOperation("根据编号查询员工信息")
    @GetMapping("/info")
    public ResultBody<EmpBase> info(String empId) {
        return ResultBody.ok(empBaseService.selectByPrimaryKey(empId));
    }

    /**
     * @param empBase
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 添加员工
     * @auther PuYaDong
     * @date 2020-06-19 16:49
     */
    @ApiOperation("添加员工")
    @PostMapping("/add")
    public ResultBody<Void> add(@RequestBody @Validated EmpBase empBase) {
        return empBaseService.add(empBase) > 0 ? ResultBody.ok() : ResultBody.failed("添加失败");
    }

    /**
     * @param empBase
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 编辑员工
     * @auther PuYaDong
     * @date 2020-06-19 16:49
     */
    @ApiOperation("编辑员工")
    @PostMapping("/update")
    public ResultBody<Void> update(@RequestBody @Validated(Update.class) EmpBase empBase) {
        return empBaseService.update(empBase) > 0 ? ResultBody.ok() : ResultBody.failed("修改失败");
    }

    /**
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 删除员工
     * @auther PuYaDong
     * @date 2020-06-19 16:49
     */
    @ApiOperation("删除员工")
    @PostMapping("/delete")
    public ResultBody<Void> delete(@RequestBody @Validated OperateIdVo operateIdVo) {
        return empBaseService.deleteByPrimaryKey(operateIdVo.getId()) > 0 ? ResultBody.ok() : ResultBody.failed("删除失败");
    }

    /**
     * @param updateStateVo
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 修改员工状态
     * @auther PuYaDong
     * @date 2020-06-24 10:02
     */
    @ApiOperation("修改员工状态")
    @PostMapping("/updateState")
    public ResultBody<Void> updateState(@RequestBody @Validated UpdateStateVo updateStateVo) {
        return empBaseService.updateState(updateStateVo) > 0 ? ResultBody.ok() : ResultBody.failed("修改失败");
    }

    /**
     * @param operateIdVo
     * @return com.yunyun.shop.common.model.ResultBody<java.lang.Void>
     * @description 重置员工密码
     * @auther PuYaDong
     * @date 2020-06-24 10:03
     */
    @ApiOperation("重置员工密码")
    @PostMapping("/resetPassword")
    public ResultBody<Void> resetPassword(@RequestBody @Validated OperateIdVo operateIdVo) {
        return empBaseService.resetPassword(operateIdVo) > 0 ? ResultBody.ok() : ResultBody.failed("重置失败");
    }

}
