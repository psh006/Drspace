package com.yunyun.shop.common.enums;

public enum Gender {
    //男
    MALE(1,"男"),
    //女
    FEMALE(2,"女");

    private int code;
    private String desc;

    Gender(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }
}
