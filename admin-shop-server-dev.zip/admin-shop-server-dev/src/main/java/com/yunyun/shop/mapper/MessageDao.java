package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-13 17:23
 */
@Repository
public interface MessageDao extends JpaRepository<Message, Long> {
}
