package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-15 16:27
 **/
@Data
public class GoodsIdVo implements Serializable {
    /**
     * 主商品编号
     */
    @NotEmpty(message = "请选择要下架的物品")
    @ApiModelProperty(value="主商品编号")
    private List<String> goodsIds;
}