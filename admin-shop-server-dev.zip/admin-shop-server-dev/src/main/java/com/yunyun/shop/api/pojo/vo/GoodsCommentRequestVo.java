package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author lxl
 * @Classname GoodsCommentRequestVo
 * @Description TODO
 * @Date 2020/6/17 15:09
 */
@Data
public class GoodsCommentRequestVo extends PageParams implements Serializable {


        /**
         * 关联商品类别编号
         */
        @ApiModelProperty(value = "关联商品类别编号")
        private String goodsCategoryId;

        /**
         * 上架状态，PUT_STATE（PUT_UP,PUT_DOWN）
         */
        @ApiModelProperty(value = "上架状态，PUT_STATE（PUT_UP,PUT_DOWN）")
        private Integer putState;


        /**
         * 商品名称
         */
        @ApiModelProperty(value = "商品名称")
        private String parentGoodsName;


        /**
         *  主商品id
         */
        @ApiModelProperty(value = "主商品id")
        private List<String> goodsIdList;


        /**
         * 评价级别
         */
        @ApiModelProperty(value = "评价级别")
        private int commentLevel;


        /**
         * 订单编号
         */
        @ApiModelProperty(value = "订单编号")
        private String orderId;


        @ApiModelProperty(value = "主商品编号")
        private String parentGoodsId;

        private static final long serialVersionUID = 1L;

}
