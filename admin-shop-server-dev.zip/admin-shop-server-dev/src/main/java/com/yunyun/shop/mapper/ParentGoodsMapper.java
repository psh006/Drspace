package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.dto.GoodsIdNameDto;
import com.yunyun.shop.api.pojo.entity.ParentGoods;import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;import org.apache.ibatis.annotations.Param;import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-16 12:17
 */
public interface ParentGoodsMapper {
    int deleteByPrimaryKey(String parentGoodsId);

    ParentGoods selectByPrimaryKey(String parentGoodsId);

    int updateByPrimaryKey(ParentGoods record);

    List<ParentGoods> queryGoodsList(GoodsRequestVo goodsRequestVo);

    int deleteSeveralGoods(@Param("goodsIdList") List<String> goodsIdList);

    int deleteLogicGoodsById(@Param("goodsIdList") List<String> goodsIdList);

    List<ParentGoods> selectRecycleGoods(GoodsRequestVo goodsRequestVo);

    int recoverGoods(@Param("goodsIdList") List<String> goodsIds);

    int putGoods(@Param("putState") int putState, @Param("goodsIds") List<String> goodsIds);

    int insert(ParentGoods parentGoods);

    int refreshParentGoods(ParentGoods parentGoods);

    List<GoodsIdNameDto> getGoodsIdNameList();
}