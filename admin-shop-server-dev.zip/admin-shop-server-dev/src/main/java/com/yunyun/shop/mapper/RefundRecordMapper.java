package com.yunyun.shop.mapper;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.HistoryRefundOrderResult;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.api.pojo.vo.HistoryRefundOrderQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RefundRecordMapper {
    int deleteByPrimaryKey(String refundId);

    int insert(RefundRecord record);

    RefundRecord selectByPrimaryKey(String refundId);

    int updateByPrimaryKey(RefundRecord record);
    //退款
    int refund(@Param("list") List<RefundRecord> list);

    List<HistoryRefundOrderResult> queryHistory(HistoryRefundOrderQuery historyRefundOrderQuery);
}