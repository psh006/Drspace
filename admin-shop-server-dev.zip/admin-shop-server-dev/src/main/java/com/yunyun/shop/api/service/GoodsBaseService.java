package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.entity.GoodsBase;
import com.yunyun.shop.api.pojo.vo.GoodsRequestVo;

import java.util.List;

public interface GoodsBaseService{


    int deleteByPrimaryKey(String goodsId);

    int insert(GoodsBase record);

    GoodsBase selectByPrimaryKey(String goodsId);

    int updateByPrimaryKey(GoodsBase record);

    /**
     * 分页查询物品
     * @auther CheGuangQuan
     * @date 2020/6/12 14:46
     * @param goodsRequestVo
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.entity.GoodsBase>
    */
    PageInfo<GoodsBase> findInPage(GoodsRequestVo goodsRequestVo);

    /**
     * 批量删除物品(物理删除)
     * @auther CheGuangQuan
     * @date 2020/6/12 14:46
     * @param goodsIds
     * @return int
    */
    int deleteSeveralGoods(List<String> goodsIds);

    /**
     * 逻辑删除
     * @auther CheGuangQuan
     * @date 2020/6/12 14:59
     * @param goodsIds
     * @return int
    */
    int deleteLogicGoodsById(List<String> goodsIds);

    /**
     * 条件分页查询回收站商品
     * @auther CheGuangQuan
     * @date 2020/6/12 15:25
     * @param goodsRequestVo
     * @return com.yunyun.shop.api.pojo.entity.GoodsBase
    */
    PageInfo<GoodsBase> selectRecycleGoods(GoodsRequestVo goodsRequestVo);

    int recoverGoods(List<String> goodsIds);
}
