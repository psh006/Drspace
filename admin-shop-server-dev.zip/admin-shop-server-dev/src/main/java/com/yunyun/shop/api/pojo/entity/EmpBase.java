package com.yunyun.shop.api.pojo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

/**
 * @description 系统员工表
 * @author PuYaDong
 * @createTime 2020-06-12 09:14
 */
@ApiModel(value = "系统员工实体")
@Data
public class EmpBase implements Serializable {
    /**
     * 员工编号
     */
    @NotBlank(groups = Update.class, message = "员工编号不能为空")
    @ApiModelProperty(value = "员工编号")
    private String empId;

    /**
     * 员工姓名
     */
    @Length(min = 2, max= 10, message = "姓名长度须在2~10个字符之间")
    @ApiModelProperty(value = "员工姓名")
    private String empName;

    /**
     * 员工状态，USER_STATE
     */
    @ApiModelProperty(value = "员工状态，USER_STATE")
    private Integer empState;

    /**
     * 登录账号，手机号或邮箱
     */
    @NotBlank(message = "登录账号不能为空")
    @Length(min = 6,max = 20,message = "登录账号长度须在6~20位")
    @ApiModelProperty(value = "登录账号，手机号或邮箱")
    private String loginCode;

    /**
     * 登录密码
     */
    @JsonIgnore
    @ApiModelProperty(value = "登录密码")
    private String loginPass;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String mobilePhone;

    /**
     * 头像
     */
    @ApiModelProperty(value = "头像")
    private String headImg;

    /**
     * 性别，GENDER
     */
    @NotNull(message = "性别不能为空")
    @ApiModelProperty(value = "性别，GENDER")
    private Integer gender;

    /**
     * 出生日期，年月日
     */
    @Past(message = "出生日期只能选择过去的日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "出生日期，年-月-日")
    private Date birthday;

    /**
     * 部门编号
     */
    @NotBlank(message = "部门不能为空")
    @ApiModelProperty(value = "部门编号")
    private String sectorId;

    /**
     * 部门名称
     */
    @ApiModelProperty(value = "部门名称")
    private String sectorName;

    /**
     * 角色编号
     */
    @ApiModelProperty(value = "角色编号")
    private String roleId;

    /**
     * 角色名称
     */
    @ApiModelProperty(value = "角色名称")
    private String roleName;

    /**
     * 备注
     */
    @Length(max = 200,message = "备注不能超过200个字")
    @ApiModelProperty(value = "备注")
    private String note;

    /**
     * 最近登录时间
     */
    @ApiModelProperty(value = "最近登录时间",readOnly = true)
    private Date lastLoginTime;

    /**
     * 操作人编号
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人编号")
    private String operateId;

    /**
     * 操作人姓名
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 更新时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}