package com.yunyun.shop.service;

import com.yunyun.shop.api.pojo.entity.OrderBase;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.api.pojo.vo.AgreeRefundVo;
import com.yunyun.shop.api.pojo.vo.RefundAddress;
import com.yunyun.shop.api.service.RefundOrderInfService;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.mapper.RefundOrderInfServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description 退款信息
 * @author zzd
 * @date 2020-06-19 10:55
 */
@Service
public class RefundOrderInfServiceImpl implements RefundOrderInfService {

    @Autowired
    private RefundOrderInfServiceMapper refundOrderInfServiceMapper;

    /**
     * @param
     * @return com.yunyun.shop.api.pojo.vo.RefundAddress
     * @description 获取售后收货地址
     * @auther zzd
     * @date 2020-06-19 11:16
     */
    @Override
    public List<RefundAddress> afterSalesReceivingAddress() {
        //获取收货地址
        List<RefundAddress> refundAddresses = refundOrderInfServiceMapper.queryRefundAddress();
        return refundAddresses;
    }

    /**
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.entity.OrderBase
     * @description 获取订单信息
     * @auther zzd
     * @date 2020-06-19 11:40
     */
    @Override
    public OrderDetail getOderInfByOrderId(String orderDetailId) {
        if (orderDetailId == null || orderDetailId == "") {
            throw new AlertException("未传入订单编号");
        } else {
            //根据订单号获取订单信息
            OrderDetail orderInf = refundOrderInfServiceMapper.queryOrderInfByOrderId(orderDetailId);
            return orderInf;
        }
    }

    /**
     * @description 根据子订单编号获取退款单信息
     * @auther zzd
     * @date 2020-06-19 13:41
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.entity.OrderDetail
     */
    @Override
    public RefundRecord orderDetailInf(String orderDetailId) {
        if (orderDetailId==null || orderDetailId==""){
            throw new AlertException("未传入子订单编号");
        }else {
            RefundRecord orderDetail=refundOrderInfServiceMapper.orderDetailInf(orderDetailId);
            return orderDetail;
        }
    }

    /**
     * @description 退款处理-同意/拒绝/批量同意/批量拒绝
     * @auther zzd
     * @date 2020-06-19 14:20
     * @param agreeRefundVoList
     * @return java.lang.String
     */
    @Override
    public int refundProcessing(List<AgreeRefundVo> agreeRefundVoList) {
        if (agreeRefundVoList.size()<=0){
            throw new AlertException("未传入参数");
        }else {
            int i = refundOrderInfServiceMapper.refundProcessing(agreeRefundVoList);
            //更改同意退款的子订单的状态
            for (AgreeRefundVo agreeRefundVo : agreeRefundVoList) {
                if (agreeRefundVo.getRefundState()==2){
                    //子订单状态改为退款中
                    refundOrderInfServiceMapper.updateOrderDetailState(agreeRefundVo);
                }
            }

            return i;
        }
    }

}
