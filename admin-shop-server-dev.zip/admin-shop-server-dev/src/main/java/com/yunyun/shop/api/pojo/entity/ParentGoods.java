package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yunyun.shop.common.model.Insert;
import com.yunyun.shop.common.model.Update;
import com.yunyun.shop.common.model.ValidList;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 主物品表
 */
@ApiModel(value = "主物品")
@Data
public class ParentGoods implements Serializable {
    /**
     * 主物品编号
     */
    @NotBlank(groups = {Update.class}, message = "主物品编号不能为空")
    @ApiModelProperty(value = "主物品编号")
    private String parentGoodsId;

    /**
     * 主物品名称
     */
    @Length(groups = {Insert.class, Update.class}, min = 1, max = 40, message = "主物品名称长度须在1~40之间")
    @ApiModelProperty(value = "主物品名称")
    private String parentGoodsName;

    /**
     * 排序
     */
    @Range(groups = {Insert.class, Update.class}, min = 1, message = "排序须大于0")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 关联物品类别编号
     */
    @NotBlank(groups = {Insert.class, Update.class}, message = "类别编号不能为空")
    @ApiModelProperty(value = "关联物品类别编号")
    private String goodsCategoryId;

    /**
     * 关联物品类别名称
     */
    @NotBlank(groups = {Insert.class, Update.class}, message = "类别名称不能为空")
    @ApiModelProperty(value = "关联物品类别名称")
    private String goodsCategoryName;

    /**
     * 所有规格，json字符串(物品规格表中字段)
     */
    @NotBlank(groups = {Insert.class, Update.class}, message = "规格不能为空")
    @ApiModelProperty(value = "所有规格，json字符串(物品规格表中字段)")
    private String goodsSpecItems;

    /**
     * 物品封面
     */
    @ApiModelProperty(value = "物品封面")
    private String goodsCover;

    /**
     * 子物品中的最低单价
     */
    @ApiModelProperty(value = "子物品中的最低单价", readOnly = true)
    private BigDecimal goodsPriceMin;

    /**
     * 子物品中的最高单价
     */
    @ApiModelProperty(value = "子物品中的最高单价", readOnly = true)
    private BigDecimal goodsPriceMax;

    /**
     * 子物品库存总和
     */
    @ApiModelProperty(value = "子物品库存总和", readOnly = true)
    private Integer goodsStockSum;

    /**
     * 上架状态，PUT_STATE（PUT_UP,PUT_DOWN）
     */
    @NotNull(groups = {Insert.class, Update.class}, message = "上架状态不能为空")
    @ApiModelProperty(value = "上架状态，PUT_STATE（PUT_UP,PUT_DOWN）")
    private Integer putState;

    /**
     * 是否包邮，YES_NO
     */
    @NotNull(groups = {Insert.class, Update.class}, message = "是否包邮不能为空")
    @ApiModelProperty(value = "是否包邮，YES_NO")
    private Integer isPinkage;

    /**
     * 物品属性，GOODS_PROPERTY
     */
    @NotNull(groups = {Insert.class, Update.class}, message = "物品属性不能为空")
    @ApiModelProperty(value = "物品属性，GOODS_PROPERTY")
    private Integer goodsProperty;

    /**
     * 可发快递编号，多个用逗号隔开
     */
    @NotNull(groups = {Insert.class, Update.class}, message = "可发快递不能为空")
    @ApiModelProperty(value = "可发快递编号，多个用逗号隔开")
    private String goodsLogistics;

    /**
     * 上架时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "上架时间")
    private Date putTime;

    /**
     * 是否可退款，YES_NO
     */
    @ApiModelProperty(value = "是否可退款，YES_NO")
    private Integer isCanRefund;

    /**
     * 是否预警
     */
    @ApiModelProperty(value = "是否预警")
    private Integer isStockWarn;

    /**
     * 运费模板编号
     */
    @ApiModelProperty(value = "运费模板编号")
    private String freightTemplateId;

    /**
     * 物品详情
     */
    @ApiModelProperty(value = "物品详情")
    private String goodsDetail;

    /**
     * 物品参数
     */
    @ApiModelProperty(value = "物品参数")
    private String goodsParams;

    /**
     * 真实销量
     */
    @ApiModelProperty(value = "真实销量", readOnly = true)
    private Integer salesVolumeReal;

    /**
     * 起始销量
     */
    @ApiModelProperty(value = "起始销量")
    private Integer salesVolumeStart;

    /**
     * 虚拟销量
     */
    @ApiModelProperty(value = "虚拟销量")
    private Integer salesVolumeVirtual;

    /**
     * 是否在WEB物城显示，YES_NO
     */
    @ApiModelProperty(value = "是否在WEB物城显示，YES_NO")
    private Integer isShowWeb;

    /**
     * 是否在APP物城显示，YES_NO
     */
    @ApiModelProperty(value = "是否在APP物城显示，YES_NO")
    private Integer isShowApp;

    /**
     * 是否在公众号/小程序物城显示，YES_NO
     */
    @ApiModelProperty(value = "是否在公众号/小程序物城显示，YES_NO")
    private Integer isShowWechat;

    /**
     * 是否删除，YES_NO（删除后将进入到回收站）
     */
    @JsonIgnore
    @ApiModelProperty(value = "是否删除，YES_NO（删除后将进入到回收站）")
    private Integer isDelete;

    /**
     * 删除时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "删除时间")
    private Date deleteTime;

    /**
     * 操作人id
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人id")
    private String operateId;

    /**
     * 操作人姓名
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作人姓名")
    private String operateName;

    /**
     * 操作时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "操作时间")
    private Date operateTime;

    /**
     * 修改时间
     */
    @JsonIgnore
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    /**
     * 子商品列表
     */
    @Valid
    @ApiModelProperty(value = "子商品列表")
    private List<ChildGoods> childGoodsList;

    private static final long serialVersionUID = 1L;
}