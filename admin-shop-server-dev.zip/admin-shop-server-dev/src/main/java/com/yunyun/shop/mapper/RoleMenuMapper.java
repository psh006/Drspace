package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.RoleMenu;
import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.api.pojo.vo.SysRoleRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *
 * @Classname RoleMenuMapper
 * @Description TODO
 * @Date 2020/6/24 10:33
 * @author lxl
 */
@Mapper
public interface RoleMenuMapper {
    int deleteByPrimaryKey(@Param("roleId") String roleId);

    int insert(RoleMenu record);

    int batchInsert(@Param("list")List<RoleMenu> list);

}