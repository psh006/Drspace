package com.yunyun.shop.api.pojo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @description 订单表
 * @author PuYaDong
 * @createTime 2020-06-11 12:53
 */
@ApiModel(value="订单实体")
@Data
public class OrderBase implements Serializable {
    /**
    * 订单编号
    */
    @ApiModelProperty(value="订单编号")
    private String orderId;

    /**
    * 订单状态，ORDER_STATE
    */
    @ApiModelProperty(value="订单状态，ORDER_STATE")
    private Integer orderState;

    /**
    * 关联客户编号
    */
    @ApiModelProperty(value="关联客户编号")
    private String customerId;

    /**
    * 收货人姓名
    */
    @ApiModelProperty(value="收货人姓名")
    private String receiptName;

    /**
    * 收货电话
    */
    @ApiModelProperty(value="收货电话")
    private String receiptPhone;

    /**
    * 收货地址
    */
    @ApiModelProperty(value="收货地址")
    private String receiptAddress;

    /**
    * 邮编
    */
    @ApiModelProperty(value="邮编")
    private String receiptPostcode;

    /**
    * 订单备注
    */
    @ApiModelProperty(value="订单备注")
    private String orderNote;

    /**
    * 关联商品{商品编号，商品名称，商品类别编号，商品类别名称，商品规格编号，商品规格名称,数量}
    */
    @ApiModelProperty(value="关联商品{商品编号，商品名称，商品类别编号，商品类别名称，商品规格编号，商品规格名称,数量}")
    private String goodsJson;

    /**
    * 商品数量
    */
    @ApiModelProperty(value="商品数量")
    private Integer orderGoodsCount;

    /**
    * 订单总金额（商品总金额+运费）
    */
    @ApiModelProperty(value="订单总金额（商品总金额+运费）")
    private BigDecimal orderAmount;

    /**
    * 商品总金额（所有商品原始价格合计）
    */
    @ApiModelProperty(value="商品总金额（所有商品原始价格合计）")
    private BigDecimal goodsAmount;

    /**
    * 运费
    */
    @ApiModelProperty(value="运费")
    private BigDecimal freightAmount;

    /**
    * 实付金额（订单总金额-优惠金额）
    */
    @ApiModelProperty(value="实付金额（订单总金额-优惠金额）")
    private BigDecimal payAmount;

    /**
    * 优惠金额
    */
    @ApiModelProperty(value="优惠金额")
    private BigDecimal discountAmount;

    /**
    * 优惠说明
    */
    @ApiModelProperty(value="优惠说明")
    private String discountNote;

    /**
    * 物流公司编号
    */
    @ApiModelProperty(value="物流公司编号")
    private String logisticsId;

    /**
    * 物流公司名称
    */
    @ApiModelProperty(value="物流公司名称")
    private String logisticsName;

    /**
    * 快递单号
    */
    @ApiModelProperty(value="快递单号")
    private String logisticsNumber;

    /**
    * 创建时间
    */
    @ApiModelProperty(value="创建时间")
    private Date createTime;

    /**
    * 完成时间
    */
    @ApiModelProperty(value="完成时间")
    private Date finishTime;

    /**
    * 取消时间
    */
    @ApiModelProperty(value="取消时间")
    private Date cancelTime;

    /**
    * 是否删除，YES_NO（仅做软删除）
    */
    @JsonIgnore
    @ApiModelProperty(value="是否删除，YES_NO（仅做软删除）")
    private Integer isDelete;

    /**
    * 操作人编号
    */
    @JsonIgnore
    @ApiModelProperty(value="操作人编号")
    private String operateId;

    /**
    * 操作人姓名
    */
    @JsonIgnore
    @ApiModelProperty(value="操作人姓名")
    private String operateName;

    /**
    * 操作时间
    */
    @JsonIgnore
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 更新时间
    */
    @JsonIgnore
    @ApiModelProperty(value="更新时间")
    private Date updateTime;

    /**
     * 支付方式
     */
    @ApiModelProperty(value = "支付方式")
    private int payMethod;

    private static final long serialVersionUID = 1L;
}
