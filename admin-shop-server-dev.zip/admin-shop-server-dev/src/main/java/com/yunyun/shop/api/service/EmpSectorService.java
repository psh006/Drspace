package com.yunyun.shop.api.service;

import com.yunyun.shop.api.pojo.entity.EmpSector;

import java.util.List;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.api.service
 * @createTime 2020-06-24 10:25
 */
public interface EmpSectorService {


    int deleteByPrimaryKey(String sectorId);

    int insert(EmpSector record);

    EmpSector selectByPrimaryKey(String sectorId);

    int updateByPrimaryKey(EmpSector record);

    /**
     * @description 部门列表
     * @auther PuYaDong
     * @date 2020-06-24 10:29
     * @param
     * @return java.util.List<com.yunyun.shop.api.pojo.entity.EmpSector>
     */
    List<EmpSector> list();
}
