package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.CommentsInfo;
import com.yunyun.shop.api.pojo.entity.GoodsComment;
import com.yunyun.shop.api.pojo.dto.GoodsCommentDTO;
import com.yunyun.shop.api.pojo.vo.GoodsCommentRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 *
 * @Classname GoodsCommentMapper
 * @Description TODO
 * @Date 2020/6/15 9:34
 * @author lxl
 */
@Mapper
public interface GoodsCommentMapper {
    int deleteByPrimaryKey(String commentId);

    int insert(GoodsComment record);

    GoodsComment selectByPrimaryKey(String commentId);

    int updateByPrimaryKey(GoodsComment record);

    List<GoodsCommentDTO> queryGoodsId();

    List<GoodsCommentDTO> queryComments(GoodsCommentRequestVo goodsCommentRequestVo);

    List<GoodsCommentDTO> countGoodComment();

    List<GoodsCommentDTO> countMidComment();

    List<GoodsCommentDTO> countBadComment();

    int updateIsTop(@Param("commentId") String commentId);

    int updateNoTop(@Param("commentId") String commentId);

    int updateIsDeleteMany(@Param("commentIds") List<String> commentIds);

    int updateNoDeleteMany(@Param("commentIds") List<String> commentIds);

    int deleteManyComments(@Param("commentIds") List<String> commentIds);

    List<CommentsInfo> queryCommentsInfoByLevel(GoodsCommentRequestVo goodsCommentRequestVo);

    List<CommentsInfo> queryCommentsIsDelete(GoodsCommentRequestVo goodsCommentRequestVo);

    List<CommentsInfo> queryGoodsInfo(@Param("goodsIds") List<String> goodsIds);

    List<CommentsInfo> queryFreightAmount(@Param("orderIds") List<String> orderIds);
}