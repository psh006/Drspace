package com.yunyun.shop.mapper;

import com.yunyun.shop.api.pojo.entity.SysRole;
import com.yunyun.shop.api.pojo.vo.SysRoleRequestVo;
import org.apache.ibatis.annotations.Mapper;import org.apache.ibatis.annotations.Param;import java.util.List;

/**
 * @author lxl
 * @Classname SysRoleMapper
 * @Description TODO
 * @Date 2020/6/24 10:31
 */
@Mapper
public interface SysRoleMapper {
    int deleteByPrimaryKey(String roleId);

    int insert(SysRole record);

    SysRole selectByPrimaryKey(String roleId);

    int updateByPrimaryKey(SysRole record);

    List<SysRole> selectRoles(SysRoleRequestVo sysRoleRequestVo);

    List<SysRole> selectRoleByUserId(String empId);

    int updateMenuIds(SysRoleRequestVo sysRoleRequestVo);
}