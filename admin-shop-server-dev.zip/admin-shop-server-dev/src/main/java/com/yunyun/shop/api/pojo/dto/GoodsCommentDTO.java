package com.yunyun.shop.api.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author lxl
 * @Classname GoodsCommentDTO
 * @Description TODO
 * @Date 2020/6/15 11:07
 */
@Data
@ApiModel(value = "评价dto")
public class GoodsCommentDTO {
    /**
     *主商品编号
     */
    @ApiModelProperty(value = "主商品编号")
    public String parentGoodsId;

    /**
     *图片
     */
    @ApiModelProperty(value = "图片")
    public String goodsCover;

    /**
     *主商品名字
     */
    @ApiModelProperty(value = "主商品名字")
    public String parentGoodsName;

    /**
     *商品类别名称
     */
    @ApiModelProperty(value = "商品类别名称")
    public String goodsCategoryName;

    /**
     *价格
     */
    @ApiModelProperty(value = "价格")
    public BigDecimal goodsPriceMin;

    /**
     *上架状态
     */
    @ApiModelProperty(value = "上架状态，PUT_STATE（PUT_UP,PUT_DOWN）")
    private Integer putState;

    /**
     *上架时间
     */
    @ApiModelProperty(value = "上架时间")
    private Date putTime;

    /**
     *总评价
     */
    @ApiModelProperty(value = "总评价")
    private Integer totalComment;

    /**
     *好评
     */
    @ApiModelProperty(value = "好评")
    private Integer goodComment;

    /**
     *中评
     */
    @ApiModelProperty(value = "中评")
    private Integer midComment;

    /**
     *差评
     */
    @ApiModelProperty(value = "差评")
    private Integer badComment;
}
