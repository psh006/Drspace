package com.yunyun.shop.api.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-06-15 16:34
 **/
@Data
@ToString
public class GoodsCategoryResultVo implements Serializable {
    /**
     * 类别编号
     */
    @ApiModelProperty(value="类别编号")
    private String goodsCategoryId;

    /**
     * 类别名称
     */
    @ApiModelProperty(value="类别名称")
    private String goodsCategoryName;

    /**
     * 父级Id
     */
    @ApiModelProperty(value="父级Id")
    private String parentId;

    /**
     * 图标
     */
    @ApiModelProperty(value="图标")
    private String goodsCategoryIcon;

    /**
     * 排序
     */
    @ApiModelProperty(value="排序")
    private Integer sort;

    /**
     * 是否枝叶 YES_NO 1是2否
     */
    @ApiModelProperty(value="是否枝叶 YES_NO 1是2否")
    private Integer isLeaf;


    /**
     * 显示状态 SHOW_STATE
     */
    @ApiModelProperty(value="显示状态 SHOW_STATE")
    private Integer isDisplay;


    /**
     * 子分类
     */
    @ApiModelProperty(value="子分类")
    private List<GoodsCategoryResultVo> children;

}