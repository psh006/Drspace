package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
    * 支付退款记录表
    */
@ApiModel(value="com-yunyun-shop-api-pojo-entity-RefundRecord")
@Data
public class RefundRecord implements Serializable {
    /**
    * 退款编号
    */
    @ApiModelProperty(value="退款编号")
    private String refundId;

    /**
    * 客户编号
    */
    @ApiModelProperty(value="客户编号")
    private String customerId;

    /**
    * 关联订单编号
    */
    @ApiModelProperty(value="关联订单编号")
    private String orderId;

    @ApiModelProperty(value="")
    private String orderDetailId;

    /**
    * 退款方式，REFUND_METHOD
    */
    @ApiModelProperty(value="退款方式，REFUND_METHOD")
    private Integer refundMethod;

    /**
    * 退款状态，REFUND_STATE
    */
    @ApiModelProperty(value="退款状态，REFUND_STATE")
    private Integer refundState;

    /**
    * 退款流水号
    */
    @ApiModelProperty(value="退款流水号")
    private String refundSerialNum;

    /**
    * 退款反馈
    */
    @ApiModelProperty(value="退款反馈")
    private String refundFeedback;

    /**
    * 退款反馈时间
    */
    @ApiModelProperty(value="退款反馈时间")
    private Date refundFeedbackTime;

    /**
    * 退款金额
    */
    @ApiModelProperty(value="退款金额")
    private BigDecimal refundAmount;

    /**
    * 退款原因
    */
    @ApiModelProperty(value="退款原因")
    private String refundReason;

    /**
    * 退款凭证,可能有多张图片以逗号分隔
    */
    @ApiModelProperty(value="退款凭证,可能有多张图片以逗号分隔")
    private String refundVoucher;

    /**
    * 退款说明、拒绝原因
    */
    @ApiModelProperty(value="退款说明、拒绝原因")
    private String refundNote;

    /**
    * 操作时间
    */
    @ApiModelProperty(value="操作时间")
    private Date operateTime;

    /**
    * 更新时间
    */
    @ApiModelProperty(value="更新时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}