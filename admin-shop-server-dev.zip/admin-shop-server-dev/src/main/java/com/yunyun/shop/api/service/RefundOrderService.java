package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.RefundOrderDetailDto;
import com.yunyun.shop.api.pojo.entity.OrderDetail;
import com.yunyun.shop.api.pojo.entity.RefundOrder;
import com.yunyun.shop.api.pojo.vo.RefundOrderRequestVo;

import java.util.List;

/**
 * @author lxl
 * @Classname RefundOrderService
 * @Description TODO
 * @Date 2020/6/19 16:24
 */
public interface RefundOrderService {

    /**
     *
     * @Description:  分页查询退款记录
     * @params: [refundOrderRequestVo]
     * @return: java.util.List<com.yunyun.shop.api.pojo.entity.RefundOrder>
     * @Author: lxl
     * @Date : 2020/6/19 16:25
     */
    PageInfo<RefundOrder> queryRefundOrder(RefundOrderRequestVo refundOrderRequestVo);

    /**
     * 查询退款详情
     * @auther CheGuangQuan
     * @date 2020/6/24 11:22
     * @param orderDetailId
     * @return com.yunyun.shop.api.pojo.dto.RefundOrderDetailDto
    */
    RefundOrderDetailDto queryRefundOrderDetail(String orderDetailId);
}
