package com.yunyun.shop.api.pojo.dto;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @program: shop
 * @description:
 * @author: CheGuangQuan
 * @create: 2020-07-01 11:05
 **/
@Data
@ApiModel(value = "积分管理dto")
public class CustomerIntegralDto extends PageParams implements Serializable {

    @ApiModelProperty(value = "途径")
    private int integralRecordType;

    @ApiModelProperty(value="姓名")
    private String customerName;

    @ApiModelProperty(value="手机号")
    private String customerPhone;

    @ApiModelProperty(value="客户等级编号")
    private String customerLevelId;

    @ApiModelProperty(value="开始时间")
    private Date startDate;

    @ApiModelProperty(value="结束时间")
    private Date endDate;

}