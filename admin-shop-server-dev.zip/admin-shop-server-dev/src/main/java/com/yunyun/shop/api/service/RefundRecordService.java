package com.yunyun.shop.api.service;

import com.github.pagehelper.PageInfo;
import com.yunyun.shop.api.pojo.dto.HistoryRefundOrderResult;
import com.yunyun.shop.api.pojo.entity.RefundRecord;
import com.yunyun.shop.api.pojo.vo.HistoryRefundOrderQuery;

import java.util.List;

public interface RefundRecordService{


    int deleteByPrimaryKey(String refundId);

    int insert(RefundRecord record);

    RefundRecord selectByPrimaryKey(String refundId);

    int updateByPrimaryKey(RefundRecord record);

    /**
     * 退款
     * @param orderId
     * @return
     */
    Boolean refund(String orderId);

    /**
     * @description 分页查询退款记录
     * @auther PuYaDong
     * @date 2020-06-28 17:39
     * @param historyRefundOrderQuery
     * @return com.github.pagehelper.PageInfo<com.yunyun.shop.api.pojo.dto.HistoryRefundOrderResult>
     */
    PageInfo<HistoryRefundOrderResult> queryHistory(HistoryRefundOrderQuery historyRefundOrderQuery);
}
