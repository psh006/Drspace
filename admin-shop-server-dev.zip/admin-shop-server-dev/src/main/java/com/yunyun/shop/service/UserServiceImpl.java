package com.yunyun.shop.service;

import com.yunyun.shop.api.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Override
    public int saveUser() {
        return 0;
    }
}
