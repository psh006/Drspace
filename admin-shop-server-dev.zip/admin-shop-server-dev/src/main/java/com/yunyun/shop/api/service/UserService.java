package com.yunyun.shop.api.service;

public interface UserService {
    int saveUser();
}
