package com.yunyun.shop.service;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.yunyun.shop.api.pojo.entity.EmpToken;
import java.util.List;
import com.yunyun.shop.mapper.EmpTokenMapper;
import com.yunyun.shop.api.service.EmpTokenService;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.service
 * @createTime 2020-06-12 09:57
 */
@Service
public class EmpTokenServiceImpl implements EmpTokenService {

    @Resource
    private EmpTokenMapper empTokenMapper;

    @Override
    public int insert(EmpToken record) {
        return empTokenMapper.insert(record);
    }

    @Override
    public EmpToken selectByPrimaryKey(String empId, Integer loginType) {
        return empTokenMapper.selectByPrimaryKey(empId, loginType);
    }

    @Override
    public void deleteByEmpIdAndLoginType(String empId, Integer loginType) {
        empTokenMapper.deleteByPrimaryKey(empId,loginType);
    }

    /**
     * @param empId
     * @return int
     * @description 删除员工所有token
     * @auther PuYaDong
     * @date 2020-06-24 13:09
     */
    @Override
    public int deleteByEmpId(String empId) {
        return empTokenMapper.deleteByEmpId(empId);
    }

}

