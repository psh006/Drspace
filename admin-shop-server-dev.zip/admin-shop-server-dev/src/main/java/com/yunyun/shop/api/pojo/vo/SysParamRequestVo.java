package com.yunyun.shop.api.pojo.vo;

import com.yunyun.shop.common.model.PageParams;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author lxl
 * @Classname SysParamVo
 * @Description TODO
 * @Date 2020/6/23 14:13
 */

@Data
public class SysParamRequestVo extends PageParams implements Serializable {
    /**
     * 参数编号
     */
    @ApiModelProperty(value="参数编号")
    private String paramId;

    /**
     * 参数名称
     */
    @ApiModelProperty(value="参数名称")
    private String paramName;
}
