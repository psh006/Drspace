package com.yunyun.shop.api.pojo.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author lxl
 * @Classname CommentsInfo
 * @Description TODO
 * @Date 2020/6/16 16:16
 */
@Data
public class CommentsInfo {


    @ApiModelProperty(value = "评价id")
    private String commentId;

    @ApiModelProperty(value = "评价级别")
    private int commentLevel;

    @ApiModelProperty(value = "评价时间")
    private Date commentTime;

    @ApiModelProperty(value = "订单编号")
    private String orderId;

    @ApiModelProperty(value = "规格")
    private String goodsSpec;


    @ApiModelProperty(value = "总金额")
    private BigDecimal detailPayAmountReal;

    @ApiModelProperty(value = "运费")
    private BigDecimal detailFreightAmount;

    @ApiModelProperty(value = "评价内容")
    private String commentContent;

    @ApiModelProperty(value = "评价人")
    private String customerId;

    @ApiModelProperty(value = "评价人")
    private String customerName;

    @ApiModelProperty(value = "性别")
    private int customerGender;

    @ApiModelProperty(value = "手机号")
    private String customerPhone;


    @ApiModelProperty(value = "子商品id")
    private String goodsId;

    @ApiModelProperty(value = "子订单id")
    private String orderDetailId;


    @ApiModelProperty(value = "是否置顶")
    private int isTop;
}
