package com.yunyun.shop;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yunyun.shop.api.service.MessageService;
import com.yunyun.shop.common.exception.AlertException;
import com.yunyun.shop.common.util.BeanConvertUtils;
import com.yunyun.shop.common.util.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class ShopServerApplicationTests {

    @Autowired
    private MessageService messageService;

    @Test
    void contextLoads() {
    }

    @Test
    void generatePass() {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        System.out.println(bCryptPasswordEncoder.encode("123456"));
    }

    public static void main(String[] args) {
        String goodsSpecItems = "{\"颜色\": [\"红色\",\"黄色\",\"绿色\"],\"尺寸\": [\"S\",\"M\",\"L\"]}";
        String goodsSpec = "{\"颜色\": \"红色\",\"尺寸\": \"M\"}";
        String goodsSpec1 = "{\"颜色\": \"红色\",\"尺寸\": \"S\"}";
        String goodsSpec2 = "{\"颜色\": \"红色\",\"尺寸\": \"M\"}";
        List<String> goodsSpecList = new ArrayList<>();
        goodsSpecList.add(goodsSpec);
        goodsSpecList.add(goodsSpec1);
        goodsSpecList.add(goodsSpec2);
        try {
            Map goodsSpecItemsMap = JSON.parseObject(goodsSpecItems,Map.class);
            // 判断子商品规格是否符合规范
            goodsSpecList.stream()
                    .map(str -> JSON.parseObject(str,Map.class))
                    .forEach(map -> {
                            goodsSpecItemsMap.forEach((key,value) -> {
                                String param = (String)map.get(key);
                                map.remove(key);
                                if(StringUtils.isNotBlank(param)){
                                    long count = ((List<String>) value).stream()
                                            .filter(s -> s.equals(param))
                                            .count();
                                    if (count == 0) {
                                        throw new AlertException("子商品保存失败，商品规格不存在");
                                    }
                                }else {
                                    throw new AlertException("子商品保存失败，商品规格不存在");
                                }
                            });
                        if(map.size() > 0){
                            throw new AlertException("子商品保存失败，商品规格不存在");
                        }
                    });
            // 判断子商品规格是否重复
            long count = goodsSpecList.stream()
                    .map(str -> JSON.parseObject(str, Map.class))
                    .distinct()
                    .count();
            if(count < goodsSpecList.size()){
                throw new AlertException("子商品保存失败，子商品规格重复");
            }
        }catch (Exception ex){
            if (ex instanceof AlertException){
                throw ex;
            }
            throw new AlertException("保存失败，规格格式错误");
        }
    }

}
