package com.yunyun.shop.mapper;
import com.google.common.collect.Lists;

import com.yunyun.shop.api.pojo.entity.SysDicts;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.FileNotFoundException;

/**
 * @author PuYaDong
 * @description com.yunyun.shop.mapper
 * @createTime 2020-06-23 17:09
 */
public class SysDictsMapperTest {
    private static SysDictsMapper mapper;

    @BeforeClass
    public static void setUpMybatisDatabase() {
        SqlSessionFactory builder = new SqlSessionFactoryBuilder().build(SysDictsMapperTest.class.getClassLoader().getResourceAsStream("mybatisTestConfiguration/SysDictsMapperTestConfiguration.xml"));
        //you can use builder.openSession(false) to not commit to database
        mapper = builder.getConfiguration().getMapper(SysDictsMapper.class, builder.openSession(true));
    }

    @Test
    public void testIsDictUnique() throws FileNotFoundException {
        SysDicts sysDicts = new SysDicts();
        sysDicts.setDictCode("TEST");

        System.out.println(mapper.isDictUnique(sysDicts));
    }
}
