/**
 * @description
 * @author mgLuoBo
 * @createTime 2019/7/25 0025 9:34
 */
// 生产环境
module.exports = {
    NODE_ENV: '"production"',
    hostUrl: 'https://masters.chinayunsoft.com/api'
};