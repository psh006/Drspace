/**
 * @description
 * @author mgLuoBo
 * @createTime 2019/7/25 0025 9:34
 */
//开发环境
module.exports = {
    NODE_ENV: '"development"',
    hostUrl: 'http://10.168.1.200:39000'
};
