module.exports = {
    publicPath: process.env.NODE_ENV === 'production' ? '/masters-student-web/' : '/',
    outputDir: 'masters-student-web',
    devServer: {
        port: 8081,
    }
};
