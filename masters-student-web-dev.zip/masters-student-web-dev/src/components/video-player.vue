<template>
    <el-dialog :title="videoTitle" class="video-player" :visible="videoVisible" width="710px" @close="videoPlayerClose" @opened="videoPlayerOpened">
        <div id="video-container" style="margin: 0 auto;"></div>
    </el-dialog>
</template>

<script>

    export default {
        name: "video-player",
        data() {
            return {
                player: null
            }
        },
        mounted() {

        },
        methods: {
            init() {
                let options = {
                    mp4: this.videoUrl,
                    autoplay: true,
                    live: false,
                    width: '100%',
                    height: '425',
                    volume: 0.5,
                    flash: false,
                    wording: {
                        2032: '请求视频失败，请检查网络',
                        2048: '请求m3u8文件失败，可能是网络错误或者跨域问题',
                        4:"当前系统环境不支持播放该视频格式"
                    }
                };
                this.player = new window.TcPlayer("video-container", options);
            },
            videoPlayerOpened() {
                this.init();
            },
            videoPlayerClose() {
                if(this.player){
                    this.player.destroy();
                }
                this.$emit("video-player-close");
            }
        },
        props: {
            videoVisible: {
                type: Boolean,
                default: () => {
                    return false
                }
            },
            videoUrl: {
                type: String,
                default: () => {
                    return ""
                }
            },
            videoTitle: {
                type: String,
                default: () => {
                    return "录像回放"
                }
            }
        }
    }
</script>

<style lang="less">
    .video-player {
        .el-dialog__body {
            padding: 0 !important;
            .video-js {

            }
        }
    }
</style>