<template>
    <div class="login">
        <!-- 登录弹窗 -->
        <el-dialog :visible="openSystemLogin" width="420px" @close="handelCloseDialog('loginForm')"
                   :close-on-click-modal="false">
            <div style="text-align: center;height: 70px;">
                <el-image
                        :src="require('./../assets/img/logo.png')"
                        fit="fit">
                </el-image>
            </div>
            <div class="login-form-div">
                <el-form ref="loginForm" :model="loginFormData" :rules="loginFormRules">
                    <el-form-item prop="loginCode">
                        <el-input v-model="loginFormData.loginCode" placeholder="手机号" size="large"
                                  @input="value=>{this.loginFormData.loginCode = this.$util.checkNumber(value)}"
                                  @keyup.enter.native="handleLogin"
                                  style="border-radius: 20px;" maxlength="11"></el-input>
                    </el-form-item>
                    <el-form-item prop="loginPass">
                        <el-input v-model="loginFormData.loginPass" placeholder="密码" size="large" maxlength="20"
                                  @input="value=>{this.loginFormData.loginPass = this.$util.checkEnNu(value)}"
                                  @keyup.enter.native="handleLogin"
                                  style="border-radius: 20px;" show-password></el-input>
                    </el-form-item>
                </el-form>
                <el-link @click="status.forgetPassDialogOpen = true" :underline="false"
                         style="color: #323EDD;">忘记密码?
                </el-link>
                <el-link @click="status.registerDialogOpen = true" :underline="false"
                         style="margin-left: 20px;color: #323EDD;">立即注册
                </el-link>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="handleLogin" :loading="status.logging" class="login-button"
                           size="medium">登录
                </el-button>
            </div>
        </el-dialog>

        <!-- 忘记密码弹窗 -->
        <el-dialog :visible="status.forgetPassDialogOpen" width="420px" @close="handelCloseDialog('forgetPassForm')"
                   :close-on-click-modal="false">
            <div style="font-weight: bold;font-size: 18px;height: 40px">
                忘记密码
            </div>
            <div class="login-form-div">
                <el-form ref="forgetPassForm" :model="forgetPassFormData" :rules="forgetPassFormRules">
                    <el-form-item prop="loginCode">
                        <el-input v-model="forgetPassFormData.loginCode" placeholder="手机号" size="large"
                                  @input="value=>{this.forgetPassFormData.loginCode = this.$util.checkNumber(value)}"
                                  maxlength="11"></el-input>
                    </el-form-item>
                    <el-form-item prop="messageCode">
                        <el-input v-model="forgetPassFormData.messageCode" placeholder="验证码" size="large"
                                  @input="value=>{this.forgetPassFormData.messageCode = this.$util.checkNumber(value)}"
                                  maxlength="6" style="width: 60%">
                        </el-input>
                        <el-link style="color:#323EDD;width: 40%" :underline="false" :disabled="status.forgetMCGetting"
                                 @click="getForgetMessageCode">{{ getForgetMCText }}</el-link>
                    </el-form-item>
                    <el-form-item prop="newPass">
                        <el-input v-model="forgetPassFormData.newPass" placeholder="新密码" size="large" maxlength="20"
                                  @input="value=>{this.forgetPassFormData.newPass = this.$util.checkEnNu(value)}"
                                  show-password></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="handleSubmit('forgetPassForm')" :loading="status.newPassSaving" class="login-button"
                           size="medium">确定
                </el-button>
            </div>
        </el-dialog>

        <!-- 注册弹窗 -->
        <el-dialog :visible="status.registerDialogOpen" width="420px" @close="handelCloseDialog('registerForm')"
                   :close-on-click-modal="false">
            <div class="login-form-div">
                <el-form ref="registerForm" :model="registerFormData" :rules="registerFormRules" label-width="80px"
                         label-position="right">
                    <div style="font-weight: bold;font-size: 18px;height: 40px">
                        注册账号
                    </div>
                    <el-form-item label="手机号" prop="loginCode">
                        <el-input v-model="registerFormData.loginCode" placeholder="手机号" size="large"
                                  @input="value=>{this.registerFormData.loginCode = this.$util.checkNumber(value)}"
                                  maxlength="11"></el-input>
                    </el-form-item>
                    <el-form-item label="验证码" prop="messageCode">
                        <el-input v-model="registerFormData.messageCode" placeholder="验证码" size="large" maxlength="6"
                                  @input="value=>{this.registerFormData.messageCode = this.$util.checkNumber(value)}"
                                  style="width: 60%">
                        </el-input>
                        <el-link style="color:#323EDD;width: 40%" :underline="false" :disabled="status.registerMCGetting"
                                 @click="getRegisterMessageCode">{{ getRegisterMCText }}</el-link>
                    </el-form-item>
                    <el-form-item label="密码" prop="loginPass">
                        <el-input v-model="registerFormData.loginPass" placeholder="密码" size="large" maxlength="20"
                                  @input="value=>{this.registerFormData.loginPass = this.$util.checkEnNu(value)}"
                                  show-password></el-input>
                    </el-form-item>
                    <div style="font-weight: bold;font-size: 18px;height: 40px">
                        基础信息
                    </div>
                    <el-form-item label="昵称" prop="nickName">
                        <el-input v-model="registerFormData.nickName" placeholder="昵称" size="large"
                                  @input="value=>{this.registerFormData.nickName = this.$util.checkCnEnNu(value)}"
                                  maxlength="10"></el-input>
                    </el-form-item>
                    <el-form-item label="性别" prop="gender">
                        <el-radio v-model="registerFormData.gender" v-for="item in genderList"
                                  :key="item.itemVal" :label="item.itemVal">{{ item.itemName }}</el-radio>
                    </el-form-item>
                    <el-form-item label="年级" prop="gradeId">
                        <!--suppress RequiredAttributes -->
                        <el-select v-model="registerFormData.gradeId" filterable placeholder="请选择"
                                   size="large" style="width: 100%" clearable>
                            <el-option v-for="item in gradeList" :key="item.gradeId"
                                       :label="item.gradeName"
                                       :value="item.gradeId"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="handleSubmit('registerForm')" :loading="status.registering" class="login-button"
                           size="medium">注册
                </el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
    import {mapState} from 'vuex';

    export default {
        name: "login",
        computed:{
            ...mapState({
                openSystemLogin: state => state.openSystemLogin,
            })
        },
        data(){
            let validatePhone = (rule, value, callback) => {
                if (!this.$util.isPhoneNumber(value)) {
                    return callback(new Error('请输入正确的手机号码!'));
                }
                return callback();
            };
            return{
                userName: "用户",
                avatar: "",
                genderList: [],
                gradeList: [],
                getForgetMCText: "获取验证码",
                getRegisterMCText: "获取验证码",
                getForgetMCDuration: 60,
                getRegisterMCDuration: 60,
                forgetTimer: "",
                registerTimer: "",
                status: {
                    isLogin: false,
                    logging: false,
                    newPassSaving: false,
                    registering: false,
                    forgetPassDialogOpen: false,
                    registerDialogOpen: false,
                    forgetMCGetting: false,
                    registerMCGetting: false,
                },
                loginFormData: {
                    loginCode: "",
                    loginPass: "",
                },
                loginFormRules: {
                    loginCode: [
                        {required: true, message: '手机号不能为空', trigger: 'blur'},
                    ],
                    loginPass: [
                        {required: true, message: '密码不能为空', trigger: 'blur'},
                    ]
                },
                forgetPassFormData: {
                    loginCode: "",
                    messageCode: "",
                    newPass: ""
                },
                forgetPassFormRules: {
                    loginCode: [
                        {required: true, message: '手机号不能为空', trigger: 'blur'},
                        {validator: validatePhone, trigger: 'blur'}
                    ],
                    messageCode: [
                        {required: true, message: '验证码不能为空', trigger: 'blur'},
                    ],
                    newPass: [
                        {required: true, message: '新密码不能为空', trigger: 'blur'},
                        {min:6, max:20, message: "密码长度须在6~20位之间", trigger: 'blur'}
                    ],
                },
                registerFormData: {
                    loginCode: "",
                    messageCode: "",
                    loginPass: "",
                    nickName: "",
                    gender: "",
                    gradeId: ""
                },
                registerFormRules: {
                    loginCode: [
                        {required: true, message: '手机号不能为空', trigger: 'blur'},
                        {validator: validatePhone, trigger: 'blur'}
                    ],
                    messageCode: [
                        {required: true, message: '验证码不能为空', trigger: 'blur'},
                    ],
                    loginPass: [
                        {required: true, message: '密码不能为空', trigger: 'blur'},
                        {min:6, max:20, message: "密码长度须在6~20位之间", trigger: 'blur'}
                    ],
                    nickName: [
                        {required: true, message: '昵称不能为空', trigger: 'blur'},
                    ],
                    gender: [
                        {required: true, message: '性别不能为空', trigger: 'blur'},
                    ],
                    gradeId: [
                        {required: true, message: '年级不能为空', trigger: 'blur'},
                    ],
                }
            }
        },
        created() {
            // 性别字典
            this.genderList = this.$dict.getDictByCode('GENDER') || [];

            // 年级列表初始化
            let params = {
                method: 'POST',
            };
            this.$request(params, "/grade/gradeList", (res) => {
                this.gradeList = res.list;
            });

        },
        methods: {
            // 登录
            handleLogin() {
                this.$refs.loginForm.validate((valid) => {
                    if (valid) {
                        this.status.logging = true;
                        let loginCode = this.loginFormData.loginCode;
                        let loginPass = this.loginFormData.loginPass;
                        let loginRole = this.loginFormData.loginRole;

                        let params = {};
                        params.loginCode = loginCode;
                        params.loginPass = loginPass;
                        params.loginRole = loginRole;
                        this.$request(params, "/login/studentLogin", (data) => {
                            this.status.logging = false;
                            this.$message.success("登录成功");
                            let user = data.list[0];
                            this.handelCloseDialog('loginForm');
                            this.status.isLogin = true;
                            this.userName = user.nickName;
                            this.avatar = user.avatar;
                            this.$util.saveUser(user);//保存用户信息
                            this.$store.commit("setSystemUserInfo",user);
                            this.$dict.initDict();//初始化数据字典
                            this.$emit("login-success");
                        }, () => {
                            this.status.logging = false;
                        });
                    }
                });
            },
            // 提交表单
            handleSubmit(formName){
                switch (formName) {
                    case "forgetPassForm":
                        this.$refs.forgetPassForm.validate((valid) => {
                            if (valid) {
                                this.status.newPassSaving = true;
                                let params = {...this.forgetPassFormData};
                                params.method= 'POST';
                                this.$request(params, "/login/forgetStudentLoginPass", () => {
                                    this.status.newPassSaving = false;
                                    this.$message.success("密码修改成功");
                                    this.handelCloseDialog('forgetPassForm');
                                    this.loginFormData.loginCode = params.loginCode;
                                    this.loginFormData.loginPass = params.newPass;
                                    this.handleLogin();
                                },()=>{
                                    this.status.newPassSaving = false;
                                });
                            }
                        });
                        break;
                    case "registerForm":
                        this.$refs.registerForm.validate((valid) => {
                            if (valid) {
                                this.status.registering = true;
                                let params = {...this.registerFormData};
                                params.method= 'POST';
                                this.$request(params, "/login/studentRegister", () => {
                                    this.status.registering = false;
                                    this.$message.success("注册成功");
                                    this.handelCloseDialog('registerForm');
                                    this.loginFormData.loginCode = params.loginCode;
                                    this.loginFormData.loginPass = params.loginPass;
                                    this.handleLogin();
                                },()=>{
                                    this.status.registering = false;
                                });
                            }
                        });
                        break;
                }
            },
            // 获取忘记密码验证码
            getForgetMessageCode() {
                // 判断手机号格式是否正确
                let loginCode = this.forgetPassFormData.loginCode;
                if (!this.$util.isPhoneNumber(loginCode)) {
                    this.$message.error("请输入正确的手机号码!");
                    return;
                }
                // 检查手机号是否存在
                let params1 = {
                    loginCode: loginCode
                }
                this.$request(params1, "/student/checkLoginCode", (res) => {
                    if(res.list[0]){
                        // 请求并设置下次请求时间
                        this.status.forgetMCGetting = true;
                        let params2 = {
                            method: 'POST',
                            mobile: loginCode,
                            // 忘记密码验证码type-3
                            type: 3,
                        };
                        this.$request(params2, "/message/sendMessage", () => {
                            // 请求成功后定时任务
                            this.$message.success(`短信验证码已发送`);
                            this.forgetTimer = setInterval(() => {
                                if (this.getForgetMCDuration === 0) {
                                    clearInterval(this.forgetTimer);
                                    this.getForgetMCDuration = 60;
                                    this.getForgetMCText = "获取验证码";
                                    this.status.forgetMCGetting = false;
                                } else {
                                    this.getForgetMCText = this.getForgetMCDuration + "s后重新发送";
                                    this.getForgetMCDuration -= 1;
                                }
                            }, 1000);
                        }, () => {
                            this.status.forgetMCGetting = false;
                        });
                    }else {
                        this.$message.error("手机号错误，请重新输入");
                    }
                });
            },
            // 获取注册验证码
            getRegisterMessageCode() {
                // 判断手机号格式是否正确
                let loginCode = this.registerFormData.loginCode;
                if (!this.$util.isPhoneNumber(loginCode)) {
                    this.$message.error("请输入正确的手机号码!");
                    return;
                }
                // 检查手机号是否存在
                let params1 = {
                    loginCode: loginCode
                }
                this.$request(params1, "/student/checkLoginCode", (res) => {
                    if(!res.list[0]){
                        // 请求并设置下次请求时间
                        this.status.registerMCGetting = true;
                        let params2 = {
                            method: 'POST',
                            mobile: loginCode,
                            // 注册type-1
                            type: 1,
                        };
                        this.$request(params2, "/message/sendMessage", () => {
                            // 请求成功后定时任务
                            this.$message.success(`短信验证码已发送`);
                            this.registerTimer = setInterval(() => {
                                if (this.getRegisterMCDuration === 0) {
                                    clearInterval(this.registerTimer);
                                    this.getRegisterMCDuration = 60;
                                    this.getRegisterMCText = "获取验证码";
                                    this.status.registerMCGetting = false;
                                } else {
                                    this.getRegisterMCText = this.getRegisterMCDuration + "s后重新发送";
                                    this.getRegisterMCDuration -= 1;
                                }
                            }, 1000);
                        }, () => {
                            this.status.registerMCGetting = false;
                        });
                    }else {
                        this.$message.error("该手机号已被注册");
                    }
                });
            },
            // 关闭弹窗
            handelCloseDialog(formName) {
                switch (formName) {
                    case "loginForm":
                        this.$nextTick(() => {
                            this.$refs['loginForm'].resetFields();
                        });
                        this.$emit("close-login");
                        break;
                    case "forgetPassForm":
                        this.$nextTick(() => {
                            this.$refs['forgetPassForm'].resetFields();
                        });
                        this.status.forgetPassDialogOpen = false;
                        break;
                    case "registerForm":
                        this.$nextTick(() => {
                            this.$refs['registerForm'].resetFields();
                        });
                        this.status.registerDialogOpen = false;
                        break;
                }
            }
        }
    }
</script>

<style lang="less">
    .login{
        .el-dialog {
            margin-top: 25vh !important;
            border-radius: 8px;

            .el-dialog__body {
                padding: 30px 40px 0 40px;

                .login-form-div {
                    .el-input__inner {
                        border-radius: 0;
                        border-top-width: 0;
                        border-left-width: 0;
                        border-right-width: 0;
                        border-bottom-width: 1px;
                        outline: none;
                    }
                }
            }

            .el-dialog__footer {
                padding: 0 40px 40px 40px;

                .login-button {
                    border-radius: 20px;
                    width: 100px;
                }
            }
        }
    }
</style>