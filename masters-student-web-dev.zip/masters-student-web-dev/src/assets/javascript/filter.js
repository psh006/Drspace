/**
 * @Describe:全局过滤器
 * @Author: ouxin
 * @Date: 2019/12/3 15:54
 */

/**
 * 是否
 */
const filterYesNo = value => {
    let code = {1: '是', 2: '否'};
    return code[value];
};

/**
 * 是否
 */
const filterAnswerSubjcetType = value => {
    let code = {1: '选择题', 2: '填空题', 3: "解答题"};
    return code[value];
};

const filters = {
    filterYesNo,
    filterAnswerSubjcetType
};


const install = function (Vue) {
    Object.keys(filters).forEach(key => {
        Vue.filter(key, filters[key])
    })
};

export default install
