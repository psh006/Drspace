export default {
    SDK_APP_ID: 1400367745,
    //用户状态-未初始化
    USER_STATUS_UNINIT: 0,
    //用户状态-未登录
    USER_STATUS_UNLOGIN: 1,
    //用户状态-已登录
    USER_STATUS_LOGINED: 2,
    //用户状态-已进入房间
    USER_STATUS_INCLASS: 3,
    //回话类型
    MESSAGE_TYPE_SYSTEM: "系统消息",
    MESSAGE_TYPE_PRIVATE: "私聊",
    MESSAGE_TYPE_GROUP_PRIVATE: "课堂私聊",
    MESSAGE_TYPE_GROUP: "群消息",
    MESSAGE_TYPE_HAND: "举手",
    MESSAGE_TYPE_BEGIN_QUESTION: "开始答题",
    MESSAGE_TYPE_OVER_QUESTION: "结束答题",
    MESSAGE_TYPE_STUDENT_ANSWER: "学生回答",
    MESSAGE_TYPE_ONSTAGE_STATE: "是否上台",
    MESSAGE_TYPE_PROSODY_STATE: "是否禁麦",
    MESSAGE_ESTOPPEL_STATE: "是否禁言",
    MESSAGE_BLACKLIST_STATE: "是否拉黑",
    //题目类别-选择题
    SUBJECT_TYPE_CHOICE: 1,
    //题目类别-填空题
    SUBJECT_TYPE_Completion: 2,
    //题目类别-解答题
    SUBJECT_TYPE_SOLVING: 3,
    //答题类别-自定义
    ANSWER_TYPE_PRIMARY: 1,
    //答题类别-课件答题
    ANSWER_TYPE_CLASS: 2
}