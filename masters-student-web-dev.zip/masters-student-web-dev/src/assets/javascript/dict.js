import request from './request'
import util from './util'

const dictUrl = "/dict/getDictListFromCache";

/**
 * 初始化数据字典
 */
const initDict = function () {
    request.requestData({}, dictUrl, (data) => {
        let dictList = data.list;
        if (util.isEmpty(dictList) || dictList.length == 0) {
            console.log("[失败] - 初始化数据字典失败！");
            return null;
        } else {
            localStorage.setItem("DICT_LIST", JSON.stringify(dictList));
            console.log("[成功] - 初始化数据字典成功！");
            return dictList;
        }
    }, () => {
        console.log("[失败] - 初始化数据字典失败！");
        return null;
    });
};

/**
 * 根据字典代码获取数据字典子项
 */
const getDictByCode = function (dictCode) {
    let dictList = JSON.parse(localStorage.getItem("DICT_LIST"));
    if (util.isEmpty(dictList) || dictList.length == 0) {
        dictList = initDict();
        if (util.isEmpty(dictList) || dictList.length == 0) {
            console.log("[失败] - 获取数据字典失败！");
            return null;
        }
    }
    for (let dict of dictList) {
        if (dict.dictCode == dictCode) {
            return dict.dictItem;
        }
    }
    console.log("[失败] - 获取数据字典失败！");
    return null;
};


/**
 * 根据字典代码和子项值获取数据字典子项名称
 */
const getItemNameByCodeAndVal = function (dictCode, itemVal) {
    let itemList = getDictByCode(dictCode);
    if (util.isEmpty(itemList) || itemList.length == 0) {
        console.log("[失败] - 获取数据字典失败！");
        return null;
    }
    for (let item of itemList) {
        if (item.itemVal == itemVal) {
            return item.itemName;
        }
    }
    console.log("[失败] - 获取数据字典失败！");
    return null;
};

export default {
    initDict,
    getDictByCode,
    getItemNameByCodeAndVal
}