import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter);

const routes = [
    {
        path: '/index',
        children: [
            {
                path: '/class-select',
                name: 'class-select',
                component: () => import("../views/class-select")
            },
            {
                path: '/class-select-topic',
                name: 'class-select-topic',
                component: () => import("../views/class-select-topic")
            },
            {
                path: '/search',
                name: 'search',
                component: () => import("../views/search")
            },
            {
                path: '/about-us',
                name: 'about-us',
                component: () => import("../views/about-us")
            },
            {
                path: '/course-details',
                name: 'course-details',
                component: () => import("../views/course-details")
            },
            {
                path: '/home',
                name: 'home',
                component: () => import("../views/home")
            },
            {
                path: '/mycourse',
                name: 'mycourse',
                component: () => import("../views/mycourse")
            },
            {
                path: '/pay',
                name: 'pay',
                component: () => import("../views/pay")
            },
            {
                path: '/pay-success',
                name: 'pay-success',
                component: () => import("../views/pay-success")
            },
            {
                path: '/teacher-info',
                name: 'teacher-info',
                component: () => import("../views/teacher-info")
            },
            {
                path: '/',
                redirect: '/home'
            },
            {
                path: '/personal-center',
                name: 'personal-center',
                component: () => import("../views/personal-center")
            },
            {
                path: '/student-cart',
                name: 'student-cart',
                component: () => import("../views/student-cart")
            },
            {
                path: '/conversation',
                name: 'conversation',
                component: () => import("../views/conversation")
            }
        ],
        component: () => import("../views/index")
    },
    {
        path: '/classroom',
        name: 'classroom',
        component: () => import("../views/classroom")
    },
    {
        path: '/',
        redirect: '/index'
    }
];

//解决两次访问相同的路由地址报错的问题
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
};

const router = new VueRouter({
    mode: 'history',
    base: '/masters-student-web/',
    routes
});

export default router
