import Vue from 'vue'
import Vuex from 'vuex'
import TIC from "./../assets/TX_api/TIC.min"
import constData from "./../assets/javascript/const-data"
import {Message} from "element-ui"
import routor from "./../router/index"

import classroomAnswer from './modules/classroom-answer'
import classroomStudentModules from './modules/classroom-student'

Vue.use(Vuex);

let showMessageInBox = (state, messageType, text) => {
    let d = new Date();
    let time = `${('0' + d.getHours()).substr(-2)}:${('0' + d.getMinutes()).substr(-2)}:${('0' + d.getSeconds()).substr(-2)}`;
    let msg = {
        time: time + ' ',
        send: messageType + ' ',
        content: text
    };
    state.groupMsg.push(msg);
};

let resetNoReadTotal = state => {
    let conversationList = [...state.conversationList];
    let total = 0;
    conversationList.map(item => {
        total += item.unreadCount;
    });
    state.notReadTotal = total;
};

export default new Vuex.Store({
    state: {
        //系统用户是否登录
        systemUserIsLogin: false,
        //是否打开系统登录弹窗
        openSystemLogin: false,
        //系统用户信息
        systemUserInfo: {},
        //TIC本体
        tic: null,
        //TIC用户当前状态
        ticUserStatus: 0,
        //TIC用户
        ticUserInfo: {
            userId: "",
            userSig: ""
        },
        //课堂消息中心
        groupMsg: [],
        //会话相关
        currentConversation: {},
        currentMessageList: [],
        nextReqMessageID: '',
        isCompleted: false, // 当前会话消息列表是否已经拉完了所有消息
        conversationList: [],
        //未读消息总数
        notReadTotal: 0
    },
    mutations: {
        // 控制系统登录弹窗
        setOpenSystemLogin(state, boolean) {
            state.openSystemLogin = boolean;
        },
        // 设置系统用户
        setSystemUserInfo(state, systemUserInfo) {
            state.systemUserIsLogin = true;
            state.systemUserInfo = systemUserInfo;
        },
        // 移除系统用户
        removeSystemUserInfo(state) {
            state.systemUserIsLogin = false;
            state.systemUserInfo = {};
        },
        // 设置TIC用户信息
        setTicUserInfo(state, ticUserInfo) {
            state.ticUserInfo.userId = ticUserInfo.userId;
            state.ticUserInfo.userSig = ticUserInfo.userSig;
        },
        //TIC初始化
        initTic(state, success_callback) {
            state.tic = null;
            state.tic = new TIC({});
            state.tic.init(constData.SDK_APP_ID, res => {
                if (res.code) {
                    console.error(constData.MESSAGE_TYPE_SYSTEM + "初始化失败,错误码" + res.code + ",失败原因" + res.desc);
                } else {
                    state.ticUserStatus = constData.USER_STATUS_UNLOGIN;
                    success_callback && success_callback();
                }
            });
        },
        //改变TIC用户状态
        toggleTicUserStatus(state, status) {
            state.ticUserStatus = status
        },
        //直播间消息插入
        insertGroupMsg(state, msg) {
            state.groupMsg.push(msg);
        },
        //直播间消息清理
        clearGroupMsg(state) {
            state.groupMsg = [];
        },
        // 设置回话列表
        setConversationList(state, conversationList) {
            state.conversationList = conversationList;
        },
        /**
         * 更新当前会话
         * 调用时机: 切换会话时
         * @param {Object} state
         * @param {Object} conversation
         */
        updateCurrentConversation(state, conversation) {
            state.currentConversation = conversation;
            state.currentMessageList = [];
            state.nextReqMessageID = '';
            state.isCompleted = false
        },
        /**
         * 消息处理中心
         * 调用时机：收/发消息事件触发时
         * @param {Object} state
         * @param {Message[]|Message} data
         * @returns
         */
        pushCurrentMessageList(state, data) {
            if (Array.isArray(data)) {
                let privateList = [];
                for (let item of data) {
                    //只要文本自定义消息
                    if (item.type === window.TIM.TYPES.MSG_TEXT && item.payload.text.includes('{"type":')) {
                        let nowConversationID = state.currentConversation.conversationID;
                        if(nowConversationID === item.conversationID && JSON.parse(item.payload.text).type === constData.MESSAGE_TYPE_PRIVATE){
                            window.tim.setMessageRead({conversationID:nowConversationID});
                        }else if(JSON.parse(item.payload.text).type !== constData.MESSAGE_TYPE_PRIVATE){
                            window.tim.setMessageRead({conversationID:nowConversationID});
                        }
                        resetNoReadTotal(state);
                        let message = JSON.parse(item.payload.text);
                        switch (message.type) {
                            case constData.MESSAGE_TYPE_PRIVATE:
                                privateList.push(item);
                                break;
                            case constData.MESSAGE_TYPE_GROUP:
                                showMessageInBox(state, message.type, message.fromUserName + ": " + message.text);
                                break;
                            case constData.MESSAGE_TYPE_BEGIN_QUESTION:
                                state.classroomAnswer.subject = message.data;
                                state.classroomAnswer.answering = true;
                                break;
                            case constData.MESSAGE_TYPE_OVER_QUESTION:
                                if(state.classroomAnswer.answering){
                                    Message.info("老师终止了答题");
                                    state.classroomAnswer.subject = {};
                                    state.classroomAnswer.answering = false;
                                }
                                break;
                            case constData.MESSAGE_TYPE_ONSTAGE_STATE:
                                state.classroomStudentModules.operateStatus.onStageState = message.data.status;
                                break;
                            case constData.MESSAGE_TYPE_PROSODY_STATE:
                                state.classroomStudentModules.operateStatus.prosodyState = message.data.status;
                                break;
                            case constData.MESSAGE_ESTOPPEL_STATE:
                                state.classroomStudentModules.operateStatus.estoppelState = message.data.status;
                                break;
                            case constData.MESSAGE_BLACKLIST_STATE:
                                if(state.ticUserStatus >= constData.USER_STATUS_INCLASS && message.data.status === 1){
                                    routor.push({path:"/mycourse"});
                                }
                                break;
                        }
                    }
                }
                if (privateList.length > 0) {
                    if (!state.currentConversation.conversationID) {
                        return;
                    }
                    state.currentMessageList = [...state.currentMessageList, ...privateList];
                }
            } else if (data.conversationID === state.currentConversation.conversationID) {
                state.currentMessageList = [...state.currentMessageList, data]
            }
        }
    },
    actions: {
        /**
         * 获取消息列表
         * 调用时机：打开某一会话时或下拉获取历史消息时
         * @param {Object} context
         * @param {String} conversationID
         */
        getMessageList(context, conversationID) {
            if (context.state.isCompleted) {
                Message.info("已经没有更多消息了");
                return
            }
            const {nextReqMessageID, currentMessageList} = context.state;
            window.tim.getMessageList({conversationID, nextReqMessageID, count: 15}).then(imReponse => {
                resetNoReadTotal(context.state);
                // 更新messageID，续拉时要用到
                context.state.nextReqMessageID = imReponse.data.nextReqMessageID;
                context.state.isCompleted = imReponse.data.isCompleted;
                // 更新当前消息列表，从头部插入
                let _currentMessageList = [...imReponse.data.messageList, ...currentMessageList];
                _currentMessageList = _currentMessageList.filter(item => {
                    // 只要私聊消息
                    if (item.type === window.TIM.TYPES.MSG_TEXT && item.payload.text.includes('{"type":')) {
                        let message = JSON.parse(item.payload.text);
                        return message.type === constData.MESSAGE_TYPE_PRIVATE;
                    }
                    return true;
                });
                context.state.currentMessageList = _currentMessageList;
            })
        },
        /**
         * 切换会话
         * 调用时机：切换会话时
         * @param {Object} context
         * @param {String} conversationID
         */
        checkoutConversation(context, conversationID) {
            // 1.切换会话前，将切换前的会话进行已读上报
            if (context.state.currentConversation.conversationID) {
                const prevConversationID = context.state.currentConversation.conversationID;
                window.tim.setMessageRead({conversationID: prevConversationID})
            }
            // 2.待切换的会话也进行已读上报
            window.tim.setMessageRead({conversationID});
            // 3. 获取会话信息
            return window.tim.getConversationProfile(conversationID).then(({data}) => {
                resetNoReadTotal(context.state);
                // 3.1 更新当前会话
                context.commit('updateCurrentConversation', data.conversation);
                // 3.2 获取消息列表
                context.dispatch('getMessageList', conversationID);
                return Promise.resolve()
            })
        }
    },
    modules: {
        classroomAnswer,
        classroomStudentModules
    }
})
