/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/6/4 0004 13:56
 */

const classroomAnswerModules = {
    state: {
        //当前是否正在答题
        answering: false,
        //当前题目
        subject: {}
    },
    mutations: {
        setAnswering(state, boolean) {
            state.answering = boolean;
        },
        setSubject(state, subject) {
            state.subject = subject;
        },
        clearSubject(state){
            state.subject = {};
        }
    },
    actions: {}
};

export default classroomAnswerModules