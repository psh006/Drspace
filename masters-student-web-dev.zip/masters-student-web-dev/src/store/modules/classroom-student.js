/**
 * @description
 * @author mgLuoBo
 * @createTime 2020/6/8 0008 13:40
 */

import util from "./../../assets/javascript/util"


const classroomStudentModules = {
    state: {
        operateStatus: {
            //是否上台
            onStageState: 2,
            //是否静音
            prosodyState: 1,
            //是否禁言
            estoppelState: 2
        },
        studentList: [],
        topList:[]
    },
    mutations: {
        setOnStageState(state, onStageState) {
            state.operateStatus.onStageState = onStageState;
        },
        setProsodyState(state, prosodyState) {
            state.operateStatus.prosodyState = prosodyState;
        },
        setEstoppelState(state, estoppelState) {
            state.operateStatus.estoppelState = estoppelState;
        },
        setStudentList(state, studentList) {
            state.studentList = studentList;
        }
    },
    actions: {}
};

export default classroomStudentModules