<template>
    <div class="teacher-info">
        <div class="title">
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item :to="{ path: '' }">老师详情</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="base-info">
            <img src="../assets/img/teacher-background.png" class="teacher-back">
            <div class="info-box">
                <el-image :src="teacherInfo.avatar" class="teacher-avatar" preview-src-list :lazy="true"/>
                <div class="info-tip">
                    <div class="info-tip-ch">
                        <div><strong>{{teacherInfo.realName}}</strong><span>{{teacherInfo.subjectName}}{{teacherInfo.post===1?'老师':'学习管理师'}}</span>
                        </div>
                        <div><span>{{$util.getAge(teacherInfo.entryDate)}}年教龄</span><span>共授课{{dur=teacherInfo.teachingDuration?dur:'0'}}小时</span>
                        </div>
                        <el-button type="success" style="margin-top: 10px;width: 154px;height: 50px;font-size: 20px"
                                   icon="el-icon-chat-dot-square"
                                   @click="sendMessage">发消息
                        </el-button>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin-top: 20px;background: #ffffff;">
            <el-tabs class="my-border-card" type="border-card" v-model="activeName">
                <el-tab-pane label="介绍" name="intro">
                    <div style="min-height: 280px">
                        <div v-if="intro=teacherInfo.briefIntroduction" v-html="intro" class="ql-editor">
                        </div>
                        <div v-else style="color: #bdc7d1">暂无介绍</div>
                    </div>
                </el-tab-pane>
                <el-tab-pane label="课程" name="course">
                    <div style="min-height: 280px">
                        <teacher-course ref="teacher-course" :teacher-id="teacherId" @teacher-click="teacherClick"/>
                    </div>
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
    import teacherCourse from './teacher-course'
    import 'quill/dist/quill.core.css';
    import 'quill/dist/quill.snow.css';
    import 'quill/dist/quill.bubble.css';
    import {mapState} from 'vuex';

    export default {
        name: "teacher-info",
        components: {
            teacherCourse
        },
        computed: {
            ...mapState({
                systemUserIsLogin: state => state.systemUserIsLogin,
            })
        },
        data() {
            return {
                teacherInfo: {
                    avatar: '',
                    realName: '',
                    subjectName: '',
                    post: '',
                    entryDate: '',
                    teachingDuration: '',
                    briefIntroduction: ''
                },
                teacherId: '',
                getFileUrl: '',
                activeName: 'intro'
            }
        },
        created() {
            this.getFileUrl = this.$getFileUrl;
            let teacherId = this.$route.query.teacherId;
            if (teacherId) {
                this.teacherId = teacherId;
                this.queryTeacherInfo();
            } else {
                this.$router.push("/");
            }
        },
        methods: {
            teacherClick(teacherId) {
                this.activeName = 'intro';
                if (this.teacherId === teacherId) {
                    return;
                }
                this.teacherId = teacherId;
                this.queryTeacherInfo(this.teacherId);
            },
            queryTeacherInfo() {
                this.$request({"teacherId": this.teacherId}, "/masters/mapper/select/queryTeacherById", (data) => {
                    if (data.flag === 200) {
                        this.teacherInfo = data.list[0];
                        this.teacherInfo.avatar = this.getFileUrl + this.teacherInfo.avatar;
                    }
                }, err => {
                    console.log(err);
                });
            },
            sendMessage() {
                if (this.systemUserIsLogin) {
                    this.$store
                        .dispatch('checkoutConversation', `C2C${this.teacherId}`)
                        .then(() => {
                            this.$router.push("/conversation");
                        }).catch(() => {
                        this.$store.commit('showMessage', {
                            message: '该老师可能没有登录过系统',
                            type: 'warning'
                        })
                    });
                } else {
                    this.$util.openLogin();
                }

            }
        }
    }
</script>

<style lang="less">
    .teacher-info {
        /*background-color: #F6F2F7;*/
        max-width: 1200px;
        /*height: 1200px;*/
        margin: 0 auto 20px;
        /*min-height: 1200px;*/

        .el-tabs--border-card > .el-tabs__header .el-tabs__item {
            border: none;
        }

        .el-tabs--border-card > .el-tabs__header .el-tabs__item {
            border: none;
            background: #F6F2F7;
        }

        .el-tabs--border-card {
            border: none;
            box-shadow: none;
        }

        .el-tabs__nav-scroll {
            background: #F6F2F7;
        }

        .is-active {
            height: 40px;
            line-height: 40px;
            background-color: #ffffff !important;
        }

        .title {
            height: 76px;
            display: flex;
            align-items: center;

            .el-breadcrumb__item {
                font-size: 16px;
                line-height: 76px;
            }
        }

        .base-info {
            position: relative;
            width: 1200px;
            height: 273px;
            border: 1px solid black;
        }

        .teacher-back {
            position: absolute;
            width: 1200px;
            height: 273px;
        }

        .info-box {
            position: relative;
            /*text-align: center;*/
            margin: 35px 300px;
            display: flex;
        }

        .teacher-avatar {
            width: 176px;
            height: 176px;
            border-radius: 50%;
            float: left;
        }

        .info-tip {
            margin-left: 20px;
            color: #d5d5d5;
            display: flex;
            align-items: center;

            .info-tip-ch {
                span, strong {
                    margin-right: 5px;
                    padding: 5px;
                }

                strong {
                    font-size: 20px;
                    color: #ffffff;
                }

                span {
                    font-size: 16px;
                }
            }
        }
    }

</style>