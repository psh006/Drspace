<template>
    <div class="conversation">
        <el-breadcrumb separator-class="el-icon-arrow-right" class="breadcrumb">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '' }">消息</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="web-QQ">
            <div class="conversation-list">
                <el-button class="close-bottom" type="text" @click="closeConversation"><i class="el-icon-close"></i></el-button>
                <div v-if="conversationList.length < 1" class="no-conversation-list">暂无消息</div>
                <div v-for="(item,index) in conversationList" :key="index"
                     :class="`conversation-list-item ${currentConversation.conversationID === item.conversationID ? ' conversation-list-item-active' : ''}`"
                     @click="selectConversation(item)">
                    <el-avatar :size="45">{{item.userProfile.nick[0]}}</el-avatar>
                    <div :class="`name-message ${item.unreadCount > 0 ? '' : 'name-message-no-unread'}`">
                        <div class="name" v-text="item.userProfile.nick"></div>
                        <div class="message" v-text="getLastMessage(item.lastMessage)"></div>
                    </div>
                    <div class="unread" v-if="item.unreadCount > 0" v-text="item.unreadCount"></div>
                </div>
            </div>
            <div class="conversation-content" v-if="currentConversation.conversationID" v-loading="status.isCheckouting">
                <div class="message-box">
                    <div class="message-title">{{currentConversation.userProfile.nick}}</div>
                    <div class="message-list" ref="message-list">
                        <template v-for="(message,index) in currentMessageList">
                            <div :key="index" v-if="message.type === 'TIMTextElem' && JSON.parse(message.payload.text).type === constData.MESSAGE_TYPE_PRIVATE"
                                 :class="`message-item ${isMine(message) ? 'message-item-mine' : ''}`">
                                <el-avatar :size="52">{{getUserHeadForList(message)}}</el-avatar>
                                <div class="placeholder"></div>
                                <div class="message-bubble">
                                    <template v-for="(item, index) in contentList(message.payload)">
                                        <span :key="index" v-if="item.name === 'text'">{{ item.text }}</span>
                                        <img v-else-if="item.name === 'img'" :src="item.src" width="20px" height="20px" :key="index"/>
                                    </template>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
                <div class="send-message-box">
                    <div class="send-bar">
                        <el-popover placement="top" width="400" trigger="click">
                            <div class="emojis">
                                <div v-for="item in emojiName" class="emoji" :key="item" @click="chooseEmoji(item)">
                                    <img :src="emojiUrl + emojiMap[item]" style="width:30px;height:30px"/>
                                </div>
                            </div>
                            <i class="el-icon-cold-drink" slot="reference" title="发表情"></i>
                        </el-popover>
                        <el-button class="send-button" size="mini" type="primary" @click="sendTextMessage">发送</el-button>
                    </div>
                    <div class="send-text">
                        <!--suppress HtmlFormInputWithoutLabel -->
                        <textarea ref="text-input"
                                  rows="6"
                                  resize="none"
                                  v-model="messageContent"
                                  class="text-input"
                                  @keydown.enter.exact.prevent="sendTextMessage"
                                  @keyup.ctrl.enter.prevent.exact="handleLine">
                        </textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {mapState} from 'vuex';
    import constData from './../assets/javascript/const-data';
    import {emojiMap, emojiName, emojiUrl} from '../assets/TX_api/emojiMap';
    import { decodeText } from '../assets/TX_api/decodeText';


    export default {
        name: "conversation",
        data() {
            return {
                status: {
                    // 是否正在切换会话
                    isCheckouting: false,
                    showAtGroupMember: false,
                },
                messageContent: "",
                emojiMap: emojiMap,
                emojiName: emojiName,
                emojiUrl: emojiUrl,
                constData:constData
            }
        },
        mounted() {

        },
        methods: {
            closeConversation(){
                this.$router.go(-1);
            },
            getLastMessage(lastMessage) {
                switch (lastMessage.type) {
                    case window.TIM.TYPES.MSG_TEXT:
                        return JSON.parse(lastMessage.messageForShow).text;
                    case window.TIM.TYPES.MSG_IMAGE:
                        return "[图片]";
                    default:
                        return "未知消息" + lastMessage.type;
                }
            },
            selectConversation(conversation) {
                this.status.isCheckouting = true;
                this.$store.dispatch('checkoutConversation', conversation.conversationID).then(() => {
                    this.status.isCheckouting = false;
                    console.log("currentConversation",this.currentConversation);
                }).catch(() => {
                    this.$message.warning("没有找到该用户");
                })
            },
            isMine(message) {
                return message.flow === 'out'
            },
            getUserHeadForList(message){
                if(this.isMine(message)){
                    return this.$util.getUser().nickName[0];
                }else {
                    return this.currentConversation.userProfile.nick[0];
                }
            },
            handleLine() {
                this.messageContent += '\n'
            },
            chooseEmoji(item) {
                this.messageContent += item;
            },
            sendTextMessage() {
                if (this.messageContent === '' || this.messageContent.trim().length === 0) {
                    this.messageContent = '';
                    this.$message.warning("不能发送空消息哦");
                    return;
                }
                let text = {};
                text.type = constData.MESSAGE_TYPE_PRIVATE;
                text.text = this.messageContent;
                text.user = this.ticUserInfo.userId;
                const message = window.tim.createTextMessage({
                    to: this.currentConversation.userProfile.userID,
                    conversationType: window.TIM.TYPES.CONV_C2C,
                    payload: {text: JSON.stringify(text)}
                });
                this.$store.commit('pushCurrentMessageList', message);
                window.tim.sendMessage(message).catch(error => {
                    this.$message.error(error.message);
                });
                this.messageContent = ''
            },
            scrollMessageListToButtom() {
                this.$nextTick(() => {
                    let messageListNode = this.$refs['message-list'];
                    if (!messageListNode) {
                        return
                    }
                    messageListNode.scrollTop = messageListNode.scrollHeight;
                })
            },
            contentList(payload) {
                return decodeText(payload);
            }
        },
        updated() {
            this.scrollMessageListToButtom();
        },
        computed: {
            ...mapState({
                conversationList: state => state.conversationList,
                currentConversation: state => state.currentConversation,
                currentMessageList: state => state.currentMessageList,
                isCompleted: state => state.isCompleted,
                ticUserInfo: state => state.ticUserInfo
            })
        }
    }
</script>

<style lang="less" scoped>
    .conversation {
        padding-bottom: 20px;

        .breadcrumb {
            width: 1200px;
            margin: 0 auto;

            .el-breadcrumb__item {
                font-size: 16px;
                line-height: 76px;
            }
        }

        .web-QQ {
            position: relative;
            display: flex;
            border: 1px #A366CC solid;
            border-radius: 15px;
            height: 746px;
            max-width: 1198px;
            margin: 0 auto;
            .close-bottom{
                position: absolute;
                top: 10px;
                right: 10px;
                font-size: 30px;
                padding: 0;
                z-index: 30;
            }
            .no-conversation-list {
                font-size: 16px;
                color: white;
                text-align: center;
            }
            .conversation-list {
                border-top-left-radius: 15px;
                border-bottom-left-radius: 15px;
                padding-top: 15px;
                width: 266px;
                height: calc(100% - 15px);
                background-color: #A366CC;
                overflow-y: auto;
                .conversation-list-item {
                    height: 85px;
                    width: calc(100% - 30px);
                    padding: 0 15px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    cursor: pointer;
                    .name-message {
                        width: calc(100% - 45px - 24px - 10px);
                        color: white;
                        .name {
                            font-size: 16px;
                            font-weight: bold;
                        }
                        .message {
                            font-size: 14px;
                            white-space:nowrap;
                            overflow:hidden;
                            text-overflow:ellipsis;
                        }
                    }
                    .name-message-no-unread {
                        width: calc(100% - 45px - 5px);
                    }
                    .unread {
                        height: 24px;
                        width: 24px;
                        background-color: #FD4D4D;
                        color: white;
                        font-size: 14px;
                        line-height: 24px;
                        text-align: center;
                        border-radius: 50%;
                    }
                    &:hover {
                        background-color: #925CB7;
                    }
                }
                .conversation-list-item-active {
                    background-color: #925CB7;
                }
            }
            .conversation-content {
                width: calc(100% - 266px);
                height: 100%;
                .message-box {
                    height: calc(100% - 171px);
                    .message-title {
                        padding: 0 32px;
                        width: calc(100% - 64px);
                        height: 77px;
                        background-color: white;
                        line-height: 77px;
                        color: #333333;
                        font-size: 24px;
                        border-top-right-radius: 15px;
                    }
                    .message-list {
                        padding: 0 32px;
                        width: calc(100% - 64px);
                        height: calc(100% - 77px);
                        background-color: #F7F7F7;
                        overflow: auto;
                        .message-item {
                            margin-top: 32px;
                            display: flex;
                            align-items: center;
                            .placeholder {
                                width: 0;
                                height: 0;
                                border: 15px solid;
                                border-color: #F7F7F7 white #F7F7F7 #F7F7F7;
                            }
                            .message-bubble {
                                max-width: 70%;
                                background-color: white;
                                border-radius: 10px;
                                height: 61px;
                                padding: 0 18px;
                                display: flex;
                                align-items: center;
                                font-size: 14px;
                                color: #333333;
                                word-wrap: break-word;
                                word-break: break-all;
                            }
                        }
                        .message-item-mine {
                            flex-direction: row-reverse;
                            .placeholder {
                                border-color: #F7F7F7 #F7F7F7 #F7F7F7 #A366CC;
                            }
                            .message-bubble {
                                background-color: #A366CC;
                                color: white;
                            }
                        }
                    }
                }
                .send-message-box {
                    padding: 0 32px;
                    width: calc(100% - 64px);
                    height: 171px;
                    background-color: white;
                    border-bottom-right-radius: 15px;
                    .send-bar {
                        height: 57px;
                        display: flex;
                        align-items: center;
                        i {
                            font-size: 25px;
                            color: #cccccc;
                            cursor: pointer;
                            &:hover{
                                color: #5D2385;
                            }
                        }
                        .send-button {
                            margin-left: auto;
                        }
                    }
                    .send-text {
                        height: (100% - 57px);
                        .text-input {
                            font-size: 16px;
                            width: 100%;
                            box-sizing: box-sizing;
                            border: none;
                            outline: none;
                            background-color: transparent;
                        }
                    }
                }
            }
        }
    }
</style>
<style lang="less">
    .emojis {
        height: 160px;
        box-sizing: border-box;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        overflow-y: scroll;
        .emoji {
            height: 40px;
            width: 40px;
            box-sizing: border-box;
            cursor: pointer;
        }
    }
</style>