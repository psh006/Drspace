<template>
    <div class="pay">
        <div class="pay-head">
            <el-breadcrumb separator-class="el-icon-arrow-right" class="breadcrumb">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item>支付订单</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="pay-main">
            <div class="pay-title">
                <div class="remind-title">确认订单信息</div>
                <div class="remind-info">请在2小时内完成支付，否则订单会被自动取消</div>
            </div>
            <div class="pay-user">
                <div style="display: flex">
                    <el-avatar v-if="$util.isEmpty(userMessage.avatar)"
                               class="user-avatar">
                        {{userMessage.nickName[0]}}
                    </el-avatar>
                    <el-avatar v-else
                               class="user-avatar"
                               :src="$getFileUrl+userMessage.avatar">
                    </el-avatar>
                    <div style="margin-left: 10px">
                        <div style="display: flex">
                            <div class="user-name">购买账号：{{userMessage.nickName}}</div>
                            <div class="user-phone">（{{userMessage.loginCode}}）</div>
                        </div>
                        <div class="user-notice">注意：购买后不支持退款、转让，请确认开课时间或有效期后再提交订单</div>
                    </div>
                </div>
                <div class="user-change" @click="showChangeBuyAccount">更换账号<i class="el-icon-arrow-right"></i></div>
            </div>
            <div class="pay-mode">
                <div class="mode-title">支付方式</div>
                <div class="mode-active" @click="openPayModeMethod">
                    <div style="display: flex;">
                        <div class="mode-image">
                            <el-image :src="payModeChoosed.image"
                                      style="height: 100%; width: 100%"></el-image>
                        </div>
                        <span class="mode-name">{{payModeChoosed.name}}</span>
                    </div>
                    <div class="mode-more" v-if="status.openPayMode===false">展开
                        <i class="el-icon-arrow-down"></i>
                    </div>
                    <div class="mode-more" v-if="status.openPayMode===true">收起
                        <i class="el-icon-arrow-up"></i>
                    </div>
                </div>
                <div class="mode-inactive" v-if="status.openPayMode===true" @click="changePayMode">
                    <div style="display: flex;">
                        <div class="mode-image">
                            <el-image :src="payModeNoChoosed.image"
                                      style="height: 100%; width: 100%"></el-image>
                        </div>
                        <span class="mode-name">{{payModeNoChoosed.name}}</span>
                    </div>
                </div>
            </div>
            <div class="pay-course">
                <div class="pay-course-title">购买课程</div>
                <div class="pay-course-list" v-for="(item,index) in courseList.courseList" :key="index">
                    <div style="display: flex">
                        <div class="course-image">
                            <el-image :src="$getFileUrl+item.courseCover"
                                      style="height: 100%;width: 100%" fit="cover"></el-image>
                        </div>
                        <div>
                            <div class="course-name">
                                {{item.courseName}}
                            </div>
                            <div class="course-time">
                                {{$util.formatDate(item.courseStart,'yyyy年MM月dd日')}}-{{$util.formatDate(item.courseEnd,'yyyy年MM月dd日')}}·{{item.allCourseHour}}课时
                            </div>
                        </div>
                    </div>
                    <div class="course-price">￥{{((item.coursePrice)/100).toFixed(2)}}</div>
                </div>
            </div>

            <div class="pay-confirm">
                <div class="confirm-message">
                    <div class="confirm-total-price">
                        <div class="confirm-info">实付：</div>
                        <div class="confirm-price">￥{{((courseList.sumPrice)/100).toFixed(2)}}</div>
                    </div>
                    <div style="display: flex; justify-content: flex-end">
                        <div class="confirm-notice">提交订单则表示您同意</div>
                        <div class="confirm-agreement" @click="showAgreement">《名师荟用户付费协议》</div>
                    </div>
                </div>
                <div class="confirm-button" @click="toPay">立即支付</div>
            </div>
        </div>

        <!--协议弹窗-->
        <el-dialog
                title="名师荟用户付费协议"
                :visible.sync="status.agreementDialogVisible"
                width="30%"
                center>
            <pre style="line-height: 21px; margin: 0 15px">
        合理详细的合同才能让合同双方不会产生意见分歧，并且在签约以后很少有发生违约现象。因而一份详尽有条理的合同需要认真细致地制定。公司依照法律的相关规定制定出的合同，让合同双方都能接受有关条例，便可以达到签约目的。
        甲方：      乙方：
        为了振兴地方经济，促进开放型经济的发展，就甲方委托乙方进行招商引资代理服务事宜，经双方友好协商，达成如下一致协议：
            一、甲方责任与义务： 1、 甲方负责提供当地的投资环境、基本情况、优惠政策等有关文字、图片资料(中英文对照)给乙方，2、 并保证所提供资料的有效性。
        合理详细的合同才能让合同双方不会产生意见分歧，并且在签约以后很少有发生违约现象。因而一份详尽有条理的合同需要认真细致地制定。公司依照法律的相关规定制定出的合同，让合同双方都能接受有关条例，便可以达到签约目的。
        为了振兴地方经济，促进开放型经济的发展，就甲方委托乙方进行招商引资代理服务事宜，经双方友好协商，达成如下一致协议：
            一、甲方责任与义务： 1、 甲方负责提供当地的投资环境、基本情况、优惠政策等有关文字、图片资料(中英文对照)给乙方，2、 并保证所提供资料的有效性。
            </pre>
        </el-dialog>

        <!--更换账号弹窗-->
        <el-dialog
                title="更换账号"
                :visible.sync="status.changeBuyAccountDialogVisible"
                width="420px"
                @closed="closeChangeBuyAccount">
            <span>
                <el-input v-model="searchParam.buyAccount" maxlength="11" placeholder="输入账号" clearable
                          @input="getSearchParam"
                          style="width: 313px"></el-input>
                <el-button type="primary" @click="searchBuyAccount">搜索</el-button>
                <div class="search-result">
                    <div class="search-title">搜索结果（{{buyAccountList.length}}）</div>
                    <div v-if="buyAccountList.length>0">
                        <div class="search-user" v-for="(item,index) in buyAccountList" :key="index">
                            <div style="display: flex">
                                <el-avatar v-if="$util.isEmpty(item.avatar)">
                                    {{item.nickName[0]}}
                                </el-avatar>
                                <el-avatar v-else :src="$getFileUrl+item.avatar"></el-avatar>
                                <div style="margin-left: 10px">
                                    <div class="search-user-name">{{item.nickName}}</div>
                                    <div class="search-user-phone">{{item.loginCode}}</div>
                                </div>
                            </div>
                            <div class="search-select">
                                <el-button type="success" @click="selectBuyAccount(item)">选择</el-button>
                            </div>
                        </div>
                    </div>
                    <div v-else class="no-data">暂无搜索结果</div>
                </div>
            </span>
        </el-dialog>

        <!--微信二维码-->
        <div v-if="options.text">
            <div class="qrcode-bg"></div>
            <div class="qrcode-logo">
                <i class="el-icon-circle-close" @click="toMyOrder"></i>
                <el-image :src="require('./../assets/img/pay-img.png')"></el-image>
                <div style="display: flex">
                    <p class="qrcode-info">请扫描二维码</p>
                    <div class="qrcode">
                        <div v-qr="options"/>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "pay",
        data() {
            return {
                userMessage: {},
                status: {
                    agreementDialogVisible: false,
                    changeBuyAccountDialogVisible: false,
                    openPayMode: false,
                },
                searchParam: {
                    buyAccount: '',
                    buyAccountLength: ''
                },
                buyAccountList: [],
                payModeChoosed: {
                    image: require("./../assets/img/alipay.png"),
                    name: '支付宝',
                    payType: 2
                },
                payModeNoChoosed: {
                    image: require('./../assets/img/wechat.png'),
                    name: '微信',
                    payType: 1
                },
                courseList: {
                    courseList: [],
                    sumPrice: ""
                },
                options: {
                    text: '',
                    width: 154,
                    height: 154,
                    background: "#ffffff",
                    foreground: "#000000"
                },
                timer: null,
                outTradeNo: ""
            }
        },
        created() {
            this.userMessage = this.$util.getUser();
            this.getCourseList();
            this.computePrice();
            // window.addEventListener('beforeunload', this.deleteOrder());
        },
        // beforeDestroy() {
        //     this.deleteOrder();
        // },
        // destroyed() {
        //     window.removeEventListener('beforeunload', this.deleteOrder);
        // },
        methods: {
            deleteOrder() {
                if(!this.$util.isEmpty(this.outTradeNo)){
                    this.$request({outTradeNo: this.outTradeNo}, "/pay/closeOrder");
                }
            },
            getCourseList() {
                /*购物车返回*/
                if (sessionStorage.getItem('courseList')) {
                    this.courseList = JSON.parse(sessionStorage.getItem('courseList'));
                    return;
                }
                /*我的订单返回*/
                if (sessionStorage.getItem('order')) {
                    this.courseList = JSON.parse(sessionStorage.getItem('order'));
                    this.userMessage.studentId = this.courseList.receivingId;
                    this.userMessage.nickName = this.courseList.receivingName;
                    this.userMessage.loginCode = this.courseList.receivingPhone;
                    /*查询用户头像*/
                    this.$request({studentId: this.courseList.receivingId}, "/masters/mapper/select/student.queryStudentById", (data) => {
                        this.userMessage.avatar = data.list[0].avatar;
                    }, () => {
                    });
                    return;
                }
                /*课程详情返回*/
                if (sessionStorage.getItem('course')) {
                    this.courseList.courseList.push(JSON.parse(sessionStorage.getItem('course')));
                    return;
                }
            },
            /*跳转我的订单*/
            toMyOrder() {
                // this.deleteOrder();
                this.$router.push({
                    path: '/personal-center',
                    query: {"index": "myOrder"}
                });
            },
            /*金额计算*/
            computePrice(){
                this.$request({
                    courseList: this.courseList.courseList,
                    customerId: this.$util.getUser().studentId,
                    payType: this.payModeChoosed.payType
                },"/masters/computePrice",data=>{
                    this.courseList.sumPrice = data.list[0].totalAmount;
                },()=>{});
            },
            /*协议弹窗*/
            showAgreement() {
                this.status.agreementDialogVisible = true;
            },
            /*更换账号弹窗*/
            showChangeBuyAccount() {
                this.status.changeBuyAccountDialogVisible = true;
            },
            /*搜索输入框*/
            getSearchParam(value) {
                this.searchParam.buyAccount = this.$util.checkNumber(value);
                this.searchParam.buyAccountLength = value.length;
            },
            /*搜索账号*/
            searchBuyAccount() {
                if (this.$util.isEmpty(this.searchParam.buyAccount)) {
                    this.$message.warning("请输入账号");
                    return;
                } else if (this.searchParam.buyAccountLength < 11) {
                    this.$message.warning("请输入正确账号");
                    return;
                }
                this.$request({loginCode: this.searchParam.buyAccount}, "/masters/changeBuyAccount", (data) => {
                    this.buyAccountList = data.list;
                }, () => {
                });
            },
            /*更换账号*/
            selectBuyAccount(item) {
                this.status.changeBuyAccountDialogVisible = false;
                this.userMessage = item;
            },
            /*关闭更换账号弹窗*/
            closeChangeBuyAccount() {
                this.searchParam.buyAccount = '';
                this.buyAccountList = '';
            },
            /*展开支付方式*/
            openPayModeMethod() {
                this.status.openPayMode = !this.status.openPayMode;
            },
            /*支付方式切换*/
            changePayMode() {
                this.status.openPayMode = !this.status.openPayMode;
                let choosedMode = {...this.payModeChoosed};
                let noChoosedMode = {...this.payModeNoChoosed};
                this.payModeChoosed = noChoosedMode;
                this.payModeNoChoosed = choosedMode;
                this.computePrice();
            },
            /*支付*/
            toPay() {
                var courseIdStr = this.courseList.courseList.map(function (obj) {
                    return obj.courseId;
                }).join(",");
                this.$request({
                    orderId: this.courseList.orderId,
                    course: this.courseList.courseList,
                    studentId: this.$util.getUser().studentId,
                    studentName: this.$util.getUser().realName,
                    parentName: this.$util.getUser().parentName,
                    payType: this.payModeChoosed.payType,
                    receivingId: this.userMessage.studentId,
                    receivingName: this.userMessage.nickName,
                    receivingPhone: this.userMessage.loginCode,
                    orderStatus: 1,
                    discountAmount: 0,
                    orderAmount: this.courseList.sumPrice,
                    payableAmount: this.courseList.sumPrice,
                }, "/masters/immediatePayment", (data) => {
                    this.outTradeNo = data.list[0].orderId;
                    this.$request({
                        customerId: this.userMessage.loginCode,
                        payType: this.payModeChoosed.payType,
                        outTradeNo: data.list[0].orderId,
                        courseId: courseIdStr,
                        totalFee: this.courseList.sumPrice
                    }, "/pay/placeOrder", (res) => {
                        /*支付宝返回数据*/
                        if (this.payModeChoosed.payType === 2) {
                            this.$message.success("下单成功！正在进入支付页面...");
                            const div = document.createElement('div');
                            div.innerHTML = res.list[0];
                            document.body.appendChild(div);
                            const punchoutForm = document.getElementsByName("punchout_form");
                            const punchoutInput = punchoutForm[0].childNodes;
                            punchoutInput[3].click();
                        }
                        /*微信返回数据*/
                        if (this.payModeChoosed.payType === 1) {
                            this.$message.success("下单成功！请扫描微信支付二维码");
                            this.options.text = res.list[0];
                            /*定时查询订单是否已支付*/
                            this.timer = window.setInterval(() => {
                                setTimeout(this.$request({orderId: data.list[0].orderId,}, "/masters/mapper/select/customerOrder.queryOrderById", (data) => {
                                    if (data.list[0].orderStatus === 5) {
                                        clearInterval(this.timer);
                                        this.timer = null;
                                        this.$router.push("pay-success");
                                    }
                                }, () => {
                                }), 0);
                            }, 3000);
                        }
                    }, () => {
                    });
                }, () => {
                });
            },
        },
        beforeRouteLeave(to, from, next) {
            window.clearInterval(this.timer);
            next();
        }
    }
</script>

<style lang="less">
    .pay {
        padding-bottom: 80px;

        .pay-head {
            width: 100%;
            height: 76px;
            border-top: 1px solid #fff;

            .breadcrumb {
                width: 1200px;
                margin: 0 auto;

                .el-breadcrumb__item {
                    font-size: 16px;
                    line-height: 76px;
                }
            }
        }

        .pay-main {
            width: 1200px;
            margin: 0 auto;
            background-color: #fff;

            .pay-title {
                height: 68px;
                line-height: 68px;
                display: flex;

                .remind-title {
                    font-size: 20px;
                    margin-left: 19px;
                }

                .remind-info {
                    font-size: 14px;
                    color: #808080;
                    margin-left: 9px;
                }
            }

            .pay-user {
                display: flex;
                justify-content: space-between;
                width: 100%;
                margin: 10px 0;

                .user-avatar {
                    margin-left: 42px;
                }

                .user-name {

                }

                .user-phone {
                    color: #808080;
                }

                .user-notice {
                    font-size: 14px;
                    color: #B3B3B3;
                    margin-top: 4px;
                }

                .user-change {
                    margin-right: 42px;
                    cursor: pointer;
                }
            }

            .pay-mode {
                .mode-title {
                    font-size: 20px;
                    margin: 30px 0px 0 19px;
                    padding-bottom: 10px;
                }

                .mode-active, .mode-inactive {
                    width: 1116px;
                    height: 80px;
                    line-height: 80px;
                    margin: 0px auto;
                    background-color: #F5F5F5;
                    display: flex;
                    justify-content: space-between;

                    .mode-image {
                        width: 44px;
                        height: 44px;
                        padding-top: 18px;
                        padding-left: 30px;
                    }

                    .mode-name {
                        margin-left: 10px;
                    }

                    .mode-more {
                        margin-right: 35px;
                        cursor: pointer;
                    }
                }

                .mode-inactive {
                    border-top: 1px solid #DBDBDB;
                }
            }

            .pay-course {
                .pay-course-title {
                    font-size: 20px;
                    margin: 30px 0 10px 19px;
                }

                .pay-course-list {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 10px;

                    .course-image {
                        width: 150px;
                        height: 85px;
                        margin: 0 17px 0 42px;
                    }

                    .course-name {
                        margin-top: 15px;
                    }

                    .course-time {
                        color: #808080;
                        margin-top: 8px;
                    }

                    .course-price {
                        font-weight: 600;
                        line-height: 85px;
                        margin-right: 42px;
                    }
                }
            }

            .pay-confirm {
                display: flex;
                margin-top: 23px;

                .confirm-message {
                    width: 975px;
                    height: 100px;
                    background-color: #FAE7CB;
                    padding-right: 25px;

                    .confirm-total-price {
                        display: flex;
                        justify-content: flex-end;
                        margin-top: 27px;

                        .confirm-info {
                            font-size: 14px;
                            line-height: 30px;
                        }

                        .confirm-price {
                            font-size: 24px;
                            font-weight: 600;
                            color: #FD4D4D;
                            line-height: 30px;
                        }
                    }

                    .confirm-notice {
                        font-size: 14px;
                        color: #808080;
                    }

                    .confirm-agreement {
                        font-size: 14px;
                        color: #4BAF50;
                        cursor: pointer;
                    }
                }

                .confirm-button {
                    width: 200px;
                    height: 100px;
                    line-height: 100px;
                    text-align: center;
                    background-color: #5D2283;
                    color: #fff;
                    font-size: 24px;
                    cursor: pointer;
                }
            }
        }

        .el-dialog__body {
            padding: 15px 25px 50px 25px;

            .search-result {
                margin-top: 25px;
                font-size: 14px;

                .search-title {
                    color: #808080;
                    padding-bottom: 10px;
                }

                .search-user {
                    height: 40px;
                    padding: 10px 0;
                    display: flex;
                    justify-content: space-between;
                    border-bottom: 1px solid #DEE2E6;

                    .search-user-name {
                    }

                    .search-user-phone {
                    }

                    .search-select {
                    }
                }

                .search-user:last-child {
                    border-bottom: none;
                }
            }
        }

        .qrcode-bg {
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            top: 0;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .qrcode-logo {
            position: absolute;
            top: 50%;
            left: 50%;
            margin-left: -140px;
            margin-top: -180px;

            .el-icon-circle-close {
                float: right;
                cursor: pointer;
                font-size: 30px;
                position: relative;
                top: -20px;
                left: -40px;
                color: #9033CC;
            }

            .el-icon-circle-close:hover{
                color: #5D2385;
            }


            .qrcode-info {
                writing-mode: horizontal-tb;
                writing-mode: vertical-lr;
                letter-spacing: 6px;
                font-size: 25px;
                -webkit-text-fill-color: #fff; /*文字的填充色*/
                -webkit-text-stroke: 1.2px #9033CC;
                font-weight: 900;
                margin-top: -14px;
                margin-left: 5px;
            }

            .qrcode {
                width: 154px;
                height: 154px;
                background-color: #fff;
                padding: 20px;
                border-radius: 20px;
                border: 6px solid #9033CC;
                margin-top: -30px;
                margin-left: 5px;
                z-index: 1;
            }
        }

        .no-data {
            color: #808080;
            text-align: center;
            margin-top: 30px;
        }

        pre {
            white-space: pre-wrap;
            white-space: -moz-pre-wrap;
            white-space: -o-pre-wrap;
            *word-wrap: break-word;
            *white-space: normal;
        }
    }
</style>