<template>
    <div class="pay-success">
        <div style="padding: 153px 0; text-align: center">
            <el-image :src="require('./../assets/img/pay-success.png')"></el-image>
            <p style="color: #333;font-size: 20px">支付成功</p>
            <p style="color: #999;font-size: 14px;margin-top: 10px;">点击跳转到
                <span style="color: #5D2283;cursor: pointer; text-decoration: underline"
                      @click="toMyOrder">我的订单</span>
            </p>
        </div>
    </div>
</template>

<script>
    export default {
        name: "pay-successs",
        methods: {
            toMyOrder() {
                this.$router.push({
                    path: '/personal-center',
                    query: {"index": "myOrder"}
                });
            }
        }
    }
</script>

<style scoped>

</style>