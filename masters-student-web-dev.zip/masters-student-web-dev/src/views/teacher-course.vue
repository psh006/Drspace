<template>
  <div class="teacher-course">
    <div v-if="courseLength>0" style="flex-direction: column">
      <div class="course-box">
        <div class="course-list" v-for="(item, index) in courseList" :key="index" @click="courseInfo(item.courseId)">
          <img :src="$getFileUrl+item.courseCover" class="course-cover">
          <div class="course-price">
            <span style="font-size: 14px;color: #ffffff">剩余{{item.maxAmount-item.applyAmount}}个名额</span>
            <strong style="font-size: 18px;color: #FD4D4D;">￥{{$util.pennyToYuan(item.coursePrice)}}</strong>
          </div>
          <div class="course-info">
            <p>{{item.courseName}}</p>
            <p style="color: #808080;display: flex;">
            <span>
              难度
            </span>
              <span style="margin-left: 10px">
              <el-rate
                      v-model="item.halfLevel"
                      disabled
                      text-color="#ff9900"/>
            </span>
            </p>
            <p style="color: #808080"><span>{{$util.formatDate(item.courseStart,'yyyy年MM月dd日')}}-{{$util.formatDate(item.courseEnd,'yyyy年MM月dd日')}}</span>·<span>{{item.allCourseHour}}课时</span>
            </p>
          </div>
          <div class="teacher-box">
            <div style="display: flex" @click.stop="getTeacherInfo(item.lecturerId)">
              <img :src="$getFileUrl +item.lecturerAvatar"/>
              <div style="margin-left: 10px">
                <p>{{item.lecturerName}}</p>
                <p style="color: #B3B3B3">授课老师</p>
              </div>
            </div>
            <div style="display: flex;margin-left: 10px;" @click.stop="getTeacherInfo(item.managerTeacherId)">
              <img :src="$getFileUrl +item.managerTeacherAvatar"/>
              <div style="margin-left: 10px">
                <p>{{item.managerTeacherName}}</p>
                <p style="color: #B3B3B3">班主任老师</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-pagination background
                     align="right"
                     layout="total, sizes, prev, pager, next, jumper"
                     :current-page="searchParams.page"
                     :page-sizes="[6, 12, 18,24]"
                     :page-size="searchParams.limit"
                     :total="courseTotal"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange"/>
    </div>
    <div v-else style="color: #bdc7d1">
      暂无课程
    </div>
  </div>
</template>

<script>
  export default {
    name: "teacher-course",
    props: {
      teacherId: {
        type: String,
        default: () => {
          return ""
        }
      }
    },
    data() {
      return {
        courseList: [],
        courseLength: 0,
        courseTotal: 0,
        searchParams: {
          teacherId: '',
          page: 1,
          limit: 6
        }
      }
    },
    mounted() {
      this.searchParams.teacherId = this.teacherId
      this.queryTeacherCourse(this.searchParams);
    },
    methods: {
      // 当前第几页
      handleCurrentChange(CurrentPage) {
        this.searchParams.page = CurrentPage;
        this.queryTeacherCourse(this.searchParams);
      },
      // 每页几条
      handleSizeChange(pageSize) {
        this.searchParams.limit = pageSize;
        this.handleCurrentChange(1);
      },
      queryTeacherCourse(params) {
        this.$request(params, "/masters/mapper/select/queryCourseList", (data) => {
          if (data.flag === 200) {
            this.courseList = data.list;
            this.courseLength = data.list.length;
            this.courseTotal = data.total
          }
        }, err => {
          console.log(err);
        });
      },
      courseInfo(courseId){
        this.$router.push({path:'/course-details',query:{courseId:courseId}})
      },
      getTeacherInfo(teacherId){
        let searchParams = {
          teacherId: teacherId,
          page: 1,
          limit: 6
        };
        this.queryTeacherCourse(searchParams);
        this.$emit("teacher-click",teacherId);
      }
    }
  }
</script>

<style lang="less">
  .teacher-course{
    .course-list {
      position: relative;
      border: 1px solid #F5F5F5;
      border-radius: 10px;
      width: 368px;
      /*float: left;*/
      margin: 10px 19px 0 0;

      .course-cover {
        width: 368px;
        height: 207px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
      }
    }

    .course-price {
      position: absolute;
      top: 162px;
      width: 348px;
      height: 46px;
      padding: 0 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: rgba(51, 51, 51, 0.5);
    }

    .course-box {
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 20px;
    }

    .course-info {
      padding: 5px 10px;
      font-size: 14px;

      p {
        padding-top: 5px;
      }
    }

    .teacher-box {
      display: flex;
      padding: 5px 10px 10px;
      border: 1px solid #F5F5F5;
      font-size: 14px;

      img {
        width: 38px;
        height: 38px;
        border-radius: 50%;
      }
    }
  }

</style>