<template>
    <div class="search">
        <div class="select-head">
            <el-breadcrumb separator-class="el-icon-arrow-right" class="breadcrumb">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item>搜索结果</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="select-main">
            <div class="select-total">
                共有<span class="total-number">{{courseTotal}}</span>门相关的课程
            </div>
            <div v-if="courseTotal===0" class="no-data">暂无相关课程</div>
            <div style="display: flex;width: 1200px;flex-wrap:wrap;">
                <div class="course-list" v-for="(courseItem,courseIndex) in courseList"
                     :key="courseIndex">
                    <div class="course-info" @click="toCourseDetail(courseItem.courseId)">
                        <div class="course-image-font">
                            <div class="course-image">
                                <el-image
                                        :src="$getFileUrl+courseItem.courseCover"
                                        fit="cover"
                                        style="width:100%; height: 100%; border-radius: 10px 10px 0px 0px;"/>
                            </div>
                            <div class="course-state">
                                <div class="course-remain">剩余{{courseItem.maxAmount-courseItem.applyAmount}}个名额</div>
                                <div class="course-price">￥{{((courseItem.coursePrice)/100).toFixed(2)}}</div>
                            </div>
                        </div>
                        <div class="course-details">
                            <div class="course-detail-title">
                                【{{courseItem.specialName}}】{{courseItem.courseName}}
                            </div>
                            <div style="display: flex; justify-content: space-between">
                                <div class="course-detail">
                                    <div class="detail-one">
                                        <div class="course-difficult">难度：</div>
                                        <el-rate v-model="courseItem.halfLevel" disabled
                                                 :colors="rateColors">
                                        </el-rate>
                                    </div>
                                    <div class="detail-two">
                                        {{$util.formatDate(courseItem.courseStart,'MM月dd日')}}-{{$util.formatDate(courseItem.courseEnd,'MM月dd日')}}
                                        {{courseItem.allCourseHour}}课时
                                    </div>
                                    <div class="detail-three">
                                        <div class="course-teachers" @click.stop="toTeacherInfo(courseItem.lecturerId)">
                                            <div class="course-teacher-image">
                                                <el-avatar :src="$getFileUrl+courseItem.lecturerAvatar"></el-avatar>
                                            </div>
                                            <div class="course-teacher">
                                                <div class="course-teacher-name">{{courseItem.lecturerName}}
                                                </div>
                                                <div class="course-teacher-type">授课老师</div>
                                            </div>
                                        </div>
                                        <div class="course-teachers"
                                             @click.stop="toTeacherInfo(courseItem.managerTeacherId)">
                                            <div class="course-teacher-image">
                                                <el-avatar
                                                        :src="$getFileUrl+courseItem.managerTeacherAvatar"></el-avatar>
                                            </div>
                                            <div class="course-teacher">
                                                <div class="course-teacher-name">
                                                    {{courseItem.managerTeacherName}}
                                                </div>
                                                <div class="course-teacher-type">学习管理师</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <el-pagination background
                           align="right"
                           layout="prev, pager, next"
                           :total="courseTotal"
                           :current-page="queryCourseParams.page"
                           :page-size="queryCourseParams.limit"
                           @current-change="handleCurrentChange">
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "search",
        data() {
            return {
                queryCourseParams: {
                    page: 1,
                    limit: 9
                },
                courseTotal: 0,
                courseList: [],
                rateColors: ['#FDC242', '#FDC242', '#FDC242'],
                searchParam: '',
                searchType: ''
            }
        },
        created() {
            this.searchParam = this.$route.params.searchParam;
            this.searchType = this.$route.params.searchType;
            this.getSearchParams();
        },
        methods: {
            // 当前第几页
            handleCurrentChange(currentPage) {
                this.queryCourseParams.page = currentPage;
                this.queryCourseList();
            },
            getSearchParams(searchType, searchParam){
                if (searchType) {
                    this.searchType = searchType;
                }
                if (searchParam) {
                    this.searchParam = searchParam;
                }
                if (this.searchType === '1') {
                    this.queryCourseParams.courseName = this.searchParam;
                    this.queryCourseParams.teacherName = '';
                } else if (this.searchType === '2') {
                    this.queryCourseParams.teacherName = this.searchParam;
                    this.queryCourseParams.courseName = '';
                } else {
                    this.courseList = '';
                    this.courseTotal = 0;
                    return;
                }
                this.searchParam = '';
                this.queryCourseParams.page = 1;
                this.queryCourseList();
            },
            queryCourseList() {
                let params = {...this.queryCourseParams};
                this.$request(params, "/masters/mapper/select/queryCourseList", (data) => {
                    this.courseList = data.list;
                    this.courseTotal = data.total;
                }, () => {
                });
            },
            toCourseDetail(courseId) {
                this.$router.push({
                    name: 'course-details',
                    query: {"courseId": courseId}
                })
            },
            toTeacherInfo(teacherId) {
                this.$router.push({
                    name: 'teacher-info',
                    query: {"teacherId": teacherId}
                })
            },
        }
    }
</script>

<style lang="less">
    .search {
        .select-head {
            width: 100%;
            height: 76px;
            border-top: 1px solid #F5F5F5;
            background-color: #FFFFFF;

            .breadcrumb {
                width: 1200px;
                margin: 0 auto;

                .el-breadcrumb__item {
                    font-size: 16px;
                    line-height: 70px;
                }
            }
        }

        .select-main {
            width: 1200px;
            margin: 0px auto;
            padding-bottom: 40px;

            .select-total {
                margin-top: 30px;
                padding-bottom: 13px;
                color: #808080;

                .total-number {
                    color: #333333;
                    font-weight: 600;
                }
            }

            .course-list:nth-child(3n+3) {
                width: 368px;
            }

            .course-list {
                .course-info {
                    width: 368px;
                    height: 360px;
                    margin: 17px 48px 20px 0px;
                    background-color: #fff;
                    font-size: 14px;
                    border-radius: 10px;
                    cursor: pointer;

                    .course-image-font {
                        position: relative;
                        height: 207px;

                        .course-image {
                            width: 368px;
                            height: 207px;
                            position: absolute;
                            left: 0;
                            right: 0;
                        }

                        .course-state {
                            width: 348px;
                            height: 40px;
                            line-height: 40px;
                            background-color: rgba(0, 0, 0, 0.4);
                            display: flex;
                            justify-content: space-between;
                            padding: 0px 10px;
                            position: absolute;
                            bottom: 0;

                            .course-remain {
                                color: #fff;
                                font-size: 14px;
                            }

                            .course-price {
                                color: #FD4D4D;
                                font-weight: 600;
                                font-size: 18px;
                            }
                        }
                    }

                    .course-details {

                        .course-detail-title {
                            margin: 8px 10px;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }

                        .course-detail {

                            .detail-one {
                                display: flex;
                                color: #8F8E94;
                                margin: 5px 10px;


                                .course-difficult {
                                    .el-rate__icon {
                                        margin-right: 0;
                                    }
                                }
                            }

                            .detail-two {
                                color: #808080;
                                padding: 5px 10px;
                            }

                            .detail-three {
                                display: flex;
                                margin: 5px 10px;

                                .course-teachers {
                                    display: flex;
                                    padding: 5px 25px 10px 0;

                                    .course-teacher-image {
                                        width: 50px;
                                        height: 40px;
                                    }

                                    .course-teacher {
                                        line-height: 20px;

                                        .course-teacher-name {

                                        }

                                        .course-teacher-type {
                                            color: #A8A8A8;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            .el-dialog, .el-pager li,
            .el-pagination .btn-next,
            .el-pagination .btn-prev {
                background-color: transparent;
            }
        }

        .no-data {
            color: #555;
            margin: 100px;
            text-align: center;
        }
    }
</style>