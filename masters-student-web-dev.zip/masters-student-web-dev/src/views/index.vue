<template>
    <div class="index">
        <div class="index-header">
            <div class="index-header-content">
                <el-image style="cursor: pointer" @click="$router.push('/home')"
                          :src="require('./../assets/img/logo.png')" fit="cover"/>
                <div class="search-box">
                    <el-input :placeholder="searchInfo" v-model="queryCourseParams.searchParam" maxlength="30"
                              class="input-with-select" @keyup.enter.native="toSearch">
                        <el-select v-model="queryCourseParams.searchType" slot="prepend" class="search-select"
                                   @change="changeSearchSelect">
                            <el-option label="课程" value="1"></el-option>
                            <el-option label="老师" value="2"></el-option>
                        </el-select>
                        <el-button slot="append" icon="el-icon-search" @click="toSearch" class="search-button">搜索
                        </el-button>
                    </el-input>
                </div>
                <div class="user-info-box">
                    <template v-if="systemUserIsLogin">
                        <div class="user-info">
                            <span class="my-course" @click="$router.push('/mycourse')">我的课程</span>
                            <el-badge :value="notReadTotal" :max="99" class="item" :hidden="notReadTotal < 1" :key="index">
                                <span class="my-course" @click="$router.push('/conversation')"><i
                                        class="el-icon-chat-dot-round"></i></span>
                            </el-badge>

                            <span class="my-course" @click="$router.push('/student-cart')"><i
                                    class="el-icon-shopping-cart-2"></i></span>
                            <span style="color: #B3B3B3;padding: 0 10px;line-height: 35px;">|</span>
                            <span class="user-name" @click="$router.push('/personal-center')"
                                  :title="systemUserInfo.nickName"
                                  style="cursor: pointer;">{{ systemUserInfo.nickName }}</span>
                            <template v-if="$util.isEmpty(systemUserInfo.avatar)">
                                <el-avatar visible="false" style="cursor: pointer;" slot="reference"
                                           @click.native="$router.push('/personal-center')"
                                           :size="35">
                                    {{systemUserInfo.nickName[0]}}
                                </el-avatar>
                            </template>
                            <template v-else>
                                <el-avatar visible="false" style="cursor: pointer;" slot="reference"
                                           @click.native="$router.push('/personal-center')"
                                           :size="35"
                                           :src="$getFileUrl + systemUserInfo.avatar">
                                </el-avatar>
                            </template>
                        </div>
                    </template>
                    <template v-else>
                        <el-link @click="openLogin" :underline="false">登录/注册</el-link>
                    </template>
                </div>
            </div>
        </div>
        <div class="index-body-footer" ref="index-body-footer">
            <div class="index-body">
                <router-view ref="routerView"/>
            </div>
            <div class="index-footer">
                <div class="footer-content">
                    <div class="footer-item">
                        <div>成都名师荟教育</div>
                    </div>
                    <div style="height: 10px"></div>
                    <div class="footer-item address">
                        <div class="address-item">
                            <div>蜀汉路校区 028-62416746</div>
                            <div>金牛区蜀汉路蜀通街12号红世大厦3楼（欧尚对面）</div>
                        </div>
                        <div class="address-item">
                            <div>梁家巷校区 028-83317238</div>
                            <div>金牛区一环路北四段108号附6号1栋附325（银海中心）</div>
                        </div>
                        <div class="address-item">
                            <div>红牌楼校区 028-85058181</div>
                            <div>武侯区红牌楼长益路159号红城一栋一单元五楼西部汽车城旁</div>
                        </div>
                        <div class="address-item">
                            <div>驷马桥校区 028-62619511</div>
                            <div>成华区金科星耀天都1栋B座322号3楼</div>
                        </div>
                        <div>
                            <div>橡树林校区 028-62418310</div>
                            <div>锦江区望江橡树林三期3栋2层</div>
                        </div>
                    </div>
                    <div style="height: 10px"></div>
                    <div class="footer-item">
                        <span @click="$router.push('/about-us')" style="cursor: pointer;">关于我们</span>
                    </div>
                    <div class="footer-item" style="margin: 5px 0">
                        满意度反馈电话：400-855-3353
                    </div>
                    <div class="footer-item" style="color: #999">
                        ©2020-2021 成都市武侯区名师荟西教育培训学校有限责任公司 版权所有 蜀ICP备19013313号-1
                    </div>
                </div>
            </div>
        </div>
        <login @close-login="closeLogin" @login-success="getUserSig"/>
    </div>
</template>

<script>
    import login from "./../components/login";
    import {mapState} from 'vuex';
    import constData from "./../assets/javascript/const-data"

    export default {
        name: "index",
        components: {
            login
        },
        computed: {
            ...mapState({
                systemUserIsLogin: state => state.systemUserIsLogin,
                systemUserInfo: state => state.systemUserInfo,
                ticUserStatus: state => state.ticUserStatus,
                tic: state => state.tic,
                notReadTotal: state => state.notReadTotal,
                ticUserInfo: state => state.ticUserInfo
            })
        },
        data() {
            return {
                status: {
                    isLogin: false
                },
                queryCourseParams: {
                    searchType: '1',
                    searchParam: ''
                },
                constData: constData,
                searchInfo: '请输入课程名称'
            }
        },
        created() {
            // 判断是登录
            let user = this.$util.getUser();
            if (!this.$util.isEmpty(user)) {
                this.$store.commit("setSystemUserInfo", user);
                this.getUserSig();
            }
        },
        beforeDestroy() {
            this.updateHandler();
        },
        destroyed() {
            window.removeEventListener('beforeunload', this.updateHandler);
        },
        watch: {
            $route: function (newRouter) {
                if (newRouter.path !== '/search') {
                    this.queryCourseParams.searchType = '1';
                    this.queryCourseParams.searchParam = '';
                }
            }
        },
        methods: {
            openLogin() {
                this.$util.openLogin();
            },
            closeLogin() {
                this.$util.closeLogin();
            },
            initTic() {
                if (this.ticUserStatus === this.constData.USER_STATUS_UNINIT) {
                    this.$store.commit("initTic", () => {
                        this.loginTic();
                    })
                } else if (this.ticUserStatus <= this.constData.USER_STATUS_UNLOGIN) {
                    this.loginTic();
                }
            },
            loginTic() {
                this.clearEvent();
                console.log("监听事件");
                // 登录成功后会触发 SDK_READY 事件，该事件触发后，可正常使用 SDK 接口
                window.tim.on(window.TIM.EVENT.SDK_READY, this.onReadyStateUpdate, this);
                // 收到新消息
                window.tim.on(window.TIM.EVENT.MESSAGE_RECEIVED, this.onReceiveMessage);
                // 会话列表更新
                window.tim.on(window.TIM.EVENT.CONVERSATION_LIST_UPDATED, this.onUpdateConversationList);
                this.tic.login(this.ticUserInfo, (res) => {
                    if (res.code) {
                        console.error(this.constData.MESSAGE_TYPE_SYSTEM, "登录失败", res);
                    } else {
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_LOGINED);
                        // 增加事件监听
                        this.addTICEventListener();
                        this.addTICStatusListener();
                    }
                });
            },
            clearEvent() {
                this.tic.removeTICEventListener();
                this.tic.removeTICStatusListener();
                window.tim.off(window.TIM.EVENT.SDK_READY, this.onReadyStateUpdate);
                window.tim.off(window.TIM.EVENT.MESSAGE_RECEIVED, this.onReceiveMessage);
                window.tim.off(window.TIM.EVENT.CONVERSATION_LIST_UPDATED, this.onUpdateConversationList);
            },
            onReadyStateUpdate() {
                this.getConversationList();
                this.updateMyProfile();
            },
            onReceiveMessage({data: messageList}) {
                console.log("接收了新的消息");
                this.$store.commit('pushCurrentMessageList', messageList)
            },
            onUpdateConversationList(event) {
                this.getConversationList(event.data)
            },
            updateMyProfile() {
                let getPromise = window.tim.getMyProfile();
                getPromise.then(imResponse => {
                    let user = this.$util.getUser();
                    let userInfo = imResponse.data;
                    let updateUserInfo = {};
                    if (userInfo.nick !== user.nickName) {
                        updateUserInfo.nick = user.nickName || "";
                    }
                    if (userInfo.avatar !== user.avatar) {
                        updateUserInfo.avatar = user.avatar || "";
                    }
                    console.log(updateUserInfo);
                    if (!this.$util.isEmpty(updateUserInfo)) {
                        let promise = window.tim.updateMyProfile(updateUserInfo);
                        promise.then(() => {
                            console.log("tim:更新资料成功")
                        }).catch(function (imError) {
                            console.warn('更新资料失败:', imError); // 更新资料失败的相关信息
                        });
                    }
                }).catch(imError => {
                    console.warn('获取资料失败:', imError); // 获取个人资料失败的相关信息
                });
            },
            /**
             * 增加IM消息监听回调
             */
            addTICMessageListener() {
                this.tic.addTICMessageListener({
                    /**
                     * 收到C2C文本消息
                     * @param fromUserId        发送此消息的用户id
                     * @param message                收到消息的内容
                     */
                    onTICRecvTextMessage: (fromUserId, message) => {
                        message = JSON.parse(message);
                        if (message.type === this.constData.MESSAGE_TYPE_GROUP_PRIVATE) {
                            this.showMessageInBox(message.type, message.fromUserName + ": " + message.text);
                        }
                    },
                    /**
                     * 收到C2C自定义消息
                     * @param fromUserId        发送此消息的用户id
                     * @param data                收到消息的内容
                     */
                    onTICRecvCustomMessage: (fromUserId, data) => {
                        console.log("收到C2C自定义消息", data)
                    },
                    /**
                     * 收到群文本消息
                     * @param fromUserId        发送此消息的用户id
                     * @param message                收到消息的内容
                     */
                    onTICRecvGroupTextMessage: (fromUserId, message) => {
                        message = JSON.parse(message);
                        if (message.type === this.constData.MESSAGE_TYPE_GROUP) {
                            this.showMessageInBox(message.type, message.fromUserName + ": " + message.text);
                        }
                    },
                    /**
                     * 收到群自定义消息
                     * @param fromUserId        发送此消息的用户id
                     * @param data                收到消息的内容
                     */
                    onTICRecvGroupCustomMessage: (fromUserId, data) => {
                        console.log("收到群自定义消息", data)
                    }
                });
            },
            getConversationList(updateConversationList) {
                if (updateConversationList) {
                    let conversationList = updateConversationList.filter(conversation => {
                        return conversation.type === window.TIM.TYPES.CONV_C2C;
                    });
                    this.$store.commit("setConversationList", conversationList);
                } else {
                    let conversationListProperties = window.tim.getConversationList();
                    conversationListProperties.then(data => {
                        let conversationList = data.data.conversationList.filter(conversation => {
                            return conversation.type === window.TIM.TYPES.CONV_C2C;
                        });
                        this.$store.commit("setConversationList", conversationList);
                    });
                }

            },
            // 事件监听回调
            addTICEventListener() {
                this.tic.addTICEventListener({
                    onTICMemberJoin: (members) => {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, members.join(',') + '进入了课堂');
                    },
                    onTICMemberQuit: (members) => {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, members.join(',') + '退出了课堂');
                    },
                    onTICClassroomDestroy: () => {
                        this.$message.success("老师解散了课堂");
                        this.$router.push("/mycourse").catch(() => {
                        });
                    },
                    onTICTrtcClientCreated: () => {
                        window.trtcClient = this.trtcClient = this.tic.getTrtcClient();
                        this.initTRTCEvent();
                    }
                });
            },
            // TRTC事件
            initTRTCEvent() {
                this.trtcClient.on('stream-added', event => {
                    const remoteStream = event.stream;
                    const remoteUserId = remoteStream.getUserId();
                    console.log('received a remoteStream ID: ' + remoteStream.getId() + ' from user: ' + remoteUserId);
                    // 若需要观看该远端流，则需要订阅它，默认会自动订阅
                    this.trtcClient.subscribe(remoteStream);
                });

                // 监听‘stream-removed’事件
                this.trtcClient.on('stream-removed', event => {
                    const remoteStream = event.stream;
                    console.log('remoteStream ID: ' + remoteStream.getId() + ' has been removed');
                    // 停止播放并删除相应<video>标签
                    remoteStream.stop();
                    document.getElementById(remoteStream.getId()).remove();
                });

                // 监听‘stream-updated’事件
                this.trtcClient.on('stream-updated', event => {
                    const remoteStream = event.stream;
                    console.log('remoteStream ID: ' + remoteStream.getId() + ' was updated hasAudio: ' +
                        remoteStream.hasAudio() + ' hasVideo: ' + remoteStream.hasVideo());
                });

                // 监听‘stream-subscribed’事件
                this.trtcClient.on('stream-subscribed', event => {
                    console.log("开启视频事件", event);
                    // let teacherId = event.userId_;
                    const remoteStream = window.remoteStream = event.stream;
                    // 远端流订阅成功，在HTML页面中创建一个<video>标签，假设该标签ID为‘remote-video-view’
                    // 播放该远端流
                    let remoteVideoWrapEl = document.createElement('div');
                    remoteVideoWrapEl.id = remoteStream.getId();
                    document.querySelector("#video-box").insertBefore(remoteVideoWrapEl, null);
                    remoteStream.play(remoteVideoWrapEl);
                });

                this.trtcClient.on('mute-audio', event => {
                    console.log('mute-audio', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}关闭了麦克风`);
                });

                this.trtcClient.on('mute-video', event => {
                    console.log('mute-video', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}关闭了摄像头`);
                });

                this.trtcClient.on('unmute-audio', event => {
                    console.log('unmute-audio', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}打开了麦克风`);
                });

                this.trtcClient.on('unmute-video', event => {
                    console.log('unmute-video', event);
                    const userId = event.userId;
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `${userId}打开了摄像头`);
                });

                this.trtcClient.on('error', error => {
                    console.error('client error observed: ' + error);
                    // const errorCode = error.getCode();
                    // 根据ErrorCode列表查看详细错误原因。
                });
            },
            // IM状态监听回调
            addTICStatusListener() {
                this.tic.addTICStatusListener({
                    onTICForceOffline: () => {
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_UNLOGIN);
                        this.$message.warning("帐号其他地方登录，被T了");
                        this.clearEvent();
                        this.$util.removeUser();
                        this.$store.commit("removeSystemUserInfo");
                        this.$router.push({path:"/"}).then(()=>{
                            window.location.reload(true);
                        })
                    }
                });
            },
            updateHandler() {
                // this.logout_internal();
            },
            logout_internal() {
                this.tic.logout((res) => {
                    if (res.code) {
                        this.$message.error('登出失败');
                        console.error(res);
                    } else {
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_UNLOGIN);
                        // 删除事件监听
                        this.tic.removeTICMessageListener();
                        this.tic.removeTICEventListener();
                        this.tic.removeTICStatusListener();
                    }
                });
            },
            showMessageInBox(messageType, text) {
                let d = new Date();
                let time = `${('0' + d.getHours()).substr(-2)}:${('0' + d.getMinutes()).substr(-2)}:${('0' + d.getSeconds()).substr(-2)}`;
                let msg = {
                    time: time + ' ',
                    send: messageType + ' ',
                    content: text
                };
                this.$store.commit("insertGroupMsg", msg)
            },
            getUserSig() {
                let userId = this.$util.getUser().studentId;
                let params = {
                    sdkAppId: constData.SDK_APP_ID,
                    userId: userId
                };
                this.$request(params, "/user/getSign", data => {
                    if (data.list && data.list[0]) {
                        let userSign = data.list[0].userSign;
                        let ticUserInfo = {
                            userId: userId,
                            userSig: userSign
                        };
                        this.$store.commit("setTicUserInfo", ticUserInfo);
                        this.initTic();
                    }
                })
            },
            changeSearchSelect(value) {
                if(value==="1"){
                    this.searchInfo = "请输入课程名称"
                }else{
                    this.searchInfo = "请输入老师姓名"
                }
                this.queryCourseParams.searchParam = '';
            },
            /*跳转到搜索页*/
            toSearch() {
                if (this.$util.isEmpty(this.queryCourseParams.searchParam)) {
                    this.$message({
                        type: 'warning',
                        message: '请输入搜索关键词',
                        duration: 1500,
                        showClose: true,
                    });
                    return;
                }
                if (this.$route.path === '/search') {
                    this.$refs.routerView.getSearchParams(this.queryCourseParams.searchType, this.queryCourseParams.searchParam);
                } else {
                    this.$router.push({
                        name: 'search',
                        params: {
                            "searchParam": this.queryCourseParams.searchParam,
                            "searchType": this.queryCourseParams.searchType
                        }
                    });
                }

            }
        },
        // 路由守卫
        beforeRouteUpdate(to, from, next) {
            this.$refs["index-body-footer"].scrollTop = 0;
            next();
        }
    }
</script>

<style lang="less" scoped>
    .index {
        height: 100%;
        background-color: #F6F2F7;

        .index-header {
            width: 100%;
            background-color: #FFFFFF;

            .index-header-content {
                max-width: 1200px;
                margin: 0 auto;
                height: 100px;
                color: #333333;
                display: flex;
                align-items: center;
                justify-content: space-between;

                .search-box {
                    .input-with-select {
                        height: 40px;
                        width: 386px;
                    }

                    .search-select {
                        width: 76px;
                        font-size: 14px;
                    }

                    .search-button {
                        background-color: #4BAF50;
                        color: #FFFFFF;
                        height: 40px;
                        border-radius: 0 20px 20px 0;
                    }
                }

                .user-info-box {
                    .user-info {
                        display: flex;
                        justify-content: center;

                        .my-course {
                            margin: 0 5px;
                            line-height: 35px;
                            cursor: pointer;
                        }

                        .user-name {
                            max-width: 80px;
                            padding: 0 10px;
                            text-align: right;
                            line-height: 35px;
                            overflow: hidden;
                            white-space: nowrap;
                            text-overflow: ellipsis;
                        }
                    }
                }
            }
        }

        .index-body-footer {
            height: calc(100% - 100px);
            overflow: auto;
            .index-body {
                min-height: calc(100% - 198px);
            }
            .index-footer {
                height: 198px;
                width: 100%;
                background-image: url("./../assets/img/bg-footer.png");
                background-size: cover;
                .footer-content {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 10px 35px 0 35px;
                    .footer-item {
                        font-size: 14px;
                        color: white;

                    }
                    .address {
                        display: flex;
                        flex-wrap: wrap;
                        font-size: 12px;
                        .address-item {
                            margin-right: 10px;
                            margin-bottom: 5px;
                        }
                    }
                }
            }
        }

    }
</style>
<style lang="less">
    .index {
        .index-header {
            .index-header-content {
                .search-box {
                    .input-with-select .el-input-group__prepend {
                        background-color: #fff;
                        color: #000;
                        border-radius: 20px 0 0 20px;
                    }

                    .el-select .el-input .el-select__caret {
                        color: #000;
                    }

                    .el-input-group > .el-input__inner {
                        height: 40px;
                        border-left: none;
                        border-top-color: #DCDCDC;
                        border-right-color: #DCDCDC;
                        border-bottom-color: #DCDCDC;
                        color: #333333;
                    }

                    .el-input-group__append {
                        border-radius: 0 20px 20px 0;
                    }
                }
            }
        }
    }
</style>