<!--suppress RequiredAttributes -->
<template>
    <div class="classroom-answer">
        <div class="answer-machine">
            <div style="margin: 20px 0" v-if="subject.subjectType === 1">请从下列选项中选择一项正确答案(当前剩余{{nowAnswerTime}}秒,已耗时{{studentAnswer.time}}秒)</div>
            <div style="margin: 20px 0" v-else>请填写你的答案(当前剩余{{nowAnswerTime}}秒,已耗时{{studentAnswer.time}}秒)</div>
            <template v-if="subject.answerType === constData.ANSWER_TYPE_PRIMARY">
                <div class="subject-title">{{subject.subjectType | filterAnswerSubjcetType}}:{{subject.subjectTitle}}</div>
                <template v-if="subject.subjectType === constData.SUBJECT_TYPE_CHOICE">
                    <div class="option-list">
                        <div v-for="(item,index) in subject.optionList"
                             :key="index"
                             :class="`option-item ${item.label === studentAnswer.answer ? 'option-item-active' : ''}`"
                             @click="choseAnswer(item.label)">
                            {{item.label}}选项: {{item.value}}
                        </div>
                    </div>
                </template>
                <template v-else>
                    <el-input v-model="studentAnswer.answer" type="textarea" maxlength="200"></el-input>
                </template>
            </template>
            <template v-if="subject.answerType === constData.ANSWER_TYPE_CLASS">
                <div class="class-answer">
                    <div :class="studentAnswer.answer === item.label ? 'class-answer-item class-answer-item-active':'class-answer-item'"
                         v-for="(item,index) in subject.optionList"
                         :key="index"
                         @click="choseAnswer(item.label)">{{item.label}}</div>
                </div>
            </template>
            <div class="operate-bar">
                <el-button type="primary" style="margin-left: 10px" @click="replayAnswer" :loading="status.replayAnswerLoading">确认答案</el-button>
                <el-button @click="answerCancel">放弃回答</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    import {mapState} from 'vuex'
    import constData from './../assets/javascript/const-data'

    export default {
        name: "classroom-answer",
        computed: {
            ...mapState({
                answering: state => state.classroomAnswer.answering,
                subject: state => state.classroomAnswer.subject,
                tic: state => state.tic
            })
        },
        mounted() {
            this.startTiming();
            this.setCloseTimer();
        },
        data() {
            return {
                studentAnswer: {
                    answer: "",
                    time: 0,
                },
                nowAnswerTime: 0,
                studentTimer: null,
                closeTimer: null,
                constData: constData,
                status: {
                    replayAnswerLoading: false
                }
            }
        },
        methods: {
            replayAnswer() {
                if (this.$util.isEmpty(this.studentAnswer.answer)) {
                    this.$message.warning("请先填写或选择答案");
                    return;
                }
                let params = {...this.studentAnswer};
                let user = this.$util.getUser();
                params.studentName = user.nickName;
                let message = {};
                message.type = constData.MESSAGE_TYPE_STUDENT_ANSWER;
                message.data = params;
                this.status.replayAnswerLoading = true;
                this.tic.sendGroupTextMessage(JSON.stringify(message), res => {
                    if (res.code !== 0) {
                        this.status.replayAnswerLoading = false;
                        this.$message.warning("回答失败,请重新尝试");
                    } else {
                        this.status.replayAnswerLoading = false;
                        this.answerCancel();
                        this.$message.success("回答成功");
                    }
                });
                //本次答题将记录进服务器
                let answerParams = {
                    courseHourId: this.courseHourId,
                    rightAnswer: this.subject.rightAnswer || "",
                    courseId: this.courseId,
                    studentId: user.studentId,
                    studentAnswer: this.studentAnswer.answer,
                    answerDuration: this.studentAnswer.time
                };
                this.$request(answerParams, "/student/insertCourseHourExam");
            },
            answerCancel() {
                this.$store.commit("setAnswering", false);
            },
            choseAnswer(label) {
                this.studentAnswer.answer = label;
            },
            //答题计时器
            startTiming() {
                if (this.studentTimer) {
                    clearInterval(this.studentTimer);
                    this.studentTimer = null;
                }
                this.studentTimer = setInterval(() => {
                    this.studentAnswer.time++;
                }, 1000)
            },
            setCloseTimer() {
                if (this.closeTimer) {
                    clearInterval(this.closeTimer);
                    this.closeTimer = null;
                }
                let answerTime = this.subject.answerTime;
                if (!this.$util.isEmpty(answerTime)) {
                    this.nowAnswerTime = answerTime;
                    this.closeTimer = setInterval(() => {
                        if (this.nowAnswerTime <= 0) {
                            clearInterval(this.closeTimer);
                            this.closeTimer = null;
                            this.$message.warning("计时已到,答题失败");
                            this.$store.commit("setAnswering", false);
                        } else {
                            this.nowAnswerTime--
                        }
                    }, 1000)
                }
            },
        },
        props: {
            courseHourId: {
                type: String,
                default() {
                    return "";
                }
            },
            courseId: {
                type: String,
                default() {
                    return "";
                }
            }
        },
        //离开页面最好清除计时
        destroyed() {
            if (this.studentTimer) {
                clearInterval(this.studentTimer);
                this.studentTimer = null;
            }
            if (this.closeTimer) {
                clearTimeout(this.closeTimer);
                this.closeTimer = null;
            }
        }
    }
</script>

<style lang="less" scoped>
    .classroom-answer {
        position: fixed;
        z-index: 100;
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        .answer-machine {
            width: 633px;
            background-color: white;
            border-radius: 5px;
            padding: 10px 30px;
            max-height: 600px;
            overflow: auto;
            .subject-title {

            }
            .option-list {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                .option-item {
                    min-height: 24px;
                    border: #bbbbbb 1px solid;
                    background-color: #C1CDD1;
                    color: #101010;
                    font-size: 14px;
                    padding: 0 5px;
                    margin-top: 5px;
                    cursor: pointer;
                    transition: background-color 0.3s;
                    display: flex;
                    align-items: center;
                    word-break: break-all;
                    &:hover {
                        color: white;
                        background-color: #5D2385;
                    }
                }
                .option-item-active {
                    color: white;
                    background-color: #5D2385;
                }
            }
            .operate-bar {
                margin-top: 20px;
                display: flex;
                flex-direction: row-reverse;
            }
            .class-answer{
                display: flex;
                align-items: center;
                justify-content: space-around;
                margin: 10px 0;
                .class-answer-item{
                    cursor: pointer;
                    height: 50px;
                    width: 50px;
                    border: 1px solid #5D2385;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    &:hover{
                        background-color: #5D2385;
                        color: white;
                    }
                }
                .class-answer-item-active{
                    background-color: #5D2385;
                    color: white;
                }
            }
        }
    }
</style>