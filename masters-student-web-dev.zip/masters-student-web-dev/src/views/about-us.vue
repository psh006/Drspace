<template>
    <div class="about-us">
        <el-breadcrumb separator-class="el-icon-arrow-right" class="breadcrumb">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>关于我们</el-breadcrumb-item>
        </el-breadcrumb>

        <div class="about-main">
            <div class="about-title">名师荟机构简介</div>
            <div class="about-image">
                <el-image :src="require('./../assets/img/aboutus.png')" style="width: 100%; height: 100%;"></el-image>
            </div>
            <div class="about-content">
                <pre>
成都名师荟教育咨询有限公司是由国内外知名教研和管理团队打造成的中高端教育品牌，名师荟-直以来专注于利用自己的教育优势，服务于中国万千学子。
同时，名师荟花巨资引|进并打造最先进的教学系统SEC,这套SEC教学系统整合了优质的教育资源，并细分出针对不同学员个性化的教学管理流程。
名师荟专注于小升初、中考、高考、艺体生文化冲刺培训。
并始终践行"助千万学子圆梦理想名校"这一重大使命!
名师荟教育拥有完整的管理运行机制，管理过程中实行标准化、流程化、专业化、规范化、系统化。
名师荟教育的管理团队是由全国知名的家庭教育专家、心理学硕士、中小学教育培训专家、心动力培训专家、成功学激励导师等组成的专业管理团队。
在全国数十个城市举办了数百场讲座，帮助了数千个家庭，受到了业界的好评和良好的社会反响。
名师荟教育以做好的教育人为宗旨，用心做教育，用爱助成长。
永远保持谦虚空杯的学习心态，尊敬同行业每一位竞争对手， 本着以诚信负责、质量为本、 勤学精进、开拓创新的核心理念。
为孩子的学业进步和心灵成长搭建起梦想起飞的平台，让所有在名师荟教育的莘莘学子收获成长，成就梦想。</pre>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "about-us"
    }
</script>

<style lang="less">
    .about-us {
        padding-bottom: 70px;

        .breadcrumb {
            width: 1200px;
            margin: 0 auto;

            .el-breadcrumb__item {
                font-size: 16px;
                line-height: 76px;
            }
        }

        .about-main {
            width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            color: #333333;

            .about-title {
                font-size: 24px;
                text-align: center;
                padding: 30px 0;
            }

            .about-image {
                width: 524px;
                height: 295px;
                margin: 0 auto;
            }

            .about-content {
                font-size: 14px;
                padding: 30px 40px;
                line-height: 45px;

                pre {
                    white-space: pre-wrap;
                    white-space: -moz-pre-wrap;
                    white-space: -o-pre-wrap;
                    *word-wrap: break-word;
                    *white-space: normal;
                }

            }
        }
    }
</style>