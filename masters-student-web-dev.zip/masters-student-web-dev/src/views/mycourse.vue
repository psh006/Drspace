<template>
    <div class="mycourse">
        <div class="mycourse-head">
            <el-breadcrumb separator-class="el-icon-arrow-right" class="breadcrumb">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item>我的课程</el-breadcrumb-item>
            </el-breadcrumb>
        </div>

        <div class="mycourse-main">
            <el-calendar v-model="selectDay" class="calendar" ref="calendar" v-loading="status.getCalenderLoading">
                <template
                        slot="dateCell"
                        slot-scope="{date, data}">
                    <div>
                        <div>{{ data.day.split('-').slice(2).join('') }}</div>
                        <div v-for="(dateItem,dateIndex) in courseDateList" :key="dateIndex">
                            <div class="course-state" v-if="dateItem.courseTimeDate===data.day">
                                <div class="course-state-load" v-for="(courseItem,courseIndex) in dateItem.courseList"
                                     :key="courseIndex" @mouseover="showTips(dateIndex)"
                                     @mouseleave="hideTips()">
                                    <p v-if="courseIndex<3">
                                        [{{courseItem.subName}}]{{courseItem.course_name}}({{$util.formatDate(courseItem.start_time,'hh-mm')}}~{{$util.formatDate(courseItem.end_time,'hh-mm')}})
                                    </p>
                                </div>
                                <div class="course-state-over" v-if="dateIndex === showIndex">
                                    <p v-for="(item,index) in dateItem.courseList"
                                       :key="index">
                                        [{{item.subName}}]{{item.course_name}}（{{$util.formatDate(item.start_time,'hh-mm')}}~{{$util.formatDate(item.end_time,'hh-mm')}}）
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>
            </el-calendar>

            <div class="course-list" v-loading="status.getCourseLoading">
                <div class="course-title">
                    近期课程
                </div>
                <div v-if="courseList.length > 0">
                    <div class="course-info" v-for="(item,index) in courseList" :key="index">
                        <div class="course-details">
                            <div class="course-detail-title">{{item.courseName}}</div>
                            <div style="display: flex; justify-content: space-between">
                                <div class="course-detail">
                                    <div class="detail-one">
                                        {{$util.formatDate(item.courseStart,'MM月dd日')}}-{{$util.formatDate(item.courseEnd,'MM月dd日')}}
                                        · {{$util.formatDate(item.startTime,'hh-mm')}}~{{$util.formatDate(item.endTime,'hh-mm')}} ·
                                        {{item.allCourseHour}}课时
                                    </div>
                                    <div class="detail-two">
                                        <div class="course-difficult">难度：</div>
                                        <el-rate v-model="item.hardLevel" disabled :colors="rateColors">
                                        </el-rate>
                                    </div>
                                    <div class="detail-three">
                                        <div class="course-teachers">
                                            <div class="course-teacher-image">
                                                <el-avatar :src="$getFileUrl+item.lecturerAvatar"></el-avatar>
                                            </div>
                                            <div class="course-teacher">
                                                <div class="course-teacher-name">{{item.lecturerName}}</div>
                                                <div class="course-teacher-type">授课老师</div>
                                            </div>
                                        </div>
                                        <div class="course-teachers">
                                            <div class="course-teacher-image">
                                                <el-avatar :src="$getFileUrl+item.managerAvatar"></el-avatar>
                                            </div>
                                            <div class="course-teacher">
                                                <div class="course-teacher-name">{{item.managerTeacherName}}</div>
                                                <div class="course-teacher-type">学习管理师</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="course-progress">
                                    <div style="position: relative">
                                        <el-progress
                                                type="circle"
                                                :percentage="parseFloat((item.havedCourseHour/item.sumCourseHour*100).toFixed(0))"
                                                :width="80"
                                                :height="80"
                                                color="#27B148"
                                                :stroke-width="10"
                                                stroke-linecap="butt"
                                                :show-text="false"
                                        >
                                        </el-progress>
                                        <div style="position: absolute;top:0;left: 0;display: flex;align-items: center;justify-content: center;height: 100%;width: 100%;flex-direction: column">
                                            <div>{{item.havedCourseHour}}/{{item.sumCourseHour}}</div>
                                            <div>个人</div>
                                        </div>
                                    </div>
                                    <div style="position: relative">
                                        <el-progress
                                                type="circle"
                                                :percentage="parseFloat((item.finishedCourseHour/item.sumCourseHour*100).toFixed(0))"
                                                :width="80"
                                                :height="80"
                                                color="#27B148"
                                                :stroke-width="10"
                                                stroke-linecap="butt"
                                                :show-text="false"
                                        >
                                        </el-progress>
                                        <div style="position: absolute;top:0;left: 0;display: flex;align-items: center;justify-content: center;height: 100%;width: 100%;flex-direction: column">
                                            <div>{{item.finishedCourseHour}}/{{item.sumCourseHour}}</div>
                                            <div>班级</div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="course-button">
                            <el-button type="primary" :loading="status.getRoomIdLoading" @click="joinClassroom(item)">进入课堂</el-button>
                            <el-button type="primary" @click="showCourseware(item.courseId,item.courseName)">课程资料</el-button>
                            <el-button type="primary" @click="joinClassroom(item,true)">观看回放</el-button>
                            <el-button type="primary" @click="homeworkAfterClass(item)">课后作业</el-button>
                        </div>
                    </div>
                    <!--课程列表分页-->
                    <el-pagination
                            layout="prev, pager, next"
                            :current-page="queryCourseListParams.page"
                            :page-size="queryCourseListParams.limit"
                            :total="courseListLength"
                            @current-change="changeCourseListPage"
                            :hide-on-single-page="status.showCourseListPage"
                            style="border:none; margin-top: 10px"
                            align="right">
                    </el-pagination>
                </div>
                <div v-else class="no-data">暂无课程</div>
            </div>
        </div>
        <!-- 课后作业弹框-->
        <el-dialog title="课程信息详情" :visible.sync="homeworkAfterDialogVisible" width="520px" custom-class="dialog-class"
                   @closed="homeworkAfterDialogVisibleClosed">
            <el-card class="box-card" shadow="never">
                <div slot="header" class="clearfix">
                    <span>课程信息列表</span>
                </div>
                <div style="text-align: center;font-size: 16px;color: #CCCCCC" v-if="hoeworkAfterlist.length <= 0">
                    暂无课程信息
                </div>
                <div style="text-align: center" class="textitem" v-for="(item,indexId) in hoeworkAfterlist" :key="indexId" v-else>
                    <span>{{item.courseHourNumerical}}</span>
                    <span>{{item.testPaperName}}</span>
                    <span class="answerClass " v-if="item.isFinish===1 && $util.isEmpty(item.studentScore)">待批改</span>
                    <span class="answerClass point" v-else-if="item.isFinish===1 && !$util.isEmpty(item.studentScore)"
                          @click="lookanswerMethod(item)">{{item.studentScore}}</span>
                    <span class="answerClass point" @click="answerMethod(item)" v-else>答题</span>
                </div>

            </el-card>
            <div class="pagination">
                <el-pagination
                        background
                        layout="prev, pager, next"
                        :total="paginationtotal"
                        :page-size="homeworkAfterQuery.limit"
                        :current-page="homeworkAfterQuery.page"
                        @size-change="testListhandlePageSize"
                        @current-change="testLishandleSearch"

                >
                </el-pagination>
            </div>
        </el-dialog>
        <!-- 答题 答题卡弹框-->
        <el-dialog custom-class="dialog-class"
                   :title="answerTestPaperList.testPaperName"
                   :visible.sync="status.answerSheetDialog"
                   :before-close="answerSheetDialoghandleClose"
                   @closed="answerSheetDialogFormVisibleClosed"
                   width="1030px"
                   top="40px"
        >
            <div class="conten">
                <div class="homeword-img">
                    <el-scrollbar style="height:100%">
                        <div class="fileimg" v-for="item in answerFileList" :key="item.file_id">
                            <img v-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.jpg' ||  item.file_url.substring(item.file_url.lastIndexOf('.'))=='.png' || item.file_url.substring(item.file_url.lastIndexOf('.'))==='.jpeg' "
                                 :src="$getFileUrl+item.file_url">
                            <div class="pdf" v-else-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.pdf'">
                                <div style="width:200px;margin-top: 20px;margin-left: 20px">
                                    <!--    上一页-->
                                    <span @click="changePdfPage(0)">上一页</span>
                                    {{currentPage}} / {{pageCount}}
                                    <!--下一页-->
                                    <span @click="changePdfPage(1)">下一页</span>
                                </div>
                                <pdf ref="myPDF"
                                     :src="$getFileUrl+item.file_url"
                                     :page="currentPage"
                                     @num-pages="pageCount=$event"
                                     @page-loaded="currentPage=$event"
                                     @loaded="loadPdfHandler"
                                >
                                </pdf>
                            </div>
                            <div v-else style="height:700px;width: 99%;position: relative">
                                <div style="position: absolute;width: 100%;height: 47px;background-color: #ffffff;margin-top: 48px;margin-left: 2px"></div>
                                <iframe style="height:650px;min-width: 100%"
                                        :src="'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com'+item.file_url"></iframe>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
                <div class="homeword-conten">
                    <el-scrollbar style="height:100%">
                        <p class="bigTitle" v-if="answerRes.length>0">答题卡</p>
                        <p v-else style="height: 100px;margin:auto;line-height: 100px;color: #ccc;text-align: center">暂无题目</p>
                        <template v-for="(subject,index) in answerRes">
                            <!-- 选择题-->
                            <div v-if="subject.topic_type === 1" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span
                                        class="titlepadding">选择题</span></span><span></span></div>
                                <div class="ability-test-content">
                                    <ol class="choice-ol">
                                        <li v-for="(item,indexId) in subject.themeList" :key="indexId">
                                            <span class="theme-class">{{item.theme_number}}.</span>
                                            <span v-if="item.chose_type===1"
                                                  style="font-size: 12px;color: #CCCCCC;margin-right: 10px">(单选)</span>
                                            <span v-else
                                                  style="font-size: 12px;color: #CCCCCC;margin-right: 10px">(多选)</span>
                                            <el-radio-group v-model="item.studentAnswer" v-if="item.chose_type===1">
                                                <el-radio-button v-for="choseitem in item.option" :label="choseitem"
                                                                 :key="choseitem">{{choseitem}}
                                                </el-radio-button>

                                            </el-radio-group>
                                            <el-checkbox-group v-model="item.studentAnswer" v-else>
                                                <el-checkbox-button v-for="choseitem in item.option" :label="choseitem"
                                                                    :key="choseitem"> {{choseitem}}
                                                </el-checkbox-button>
                                            </el-checkbox-group>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                            <!-- 填空题-->
                            <div v-if="subject.topic_type === 2" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span
                                        class="titlepadding">填空题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                    <el-form>
                                        <ol class="choice-ol">
                                            <el-form-item v-for="(item,indexId) in subject.themeList " :key="indexId">
                                                <li>
                                                    <span class="theme-class">{{item.theme_number}}.</span>
                                                    <el-input style="width:220px" v-model="item.studentAnswer"
                                                              :label="item.name" maxlength="30"></el-input>
                                                </li>
                                            </el-form-item>
                                        </ol>
                                    </el-form>
                                </div>
                            </div>
                            <!-- 判断题-->
                            <div v-if="subject.topic_type === 3" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span
                                        class="titlepadding">判断题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                    <el-form>
                                        <ol type="1" class="choice-ol">
                                            <li v-for="(item,indexId) in subject.themeList" :key="indexId">
                                                <span class="theme-class">{{item.theme_number}}.</span>
                                                <span class="judge">
                                                <template>
                                                  <el-radio-group v-model="item.studentAnswer">
                                                    <el-radio label="YES">正确</el-radio>
                                                    <el-radio label="NO">错误</el-radio>
                                                  </el-radio-group>
                                                </template>
                                            </span>
                                            </li>
                                        </ol>
                                    </el-form>
                                </div>
                            </div>
                            <div v-if="subject.topic_type === 5" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span
                                        class="titlepadding">连线题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                    <el-form :model="subject" ref="connectionForm">
                                        <el-form-item v-for="(item,indexId) in subject.themeList" :label="`${item.theme_number}`" :key="indexId">
                                            <el-input style="width:220px" v-model="item.studentAnswer" @blur.prevent="AnswerRules(item.studentAnswer)"
                                                      placeholder=" 例如：1-2,2-3"></el-input>
                                        </el-form-item>
                                    </el-form>
                                </div>
                            </div>
                            <!-- 解答题-->
                            <div v-if="subject.topic_type === 4" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span
                                        class="titlepadding">解答题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                    <el-form>
                                        <ol class="choice-ol">
                                            <li v-for="(item,indexId) in subject.themeList" :key="indexId">
                                                <span class="theme-class">{{item.theme_number}}.</span>
                                                <el-form-item>
                                                    <el-input v-model="item.studentAnswer"
                                                              style="width: 280px;padding-top: 10px" type="textarea"
                                                              rows="5"></el-input>
                                                </el-form-item>
                                            </li>
                                        </ol>
                                    </el-form>
                                </div>
                            </div>
                        </template>
                        <!--  提交-->
                        <div class="question-type">
                            <div style="padding-left: 250px">
                                <el-button type="primary" :disabled="status.stopSubmit" @click="submitTestPaper" v-if="answerRes.length>0">提交
                                </el-button>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
            </div>
        </el-dialog>
        <!-- 查看试卷详情 答题卡 弹框  -->
        <!-- 课后作业答题卡-->
        <el-dialog :title="testPaperAnswerList.testPaperName" :visible.sync="HomeWorkDetailsAnswerSheetDialog"
                   width="1010px" top="60px">
            <div class="look-answer-conten">
                <div class="homeword-img">
                    <el-scrollbar style="height:100%">
                        <div class="fileimg" v-for="(item,indexId) in fileList" :key="indexId">
                            <img v-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.jpg' ||  item.file_url.substring(item.file_url.lastIndexOf('.'))=='.png' || item.file_url.substring(item.file_url.lastIndexOf('.'))==='.jpeg' "
                                 :src="$getFileUrl+item.file_url">
                            <div class="pdf" v-else-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.pdf'">
                                <div style="width:200px;margin-top: 20px;margin-left: 20px">
                                    <!--    上一页-->
                                    <span @click="changePdfPage(0)">上一页</span>
                                    {{currentPage}} / {{pageCount}}
                                    <!--下一页-->
                                    <span @click="changePdfPage(1)">下一页</span>
                                </div>
                                <pdf ref="myPDF"
                                     :src="$getFileUrl+item.file_url"
                                     :page="currentPage"
                                     @num-pages="pageCount=$event"
                                     @page-loaded="currentPage=$event"
                                     @loaded="loadPdfHandler"
                                >
                                </pdf>
                            </div>
                            <div v-else style="height:700px;width: 99%;position: relative">
                                <div style="position: absolute;width: 100%;height: 47px;background-color: #ffffff;margin-top: 48px;margin-left: 2px"></div>
                                <iframe style="height:650px;min-width: 100%"
                                        :src="'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com'+item.file_url"></iframe>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
                <div class="homeword-conten">
                    <el-scrollbar style="height:100%">
                        <div class="title">
                            <p><span class="text-underline">{{testPaperAnswerList.testPaperName}}</span></p>
                        </div>
                        <div class="achievement" v-if="testPaperAnswerList.homework_score>0"><span
                                class="achievementscore">成绩:</span><span class="text-underline">{{testPaperAnswerList.homework_score}}</span>
                        </div>
                        <template v-for="(answeritem,indexId) in answerList">
                            <div class="question-type" v-if="answeritem.topic_type === 2" :key="indexId">
                                <div class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}}, </span><span
                                        style="padding-right: 10px">填空题{{answeritem.score}}</span><span></span>
                                </div>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="themenumber">{{item.theme_number}} 、</span>
                                                <div class="chose-button">填写: {{item.student_answer}}</div>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer===item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div style="font-size: 12px" v-if="item.right_answer!=item.student_answer">
                                                <span>答案: {{item.right_answer}}</span></div>
                                            <div>
                                                <div class="ider" v-if="item.is_show_theme_solve===1"
                                                     @click="solutionsToProblems(item.solveList)">解题思路
                                                </div>
                                                <div v-else class="ider-none"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="question-type" v-if="answeritem.topic_type === 1" :key="indexId">
                                <div class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}} , </span><span
                                        style="padding-right: 10px">选择题 {{answeritem.score}}</span><span></span>
                                </div>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="themenumber">{{item.theme_number}} 、 </span>
                                                <div class="chose-button">选择: {{item.student_answer}}</div>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer===item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div style="font-size: 12px;width: 80px"
                                                 v-if="item.right_answer!=item.student_answer"><span>答案: {{item.right_answer}}</span>
                                            </div>
                                            <div>
                                                <div class="ider" v-if="item.is_show_theme_solve===1"
                                                     @click="solutionsToProblems(item.solveList)">解题思路
                                                </div>
                                                <div v-else class="ider-none"></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="question-type" v-if="answeritem.topic_type === 3" :key="indexId">
                                <div class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}}, </span><span
                                        style="padding-right: 10px">判断题 {{answeritem.score}}</span><span> </span>
                                </div>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="themenumber">{{item.theme_number}} 、 </span>
                                                <i v-if="item.student_answer === 'NO'" class="el-icon-close fork"></i>
                                                <i class="el-icon-check hook"
                                                   v-else-if="item.student_answer==='YES'"></i>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer===item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div style="font-size: 12px" v-if="item.right_answer!=item.student_answer">
                                                <span style="font-size: 12px">答案:{{item.right_answer}}</span></div>
                                            <div>
                                                <div class="ider" v-if="item.is_show_theme_solve===1"
                                                     @click="solutionsToProblems(item.solveList)">解题思路
                                                </div>
                                                <div v-else class="ider-none"></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="question-type" v-if="answeritem.topic_type ===5" :key="indexId">
                                <div class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)"><span>{{answeritem.topic_index}}, </span><span
                                        style="padding-right: 10px">连线题 {{answeritem.score}}</span><span> </span>
                                </div>
                                <div class="question">
                                    <div class="question-conten" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="question-conten-list">
                                            <div class="write"><span class="themenumber">{{item.theme_number}} 、 </span>
                                                <div>{{item.student_answer}}</div>
                                            </div>
                                            <div class="list-img">
                                                <i v-if="item.right_answer===item.student_answer"
                                                   class="el-icon-check hook"></i>
                                                <i v-else class="el-icon-close fork"></i>
                                            </div>
                                            <div class="answer"><span style="font-size: 12px" v-if="item.right_answer!=item.student_answer">答案:{{item.right_answer}}</span>
                                            </div>
                                            <div>
                                                <div class="ider" v-if="item.is_show_theme_solve===1"
                                                     @click="solutionsToProblems(item.solveList)">解题思路
                                                </div>
                                                <div v-else class="ider-none"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="question-type" v-if="answeritem.topic_type ===4" :key="indexId">
                                <div class="Types-of" v-if="!$util.isEmpty(answeritem.themeList)">
                                    <span>{{answeritem.topic_index}} , </span><span>解答题 {{answeritem.score}}</span>
                                    <span></span></div>
                                <div class="question">
                                    <div class="answer-question" v-for="(item,indexId) in answeritem.themeList"
                                         :key="indexId">
                                        <div class="scoring">
                                            <div>
                                                <div class="ider" v-if="item.is_show_theme_solve===1"
                                                     @click="solutionsToProblems(item.solveList)">解题思路
                                                </div>
                                                <div v-else class="ider-none"></div>
                                            </div>
                                            <div style="margin-right: 35px">老师批改内容</div>
                                        </div>
                                        <div class="answer">
                                            <div class="reple" style="height: 105px" @click="look"
                                                 v-if="lookshow===true"> 查看学生解题
                                            </div>
                                            <div class="reple" style="border: none" v-else>
                                                <el-input readonly type="textarea" :rows="5"
                                                          :value="item.student_answer"></el-input>
                                            </div>

                                            <div class="ider" v-if="item.is_show_theme_solve===1"
                                                 @click="solutionsToProblems(item.solveList)">解题思路
                                            </div>
                                            <div v-else class="ider-none"></div>
                                            <div class="correction">
                                                <el-form ref="subjectForm">
                                                    <el-form-item prop="teacherremark">
                                                        <el-input readonly type="textarea" :rows="5"
                                                                  :value="item.teacher_remark" maxlength="50"
                                                                  v-model="item.teacher_remark"></el-input>
                                                    </el-form-item>
                                                </el-form>
                                            </div>
                                        </div>
                                        <div class="comment">
                                            <el-form>
                                                <el-form-item label="老师点评 :">
                                                    <el-input type="textarea"
                                                              maxlength="200"
                                                              :value="testPaperAnswerList.teacher_comment"
                                                              readonly></el-input>
                                                </el-form-item>
                                            </el-form>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </template>
                    </el-scrollbar>
                </div>
            </div>
        </el-dialog>
        <!-- 查看解题思路 答题卡 弹框-->
        <el-dialog title="解题思路" :visible.sync="solutionsToProblemsDialogVisible"
                   @close="solutionsToProblemsVisibleClosed" width="30%">
            <div class="el-form-item-image">
                <el-scrollbar style="height:100%">
                    <div class="imga-update imga-update-show  " style="width: 500px">
                        <el-upload action="#" list-type="picture-card" :file-list="fileListimg" disabled>
                            <div slot="file" slot-scope="{file}">
                                <div class="uid-type" v-if="!isImg(file)"><span style="padding-right: 5px"><i
                                        class="el-icon-folder"></i></span>
                                    <span v-if="!$util.isEmpty(file.uid) && typeof (file.uid) === 'string'">{{file.uid.substring(file.uid.lastIndexOf("_")+1)}}</span>
                                </div>
                                <img v-else class="el-upload-list__item-thumbnail" :src="$getFileUrl+file.uid"
                                     style="height: 100%"
                                     alt/>
                                <span class="el-upload-list__item-actions">
                                    <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)"><i
                                            class="el-icon-view"></i> </span></span>

                            </div>
                        </el-upload>
                        <el-dialog :visible.sync="lookSolutionsToProblemsVisibleDialog" width="900px" top="30px"
                                   @close="lookSolutionsDialogVisibleClose">
                            <div style="width: 860px;height: 706px">
                                <el-scrollbar style="height:100%">
                                    <img v-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.jpg' ||  dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))=='.png' || dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.'))==='.jpeg' "
                                         style="height:100%;width: 100%" :src="dialogImageUrl"/>
                                    <div class="pdf" v-else-if="dialogImageUrl.substring(dialogImageUrl.lastIndexOf('.')) ==='.pdf'">
                                        <div style="width:200px">
                                            <!--    上一页-->
                                            <span @click="changePdfPage(0)">上一页</span>
                                            {{currentPage}} / {{pageCount}}
                                            <!--下一页-->
                                            <span @click="changePdfPage(1)">下一页</span>
                                        </div>
                                        <pdf ref="myPDF"
                                             :src="dialogImageUrl"
                                             :page="currentPage"
                                             @num-pages="pageCount=$event"
                                             @page-loaded="currentPage=$event"
                                             @loaded="loadPdfHandler"
                                        >
                                        </pdf>
                                    </div>
                                    <div v-else style="height:700px;width: 99%">
                                        <iframe style="height:700px;width: 100%;margin-top: -90px" :src="dialogImageUrl"></iframe>
                                    </div>
                                </el-scrollbar>
                            </div>
                        </el-dialog>
                    </div>
                </el-scrollbar>
            </div>
        </el-dialog>

        <!-- 课程资料弹窗 -->
        <el-dialog :title="coursewareDialogTitle" :visible.sync="status.coursewareDialogOpen"
                   width="835px" :close-on-click-modal="false">
            <!-- 搜索表单 -->
            <el-form :model="coursewarePageInfo" inline>
                <el-form-item label="课时">
                    <el-select v-model="coursewarePageInfo.courseHourId" clearable>
                        <el-option label="全部" value=""></el-option>
                        <el-option v-for="item in courseHourList" :key="item.courseHourId"
                                   :label="item.courseHourNumerical"
                                   :value="item.courseHourId"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="名称">
                    <el-input v-model="coursewarePageInfo.fileName"
                              placeholder="请输入文件名称" clearable
                              maxlength="50"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" :loading="status.coursewareDataLoading"
                               @click="handleCoursewarePage(1)"
                               icon="el-icon-search">查询
                    </el-button>
                </el-form-item>
            </el-form>
            <!-- 课堂课件 -->
            <el-table :data="coursewareData" v-loading="status.coursewareDataLoading"
                      style="border: 1px solid #EBEEF5; border-bottom: none">
                <el-table-column label="文件名称" prop="fileName" min-width="150px"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="文件大小" prop="fileSize" min-width="100px"></el-table-column>
                <el-table-column label="上传时间" prop="operateTime" min-width="150px"></el-table-column>
                <el-table-column label="操作" width="80px">
                    <template slot-scope="scope">
                        <el-link type="primary" :underline="false" target="_blank"
                                 :href="$getFileUrl + scope.row.fileUrl">下载
                        </el-link>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <el-pagination
                    layout="total, sizes, prev, pager, next, jumper"
                    background
                    :current-page="coursewarePageInfo.page"
                    :page-sizes="[5, 10, 20, 50]"
                    :page-size="coursewarePageInfo.limit"
                    :total="coursewareTotal"
                    @size-change="handleCoursewarePageSize"
                    @current-change="handleCoursewarePage">
            </el-pagination>
        </el-dialog>
        <videoPlayer :video-visible="status.videoVisible" :video-url="videoUrl" :video-title="videoTitle"
                     @video-player-close="status.videoVisible = false"></videoPlayer>
    </div>
</template>
<script>
    import pdf from 'vue-pdf'
    import videoPlayer from "./../components/video-player"

    export default {
        name: "mycourse",
        components: {
            pdf,
            videoPlayer
        },
        data() {

            return {
                //pdf  在线预览  翻页
                currentPage: 0, // pdf文件页码
                pageCount: 0, // pdf文件总页数
                //查看解题思路
                fileListimg: [],
                dialogImageUrl: '',
                //文档在线预览
                previewDomainName: 'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com',
                solutionsToProblemsDialogVisible: false,
                lookSolutionsToProblemsVisibleDialog: false,
                //查看课后作业弹框
                operationDetailsDialog: false,
                //课后作业 答题卡
                input: '',
                choses: [],
                homeworkAfterDialogVisible: false,
                hoeworkAfterlist: [],
                paginationtotal: 0,
                homeworkAfterQuery: {
                    studentId: "",
                    courseId: "",
                    page: 1,
                    limit: 5,
                },
                answerRes: [],
                //开始答题
                startanswerquertion: {
                    testPaperId: "",
                    studentId: "",
                    homeworkId: "",
                    teacherId: "",
                    teacherName: "",
                    courseHourId: ""
                },
                //提交答题内容
                answerQuestionsSubmit: {
                    answerCardId: "",
                    testPaperId: "",
                    studentId: "",
                    homeworkId: "",
                    teacherId: "",
                    teacherName: "",
                    courseHourId: "",
                    //答案内容
                    list: [],
                },
                //答题 试卷
                answerFileList: [],
                //  试卷内容
                answerTestPaperList: [],
                //获取答题卡内容
                answerSheetQuest: {
                    studentId: "",
                    testPaperId: "",
                    homeworkId: "",
                },
                answerList: [],
                testPaperAnswerList: [],
                fileList: [],
                HomeWorkDetailsAnswerSheetDialog: false,
                lookshow: false,
                selectDay: new Date(),
                courseDateList: [],
                courseList: [],
                courseListLength: '',
                queryCourseListParams: {
                    page: 1,
                    limit: 3
                },
                status: {
                    getCalenderLoading: false,
                    getCourseLoading: false,
                    answerSheetDialog: false,
                    getRoomIdLoading: false,
                    coursewareDialogOpen: false,
                    showCourseListPage: false,
                    videoVisible: false,
                    stopSubmit: false,
                    videoTitle: false
                },
                videoTitle: "",
                videoUrl: "",
                rateColors: ['#4BAF50', '#4BAF50', '#4BAF50'],
                showIndex: '',
                coursewareDialogTitle: '课程资料',
                courseHourList: [],
                coursewarePageInfo: {
                    page: 1,
                    limit: 5
                },
                coursewareTotal: 0,
                coursewareData: []
            }
        }
        ,
        watch: {
            selectDay: function () {
                this.getCalenderList();
                this.queryCourseListParams.page = 1;
                this.getCourseList();
            }
        },
        mounted() {
            this.testLishandleSearch(1);
        },
        created() {
            this.getCalenderList();
            this.getCourseList();
        },
        methods: {
            //在线预览 打开  展示当前  文档
            lookSolutionsDialogVisibleClose() {
                this.dialogImageUrl = ''
            },
            // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
            changePdfPage(val) {
                // console.log(val)
                if (val === 0 && this.currentPage > 1) {
                    this.currentPage--
                    // console.log(this.currentPage)
                }
                if (val === 1 && this.currentPage < this.pageCount) {
                    this.currentPage++
                    // console.log(this.currentPage)
                }
            },
            // pdf加载时
            loadPdfHandler() {
                this.currentPage = 1 // 加载的时候先加载第一页
            },
            //点击查看解题思路 弹框
            solutionsToProblems(solveList) {
                this.solutionsToProblemsDialogVisible = true;
                for (let item of solveList) {
                    this.fileListimg.push({uid: item})
                }
            },
            //关闭查看解题思路 弹框  执行的事件
            solutionsToProblemsVisibleClosed() {
                this.fileListimg = []
            },
            //查看解题思路的上传下载
            handlePictureCardPreview(file) {
                let index = file.uid.lastIndexOf(".");//得到最后 "."在第几位
                let fileType = file.uid.substring(index);   //截断"."之前的，得到后缀)
                const isJPEG = fileType === '.jpeg';
                const isPNG = fileType === '.png';
                const isJPG = fileType === '.jpg';
                const isPDF = fileType === '.pdf';
                if (!isJPEG && !isPNG && !isJPG && !isPDF) {
                    this.dialogImageUrl = this.previewDomainName + file.uid;
                    this.lookSolutionsToProblemsVisibleDialog = true;
                } else if (isPDF) {
                    this.lookSolutionsToProblemsVisibleDialog = true;
                    this.$nextTick(() => {
                        this.dialogImageUrl = this.$getFileUrl + file.uid
                    });
                } else {
                    this.dialogImageUrl = this.$getFileUrl + file.uid;
                    this.lookSolutionsToProblemsVisibleDialog = true;
                }
            },
            //判断是解题思路的文件类型
            isImg(fileName) {
                if (!this.$util.isEmpty(fileName.uid) && typeof (fileName.uid) === 'string') {
                    let index = fileName.uid.lastIndexOf(".");//得到最后 "."在第几位
                    let fileType = fileName.uid.substring(index);   //截断"."之前的，得到后缀)
                    const isJPEG = fileType.includes('.jpeg');
                    const isPNG = fileType.includes('.png');
                    const isJPG = fileType.includes('.jpg');
                    return isJPEG || isPNG || isJPG;
                }
            },
            showTips(index) {
                this.showIndex = index;
            },
            hideTips() {
                this.showIndex = '';
            },
            getCalenderList() {
                let params = {};
                params.studentId = this.$util.getUser().studentId;
                params.today = this.$util.formatDate(null, 'yyyy-MM-dd', this.selectDay);
                this.status.getCalenderLoading = true;
                this.$request(params, "/student/queryStudentCourse", (data) => {
                    this.courseDateList = data.list;
                    this.status.getCalenderLoading = false;
                }, () => {
                    this.status.getCalenderLoading = false;
                });
            },
            changeCourseListPage(currentPage) {
                this.queryCourseListParams.page = currentPage;
                this.getCourseList();
            },
            getCourseList() {
                let params = {...this.queryCourseListParams};
                params.studentId = this.$util.getUser().studentId;
                params.courseTimeDate = this.$util.formatDate(null, 'yyyy-MM-dd', this.selectDay);
                this.status.getCourseListLoading = true;
                this.$request(params, "/student/queryStudentCourseInfoByDate", (data) => {
                    for (let item of data.list) {
                        item.hardLevel = item.hardLevel / 2;
                    }
                    this.courseList = data.list;
                    this.courseListLength = data.total;
                    this.status.showCourseListPage = this.courseListLength <= this.queryCourseListParams.limit;
                    this.status.getCourseListLoading = false;
                }, () => {
                    this.status.getCourseListLoading = false;
                });
            },
            joinClassroom(item, playVideo) {
                let nowTime = new Date();
                //可提前十分钟进入教室
                if (!playVideo && new Date(item.startTime).getTime() > (nowTime.getTime() + 600000)) {
                    this.$message.warning("课时未开始");
                    return;
                }
                //不允许在结束时间之后进入教师
                if (!playVideo && new Date(item.endTime).getTime() < nowTime.getTime()) {
                    this.$message.warning("课时已结束");
                    return;
                }
                let courseId = item.courseId;
                let courseName = item.courseName;
                let lecturerId = item.lecturerId;
                let lecturerName = item.lecturerName;
                let courseTimeId = item.courseTimeId;
                this.status.getRoomIdLoading = true;
                this.$request({courseId,courseTimeId}, '/teacher/comingRoom', data => {
                    this.status.getRoomIdLoading = false;
                    //如果返回的数据为空
                    if (this.$util.isEmpty(data.list) || this.$util.isEmpty(data.list[0])) {
                        this.$message.warning("课时信息不存在或课程已结束");
                        return;
                    }
                    //获取课时ID
                    let courseHourId = data.list[0].courseHourId;
                    if (playVideo) {
                        this.playVideo(courseHourId, `${courseName} ${lecturerName}`);
                    } else {
                        let roomID = data.list[0].roomId;
                        let courseState = data.list[0].courseState;
                        if(this.$util.isEmpty(roomID)){
                            this.$message.warning("未能查询到房间号");
                            return;
                        }
                        if(!this.$util.isEmpty(courseState) && courseState === 3){
                            this.$message.warning("课时已结束");
                            return;
                        }
                        this.$request({
                            roomId: roomID,
                            studentId: this.$util.getUser().studentId
                        }, '/masters/mapper/select/studentStatus.selectStudentStatus', data => {
                            let checkBlack = false;
                            let student = null;
                            if (data.list.length > 0) {
                                student = data.list[0];
                                if(student.blacklistState === 1){
                                    checkBlack = true;
                                    this.$message.error("您已被禁止进入该课堂");
                                }
                            }
                            if(!checkBlack){
                                if(!this.$util.isEmpty(student)){
                                    this.$store.commit("setOnStageState",student.onStageState);
                                    this.$store.commit("setProsodyState",student.prosodyState);
                                    this.$store.commit("setEstoppelState",student.estoppelState);
                                }else {
                                    this.$store.commit("setOnStageState",2);
                                    this.$store.commit("setProsodyState",1);
                                    this.$store.commit("setEstoppelState",2);
                                }
                                this.$router.push({
                                    path: "/classroom",
                                    query: {roomID, courseHourId, courseName, courseId, lecturerId}
                                })
                            }
                        });
                    }
                }, () => {
                    this.status.getRoomIdLoading = false;
                });
            },
            playVideo(courseHourId, videoTitle) {
                if (this.$util.isEmpty(courseHourId)) {
                    this.$message.warning("未能获取到课时ID");
                    return;
                }
                this.status.getVideoLoading = true;
                this.$request({courseHourId}, "/masters/mapper/select/course.selectVideoUrlByCourseHour", data => {
                    this.status.getVideoLoading = false;
                    this.videoTitle = videoTitle;
                    if (data.list && data.list[0] && !this.$util.isEmpty(data.list[0].videoUrl)) {
                        this.videoUrl = data.list[0].videoUrl;
                        this.status.videoVisible = true;
                    } else {
                        this.$message.warning("这堂课还没有录像");
                    }
                }, () => {
                    this.status.getVideoLoading = false;
                })
            },
            //分页
            testListhandlePageSize(limit) {
                this.homeworkAfterQuery.limit = limit;
                this.testLishandleSearch(1);
            },
            //上页  下页
            testLishandleSearch(page) {
                this.homeworkAfterQuery.page = page;
                this.homeworkAfterClassList()
            },
            homeworkAfterDialogVisibleClosed() {
                this.homeworkAfterQuery.page = 1
            },


            // 课后作业弹框
            homeworkAfterClass(row) {
                this.startanswerquertion.teacherId = row.lecturerId;
                this.startanswerquertion.teacherName = row.lecturerName;
                this.answerQuestionsSubmit.teacherId = row.lecturerId;
                this.answerQuestionsSubmit.teacherName = row.lecturerName;
                this.homeworkAfterQuery.courseId = row.courseId;
                this.homeworkAfterQuery.studentId = this.$util.getUser().studentId;
                this.homeworkAfterDialogVisible = true;
                this.homeworkAfterClassList();

            },
            //课后 作业 列表 请求
            homeworkAfterClassList() {
                let params = {...this.homeworkAfterQuery};
                this.$request(params, "/masters/mapper/select/student.queryStudentWorkByCourseIdAndStudentId", res => {
                    this.hoeworkAfterlist = res.list;
                    this.paginationtotal = res.total
                })
            },
            // 答题卡弹框
            answerMethod(row) {
                if (new Date(row.mustFinishTime).getTime() < new Date().getTime()) {
                    this.$message.warning("答题已终止");
                    return;
                }
                this.answerSheetQuest.testPaperId = row.testPaperId;
                this.answerQuestionsSubmit.courseHourId = row.courseHourId;
                this.answerQuestionsSubmit.homeworkId = row.homeworkId;
                let startparams = {...this.startanswerquertion};
                startparams.courseHourId = row.courseHourId;
                startparams.homeworkId = row.homeworkId;
                startparams.studentId = row.studentId;
                startparams.testPaperId = row.testPaperId;
                this.$request(startparams, "/masters/course/queryCourseAbiTestPaper", res => {
                    this.answerFileList = res.list[0].fileList;
                    this.answerTestPaperList = res.list[0].testPaper;
                    let answerRes = res.list[0].list;
                    this.status.answerSheetDialog = true;
                    answerRes.map(item => {
                        if (item.topic_type === 1) {
                            item.themeList.map(item => {
                                item.studentAnswer = [];
                                if (!this.$util.isEmpty(item.option)) {
                                    item.option = item.option.replace(/；/ig, ';');

                                    item.option = item.option.split(';');
                                    for (let i = 0; i < item.option.length; i++) {
                                        item.option[i] = item.option[i].split(':')[0]
                                    }
                                }
                            })
                        }

                    });
                    console.log("answerRes", answerRes);
                    this.answerRes = answerRes;
                    this.answerQuestionsSubmit.answerCardId = res.list[0].testPaper.answer_card_id;
                    this.answerQuestionsSubmit.testPaperId = res.list[0].testPaper.test_paper_id;
                    this.answerQuestionsSubmit.studentId = res.list[0].testPaper.student_id

                })
            },
            //
            look() {
                this.lookshow = false
            },
            //查看答题卡
            lookanswerMethod(row) {
                this.operationDetailsDialog = true;
                this.answerSheetQuest.studentId = row.studentId;
                this.answerSheetQuest.testPaperId = row.testPaperId;
                this.answerSheetQuest.homeworkId = row.homeworkId;
                let params = {...this.answerSheetQuest};
                //    查看  答题卡内容
                this.$request(params, "/student/queryStudentWorkInfo", res => {
                    this.HomeWorkDetailsAnswerSheetDialog = true;
                    let answerList = res.list[0].list;
                    for (let answer of answerList) {
                        let studentScore = 0;
                        let themeScore = 0;
                        answer.themeList.map(item => {
                            studentScore += item.student_score || 0;
                            themeScore += item.theme_score || 0;
                        });
                        answer.score = `${studentScore}/${themeScore}`
                    }
                    this.answerList = answerList;
                    this.testPaperAnswerList = res.list[0].testPaper;
                    this.fileList = res.list[0].fileList;
                    console.log(this.answerList)
                }, () => {
                })
            },
            //答题卡是否关闭  确认
            answerSheetDialoghandleClose(done) {
                this.$confirm('确认关闭？')
                    .then(() => {
                        done()
                    })
                    .catch(() => {
                    });
            },
            //答题卡关闭  之后执行的事件
            answerSheetDialogFormVisibleClosed() {
                this.$nextTick(() => {
                    // this.$refs["connectionForm"].resetFields();
                    // this.$refs.connectionForm.validates()
                })

            },
            //连线题  验证规则
            AnswerRules(itemAnswer) {
                if (!this.$util.isEmpty(itemAnswer)) {
                    itemAnswer = itemAnswer + ",";
                    let answerReg = /^(([1-9]?\d|100)[-]([1-9]?\d|100)+[,|\uff0c])+$/;
                    if (!answerReg.test(itemAnswer)) {
                        this.$message.warning('匹配之间以短横线分隔,每个答案以逗号分隔,例如:1-2,2-1');
                        this.status.stopSubmit = true;
                    } else {
                        this.status.stopSubmit = false;

                    }
                }

            },
            //提交 试卷答题卡 内容
            submitTestPaper() {
                this.homeworkAfterDialogVisible = false;
                this.answerQuestionsSubmit.list = [];
                let parmse = {...this.answerQuestionsSubmit};
                let answer = this.answerRes;
                // 选择题
                answer.map(item => {
                    if (item.topic_type === 1) {
                        item.themeList.map(item => {
                            if (item.studentAnswer.constructor === Array) {
                                if (item.studentAnswer.length > 1) {
                                    item.studentAnswer = item.studentAnswer.join(',')
                                } else if (item.studentAnswer.length === 1) {
                                    item.studentAnswer = item.studentAnswer.toString()
                                } else {
                                    item.studentAnswer = " ";
                                }
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                });
                answer.map(item => {
                    if (item.topic_type === 2) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                });
                answer.map(item => {
                    if (item.topic_type === 3) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                });
                answer.map(item => {
                    if (item.topic_type === 4) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                });
                answer.map(item => {
                    if (item.topic_type === 5) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer.replace(/，/ig, ',');
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                });
                this.$request(parmse, "/masters/course/automaticScoring", res => {
                    this.status.answerSheetDialog = false;
                    this.$message.success("提交成功" + "   " + res.message)
                }, (res) => {
                    this.$message.error(res.message);
                    this.status.answerSheetDialog = false
                })
            },
            // 展示课程资料弹窗
            showCourseware(courseId, courseName) {
                this.coursewareDialogTitle = courseName + " - 课程资料";
                this.status.coursewareDialogOpen = true;
                // 课时列表
                let params = {
                    courseId: courseId,
                    method: "POST"
                };
                this.$request(params, "/masters/mapper/select/courseHour.queryCourseHour", (res) => {
                    this.courseHourList = res.list;
                });
                // 课程资料
                this.coursewarePageInfo.courseId = courseId;
                this.handleCoursewarePage(1);
            },
            // 课时课件第几页
            handleCoursewarePage(page) {
                if (page) {
                    this.coursewarePageInfo.page = page;
                }
                this.getCoursewareData();
            },
            // 课时课件页数大小
            handleCoursewarePageSize(limit) {
                this.coursewarePageInfo.limit = limit;
                this.getCoursewareData();
            },
            // 获取课程课件
            getCoursewareData() {
                this.status.coursewareDataLoading = true;
                let params = {...this.coursewarePageInfo};
                params.method = 'POST';
                this.$request(params, "/masters/mapper/select/courseHour.queryCourseHourCourseware", (res) => {
                    this.coursewareData = res.list;
                    this.coursewareTotal = res.total;
                    this.status.coursewareDataLoading = false;
                }, () => {
                    this.$message.error("获取数据失败");
                    this.coursewareData = [];
                    this.coursewareTotal = 0;
                    this.status.coursewareDataLoading = false;
                });
            },
        }
    }
</script>

<style lang="less">
    .mycourse {
        background-color: #F6F2F7;
        /*解题思路的样式*/

        .el-form-item-image {
            height: 300px;

            .el-scrollbar__thumb {
                display: none;
            }

            .el-scrollbar__wrap {
                overflow-x: hidden;
                overflow-y: auto;
            }

            .el-dialog__body {
                padding: 0 20px 30px;
                color: #606266;
                font-size: 14px;
                word-break: break-all;
                margin-top: 15px;
            }

            .imga-update {
                width: 500px;
                text-align: center;
                line-height: 55px;
                margin: 10px;
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-start;

                .uid-type {
                    line-height: 130px;
                    font-size: 12px;
                    width: 80px;
                    margin: auto;
                    overflow: hidden; //超出的文本隐藏
                    text-overflow: ellipsis; //溢出用省略号显示
                    white-space: nowrap; //溢出不换行
                }

                .el-upload--picture-card {
                    display: none;
                }

            }
        }

        /*答题卡样式*/

        .conten {

            display: flex;
            justify-content: space-between;

            .el-dialog__body {
                padding: 0 20px 30px 20px;
            }

            .homeword-img {
                width: 778px;
                height: 606px;
                background-color: #ffffff;
                border-right: solid 1px #e4e7ed;
                box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
                overflow: hidden;
                cursor: pointer;

                .el-scrollbar__thumb {
                    display: none;
                }

                .el-scrollbar__wrap {
                    overflow-x: hidden;
                    overflow-y: auto;
                }

                .fileimg {
                    width: 658px;
                    height: 606px;
                    .cui-viewerchrome {
                        .cui-topBar2 {
                            display: none !important;
                        }
                    }
                    img {
                        max-width: 100%;
                        height: 100%;
                    }
                }
            }

            .homeword-conten {
                width: 384px;
                height: 606px;
                background-color: #ffffff;
                border-right: solid 1px #e4e7ed;
                box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
                padding: 0 0 0 30px;
                //答题卡样式 滚动
                .el-scrollbar__thumb {
                    display: none;
                }

                .el-scrollbar__wrap {
                    overflow-x: hidden;
                    overflow-y: auto;
                }

                .el-dialog__body {
                    padding: 0 20px 30px;
                    color: #606266;
                    font-size: 14px;
                    word-break: break-all;
                    margin-top: 15px;
                }

                .big-title {
                    padding: 10px 0;
                }

                .question-type {
                    width: 100%;
                    padding-bottom: 20px;

                    .title {
                        color: #333333;
                        font-size: 16px;

                        .titlepadding {
                            padding: 0 8px;
                        }
                    }

                    .ability-test-content {
                        padding-top: 15px;

                        .choice-ol {
                            list-style: none;

                            li {
                                padding: 0 0 15px 0;
                                display: flex;
                                justify-content: flex-start;
                                align-items: center;

                                .theme-class {
                                    display: block;
                                    width: 25px;
                                    padding-right: 2px;
                                }
                            }
                        }

                        ul {
                            width: 100%;
                            display: flex;
                            justify-content: flex-start;
                            flex-wrap: wrap;
                            align-items: center;

                            li {
                                width: 100%;
                                padding-right: 5px;
                                list-style-type: decimal;
                                list-style-position: inside;
                                padding-bottom: 10px;

                                .judge {
                                    padding: 0 90px 0 10px;
                                }

                                .el-checkbox-group {
                                    padding-left: 10px;
                                    width: 195px;
                                    display: inline-block;
                                }

                                .el-radio-group {
                                    padding-left: 10px;
                                    width: 195px;
                                    display: inline-block;
                                }

                                .el-input {
                                    padding-left: 5px;
                                }

                            }
                        }
                    }
                }
            }
        }

        .mycourse-head {
            width: 100%;
            height: 76px;
            background-color: #fff;
            border-top: 1px solid #F5F5F5;

            .breadcrumb {
                width: 1200px;
                margin: 0 auto;

                .el-breadcrumb__item {
                    font-size: 16px;
                    line-height: 76px;
                }
            }
        }

        .mycourse-main {
            width: 1200px;
            margin: 0 auto;
            padding-bottom: 20px;
            display: flex;
            justify-content: space-between;

            .calendar {
                width: 632px;
                height: 620px;

                .course-state {
                    width: 100%;
                    font-size: 12px;
                    position: relative;

                    .course-state-load {
                        p {
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }
                    }

                    .course-state-over {
                        position: absolute;
                        top: 50px;
                        left: 0;
                        background-color: #fff;
                        width: max-content; //兼容
                        padding: 6px 10px;
                        border-radius: 5px;
                        color: #000;
                        border: 1px solid #aaa;
                        line-height: 20px;
                        font-size: 8px;
                        z-index: 1;
                    }
                }

                .el-calendar__header {
                    background-color: #F6F2F7;
                    padding-left: 0;
                    padding-right: 0;
                }

                /*日历选中框*/

                .el-calendar-table {
                    td.is-selected, .el-calendar-day:hover {
                        color: #fff;
                        background-color: #5D2385;

                        .course-count {
                            color: #fff;
                        }
                    }

                    .el-calendar-day {
                        height: 80px;
                    }
                }
            }

            .course-list {
                width: 546px;

                .course-title {
                    padding-top: 15px;
                }

                .course-info {
                    width: 524px;
                    height: 175px;
                    margin-top: 17px;
                    padding: 10px;
                    background-color: #fff;
                    font-size: 14px;

                    .course-details {

                        .course-detail-title {

                        }

                        .course-detail {

                            .detail-one {
                                color: #808080;
                                padding-top: 7px;
                            }

                            .detail-two {
                                display: flex;
                                color: #8F8E94;
                                padding-top: 7px;

                                .course-difficult {
                                    .el-rate__icon {
                                        margin-right: 0;
                                    }
                                }
                            }

                            .detail-three {
                                display: flex;

                                .course-teachers {
                                    display: flex;
                                    padding: 10px 25px 10px 0;

                                    .course-teacher-image {
                                        width: 50px;
                                        height: 40px;
                                    }

                                    .course-teacher {
                                        line-height: 20px;

                                        .course-teacher-name {

                                        }

                                        .course-teacher-type {
                                            color: #A8A8A8;
                                        }
                                    }
                                }
                            }
                        }

                        .course-progress {
                            width: 180px;
                            height: 80px;
                            margin: 8px 20px 0 0;
                            display: flex;
                            justify-content: space-between;

                            .el-progress__text {
                                font-size: 18px !important;
                                color: #101010;
                            }
                        }
                    }

                    .course-button {
                        width: 100%;
                        display: flex;
                        justify-content: flex-end;
                        padding-top: 10px;
                        border-top: 1px solid #F5F5F5;
                    }
                }
            }

            .no-data {
                width: 100%;
                text-align: center;
                color: #555;
                margin-top: 150px;
            }
        }

        .dialog-class {
            border-radius: 10px;
            /* 课后作业*/

            .el-card__body {
                margin: 0 15px;
                padding: 0;
            }

            .el-card__header {
                padding: 10px 0;
                margin: 10px;
            }

            .box-card {
                border: none;

                .textitem {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    height: 25px;
                    line-height: 25px;
                    color: #333333;
                    font-size: 14px;
                    cursor: pointer;

                    .answerClass {
                        font-size: 14px;
                        color: #505BDA;

                        .point {
                            cursor: pointer;
                        }
                    }
                }
            }

            .pagination {
                padding-top: 20px;
                display: flex;
                justify-content: flex-end;
            }
        }

        /*    查看答题卡  试卷 答案 样式*/

        .look-homework-conten {
            display: flex;
            justify-content: space-between;

            .homeword-img {
                width: 578px;
                height: 706px;
                background-color: #ffffff;
                border-right: solid 1px #e4e7ed;
                box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
                border-radius: 4px;
                overflow: hidden;
                //答题卡样式 滚动
                .el-scrollbar__thumb {
                    display: none;
                }

                .el-scrollbar__wrap {
                    overflow-x: hidden;
                    overflow-y: auto;
                }

                .el-dialog__body {
                    padding: 0 20px 30px;
                    color: #606266;
                    font-size: 14px;
                    word-break: break-all;
                    margin-top: 15px;
                }

                .fileimg {
                    width: 578px;
                    height: 706px;
                    .cui-viewerchrome {
                        .cui-topBar2 {
                            display: none !important;
                        }
                    }

                    img {
                        max-width: 100%;
                        height: 100%;
                    }
                }

            }

            .homeword-conten {
                width: 384px;
                height: 706px;
                background-color: #ffffff;
                border-right: solid 1px #e4e7ed;
                box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
                border-radius: 4px;
                //答题卡样式 滚动
                .el-scrollbar__thumb {
                    display: none;
                }

                .el-scrollbar__wrap {
                    overflow-x: hidden;
                    overflow-y: auto;
                }

                .el-dialog__body {
                    padding: 0 20px 30px;
                    color: #606266;
                    font-size: 14px;
                    word-break: break-all;
                    margin-top: 15px;
                }

                .title {
                    margin: 15px auto 10px;
                    text-align: center;
                }

                .achievement {
                    width: 30%;
                    margin-left: 230px;

                    .achievementscore {
                        font-family: SourceHanSansSC;
                        font-weight: 400;
                        font-size: 28px;
                        color: rgb(16, 16, 16);
                        font-style: normal;
                        letter-spacing: 0;
                        line-height: 41px;
                        text-decoration: none;
                    }
                }

                .question-type {
                    width: cale(100%-30px);
                    margin: auto;
                    padding: 0 30px;

                    .question {
                        .answer-question {
                            width: 100%;
                            height: 200px;
                            padding-top: 5px;

                            .comment {
                                padding: 10px 0;
                                width: 100%;
                            }

                            .scoring {
                                display: flex;
                                justify-content: space-between;
                                align-items: center;

                                .ideastext {
                                    padding: 0 10px;
                                }
                            }

                            .answer {
                                width: 100%;
                                margin-top: 10px;
                                display: flex;
                                justify-content: space-between;

                                .reple {
                                    width: 45%;
                                    border: solid 1px #CCCCCC;
                                    text-align: center;
                                    line-height: 100px;
                                }

                                .correction {
                                    width: 45%;
                                }
                            }
                        }
                    }

                    .types-of {
                        font-size: 16px;
                        padding-bottom: 10px;
                    }

                    .question-conten {
                        width: 100%;
                        padding-bottom: 10px;
                        font-size: 16px;

                        .question-conten-list {
                            width: 100%;
                            height: 30px;
                            display: flex;
                            justify-content: space-between;
                            align-items: center;

                            .write {
                                width: 120px;
                                display: flex;
                                justify-content: flex-start;
                                align-items: center;

                                .chose-button {
                                    height: 25px;
                                    border: solid #ccc 1px;
                                    text-align: center;
                                    line-height: 25px;
                                    margin-left: 20px;
                                }
                            }

                            .list-img {
                                font-size: 30px;

                                .hook {
                                    color: green;
                                }

                                .fork {
                                    color: red;
                                }
                            }

                            .ider {
                                width: 100px;
                                background: red;

                                .ideastext {
                                    background: tomato;
                                    padding: 0 10px;
                                }
                            }
                        }
                    }
                }
            }

            .text-underline {
                font-family: SourceHanSansSC;
                font-weight: 400;
                font-size: 28px;
                /* color: rgb(16, 16, 16); */
                font-style: normal;
                letter-spacing: 0;
                line-height: 41px;
                text-decoration: underline;
            }
        }

    }

    /* ==========答题卡样式==========*/
    /*.dialog-class {*/
    /*    border-radius: 10px;*/
    /*}*/

    /*.el-scrollbar__thumb {*/
    /*    display: none;*/
    /*}*/

    /*.el-scrollbar__wrap {*/
    /*    overflow-x: hidden;*/
    /*    overflow-y: auto;*/
    /*}*/

    /*.el-dialog__body {*/
    /*    padding: 0px 20px 30px;*/
    /*    color: #606266;*/
    /*    font-size: 14px;*/
    /*    word-break: break-all;*/
    /*}*/

    //答题卡样式

    .look-answer-conten {
        display: flex;
        justify-content: space-between;

        .homeword-img {
            width: 578px;
            height: 606px;
            background-color: #ffffff;
            border-right: solid 1px #e4e7ed;
            box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
            border-radius: 4px;
            overflow: hidden;
            cursor: pointer;
            //答题卡样式 滚动
            .el-scrollbar__thumb {
                display: none;
            }

            .el-scrollbar__wrap {
                overflow-x: hidden;
                overflow-y: auto;
            }

            .el-dialog__body {
                padding: 0 20px 30px;
                color: #606266;
                font-size: 14px;
                word-break: break-all;
                margin-top: 15px;
            }

            .fileimg {
                width: 578px;
                height: 606px;

                img {
                    max-width: 100%;
                    height: 100%;
                }
            }

        }

        .homeword-conten {
            width: 384px;
            height: 606px;
            background-color: #ffffff;
            border-right: solid 1px #e4e7ed;
            box-shadow: rgba(0, 0, 0, 0.06) 0 2px 12px 0;
            border-radius: 4px;
            //答题卡样式 滚动
            .el-scrollbar__thumb {
                display: none;
            }

            .el-scrollbar__wrap {
                overflow-x: hidden;
                overflow-y: auto;
            }

            .el-dialog__body {
                padding: 0 20px 30px;
                color: #606266;
                font-size: 14px;
                word-break: break-all;
                margin-top: 15px;
            }

            .title {
                margin: 15px auto 10px;
                text-align: center;
            }

            .achievement {
                margin-left: 200px;

                .achievementscore {
                    font-family: SourceHanSansSC;
                    font-weight: 400;
                    font-size: 28px;
                    color: rgb(16, 16, 16);
                    font-style: normal;
                    letter-spacing: 0;
                    line-height: 41px;
                    text-decoration: none;
                }
            }

            .question-type {
                width: cale(100%-30px);
                margin: auto;
                padding: 0 30px;

                .question {
                    .answer-question {
                        width: 100%;
                        height: 200px;
                        padding-top: 5px;

                        .comment {
                            padding: 10px 0;
                            width: 100%;
                        }

                        .scoring {
                            display: flex;
                            justify-content: space-between;
                            align-items: center;

                            .ideastext {
                                padding: 0 10px;
                            }
                        }

                        .answer {
                            width: 100%;
                            margin-top: 10px;
                            display: flex;
                            justify-content: space-between;

                            .reple {
                                width: 45%;
                                border: solid 1px #CCCCCC;
                                text-align: center;
                                line-height: 100px;
                            }

                            .correction {
                                width: 45%;
                            }
                        }
                    }
                }

                .types-of {
                    font-size: 16px;
                    padding-bottom: 10px;
                }

                .question-conten {
                    width: 100%;
                    padding-bottom: 10px;
                    font-size: 16px;

                    .question-conten-list {
                        width: 100%;
                        height: 30px;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;

                        .write {
                            display: flex;
                            justify-content: flex-start;
                            align-items: center;
                            font-size: 12px;

                            .themenumber {
                                width: 35px;
                            }

                            .chose-button {
                            }
                        }

                        .list-img {
                            font-size: 30px;

                            .hook {
                                color: green;
                            }

                            .fork {
                                color: red;
                            }
                        }

                        .ider-none {
                            width: 90px;
                            height: 30px;
                            border: none;
                        }

                        .ider {
                            width: 70px;
                            height: 30px;
                            line-height: 30px;
                            font-size: 10px;
                            text-align: center;
                            border: solid 1px #CCCCCC;
                            cursor: pointer;
                            .ideastext {
                                padding: 0 10px;
                            }
                        }
                    }
                }
            }
        }

        .text-underline {
            font-family: SourceHanSansSC;
            font-weight: 400;
            font-size: 28px;
            /* color: rgb(16, 16, 16); */
            font-style: normal;
            letter-spacing: 0;
            line-height: 41px;
            text-decoration: underline;
        }
    }


</style>