<template>
    <div class="classroom">
        <div class="class-title-box">
            <div class="title">名师荟教育：{{courseName}}</div>
            <div class="button-box">
                <i class="el-icon-switch-button" @click="outRoom"></i>
                <i v-if="!isPushing" class="el-icon-video-camera" @click="startRTC"></i>
                <i v-else class="el-icon-video-pause" @click="stopPush"></i>
                <el-button type="success" size="mini" @click="hands">举手</el-button>
            </div>
        </div>
        <div class="video-box" id="video-box"></div>
        <div class="watch-box">
            <div class="whiteboard">
                <div id="whiteboard"></div>
            </div>
            <div class="msg-box">
                <div class="msgs">
                    <div class="msgs-title">
                        讨论区
                    </div>
                    <div class="msgs-content">
                        <div v-for="(msg,index) in groupMsg" :key="index">
                            <span class="msg-tim">{{msg.time}}</span>
                            <span class="msg-source">{{msg.send}}</span>
                            <span class="msg-content">{{msg.content}}</span>
                        </div>
                    </div>
                </div>
                <div class="send-msg">
                    <el-input placeholder="发送群消息..." v-model="imMsg.common.data" maxlength="30"></el-input>
                    <el-button :disabled="ticUserStatus < constData.USER_STATUS_INCLASS" type="success" style="margin-left: 10px"
                               @click="sendMsg(constData.MESSAGE_TYPE_GROUP)">发送
                    </el-button>
                </div>
            </div>
        </div>
        <el-dialog title="提示" :visible.sync="status.joinClassDialog" width="30%" :show-close="false" :close-on-click-modal="false"
                   :close-on-press-escape="false">
            <span>加入课堂失败!请尝试重新加入房间</span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="quitClassroom">退出房间</el-button>
                <el-button type="primary" @click="joinClassroom">再次尝试</el-button>
            </span>
        </el-dialog>
        <classroomAnswer v-if="answering" :course-hour-id="courseHourId" :course-id="courseId"/>
    </div>
</template>

<script>
    import {mapState} from 'vuex'
    import constData from './../assets/javascript/const-data'
    import classroomAnswer from "./classroom-answer"

    export default {
        name: 'classroom',
        components: {
            classroomAnswer
        },
        data() {
            return {
                handTime: 0,
                handSetInterval: null,
                teduBoard: null,
                //当前房间号
                roomID: null,
                courseHourId: "",
                courseName: "",
                courseId: "",
                teacherId: "",
                //状态
                status: {
                    //加入课堂弹窗
                    joinClassDialog: false
                },
                //常量
                constData: constData,
                //board(涂鸦)
                drawEnable: false, //是否可以涂鸦
                synDrawEnable: true, //是否将你画的涂鸦同步给其他人
                toolType: 1,
                brushThin: 100,
                backgroundImage: "背景图",
                backgroundImageH5: "背景图H5",
                backgroundColor: "#ff0000",
                globalBackgroundColor: "#ff0000",
                brushColor: "#ff0000",
                textColor: "#ff0000",
                textStyle: "#ff0000",
                textFamily: "sans-serif,serif,monospace",
                textSize: 320,
                scaleSize: 100,
                fitMode: 1,
                ration: "16:9",
                canRedo: 0,
                canUndo: 0,
                //board(白板操作)
                boardData: {
                    currentBoardId: null, //当前白板ID
                    boardIdlist: [], //白板ID列表
                    current: 0, //当前白板index
                    total: 0 //总页数
                },
                //board(文件操作)
                currentFileId: null, // 当前文件Id
                fileInfoList: [], // 所有文件信息
                thumbUrls: [], // 缩略图

                //音视频及设备
                enableCamera: true,
                enableMic: true,
                cameraIndex: 0,
                micIndex: 0,
                devices: {
                    camera: [],
                    mic: []
                },
                imMsg: {
                    common: {
                        data: "",
                        toUser: ""
                    },
                    custom: {}
                },
                //
                isShow: false,
                // 是否正在推流
                isPushing: false,
                // 是否推摄像头流
                isPushCamera: false,
                localStream: null,
                remoteVideos: {},
                willDeleteFile: null,
                willSwitchFile: null,
                willAddVideoFile: null,
                willDeleteBoard: null,
                willAddH5File: null
            }
        },
        computed: {
            ...mapState({
                ticUserStatus: state => state.ticUserStatus,
                tic: state => state.tic,
                groupMsg: state => state.groupMsg,
                ticUserInfo: state => state.ticUserInfo,
                answering: state => state.classroomAnswer.answering,
                studentList: state => state.classroomStudentModules.studentList,
                onStageState: state => state.classroomStudentModules.operateStatus.onStageState,
                prosodyState: state => state.classroomStudentModules.operateStatus.prosodyState,
                estoppelState: state => state.classroomStudentModules.operateStatus.estoppelState,
            })
        },
        watch: {
            onStageState(change) {
                if (change === 2) {
                    this.stopPush();
                } else {
                    this.startRTC();
                }
            },
            prosodyState(change) {
                console.log("音频操作",change);
                if (change === 2) {
                    this.audioOn();
                } else {
                    this.audioOff();
                }
            }
        },
        created() {

        },
        mounted() {
            let roomID = this.$route.query.roomID;
            let courseHourId = this.$route.query.courseHourId;
            let courseName = this.$route.query.courseName;
            let courseId = this.$route.query.courseId;
            let lecturerId = this.$route.query.lecturerId;
            if (this.$util.isEmpty(roomID)) {
                this.$router.push("/mycourse");
                return;
            }
            if (this.$util.isEmpty(this.tic)) {
                this.$router.push("/mycourse");
                return;
            }
            this.roomID = roomID;
            this.courseHourId = courseHourId;
            this.courseName = courseName || "暂无课程名称";
            this.courseId = courseId;
            this.teacherId = lecturerId;

            if (this.$util.isEmpty(this.tic)) {
                this.$router.push("/mycourse");
                return;
            }
            this.joinClassroom()
        },
        methods: {
            showMessageInBox(messageType, text) {
                let d = new Date();
                let time = `${('0' + d.getHours()).substr(-2)}:${('0' + d.getMinutes()).substr(-2)}:${('0' + d.getSeconds()).substr(-2)}`;
                let msg = {
                    time: time + ' ',
                    send: messageType + ' ',
                    content: text
                };
                this.$store.commit("insertGroupMsg", msg)
            },
            initData() {
                this.$store.commit("clearGroupMsg");
                this.devices = {
                    camera: [],
                    mic: []
                };
                this.cameraIndex = 0;
                this.micIndex = 0;
                this.imMsg = {
                    common: {
                        data: '',
                        toUser: ''
                    },
                    custom: {
                        data: '',
                        toUser: ''
                    }
                };
                this.drawEnable = false; //是否可以涂鸦
                this.synDrawEnable = true; //是否将你画的涂鸦同步给其他人
                this.toolType = 1;
                this.brushThin = 100;
                this.backgroundImage = "背景图";
                this.backgroundImageH5 = "背景图H5";
                this.backgroundColor = "#ff0000";
                this.globalBackgroundColor = "#ff0000";
                this.brushColor = "#ff0000";
                this.textColor = "#ff0000";
                this.textStyle = "#ff0000";
                this.textFamily = "sans-serif,serif,monospace";
                this.textSize = 320;
                this.scaleSize = 100;
                this.fitMode = 1;
                this.ration = "16:9";
                this.canRedo = 0;
                this.canUndo = 0;
            },
            clearClassInfo() {
                //设备信息
                this.remoteVideos = {};
                this.enableCamera = true;
                this.enableMic = true;
                this.isPushing = false;
                this.isPushCamera = false;

                //白板信息
                this.boardData.currentBoardId = null;
                this.boardData.boardIdlist = [];
                this.boardData.current = 0;
                this.boardData.total = 0;

                this.fileInfoList = [];
                this.currentFileId = null;
            },
            joinClassroom() {
                if (!this.roomID) {
                    this.$message.warning('房间号不能为空');
                    return;
                }
                if (this.ticUserStatus === this.constData.USER_STATUS_INCLASS) {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "已经在课堂中");
                    return;
                }
                this.tic.joinClassroom({
                    // compatSaas: true,
                    classId: this.roomID
                }, {
                    // mode: 1 //直播模式，支持1000人以上场景
                    mode: 0, // //实时通话模式，支持1000人以下场景，低延时
                    // role: 20 // 主播，只在直播模式模式下有效
                    // role: 21 // 观众（观众角色没有发布本地流的权限，只有收看远端流的权限。如果观众想要连麦跟主播互动， 请先通过 switchRole() 切换角色到主播 anchor 后再发布本地流），只在TIC.CONSTANT.TICClassScene.TIC_CLASS_SCENE_LIVE模式下有效
                }, {
                    id: 'whiteboard',
                    ratio: '16:9',
                    smoothLevel: 0,
                    boardContentFitMode: 1,
                    toolType: 0,
                    drawEnable:false
                }, res => {
                    if (res.code) {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "加入房间失败,错误码" + res.code + ",原因:" + res.desc);
                        this.status.joinClassDialog = true;
                    } else {
                        this.status.joinClassDialog = false;
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "加入课堂成功");
                        window.teduBoard = this.teduBoard = this.tic.getBoardInstance();
                        this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_INCLASS);
                        this.insertSchedule();
                        this.loadStudentList();
                        this.initBoardEvent();
                    }
                });
            },
            /**
             * 退出课堂
             */
            quitClassroom(callback) {
                if (this.ticUserStatus >= this.constData.USER_STATUS_INCLASS) {
                    if (!this.roomID) {
                        this.$message.warning('房间号不能为空');
                        return;
                    }
                    this.tic.quitClassroom(res => {
                        if (res.code) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "退出课堂失败, 错误码" + res.code);
                            console.log('quitClassroom error' + res);
                            this.clearClassInfo();
                            this.$router.push("/mycourse").catch(() => {
                            });
                        } else {
                            this.initData();
                            this.$store.commit("toggleTicUserStatus", this.constData.USER_STATUS_LOGINED);
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "退出课堂成功");
                            this.clearClassInfo();
                            this.$router.push("/mycourse").catch(() => {
                            });
                        }
                        callback && callback({
                            code: 0
                        });
                    });
                } else {
                    this.$router.push("/mycourse").catch(() => {
                    });
                }
            },
            // 监听白板事件（按需监听）
            initBoardEvent() {
                var teduBoard = this.teduBoard;
                // 撤销状态改变
                teduBoard.on("TEB_OPERATE_CANUNDO_STATUS_CHANGED", (enable) => {
                    this.canUndo = enable ? 1 : 0;
                    console.log('======================:  ', 'TEB_OPERATE_CANUNDO_STATUS_CHANGED', enable ? '可撤销' : '不可撤销');
                });
                // 重做状态改变
                teduBoard.on("TEB_OPERATE_CANREDO_STATUS_CHANGED", (enable) => {
                    this.canRedo = enable ? 1 : 0;
                    console.log('======================:  ', 'TEB_OPERATE_CANREDO_STATUS_CHANGED', enable ? '可恢复' : '不可恢复');
                });
                // 新增白板
                teduBoard.on("TEB_ADDBOARD", (boardIds, fid) => {
                    console.log('======================:  ', 'TEB_ADDBOARD', ' boardIds:', boardIds, ' fid:', fid);
                    this.proBoardData();
                });
                // 收到白板初始化完成事件后，表示白板已处于正常工作状态（此时白板为空白白板，历史数据尚未拉取完成）
                teduBoard.on("TEB_INIT", () => {
                    console.log('======================:  ', 'TEB_INIT');
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "互动白板已启动");
                });
                teduBoard.on("TEB_HISTROYDATA_SYNCCOMPLETED", () => {
                    console.log('======================:  ', 'TEB_HISTROYDATA_SYNCCOMPLETED');
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "互动白板同步完成");
                });
                // 白板错误回调
                teduBoard.on("TEB_ERROR", (code, msg) => {
                    console.error('======================:  ', 'TEB_ERROR', ' code:', code, ' msg:', msg);
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "onTEBError code=" + code + " msg:" + msg);
                });
                // 白板警告回调
                teduBoard.on("TEB_WARNING", (code, msg) => {
                    console.error('======================:  ', 'TEB_WARNING', ' code:', code, ' msg:', msg);
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, "onTEBWarning code=" + code + " msg:" + msg);
                });
                // 图片状态加载回调
                teduBoard.on("TEB_IMAGE_STATUS_CHANGED", (status, data) => {
                    console.log('======================:  ', 'TEB_IMAGE_STATUS_CHANGED', ' status:', status, ' data:', data);
                });
                // 删除白板页回调
                teduBoard.on("TEB_DELETEBOARD", (boardIds, fid) => {
                    console.log('======================:  ', 'TEB_DELETEBOARD', ' boardIds:', boardIds, ' fid:', fid);
                    this.proBoardData();
                });
                // 跳转白板页回调
                teduBoard.on("TEB_GOTOBOARD", (boardId, fid) => {
                    console.log('======================:  ', 'TEB_GOTOBOARD', ' boardId:', boardId, ' fid:', fid);
                    this.proBoardData();
                });
                // ppt动画步数改变回调
                teduBoard.on("TEB_GOTOSTEP", (step, count) => {
                    console.log('======================:  ', 'TEB_GOTOSTEP', ' step:', step, ' count:', count);
                });
                // 增加H5动画PPT文件回调
                teduBoard.on("TEB_ADDH5PPTFILE", (fid) => {
                    console.log('======================:  ', 'TEB_ADDH5PPTFILE', ' fid:', fid);
                    this.proBoardData();
                });
                // 增加文件回调
                teduBoard.on("TEB_ADDFILE", (fid) => {
                    console.log('======================:  ', 'TEB_ADDFILE', ' fid:', fid);
                    this.proBoardData();
                });
                // 增加转码文件回调
                teduBoard.on("TEB_ADDTRANSCODEFILE", (fid) => {
                    console.log('======================:  ', 'TEB_ADDTRANSCODEFILE', ' fid:', fid);
                    this.proBoardData();
                });
                // 增加Images文件回调
                teduBoard.on("TEB_ADDIMAGESFILE", (fid) => {
                    console.log('======================:  ', 'TEB_ADDIMAGESFILE', ' fid:', fid);
                    this.proBoardData();
                });
                // 删除文件回调
                teduBoard.on("TEB_DELETEFILE", (fid) => {
                    console.log('======================:  ', 'TEB_DELETEFILE', ' fid:', fid);
                    this.proBoardData();
                });
                // 文件上传状态
                teduBoard.on("TEB_FILEUPLOADSTATUS", (status, data) => {
                    console.log('======================:  ', 'TEB_FILEUPLOADSTATUS', status, data);
                    if (status === 1) {
                        this.$message.success('上传成功');
                    } else {
                        this.$message.error('上传失败');
                    }
                    document.getElementById('file_input').value = '';
                });
                // 切换文件回调
                teduBoard.on("TEB_SWITCHFILE", (fid) => {
                    console.log('======================:  ', 'TEB_SWITCHFILE', ' fid:', fid);
                    this.proBoardData();
                });
                // 上传背景图片的回调
                teduBoard.on("TEB_SETBACKGROUNDIMAGE", (fileName, fileUrl, userData) => {
                    console.log('======================:  ', 'TEB_SETBACKGROUNDIMAGE', '  fileName:', fileName, '  fileUrl:', fileUrl, ' userData:', userData);
                });
                // 增加图片元素
                teduBoard.on("TEB_ADDIMAGEELEMENT", (fileName, fileUrl, userData) => {
                    console.log('======================:  ', 'TEB_ADDIMAGEELEMENT', '  fileName:', fileName, '  fileUrl:', fileUrl, ' userData:', userData);
                });
                // 文件上传进度
                teduBoard.on("TEB_FILEUPLOADPROGRESS", (data) => {
                    console.log('======================:  ', 'TEB_FILEUPLOADPROGRESS:: ', data);
                });
                // H5背景加载状态
                teduBoard.on("TEB_H5BACKGROUND_STATUS_CHANGED", (status, data) => {
                    console.log('======================:  ', 'TEB_H5BACKGROUND_STATUS_CHANGED:: status:', status, '  data:', data);
                });
                // 转码进度
                teduBoard.on("TEB_TRANSCODEPROGRESS", res => {
                    console.log('=======  TEB_TRANSCODEPROGRESS 转码进度：', JSON.stringify(res));
                    if (res.code) {
                        this.$message.error('转码失败code:' + res.code + ' message:' + res.message);
                    } else {
                        let status = res.status;
                        if (status === 'FINISHED') {
                            this.$message.success('转码完成');
                            this.teduBoard.addTranscodeFile({
                                url: res.resultUrl,
                                title: res.title,
                                pages: res.pages,
                                resolution: res.resolution
                            });
                        }
                    }
                });
            },
            /**
             * 白板事件回调处理
             * @param {*}
             */
            proBoardData() {
                this.fileInfoList = this.teduBoard.getFileInfoList();
                this.currentFileId = this.teduBoard.getCurrentFile();
                this.thumbUrls = this.teduBoard.getThumbnailImages(this.currentFileId);
                var fileInfo = this.teduBoard.getFileInfo(this.currentFileId);
                if (fileInfo) {
                    this.boardData = {
                        currentBoardId: this.currentFileId,
                        boardIdlist: this.teduBoard.getFileBoardList(this.currentFileId),
                        current: fileInfo.currentPageIndex + 1,
                        total: fileInfo.pageCount
                    }
                }
            },
            sendMsg(messageType, data) {
                if (this.estoppelState === 1) {
                    this.$message.warning(`您已经被禁言`);
                    return;
                }
                if (!this.imMsg.common.data || this.imMsg.common.data.length < 1) {
                    this.$message.warning(`不能发送空消息`);
                    return;
                }
                let message = {};
                message.type = messageType;
                message.text = this.imMsg.common.data;
                message.user = this.ticUserInfo.userId;
                message.fromUserName = this.$util.getUser().nickName;
                message.data = data;
                // C2C 文本
                if (this.imMsg.common.toUser && this.imMsg.common.data.length > 1) {
                    this.tic.sendTextMessage(this.imMsg.common.toUser, JSON.stringify(message), res => {
                        if (res.code !== 0) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '发送消息失败,错误码' + res.code);
                        } else {
                            this.showMessageInBox(messageType, message.fromUserName + ":" + message.text);
                        }
                    });
                    // 群组 文本
                } else {
                    if (!this.roomID) {
                        this.$message.error('发送群消息时，房间号为空');
                        return;
                    }
                    this.tic.sendGroupTextMessage(JSON.stringify(message), res => {
                        if (res.code !== 0) {
                            this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '发送消息失败,错误码' + res.code);
                        } else {
                            this.showMessageInBox(messageType, message.fromUserName + ":" + message.text);
                        }
                    });
                }
                this.imMsg.common.data = "";
                this.imMsg.common.toUser = "";
            },
            // 启动推流(推摄像头)
            startRTC() {
                if (this.onStageState === 2) {
                    this.$message.warning("未上台不能开启摄像头");
                    return;
                }
                // 从麦克风和摄像头采集本地音视频流
                let audio = this.prosodyState === 2;
                let cameraStream = window.TRTC.createStream({
                    audio: audio,
                    video: true
                });
                // 设置视频分辨率等参数
                cameraStream.setVideoProfile('720p');
                if (this.localStream && this.isPushing) { // 如果正在推流, 先停止发布流
                    this.stopPush(() => {
                        this.publishLocalStream(cameraStream);
                    });
                } else {
                    this.publishLocalStream(cameraStream);
                }
            },
            outRoom() {
                this.quitClassroom();
            },
            //启用音频
            audioOn() {
                if (this.localStream && this.isPushing && this.prosodyState === 2) {
                    console.log("启用音频");
                    this.localStream.unmuteAudio();
                }
            },
            //禁用音频
            audioOff() {
                if (this.localStream && this.isPushing) {
                    console.log("禁用音频");
                    this.localStream.muteAudio();
                }
            },
            /**
             * 结束推流
             */
            stopPush(callback) {
                if (this.localStream && this.isPushing) {
                    window.trtcClient.unpublish(this.localStream).then(() => {
                        this.isPushing = false;
                        document.getElementById('local_video').remove();
                        this.localStream.stop();
                        this.localStream = null;
                        if (Object.prototype.toString.call(callback) === '[object Function]') {
                            callback();
                        }
                    }).catch((err) => {
                        console.error("结束推流失败", err)
                    });
                }
            },
            hands() {
                if (this.handTime > 0) {
                    this.$message.warning(`${this.handTime}秒后可再次举手`);
                    return;
                }
                let params = {};
                let user = this.$util.getUser();
                params.studentName = user.nickName;
                params.studentId = user.studentId;
                params.roomId = this.roomID;
                let message = {};
                message.type = constData.MESSAGE_TYPE_HAND;
                message.data = params;
                this.handTime = 10;
                this.tic.sendGroupTextMessage(JSON.stringify(message), res => {
                    if (res.code !== 0) {
                        this.handTime = 0;
                        this.$message.warning("举手失败");
                    } else {
                        this.$message.success("举手成功");
                        this.handSetInterval = setInterval(() => {
                            if (this.handTime > 0) {
                                this.handTime--;
                            } else {
                                if (this.handSetInterval) {
                                    clearInterval(this.handSetInterval);
                                    this.handSetInterval = null;
                                }
                            }
                        }, 1000);
                    }
                });
            },
            //添加学生上课记录
            insertSchedule() {
                let params = {
                    studentId: this.ticUserInfo.userId,
                    roomId: this.roomID,
                    courseId: this.courseId
                };
                this.$request(params, "/masters/insertSchedule");
            },
            loadStudentList() {
                //查询该房间里的所有学生
                this.$request({roomId: this.roomID}, '/masters/mapper/select/studentStatus.selectStudentStatus', data => {
                    let studentList = data.list;
                    console.log("学生列表", studentList);
                    //从所有学生中找出自己
                    let student = studentList.find(item => {
                        return this.ticUserInfo.userId === item.studentId;
                    });
                    console.log("自己", student);
                    //如果自己不存在,则表示自己第一次进入房间,执行数据库插入操作
                    if (this.$util.isEmpty(student)) {
                        let params = {};
                        params.studentId = this.ticUserInfo.userId;
                        params.roomId = this.roomID;
                        params.nickName = this.$util.getUser().nickName;
                        params.avatar = this.$util.getUser().avatar;
                        this.$request(params, "/courseHour/insertStudentStatus", () => {
                            params.onStageState = 2;
                            params.prosodyState = 1;
                            params.estoppelState = 2;
                            params.blacklistState = 2;
                            studentList.push(params);
                            this.$store.commit("setStudentList", studentList);
                        }, () => {
                            this.$store.commit("setStudentList", studentList);
                        });
                    } else {
                        this.$store.commit("setStudentList", studentList);
                    }
                });
            },
            // 发布本地流
            publishLocalStream(localStream) {
                localStream.initialize().catch(error => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '视频推流失败');
                    console.error('failed initialize localStream ' + error);
                }).then(() => {
                    let localVideoWrapEl = document.getElementById('local_video');
                    if (!localVideoWrapEl) {
                        localVideoWrapEl = document.createElement('div');
                        localVideoWrapEl.id = 'local_video';
                        document.querySelector("#video-box").insertBefore(localVideoWrapEl, null);
                    }
                    // 本地流播放
                    localStream.play(localVideoWrapEl, {
                        muted: true
                    });
                    // 发布本地流（远端可收到）
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '开始发布本地流');
                    window.trtcClient && window.trtcClient.publish(localStream).then(() => {
                        // 本地流发布成功
                        this.isPushing = true; // 正在推流
                        this.isPushCamera = true; // 正在推摄像头
                        this.localStream = localStream;
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '视频推流成功');
                    }).catch(error => {
                        this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, '视频推流失败');
                        console.log(error);
                    });
                }).catch(error => {
                    this.showMessageInBox(this.constData.MESSAGE_TYPE_SYSTEM, `获取本地流失败, ${JSON.stringify(error)}`);
                });
            }
        },
        beforeDestroy() {
            this.quitClassroom();
        }
    }
</script>

<style lang="less">
    .classroom {
        height: 100%;
        .class-title-box {
            height: 60px;
            width: calc(100% - 60px);
            padding: 0 30px;
            background-color: #34363B;
            display: flex;
            .title, .button-box {
                display: flex;
                align-items: center;
                height: 100%;
            }
            .title {
                width: calc(100% - 300px);
                color: #EDF1F2;
                font-size: 24px;
            }
            .button-box {
                width: 300px;
                flex-direction: row-reverse;
                font-size: 24px;
                color: #737882;
                i {
                    cursor: pointer;
                    margin-left: 15px;
                    &:hover {
                        color: #409EFF;
                    }
                }
            }
        }
        .video-box {
            padding: 0 30px;
            width: calc(100% - 60px);
            height: 160px;
            background-color: #212224;
            display: flex;
            align-items: center;
            & > div {
                width: 120px;
                height: 120px;
                margin-right: 10px;
            }
        }
        .watch-box {
            height: calc(100% - 60px - 160px);
            display: flex;
            .whiteboard {
                height: 100%;
                width: calc(100% - 420px);
                background-color: black;
                #whiteboard {
                    position: relative;
                    width: 100%;
                    height: 100%;
                    overflow: hidden;
                    box-sizing: content-box;
                }
            }
            .msg-box {
                height: 100%;
                width: 420px;
                background-color: #34363B;
                .msgs {
                    padding: 0 15px;
                    width: calc(100% - 30px);
                    height: calc(100% - 60px);
                    .msgs-title {
                        height: 48px;
                        line-height: 48px;
                        color: #EDF1F2;
                        font-size: 16px;
                    }
                    .msgs-content {
                        overflow: auto;
                        height: calc(100% - 48px);
                        .msg-tim, .msg-source, .msg-content {
                            font-size: 14px;
                            color: #C2C7CC;
                        }
                        .msg-tim {

                        }
                        .msg-source {

                        }
                        .msg-content {

                        }
                    }
                }
                .send-msg {
                    padding: 0 15px;
                    height: 60px;
                    width: calc(100% - 30px);
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                }
            }
        }
    }
</style>
