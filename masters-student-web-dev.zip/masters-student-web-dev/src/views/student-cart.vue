<template>
  <div class="student-cart">
    <div class="title">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '' }">购物车</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div style="background-color: #ffffff;">
      <div style="padding: 20px;font-size: 16px">我的选课单</div>
      <div class="cart-table">
        <el-table
                ref="multipleTable"
                :data="tableData"
                tooltip-effect="dark"
                @selection-change="handleSelectionChange">
          <el-table-column
                  type="selection"
                  width="55">
          </el-table-column>
          <el-table-column
                  label="课程名称"
                  width="600">
            <template slot-scope="scope">
              <div class="course-name">
                <img :src="$getFileUrl+scope.row.courseCover" style="width: 150px;height: 85px">
                <div style="margin-left: 10px;display: flex;align-items: center;">
                  <div>
                    <p>{{scope.row.courseName}}</p>
                    <p class="course-info">
                      {{$util.formatDate(scope.row.courseStart,'yyyy年MM月dd日')}}-{{$util.formatDate(scope.row.courseEnd,'yyyy年MM月dd日')}}·{{scope.row.allCourseHour}}课时</p>
                  </div>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column
                  label="授课老师"
                  width="250">
            <template slot-scope="scope">
              <span style="font-size: 16px;font-weight:400;">{{scope.row.lecturerName}}</span>
            </template>
          </el-table-column>
          <el-table-column
                  label="单价（元）"
                  width="200">
            <template slot-scope="scope">
              <span style="font-size: 16px;font-weight:400;">￥{{$util.pennyToYuan(scope.row.coursePrice)}}</span>
            </template>
          </el-table-column>
          <el-table-column
                  width="50">
            <template slot-scope="scope">
              <span @click="deleteCart(scope, tableData)"><i class="el-icon-delete" style="font-size: 20px;cursor:pointer;"></i></span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="choose-course">
        <div class="course-num">
          <div style="font-size:16px;margin-left: 60px">共{{multipleSelection.length}}项</div>
          <div>
            <p style="display: flex;justify-content:flex-end;align-items: center;">
              <span style="font-size: 14px">合计：</span>
              <span style="font-size:24px;font-weight:bold;color:rgba(253,77,77,1);">￥{{$util.pennyToYuan(sumCoursePrice)}}</span>
            </p>
            <p style="color: #808080;font-size: 14px;">
              (购买后不支持退款、转让，请确认开课时间或有效期后再提交订单)
            </p>
          </div>
        </div>
        <div class="course-submit" @click="submitCourse">
          结算
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "student-cart",
    data() {
      return {
        tableData: [],
        multipleSelection: [],
        sumCoursePrice:0,
        studentId:''
      }
    },
    mounted(){
      this.studentId = this.$util.getUser().studentId;
      this.queryStudentCourse(this.studentId);
    },
    methods: {
      //查询购物车课程
      queryStudentCourse(studentId){
        this.$request({"studentId":studentId}, "/masters/mapper/select/queryStudentCart", (data) => {
          if (data.flag === 200) {
            this.tableData = data.list
          }
        }, err => {
          console.log(err);
        });
      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
        this.sumPrice();
      },
      //删除购物车
      deleteCart(scope,rows) {
        this.$confirm('确定要删除该课程吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(() => {
          let index = scope.$index;
          let course = scope.row;
          course.studentId = this.studentId;
          //执行删除操作
          this.deleteCourseCart(course);
          rows.splice(index, 1);
        });
      },
      //提交订单
      submitCourse(){
        let multipleSelection = this.multipleSelection;
        if (multipleSelection.length===0){
          this.$message.error("请选择要结算的课程");
          return;
        }
        let param = {};
        param.courseList = multipleSelection;
        param.sumPrice = this.sumCoursePrice;
        sessionStorage.setItem('courseList', JSON.stringify(param));
        sessionStorage.removeItem('course');
        sessionStorage.removeItem('order');
        this.$router.push("pay");
      },
      //合计金额
      sumPrice(){
        let coursePrice = this.multipleSelection.map(course=>{
          return course.coursePrice;
        });
        let sum = coursePrice.reduce((prev,curr)=>{
          const value = Number(curr);
          if (!isNaN(value)) {
            return prev + curr;
          } else {
            return prev;
          }
        }, 0);
        this.sumCoursePrice = sum;
      },
      //删除购物车课程
      deleteCourseCart(course){
        this.$request(course, "/masters/mapper/select/deleteStudentCart", (data) => {
          if (data.flag === 200) {
            this.$message.success("删除成功");
          }
        }, err => {
          this.$message.error("删除失败");
          console.log(err);
        });
      }
    }
  }
</script>

<style lang="less" scoped>
  .student-cart {
    max-width: 1200px;
    margin: 0 auto 20px;
    min-height: 300px;
    font-size: 16px;

    .cart-table {
      padding: 20px;
    }
    .title {
      height: 76px;
      display: flex;
      align-items: center;
      .el-breadcrumb__item {
        font-size: 16px;
        line-height: 76px;
      }
    }
    .course-name {
      display: flex;
      font-size: 16px;

      .course-info {
        color: #808080;
      }
    }

    .choose-course{
      height: 100px;
      width: 100%;
      display: flex;
      .course-num{
        background-color: #FAE7CB;
        width: 1000px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px;
      }
      .course-submit{
        background-color: #5D2283;
        width: 200px;
        color: #ffffff;
        font-size:24px;
        font-weight:bold;
        display: flex;
        align-items: center;
        justify-content:center;
        cursor:pointer;
      }
    }
  }


</style>