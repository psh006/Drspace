<template>
    <div class="personal-center">

        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right" class="breadcrumb">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/personal-center' }">个人中心</el-breadcrumb-item>
        </el-breadcrumb>

        <!-- 个人中心主体 -->
        <div>
            <el-row :gutter="40">

                <!-- 左边导航栏 -->
                <el-col :span="6">
                    <el-menu
                            :default-active="defaultActive"
                            class="el-menu-vertical-demo"
                            @select="handleSelect">
                        <el-submenu index="1">
                            <template slot="title">
                                <i class="el-icon-user"></i>
                                <span>个人中心</span>
                            </template>
                            <el-menu-item-group>
                                <el-menu-item index="myInfo">我的资料</el-menu-item>
                                <el-menu-item index="updatePass">密码修改</el-menu-item>
                            </el-menu-item-group>
                        </el-submenu>
                        <el-submenu index="2">
                            <template slot="title">
                                <i class="el-icon-s-order"></i>
                                <span>订单</span>
                            </template>
                            <el-menu-item-group>
                                <el-menu-item index="myOrder">我的订单</el-menu-item>
                            </el-menu-item-group>
                        </el-submenu>
                        <el-menu-item index="3">
                            <i class="el-icon-switch-button"></i>
                            <span slot="title">退出登录</span>
                        </el-menu-item>
                    </el-menu>
                </el-col>

                <!-- 右边内容栏 -->
                <el-col :span="18">
                    <!-- 提供栏目 -->
                    <el-tabs>
                        <el-tab-pane :label="tabName">
                        </el-tab-pane>
                    </el-tabs>
                    <!-- 提供内容 -->
                    <el-tabs v-model="activeName" ref="tabs" class="true-tabs">
                        <!-- 我的资料栏 -->
                        <el-tab-pane label="我的资料" name="myInfo">
                            <div class="content">
                                <span style="color: #B3B3B3;font-size: 7px;">
                                    完善个人资料是让别人认识你的第一步
                                </span>
                                <el-form ref="myInfoForm" :model="myInfoFormData" label-width="80px"
                                         :rules="myInfoFormRules">
                                    <span class="form-title">
                                         基本信息
                                    </span>
                                    <el-form-item label="头像" prop="avatar">
                                        <div style="width: 600px;">
                                            <el-upload
                                                    class="avatar-uploader"
                                                    ref="upload"
                                                    :action="$uploadFileUrl"
                                                    accept=".jpg,.png"
                                                    :on-success="handleAvatarSuccess"
                                                    :before-upload="beforeAvatarUpload"
                                                    :show-file-list="false">
                                                <img v-if="myInfoFormData.avatar"
                                                     :src="$getFileUrl + myInfoFormData.avatar"
                                                     class="avatar">
                                                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                                <div slot="tip" class="el-upload__tip">
                                                    只能上传jpg/png文件，且不超过2M，建议图片长宽比为1:1，保存后生效
                                                </div>
                                            </el-upload>
                                        </div>
                                    </el-form-item>
                                    <el-form-item label="手机号">
                                        <el-input v-model="myInfoFormData.loginCode" style="width: 300px"
                                                  readonly></el-input>
                                        <el-button type="success" @click="handleSelect('1-3')"
                                                   icon="el-icon-edit"
                                                   style="margin-left: 10px">修改
                                        </el-button>
                                    </el-form-item>
                                    <el-form-item label="昵称" prop="nickName">
                                        <el-input v-model="myInfoFormData.nickName" maxlength="10"
                                                  @input="value=>{this.myInfoFormData.nickName = this.$util.checkCnEnNu(value)}"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                    <el-form-item label="性别" prop="gender">
                                        <el-radio v-model="myInfoFormData.gender" v-for="item in genderList"
                                                  :key="item.itemVal" :label="parseInt(item.itemVal)">
                                            {{ item.itemName }}
                                        </el-radio>
                                    </el-form-item>
                                    <el-form-item label="出生日期" prop="birthday">
                                        <el-date-picker v-model="myInfoFormData.birthday"
                                                        style="width: 300px"
                                                        clearable
                                                        type="date"
                                                        value-format="yyyy-MM-dd"/>
                                    </el-form-item>
                                    <el-form-item label="年级" prop="gradeId">
                                        <el-select v-model="myInfoFormData.gradeId" filterable placeholder="请选择"
                                                   style="width: 300px" clearable>
                                            <el-option v-for="item in gradeList" :key="item.gradeId"
                                                       :label="item.gradeName"
                                                       :value="item.gradeId"></el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item label="个人介绍" prop="personalIntroduce">
                                        <el-input v-model="myInfoFormData.personalIntroduce"
                                                  :autosize="{ minRows: 4 }"
                                                  maxlength="200" show-word-limit
                                                  type="textarea" style="width: 600px;"></el-input>
                                    </el-form-item>
                                    <span class="form-title">
                                         联系信息
                                     </span>
                                    <el-form-item label="真实姓名" prop="realName">
                                        <el-input v-model="myInfoFormData.realName" maxlength="20"
                                                  @input="value=>{this.myInfoFormData.realName = this.$util.checkCnEn(value)}"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                    <el-form-item label="家长姓名" prop="parentName">
                                        <el-input v-model="myInfoFormData.parentName" maxlength="20"
                                                  @input="value=>{this.myInfoFormData.parentName = this.$util.checkCnEn(value)}"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                    <el-form-item label="联系方式" prop="parentContact">
                                        <el-input v-model="myInfoFormData.parentContact" maxlength="11"
                                                  placeholder="家长手机号码"
                                                  @input="value=>{this.myInfoFormData.parentContact = this.$util.checkNumber(value)}"
                                                  style="width: 300px">
                                        </el-input>
                                    </el-form-item>
                                    <el-form-item label="家庭住址">
                                        <el-input v-model="myInfoFormData.homeAddress" maxlength="50"
                                                  style="width: 600px"></el-input>
                                    </el-form-item>
                                </el-form>
                                <el-button type="primary" @click="handleSubmit('myInfoForm')"
                                           :loading="status.myInfoSaving"
                                           style="margin-left: 85px;" :disabled="status.myInfoFormDataLoading"
                                           >保存
                                </el-button>
                            </div>
                        </el-tab-pane>

                        <!-- 密码修改栏 -->
                        <el-tab-pane label="密码修改" name="updatePass">
                            <div class="content">
                                <el-form ref="passForm" :model="passFormData" label-width="80px"
                                         :rules="passFormRules">
                                    <el-form-item label="旧密码" prop="oldPass">
                                        <el-input v-model="passFormData.oldPass" maxlength="20" show-password
                                                  placeholder="请输入旧密码"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                    <el-form-item label="新密码" prop="newPass">
                                        <el-input v-model="passFormData.newPass" maxlength="20" show-password
                                                  placeholder="6~20位数字、字母组成"
                                                  @input="value=>{this.passFormData.newPass = this.$util.checkEnNu(value)}"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                    <el-form-item label="重复密码" prop="rePass">
                                        <el-input v-model="passFormData.rePass" maxlength="20" show-password
                                                  placeholder="请重复输入新密码"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                </el-form>
                                <el-button type="primary" @click="handleSubmit('updatePassForm')"
                                           :loading="status.passSaving"
                                           style="margin-left: 80px;"
                                           >保存
                                </el-button>
                            </div>
                        </el-tab-pane>

                        <!-- 修改手机号码栏 -->
                        <el-tab-pane label="我的资料" name="updatePhone">
                            <div class="content">
                                <el-page-header @back="activeName = 'myInfo'" content="修改手机号"
                                                style="margin-bottom: 20px">
                                </el-page-header>
                                <el-form ref="phoneForm" :model="phoneFormData" label-width="80px"
                                         :rules="phoneFormRules">
                                    <el-form-item label="旧手机号">
                                        <el-input v-model="phoneFormData.oldLoginCode" maxlength="11"
                                                  disabled
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                    <el-form-item label="验证码" prop="messageCode">
                                        <el-input v-model="phoneFormData.messageCode" maxlength="6"
                                                  @input="value=>{this.phoneFormData.messageCode = this.$util.checkNumber(value)}"
                                                  style="width: 300px"></el-input>
                                        <el-button type="success" @click="getMC" :disabled="status.MCGetting"
                                                   style="margin-left: 10px">{{ getMCButtonText }}
                                        </el-button>
                                    </el-form-item>
                                    <el-form-item label="新手机号" prop="newLoginCode">
                                        <el-input v-model="phoneFormData.newLoginCode" maxlength="11"
                                                  @input="value=>{this.phoneFormData.newLoginCode = this.$util.checkNumber(value)}"
                                                  style="width: 300px"></el-input>
                                    </el-form-item>
                                </el-form>
                                <el-button type="primary" @click="handleSubmit('phoneForm')"
                                           :loading="status.phoneSaving"
                                           style="margin-left: 80px;"
                                           >保存
                                </el-button>
                            </div>
                        </el-tab-pane>

                        <!-- 我的订单栏 -->
                        <el-tab-pane label="我的订单" name="myOrder">
                            <div class="content">
                                <!-- 搜索表单 -->
                                <el-form ref="searchForm" :model="orderPageInfo" inline>
                                    <el-form-item label="时间:" prop="createDate">
                                        <el-date-picker v-model="orderPageInfo.createDate"
                                                        style="width: 300px;"
                                                        type="daterange"
                                                        value-format="yyyy-MM-dd"
                                                        range-separator="至"
                                                        start-placeholder="开始日期"
                                                        end-placeholder="结束日期"/>
                                    </el-form-item>
                                    <el-form-item label="年级:" prop="gradeId">
                                        <el-select v-model="orderPageInfo.gradeId" clearable style="width: 150px;">
                                            <el-option label="全部" value=""></el-option>
                                            <el-option v-for="item in gradeList" :key="item.gradeId"
                                                       :label="item.gradeName"
                                                       :value="item.gradeId"></el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item label="科目:" prop="subjectId">
                                        <el-select v-model="orderPageInfo.subjectId" clearable style="width: 150px;">
                                            <el-option label="全部" value=""></el-option>
                                            <el-option v-for="item in subjectList" :key="item.subjectId"
                                                       :label="item.subjectName"
                                                       :value="item.subjectId"></el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item>
                                        <el-button type="primary" :loading="status.orderDataLoading"
                                                   @click="handleOrderPage(1)"
                                                   icon="el-icon-search">查询
                                        </el-button>
                                    </el-form-item>
                                </el-form>

                                <!-- 数据表格 -->
                                <el-table :data="myOrderData" v-loading="status.orderDataLoading" type="index"
                                          style="border: 1px solid #EBEEF5; border-bottom: none">
                                    <el-table-column label="订单课程" min-width="480px" header-align="center">
                                        <template slot-scope="scope">
                                            <el-row v-if="scope.row.orderDetail.length === 1">
                                                <el-col :span="7">
                                                    <el-image
                                                            style="width: 128px; height: 72px"
                                                            :src="$getFileUrl + scope.row.orderDetail[0].courseCover"
                                                            fit="contain"></el-image>
                                                </el-col>
                                                <el-col :span="17">
                                                    <div style="color:#333333;font-size: 14px;max-width: 200px;"
                                                         :title="scope.row.orderDetail[0].courseName || '-'"
                                                         class="text-too-long">
                                                        {{ (scope.row.orderDetail[0].courseName || '-') }}
                                                    </div>
                                                    <div style="color:#808080;font-size: 14px;">
                                                        {{ (scope.row.orderDetail[0].courseStart || '-') + '~' +
                                                        (scope.row.orderDetail[0].courseEnd || '-') + ' · 共' +
                                                        (scope.row.orderDetail[0].allCourseHour || '-') + '课时'}}
                                                    </div>
                                                    <div style="color:#808080;font-size: 14px;">
                                                        {{ '授课老师: ' + (scope.row.orderDetail[0].lecturerName || '-') +
                                                        ' · 班主任老师: ' + (scope.row.orderDetail[0].managerTeacherName || '-') }}
                                                    </div>
                                                </el-col>
                                            </el-row>
                                            <el-row v-else>
                                                <el-col :span="7">
                                                    <el-popover
                                                            placement="top"
                                                            width="400"
                                                            trigger="hover">
                                                        <div>
                                                            <div style="color:#333333;font-size: 14px;">
                                                                {{ (scope.row.orderDetail[0].courseName || '-') }}
                                                            </div>
                                                            <div style="color:#808080;font-size: 14px;">
                                                                {{ (scope.row.orderDetail[0].courseStart || '-') + '~' +
                                                                (scope.row.orderDetail[0].courseEnd || '-') + ' · 共' +
                                                                (scope.row.orderDetail[0].allCourseHour || '-') + '课时'}}
                                                            </div>
                                                            <div style="color:#808080;font-size: 14px;">
                                                                {{ '授课老师: ' + (scope.row.orderDetail[0].lecturerName || '-') +
                                                                ' · 班主任老师: ' +
                                                                (scope.row.orderDetail[0].managerTeacherName || '-')
                                                                }}
                                                            </div>
                                                        </div>
                                                        <el-image
                                                                slot="reference"
                                                                style="width: 128px; height: 72px"
                                                                :src="$getFileUrl + scope.row.orderDetail[0].courseCover"
                                                                fit="contain"></el-image>
                                                    </el-popover>
                                                </el-col>
                                                <el-col :span="7" v-if="scope.row.orderDetail.length > 1">
                                                    <el-popover
                                                            placement="top"
                                                            width="400"
                                                            trigger="hover">
                                                        <div>
                                                            <div style="color:#333333;font-size: 14px;">
                                                                {{ scope.row.orderDetail[1].courseName }}
                                                            </div>
                                                            <div style="color:#808080;font-size: 14px;">
                                                                {{ scope.row.orderDetail[1].courseStart + '~' +
                                                                scope.row.orderDetail[1].courseEnd + ' · 共' +
                                                                scope.row.orderDetail[1].allCourseHour + '课时'}}
                                                            </div>
                                                            <div style="color:#808080;font-size: 14px;">
                                                                {{ '授课老师: ' + scope.row.orderDetail[1].lecturerName +
                                                                ' · 班主任老师: ' +
                                                                scope.row.orderDetail[1].managerTeacherName
                                                                }}
                                                            </div>
                                                        </div>
                                                        <el-image
                                                                slot="reference"
                                                                style="width: 128px; height: 72px"
                                                                :src="$getFileUrl + scope.row.orderDetail[1].courseCover"
                                                                fit="contain"></el-image>
                                                    </el-popover>
                                                </el-col>
                                                <el-col :span="7" v-if="scope.row.orderDetail.length > 2">
                                                    <el-popover
                                                            placement="top"
                                                            width="400"
                                                            trigger="hover">
                                                        <div>
                                                            <div style="color:#333333;font-size: 14px;">
                                                                {{ scope.row.orderDetail[2].courseName }}
                                                            </div>
                                                            <div style="color:#808080;font-size: 14px;">
                                                                {{ scope.row.orderDetail[2].courseStart + '~' +
                                                                scope.row.orderDetail[2].courseEnd + ' · 共' +
                                                                scope.row.orderDetail[2].allCourseHour + '课时'}}
                                                            </div>
                                                            <div style="color:#808080;font-size: 14px;">
                                                                {{ '授课老师: ' + scope.row.orderDetail[2].lecturerName +
                                                                ' · 班主任老师: ' +
                                                                scope.row.orderDetail[2].managerTeacherName
                                                                }}
                                                            </div>
                                                        </div>
                                                        <el-image
                                                                slot="reference"
                                                                style="width: 128px; height: 72px"
                                                                :src="$getFileUrl + scope.row.orderDetail[2].courseCover"
                                                                fit="contain"></el-image>
                                                    </el-popover>
                                                </el-col>
                                                <el-col :span="3" v-if="scope.row.orderDetail.length >= 3">
                                                    <span style="line-height: 72px;margin-left: 10px">
                                                            {{ '共'+ scope.row.orderDetail.length + '门' }}
                                                    </span>
                                                </el-col>
                                            </el-row>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="金额" align="center"
                                                     :formatter="formatOrderAmount"
                                                     min-width="85px"></el-table-column>
                                    <el-table-column label="状态" prop="orderStatus" min-width="80px"
                                                     align="center">
                                        <template slot-scope="scope">
                                            <span v-if="scope.row.orderStatus === 1" style="color: #FD4D4D">
                                                <!-- 待支付 -->
                                                {{ formatOrderStatus(scope.row) }}
                                            </span>
                                            <span v-else-if="scope.row.orderStatus === 2" style="color: #323EDD">
                                                <!-- 支付中 -->
                                                {{ formatOrderStatus(scope.row) + '...' }}
                                            </span>
                                            <span v-else-if="scope.row.orderStatus === 3" style="color: #323EDD">
                                                <!-- 退款中 -->
                                                {{ formatOrderStatus(scope.row) + '...' }}
                                            </span>
                                            <span v-else-if="scope.row.orderStatus === 4" style="color: #808080">
                                                <!-- 取消订单 -->
                                                已取消
                                            </span>
                                            <span v-else-if="scope.row.orderStatus === 5" style="color: #4BAF50">
                                                <!-- 订单完成 -->
                                                已完成
                                            </span>
                                            <span v-else-if="scope.row.orderStatus === 6" style="color: #808080">
                                                <!-- 已退款 -->
                                                {{ formatOrderStatus(scope.row) }}
                                            </span>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="创建时间" prop="createTime" min-width="100px" align="center">
                                        <template slot-scope="scope">
                                            <div>{{ formatDate(scope.row.createTime) }}</div>
                                            <div>{{ formatTime(scope.row.createTime) }}</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="操作" min-width="100px" align="center">
                                        <template slot-scope="scope">
                                            <el-button type="text"
                                                       @click.stop="showOrderDetail(scope.row)">详情
                                            </el-button>
                                            <el-button type="text" v-if="scope.row.orderStatus === 1"
                                                       @click.stop="toPay(scope.row)">去支付
                                            </el-button>
                                            <el-button type="text" @click.stop="handleCancelOrder(scope.row.orderId)"
                                                       v-if="scope.row.orderStatus === 1">取消
                                            </el-button>
                                            <el-button type="text" @click.stop="handleDeleteOrder(scope.row.orderId)"
                                                       v-if="scope.row.orderStatus === 4">删除
                                            </el-button>
                                        </template>
                                    </el-table-column>
                                </el-table>
                                <!-- 分页组件 -->
                                <el-pagination
                                        layout="total, prev, pager, next, jumper"
                                        :current-page="orderPageInfo.page"
                                        :page-size="orderPageInfo.limit"
                                        :total="myOrderTotal"
                                        @current-change="handleOrderPage">
                                </el-pagination>
                            </div>
                        </el-tab-pane>
                        <!-- 订单详情栏 -->
                        <el-tab-pane label="我的订单" name="orderDetail">
                            <div class="content">
                                <el-page-header @back="activeName = 'myOrder'" content="订单详情" style="margin-bottom: 20px">
                                </el-page-header>
                                <span style="color:#808080;font-size: 16px;margin-bottom: 10px;">课程信息</span>
                                <el-divider></el-divider>
                                <div v-for="course in order.orderDetail" :key="course.courseId">
                                    <el-row>
                                        <el-col :span="6">
                                            <el-image
                                                    style="width: 192px; height: 108px"
                                                    :src="$getFileUrl + course.courseCover"
                                                    fit="contain"></el-image>
                                        </el-col>
                                        <el-col :span="10">
                                            <div style="color:#333333;font-size: 14px; margin-top: 20px;max-width: 200px;"
                                                 :title="course.courseName"
                                                 class="text-too-long">
                                                {{ course.courseName }}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;">
                                                {{ course.courseStart + '~' + course.courseEnd + ' · 共' +
                                                course.allCourseHour + '课时'}}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;">
                                                {{ '授课老师: ' + course.lecturerName + ' · 班主任老师: ' +
                                                course.managerTeacherName }}
                                            </div>
                                        </el-col>
                                        <el-col :span="4" style="text-align: center;">
                                            <!-- v-if="order.orderStatus === 5" -->
                                            <div style="color: #333333;font-size: 14px;font-weight: bold;line-height: 108px;">
                                                ￥{{ $util.pennyToYuan(course.coursePrice) }}
                                            </div>
                                        </el-col>
                                        <el-col :span="4" style="text-align: center;">
                                            <div style="line-height: 108px;">
                                                <el-button type="text"
                                                           @click.stop="toCourseDetail(course)">详情
                                                </el-button>
                                                <el-button type="text"
                                                           v-if="order.orderStatus === 5"
                                                           @click.stop="showEvaluateDialog(course)">评价
                                                </el-button>
                                            </div>
                                        </el-col>
                                    </el-row>
                                    <el-divider></el-divider>
                                </div>
                                <span style="color:#808080;font-size: 16px;">订单信息</span>
                                <div style="margin-top: 16px;">
                                    <el-row>
                                        <el-col :span="4">
                                            <div style="color:#808080;font-size: 14px;">订单状态:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">订单备注:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">创建时间:</div>
                                        </el-col>
                                        <el-col :span="20">
                                            <div style="color:#808080;font-size: 14px;">{{ formatOrderStatus(order) }}</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                {{ order.remarks || '-' }}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                {{ order.createTime || '-' }}
                                            </div>
                                        </el-col>
                                    </el-row>
                                </div>
                                <el-divider></el-divider>
                                <span style="color:#808080;font-size: 16px;">付款信息</span>
                                <div style="margin-top: 16px;">
                                    <el-row>
                                        <el-col :span="4">
                                            <div style="color:#808080;font-size: 14px;">付款方式:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">付款时间:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">支付编号:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">课程总额:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">应付金额:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">实付金额:</div>
                                        </el-col>
                                        <el-col :span="20">
                                            <div style="color:#808080;font-size: 14px;">{{ formatPayType(order.payType) }}</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                {{ order.payTime || '-' }}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                {{ order.payId || '-' }}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                ￥{{ computeAllCoursePrice(order) }}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                ￥{{ $util.pennyToYuan(order.orderAmount) }}
                                            </div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">
                                                ￥{{ $util.pennyToYuan(order.payableAmount) }}
                                            </div>
                                        </el-col>
                                    </el-row>
                                </div>
                                <el-divider></el-divider>
                                <span style="color:#808080;font-size: 16px;">购买账户信息</span>
                                <div style="margin-top: 16px;">
                                    <el-row>
                                        <el-col :span="4">
                                            <div style="color:#808080;font-size: 14px;">用户昵称:</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">购买账号:</div>
                                        </el-col>
                                        <el-col :span="20">
                                            <div style="color:#808080;font-size: 14px;">{{ order.receivingName || '-' }}</div>
                                            <div style="color:#808080;font-size: 14px;margin-top: 6px;">{{ order.receivingPhone || '-' }}</div>
                                        </el-col>
                                    </el-row>
                                </div>
                            </div>
                        </el-tab-pane>
                    </el-tabs>
                </el-col>
            </el-row>
        </div>

        <!-- 评论课程弹框栏 -->
        <el-dialog title="评价课程" :visible.sync="status.evaluateOrderOpen"
                   width="700px" :close-on-click-modal="false">
            <span style="color:#808080;font-size: 14px;">
                课程信息
                <span style="color:#808080;font-size: 8px;" v-show="status.isEvaluated">(已评价)</span>
                <span style="color:#808080;font-size: 8px;" v-show="!status.isEvaluated">(未评价)</span>
            </span>
            <el-divider></el-divider>
            <el-row>
                <el-col :span="8">
                    <el-image
                            style="width: 192px; height: 108px"
                            :src="$getFileUrl + course.courseCover"
                            fit="contain"></el-image>
                </el-col>
                <el-col :span="12">
                    <div style="color:#333333;font-size: 14px;">
                        {{ course.courseName || '-' }}
                    </div>
                    <div style="color:#808080;font-size: 14px;">
                        {{ course.courseStart || '-' + '~' + course.courseEnd || '-' + ' · 共' + course.allCourseHour || '-' + '课时'}}
                    </div>
                    <div style="color:#808080;font-size: 14px;">
                        {{ '授课老师: ' + course.lecturerName || '-' + ' · 班主任老师: ' + course.managerTeacherName || '-' }}
                    </div>
                </el-col>
                <el-col :span="4">
                    <span style="color: #333333;font-size: 14px;font-weight: bold;">
                            ￥{{ $util.pennyToYuan(course.coursePrice) || '-' }}
                    </span>
                </el-col>
            </el-row>
            <el-divider></el-divider>
            <el-form ref="evaluateForm" :model="evaluateFormData" :rules="evaluateFormRules"
                     :disabled="status.isEvaluated">
                <el-form-item label="星级" prop="evaluateNumber">
                    <el-rate v-model="evaluateFormData.evaluateNumber"
                             style="margin-top: 6px"></el-rate>
                </el-form-item>
                <el-form-item label="评价" prop="evaluateContent">
                    <el-input :autosize="{ minRows: 3 }" v-model="evaluateFormData.evaluateContent"
                              maxlength="200" show-word-limit
                              type="textarea"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer" v-show="!status.isEvaluated">
                    <el-button @click="status.evaluateOrderOpen = false">取消</el-button>
                    <el-button type="primary" @click="handleSubmit('evaluateForm')" :loading="status.evaluateSaving"
                               >保存</el-button>
            </span>
        </el-dialog>

        <!--微信二维码-->
        <div v-if="options.text" style="z-index:5;">
            <div class="qrcode-bg"></div>
            <div class="qrcode-logo">
                <i class="el-icon-circle-close" @click="closeQrcode"></i>
                <el-image :src="require('./../assets/img/pay-img.png')"></el-image>
                <div style="display: flex">
                    <p class="qrcode-info">请扫描二维码</p>
                    <div class="qrcode">
                        <div v-qr="options"/>
                    </div>
                </div>
            </div>
        </div>

        <div class="blank"></div>
    </div>
</template>
<script>
    import {mapState} from 'vuex';
    import constData from "./../assets/javascript/const-data"

    export default {
        name: 'personal-center',
        computed: {
            ...mapState({
                tic: state => state.tic,
            })
        },
        data() {
            let validatePhone = (rule, value, callback) => {
                if (!this.$util.isPhoneNumber(value)) {
                    return callback(new Error('请输入正确的手机号码!'));
                }
                return callback();
            };
            let validateParentContact = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                if (!this.$util.isPhoneNumber(value)) {
                    return callback(new Error('请输入正确的手机号码!'));
                }
                return callback();
            };
            let isName = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                let nameReg = /^[\u4E00-\u9FA5.·\u36c3\u4DAE]{2,20}$|^[A-Za-z]{2,20}$/;
                if (!nameReg.test(value)) {
                    return callback(new Error('姓名格式须为2~20个连续的汉字或字母'));
                }
                return callback();
            };
            let isParentName = (rule, value, callback) => {
                if (this.$util.isEmpty(value)) {
                    return callback();
                }
                let nameReg = /^[\u4E00-\u9FA5.·\u36c3\u4DAE]{2,20}$|^[A-Za-z]{2,20}$/;
                if (!nameReg.test(value)) {
                    return callback(new Error('姓名格式须为2~20个连续的汉字或字母'));
                }
                return callback();
            };
            let validateBirthday = (rule, value, callback) => {
                let min = new Date(1970, 1, 1);
                let max = new Date();
                let time = value.split("-");
                let birthday = new Date(time[0], time[1] - 1, time[2]);
                if (birthday.getTime() <= min.getTime() || birthday.getTime() >= max.getTime()) {
                    return callback(new Error('请选择1970年至现在的日期'));
                }
                return callback();
            };
            return {
                // tab栏名
                tabName: "我的资料",
                // 激活的tab栏
                activeName: "myInfo",
                defaultActive: "myInfo",
                // 我的资料表单数据
                myInfoFormData: {
                    nickName: "",
                    avatar: "",
                    gender: "",
                    gradeId: "",
                    personalIntroduce: "",
                    realName: "",
                    parentName: "",
                    parentContact: "",
                    homeAddress: "",
                },
                // 我的资料表单校验规则
                myInfoFormRules: {
                    nickName: [
                        {required: true, message: '昵称不能为空', trigger: 'blur'}
                    ],
                    realName: [
                        {validator: isName, trigger: 'blur'}
                    ],
                    gender: [
                        {required: true, message: '性别不能为空', trigger: 'blur'}
                    ],
                    gradeId: [
                        {required: true, message: '年级不能为空', trigger: 'blur'}
                    ],
                    parentName: [
                        {validator: isParentName, trigger: 'blur'}
                    ],
                    parentContact: [
                        {validator: validateParentContact, trigger: 'blur'}
                    ],
                    birthday: [
                        {required: true, message: '出生日期不能为空', trigger: 'blur'},
                        {validator: validateBirthday, trigger: 'blur'}
                    ]
                },
                getMCButtonText: "获取验证码", // 获取验证码链接文字
                getMCDuration: 60, // 验证码获取时长
                timer: "", // 验证码定时器
                gradeList: [], // 年级列表
                subjectList: [], // 科目列表
                payTypeList: [], //支付方式列表
                genderList: [], // 性别列表
                // 修改密码表单
                passFormData: {
                    oldPass: "",
                    newPass: "",
                    rePass: "",
                },
                outTradeNo: "",
                // 修改密码表单验证规则
                passFormRules: {
                    oldPass: [
                        {required: true, message: '旧密码不能为空', trigger: 'blur'}
                    ],
                    newPass: [
                        {required: true, message: '新密码不能为空', trigger: 'blur'},
                        {min: 6, max: 20, message: '密码长度须在6~20位'}
                    ],
                    rePass: [
                        {required: true, message: '重复密码不能为空', trigger: 'blur'}
                    ],
                },
                // 修改手机号表单数据
                phoneFormData: {
                    oldLoginCode: "",
                    newLoginCode: "",
                    messageCode: "",
                },
                // 修改手机号编导你校验规则
                phoneFormRules: {
                    newLoginCode: [
                        {required: true, message: '新手机号不能为空', trigger: 'blur'},
                        {validator: validatePhone, trigger: 'blur'}
                    ],
                    messageCode: [
                        {required: true, message: '验证码不能为空', trigger: 'blur'}
                    ],
                },
                // 订单状态列表
                orderStateList: [],
                // 我的订单分页查询参数
                orderPageInfo: {
                    page: 1,
                    limit: 5,
                    gradeId: "",
                    subjectId: "",
                },
                myOrderData: [], // 我的订单数据
                myOrderTotal: 0, // 订单总数
                order: {}, // 单个订单
                course: {}, // 评论课程
                // 评论表单
                evaluateFormData: {
                    courseId: "",
                    studentId: "",
                    evaluateNumber: null,
                    evaluateContent: "",
                },
                // 评论表单校验规则
                evaluateFormRules: {
                    evaluateNumber: [
                        {required: true, message: '评分不能为空', trigger: 'blur'}
                    ],
                    evaluateContent: [
                        {required: true, message: '评价不能为空', trigger: 'blur'}
                    ]
                },
                // 状态
                status: {
                    myInfoFormDataLoading: false,
                    myInfoSaving: false,
                    passSaving: false,
                    phoneSaving: false,
                    evaluateSaving: false,
                    orderDataLoading: false,
                    MCGetting: false,
                    orderDetailOpen: false,
                    evaluateOrderOpen: false,
                    isEvaluated: false,
                },
                options: {
                    text: '',
                    width: 154,
                    height: 154,
                    background: "#ffffff",
                    foreground: "#000000"
                },
                timer2: null,
            }
        },
        mounted() {
            // 性别字典
            this.genderList = this.$dict.getDictByCode('GENDER') || [];
            // 订单状态
            this.orderStateList = this.$dict.getDictByCode('ORDER_STATE') || [];
            // 支付方式
            this.payTypeList = this.$dict.getDictByCode('PAY_TYPE') || [];
            // 年级初始化
            this.gradeList = [];
            let params = {
                method: 'POST',
            }
            this.$request(params, "/grade/gradeList", (res) => {
                this.gradeList = res.list;
            });
            // 科目数据初始化
            this.subjectList = [];
            this.$request(params, "/subject/subjectList", (res) => {
                this.subjectList = res.list;
            });
            // 路由跳转
            let index = this.$route.query.index;
            if (index) {
                this.defaultActive = index;
                this.handleSelect(index);
            }
            // 获取个人资料
            this.getMyInfoData();
            // window.addEventListener('beforeunload', this.deleteOrder);
        },
        // beforeDestroy() {
        //     this.deleteOrder();
        // },
        // destroyed() {
        //     window.removeEventListener('beforeunload', this.deleteOrder);
        // },
        methods: {
            // 获取我的资料
            getMyInfoData() {
                this.status.myInfoFormDataLoading = true;
                this.$request(this.$util.getUser(), "/student/myInfo", (res) => {
                    this.myInfoFormData = res.list[0];
                    this.status.myInfoFormDataLoading = false;
                }, () => {
                    this.myInfoFormData = {};
                    this.status.myInfoFormDataLoading = false;
                });
            },
            // 获取验证码
            getMC() {
                this.status.MCGetting = true;
                let params = {
                    method: 'POST',
                    mobile: this.phoneFormData.oldLoginCode,
                    // 修改手机号验证码type-2
                    type: 2,
                };
                this.$request(params, "/message/sendMessage", () => {
                    // 请求成功后定时任务
                    this.$message.success(`短信验证码已发送`);
                    this.timer = setInterval(() => {
                        if (this.getMCDuration === 0) {
                            clearInterval(this.timer);
                            this.getMCDuration = 60;
                            this.getMCButtonText = "获取验证码";
                            this.status.MCGetting = false;
                        } else {
                            this.getMCButtonText = this.getMCDuration + "s后重新获取";
                            this.getMCDuration -= 1;
                        }
                    }, 1000);
                }, () => {
                    this.status.MCGetting = false;
                });
            },
            // 获取我的订单
            getMyOrderData() {
                this.status.orderDataLoading = true;
                let params = {...this.orderPageInfo};
                params.method = 'POST';
                if (params.createDate && params.createDate.length >= 2) {
                    params.startTime = params.createDate[0] + " 00:00:00";
                    params.endTime = params.createDate[1] + " 23:59:59";
                    delete params.createDate;
                }
                this.$request(params, "/studentOrder/queryStudentOrder", (res) => {
                    this.myOrderData = res.list;
                    this.myOrderTotal = res.total;
                    this.status.orderDataLoading = false;
                }, () => {
                    this.myOrderTotal = 0;
                    this.myOrderData = [];
                    this.status.orderDataLoading = false;
                });
            },
            // 左边菜单栏选中事件
            handleSelect(index) {
                switch (index) {
                    case 'myInfo':
                        this.tabName = "我的资料";
                        this.activeName = "myInfo";
                        this.$nextTick(() => {
                            this.$refs['myInfoForm'].resetFields();
                        });
                        this.getMyInfoData();
                        break;
                    case 'updatePass':
                        this.tabName = "密码修改";
                        this.activeName = "updatePass";
                        this.$nextTick(() => {
                            this.$refs['passForm'].resetFields();
                        });
                        break;
                    case '1-3':
                        this.tabName = "我的资料";
                        this.activeName = "updatePhone";
                        this.phoneFormData.oldLoginCode = this.myInfoFormData.loginCode;
                        this.$nextTick(() => {
                            this.$refs['phoneForm'].resetFields();
                        });
                        break;
                    case 'myOrder':
                        this.tabName = "我的订单";
                        this.activeName = "myOrder";
                        this.handleResetForm("searchForm");
                        this.handleOrderPage(1);
                        break;
                    case '3':
                        this.$confirm('确定要退出登录吗?', '提示', {
                            confirmButtonText: '确定',
                            cancelButtonText: '取消',
                            type: 'warning'
                        }).then(() => {
                            this.$request(this.$util.getUser(), "/login/userLoginOut", () => {
                                this.$message.success("已退出登录");
                                this.$util.removeUser();
                                this.$store.commit("removeSystemUserInfo");
                                this.$router.push("/home").finally(()=>{
                                    window.location.reload(true);
                                });
                                this.logout_internal();
                            }, () => {
                                this.$util.removeUser();
                                this.$store.commit("removeSystemUserInfo");
                                this.$router.push("/home").finally(()=>{
                                    window.location.reload(true);
                                });
                                this.logout_internal();
                            });
                        }).catch(() => {
                        });
                        break;
                    default :
                        this.tabName = "我的资料";
                        this.activeName = "myInfo";
                        this.$nextTick(() => {
                            this.$refs['myInfoForm'].resetFields();
                        });
                        this.getMyInfoData();
                        break;
                }
            },
            logout_internal() {
                this.tic.logout((res) => {
                    if (res.code) {
                        this.$message.error('登出失败');
                    } else {
                        this.$store.commit("toggleTicUserStatus", constData.USER_STATUS_UNLOGIN);
                        // 删除事件监听
                        this.tic.removeTICMessageListener();
                        this.tic.removeTICEventListener();
                        this.tic.removeTICStatusListener();
                    }
                });
            },
            // 表单提交
            handleSubmit(formName) {
                switch (formName) {
                    // 我的资料表单
                    case "myInfoForm":
                        this.$refs.myInfoForm.validate((valid) => {
                            if (valid) {
                                this.status.myInfoSaving = true;
                                let params = this.myInfoFormData;
                                params.method = 'POST';
                                if (!this.$util.isEmpty(params.gradeId)) {
                                    this.gradeList.forEach(grade => {
                                        if (grade.gradeId === params.gradeId) {
                                            params.gradeName = grade.gradeName;
                                        }
                                    })
                                }
                                // 修改
                                this.$request(params, "/student/updateMyInfo", () => {
                                    this.$message.success(`保存成功`);
                                    this.status.myInfoSaving = false;
                                    // 刷新数据
                                    this.getMyInfoData();
                                    // 更新头部信息
                                    let user = this.$util.getUser();
                                    user.avatar = params.avatar;
                                    user.nickName = params.nickName;
                                    this.$util.saveUser(user);
                                    this.$store.commit("setSystemUserInfo", user);
                                }, () => {
                                    this.status.myInfoSaving = false;
                                });
                            }
                        });
                        break;
                    // 修改密码表单
                    case "updatePassForm":
                        this.$refs.passForm.validate((valid) => {
                            if (valid) {
                                let param = {...this.passFormData}
                                if (param.newPass !== param.rePass) {
                                    this.$message.error('两次密码不一致');
                                    return;
                                }
                                if (param.newPass === param.oldPass) {
                                    this.$message.error('新密码不可与旧密码相同');
                                    return;
                                }
                                this.$confirm('确定修改密码吗？', '提示', {
                                    confirmButtonText: '确定',
                                    cancelButtonText: '取消',
                                    type: 'warning',
                                    center: true
                                }).then(() => {
                                    this.status.passSaving = true;
                                    this.$request(param, "/login/updateStudentLoginPass", (data) => {
                                        if (data.flag === 200) {
                                            this.$message.success("修改成功，请重新登录!");
                                            this.passFormData = {};
                                            this.status.passSaving = false
                                            this.$util.removeUser();
                                            this.$store.commit("removeSystemUserInfo");
                                            this.$router.push("/home");
                                        }
                                    }, () => {
                                        this.status.passSaving = false;
                                    });
                                });
                            }
                        });
                        break;
                    // 修改手机号码表单
                    case "phoneForm":
                        this.$refs.phoneForm.validate((valid) => {
                            if (valid) {
                                // 判断手机号格式是否正确
                                let newLoginCode = this.phoneFormData.newLoginCode;
                                if (!this.$util.isPhoneNumber(newLoginCode)) {
                                    this.$message.error("请输入正确的手机号码!");
                                    return;
                                }
                                // 检查新手机号是否存在
                                let params1 = {
                                    loginCode: newLoginCode
                                }
                                this.$request(params1, "/student/checkLoginCode", (res) => {
                                    if (!res.list[0]) {
                                        let params = {...this.phoneFormData};
                                        params.method = "POST";
                                        this.status.phoneSaving = true;
                                        this.$request(params, "/login/updateStudentLoginCode", (data) => {
                                            if (data.flag === 200) {
                                                this.$message.success("修改成功，请重新登录!");
                                                this.phoneFormData = {};
                                                this.status.phoneSaving = false
                                                this.$util.removeUser();
                                                this.$store.commit("removeSystemUserInfo");
                                                this.$router.push("/home");
                                            }
                                        }, () => {
                                            this.status.phoneSaving = false
                                        });
                                    }else {
                                        this.$message.error("该手机号已被注册");
                                    }
                                });
                            }
                        });
                        break;
                    case "evaluateForm":
                        this.$refs.evaluateForm.validate((valid) => {
                            if (valid) {
                                this.status.evaluateSaving = true;
                                let params = {...this.evaluateFormData};
                                params.method = "POST";
                                if (this.$util.isEmpty(params.courseEvaluateId)) {
                                    // 添加评价
                                    this.$request(params, "/courseEvaluate/evaluateCourse", () => {
                                        this.status.evaluateSaving = false;
                                        this.$message.success('评价成功');
                                        this.status.evaluateOrderOpen = false;
                                    }, () => {
                                        this.status.evaluateSaving = false;
                                    });
                                } else {
                                    // 修改评价
                                    this.$request(params, "/courseEvaluate/updateEvaluate", () => {
                                        this.status.evaluateSaving = false;
                                        this.$message.success('评价成功');
                                        this.status.evaluateOrderOpen = false;
                                    }, () => {
                                        this.status.evaluateSaving = false;
                                    });
                                }
                            }
                        });
                        break;
                }
            },
            // 重置表单
            handleResetForm(form) {
                if (form === "searchForm") {
                    this.$nextTick(() => {
                        this.orderPageInfo = this.$options.data().orderPageInfo;
                        this.$refs['searchForm'].resetFields();
                    });
                }
            },
            // 头像上传成功回调
            handleAvatarSuccess(res) {
                this.$set(this.myInfoFormData,"avatar",res.message);
                // this.myInfoFormData.avatar = res.message;
            },
            // 头像上传前处理
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg';
                const isPNG = file.type === 'image/png';
                const isLt2M = file.size / 1024 / 1024 < 2;
                if (!isJPG && !isPNG) {
                    this.$message.error('上传头像图片只能是 JPG或PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return (isJPG || isPNG) && isLt2M;
            },
            // 处理订单分页第几页
            handleOrderPage(page) {
                if (page) {
                    this.orderPageInfo.page = page;
                }
                this.getMyOrderData();
            },
            // 处理弹窗
            showEvaluateDialog(course) {
                this.course = course;
                this.status.evaluateOrderOpen = true;
                this.$nextTick(() => {
                    this.$refs['evaluateForm'].resetFields();
                });
                let params = {
                    courseId: course.courseId,
                    studentId: this.$util.getUser().studentId,
                };
                this.$request(params, "/masters/mapper/select/courseEvaluate.queryByStudentEvaluate", (res) => {
                    if (this.$util.isEmpty(res.list[0])) {
                        this.evaluateFormData = this.$options.data().evaluateFormData;
                        this.evaluateFormData.studentId = this.$util.getUser().studentId;
                        this.evaluateFormData.courseId = course.courseId;
                        this.evaluateFormData.nickName = this.$util.getUser().nickName;
                        this.evaluateFormData.avatar = this.$util.getUser().avatar;
                        this.status.isEvaluated = false;
                    } else {
                        this.evaluateFormData = res.list[0];
                        this.status.isEvaluated = true;
                    }
                }, () => {
                    this.evaluateFormData = this.$options.data().evaluateFormData;
                    this.evaluateFormData.studentId = this.$util.getUser().studentId;
                    this.evaluateFormData.courseId = course.courseId;
                    this.evaluateFormData.nickName = this.$util.getUser().nickName;
                    this.evaluateFormData.avatar = this.$util.getUser().avatar;
                    this.status.isEvaluated = false;
                });
            },
            // 展示订单详情
            showOrderDetail(order) {
                this.order = order;
                this.activeName = "orderDetail";
                this.tabName = "我的订单";
            },
            // 取消订单
            handleCancelOrder(orderId) {
                this.$confirm('确定取消此订单吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                    center: true
                }).then(() => {
                    let params = {
                        method: 'POST',
                        orderId: orderId
                    };
                    this.$request(params, "/studentOrder/cancelOrder", () => {
                        this.$message.success(`订单取消成功`);
                        this.getMyOrderData();
                    });
                });
            },
            // 删除订单
            handleDeleteOrder(orderId) {
                this.$confirm('确定删除此订单吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                    center: true
                }).then(() => {
                    let params = {
                        method: 'POST',
                        orderId: orderId
                    };
                    this.$request(params, "/studentOrder/deleteOrder", () => {
                        this.$message.success(`订单删除成功`);
                        this.handleOrderPage(1);
                    });
                });
            },
            // 去支付
            toPay(order) {
                var courseIdStr = order.orderDetail.map(function (obj) {
                    return obj.courseId;
                }).join(",");
                let sumPrice = order.orderDetail.map(cur => cur.coursePrice).reduce((pre, cur) => pre + cur);
                this.outTradeNo = order.orderId;
                this.$request({
                    customerId: this.$util.getUser().loginCode,
                    payType: order.payType,
                    outTradeNo: order.orderId,
                    courseId: courseIdStr,
                    totalFee: sumPrice
                }, "/pay/placeOrder", (res) => {
                    /*支付宝返回数据*/
                    if (order.payType === 2) {
                        this.$message.success("正在进入支付页面...");
                        const div = document.createElement('div');
                        div.innerHTML = res.list[0];
                        document.body.appendChild(div);
                        const punchoutForm = document.getElementsByName("punchout_form");
                        const punchoutInput = punchoutForm[0].childNodes;
                        punchoutInput[3].click();
                    }
                    /*微信返回数据*/
                    if (order.payType === 1) {
                        this.$message.success("请扫描微信支付二维码");
                        this.options.text = res.list[0];
                        /*定时查询订单是否已支付*/
                        this.timer2 = window.setInterval(() => {
                            setTimeout(this.$request({orderId: order.orderId,}, "/masters/mapper/select/customerOrder.queryOrderById", (data) => {
                                if (data.list[0].orderStatus === 5) {
                                    this.$router.push("pay-success");
                                }
                            }, () => {
                            }), 0);
                        }, 3000);
                    }
                })
            },
            // 跳转至课程详情
            toCourseDetail(course) {
                this.$router.push("/course-details?courseId=" + course.courseId);
            },
            // 金额分转元并格式化
            formatOrderAmount(row) {
                return "￥" + this.$util.pennyToYuan(row.orderAmount);
            },
            // 日期格式化
            formatDate(date) {
                let _date = new Date(date);
                return _date.getFullYear() + '-' + (_date.getMonth() + 1) + '-' + _date.getDate();
            },
            // 时间格式化
            formatTime(date) {
                let _date = new Date(date);
                return _date.getHours() + ':' + _date.getMinutes() + ':' + _date.getSeconds();
            },
            // 转换订单状态
            formatOrderStatus(row) {
                let orderStatus = row.orderStatus + "";
                for (let i = 0; i < this.orderStateList.length; i++) {
                    if (orderStatus === this.orderStateList[i].itemVal) {
                        return this.orderStateList[i].itemName;
                    }
                }
                return "-";
            },
            // 付款方式格式化
            formatPayType(payType) {
                for (let i = 0; i < this.payTypeList.length; i++) {
                    if (payType === parseInt(this.payTypeList[i].itemVal)) {
                        return this.payTypeList[i].itemName;
                    }
                }
                return "-";
            },
            // 计算课程总价
            computeAllCoursePrice(order) {
                if (!this.$util.isEmpty(order.orderDetail)) {
                    return this.$util.pennyToYuan(order.orderDetail.map(cur => cur.coursePrice).reduce((pre, cur) => pre + cur));
                } else {
                    return "-";
                }
            },
            // 关闭微信二维码弹窗
            closeQrcode() {
                // this.deleteOrder();
                this.options.text = "";
            },
            deleteOrder() {
                if(!this.$util.isEmpty(this.outTradeNo)){
                    this.$request({outTradeNo: this.outTradeNo}, "/pay/closeOrder");
                }
            }
        },
        beforeRouteLeave(to, from, next) {
            window.clearInterval(this.timer);
            window.clearInterval(this.timer2);
            next();
        }
    }
</script>

<style lang="less">
    .personal-center {
        width: 1200px;
        margin: 0 auto;

        .el-menu {
            border: 0;
        }

        .true-tabs {
            .el-tabs__header {
                display: none;
            }
        }

        .breadcrumb {
            height: 76px;
            .el-breadcrumb__item {
                font-size: 16px;
                line-height: 76px;
            }

        }

        .content {
            background-color: #FFFFFF;
            padding: 20px;
        }

        .form-title {
            font-size: 18px;
            color: #333333;
            line-height: 64px;
        }

        .el-pagination {
            display: flex;
            justify-content: flex-end;
        }

        .el-divider {
            margin: 8px 0;
        }

        .avatar-uploader .el-upload {
            border: 1px dashed #d9d9d9;
            border-radius: 6px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .avatar-uploader .el-upload:hover {
            border-color: #409EFF;
        }

        .avatar-uploader-icon {
            font-size: 28px;
            color: #8c939d;
            width: 64px;
            height: 64px;
            line-height: 64px;
            text-align: center;
        }

        .avatar {
            width: 64px;
            height: 64px;
            display: block;
        }

        /* 留白 */
        .blank {
            height: 150px;
        }

        .none {
            .el-tabs__header {
                display: none;
            }
        }

        /* 过长显示 */
        .text-too-long {
            display: inline-block;
            overflow: hidden;
            -ms-text-overflow: ellipsis;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .qrcode-bg {
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            top: 0;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .qrcode-logo {
            position: absolute;
            top: 50%;
            left: 50%;
            margin-left: -140px;
            margin-top: -180px;

            .el-icon-circle-close {
                float: right;
                cursor: pointer;
                font-size: 30px;
                position: relative;
                top: -20px;
                left: -40px;
                color: #9033CC;
            }

            .el-icon-circle-close:hover{
                color: #5D2385;
            }

            .qrcode-info {
                writing-mode: horizontal-tb;
                writing-mode: vertical-lr;
                letter-spacing: 6px;
                font-size: 25px;
                -webkit-text-fill-color: #fff; /*文字的填充色*/
                -webkit-text-stroke: 1.2px #9033CC;
                font-weight: 900;
                margin-top: -14px;
                margin-left: 5px;
            }

            .qrcode {
                width: 154px;
                height: 154px;
                background-color: #fff;
                padding: 20px;
                border-radius: 20px;
                border: 6px solid #9033CC;
                margin-top: -30px;
                margin-left: 5px;
                z-index: 6;
            }
        }

        .el-tabs__nav-wrap::after {
            z-index: 0;
        }

        .el-table--border::after, .el-table--group::after, .el-table::before {
            z-index: 0;
        }
    }

</style>