<template>
    <div class="home">
        <div style="width: 100%; height: 50px; background-color: #fff; border-top: 1px solid #F5F5F5;">
            <div class="selectList">
                <div class="select-subject">
                    <el-tabs v-model="subjectId">
                        <el-tab-pane label="首页"></el-tab-pane>
                    </el-tabs>
                    <el-tabs v-model="subjectId" @tab-click="selectClass" v-for="(item,index) of subjectList"
                             :key="index">
                        <el-tab-pane :label="item.subjectName" :name="item.subjectId"></el-tab-pane>
                    </el-tabs>
                </div>
                <div class="select-grade">
                    <el-select v-model="gradeId" style="width: 120px" @change="selectClass"
                               @visible-change="showOptions">
                        <el-option label="全部年级" value="" key=""></el-option>
                        <el-option
                                v-for="item in gradeList"
                                :key="item.gradeId"
                                :label="item.gradeName"
                                :value="item.gradeId">
                        </el-option>
                    </el-select>
                </div>
            </div>
        </div>

        <div class="carousel-box" v-if="bannerList.length>0" style="width: 100%"
             :style='{height: bannerImgHeight ? bannerImgHeight+"px" : "500px"}'>
            <el-carousel class="carousel" ref="carousel" arrow="never" @change="carouselChange">
                <el-carousel-item v-for="(item,index) in bannerList" :key="index"
                                  @click="toCourseDetail(item.courseId)">
                    <el-image :src="$getFileUrl+item.adCover" style="width: 100%; height: 100%" fit="cover"
                              @load="justifyImgHeight($event)" @click="toCourseDetail(item.courseId)"></el-image>
                </el-carousel-item>
            </el-carousel>
            <div class="title-box">
                <div v-for="(item,index) in bannerList"
                     :class="'title-item' + (index === nowImgIndex ? ' title-item-active' : '')"
                     @mouseover="setActiveItem(index)" :key="index" @click="toCourseDetail(item.courseId)">
                    <div class="title-index-icon">
                        <el-image :src="require('./../assets/img/banner-active.png')" v-show="index === nowImgIndex"
                                  style="width: 100%;height: 100%;"></el-image>
                    </div>
                    <div class="title-name">{{item.adName}}</div>
                </div>
            </div>
        </div>

        <div class="topic-list">
            <div v-for="(topicItem,topicIndex) in topicList" :key="topicIndex">
                <div class="topic-title">
                    <div class="course-topic">
                        {{topicItem.specialName}}
                        <div class="topic-hot">
                            <el-image :src="require('./../assets/img/xad.png')" fit="cover"
                                      style="height: 100%; width: 100%"/>
                        </div>
                    </div>
                    <div class="course-more" @click="toTopicSelect(topicItem.specialId,topicItem.specialName)">查看更多<i
                            class="el-icon-arrow-right"></i>
                    </div>
                </div>
                <div v-if="topicItem.courseList && topicItem.courseList.length>0" style="display: flex;">
                    <div class="course-list" v-for="(courseItem,courseIndex) in topicItem.courseList"
                         :key="courseIndex">
                        <div class="course-info" v-if="courseIndex<3" @click="toCourseDetail(courseItem.courseId)">
                            <div class="course-image-font">
                                <div class="course-image">
                                    <el-image
                                            :src="$getFileUrl+courseItem.courseCover"
                                            fit="cover"
                                            style="width:100%; height: 100%; border-radius: 10px 10px 0px 0px;"/>
                                </div>
                                <div class="course-state">
                                    <div class="course-remain">
                                        剩余{{courseItem.maxAmount-courseItem.applyAmount}}个名额
                                    </div>
                                    <div class="course-price">￥{{((courseItem.coursePrice)/100).toFixed(2)}}</div>
                                </div>
                            </div>
                            <div class="course-details">
                                <div class="course-detail-title">
                                    【{{courseItem.specialName}}】{{courseItem.courseName}}
                                </div>
                                <div style="display: flex; justify-content: space-between">
                                    <div class="course-detail">
                                        <div class="detail-one">
                                            <div class="course-difficult">难度：</div>
                                            <el-rate v-model="courseItem.halfLevel" disabled
                                                     :colors="rateColors">
                                            </el-rate>
                                        </div>
                                        <div class="detail-two">
                                            {{$util.formatDate(courseItem.courseStart,'MM月dd日')}}-{{$util.formatDate(courseItem.courseEnd,'MM月dd日')}}
                                            {{courseItem.allCourseHour}}课时
                                        </div>
                                        <div class="detail-three">
                                            <div class="course-teachers"
                                                 @click.stop="toTeacherInfo(courseItem.lecturerId)">
                                                <div class="course-teacher-image">
                                                    <el-avatar
                                                            :src="$getFileUrl+courseItem.lecturerAvatar"></el-avatar>
                                                </div>
                                                <div class="course-teacher">
                                                    <div class="course-teacher-name">{{courseItem.lecturerName}}
                                                    </div>
                                                    <div class="course-teacher-type">授课老师</div>
                                                </div>
                                            </div>
                                            <div class="course-teachers"
                                                 @click.stop="toTeacherInfo(courseItem.managerTeacherId)">
                                                <div class="course-teacher-image">
                                                    <el-avatar
                                                            :src="$getFileUrl+courseItem.managerTeacherAvatar"></el-avatar>
                                                </div>
                                                <div class="course-teacher">
                                                    <div class="course-teacher-name">
                                                        {{courseItem.managerTeacherName}}
                                                    </div>
                                                    <div class="course-teacher-type">学习管理师</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else style="width:100%; height: 170px; padding-top: 170px; text-align: center; color: #888">
                    暂无课程
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        name: 'home',
        data() {
            return {
                subjectList: [],
                gradeList: [],
                gradeId: '',
                subjectId: '',
                nowImgIndex: 0,
                bannerList: [],
                topicList: [],
                queryCourseParams: {},
                rateColors: ['#FDC242', '#FDC242', '#FDC242'],
                bannerImgHeight: 0
            }
        },
        created() {
            this.queryTopicList();
            this.querySubjectList();
            this.queryGradeList();
            this.queryBannerList();
        },
        methods: {
            /*banner图高度适应*/
            justifyImgHeight(e) {
                this.bannerImgHeight = e.currentTarget.clientWidth * 0.3
            },
            querySubjectList() {
                this.$request({}, "/masters/mapper/select/subjectList", (data) => {
                    this.subjectList = data.list;
                }, () => {
                });
            },
            queryGradeList() {
                this.$request({}, "/masters/mapper/select/gradeList", (data) => {
                    this.gradeList = data.list;
                }, () => {
                });
            },
            /*年级下拉框*/
            showOptions(isShow) {
                if (isShow === true) {
                    this.gradeId = '请选择年级';
                } else {
                    this.gradeId = ''
                }
            },
            /*跳转到课程筛选*/
            selectClass() {
                this.$router.push({
                    name: 'class-select',
                    query: {"gradeId": this.gradeId, "subjectId": this.subjectId}
                })
            },
            toTopicSelect(specialId, specialName) {
                this.$router.push({
                    name: 'class-select-topic',
                    query: {"specialId": specialId, "specialName": specialName}
                })
            },
            toCourseDetail(courseId) {
                this.$router.push({
                    name: 'course-details',
                    query: {"courseId": courseId}
                })
            },
            toTeacherInfo(teacherId) {
                this.$router.push({
                    name: 'teacher-info', query: {"teacherId": teacherId}
                })
            },
            /*轮播图切换*/
            carouselChange(index) {
                this.nowImgIndex = index;
            },
            /*轮播图切换*/
            setActiveItem(index) {
                this.$refs.carousel.setActiveItem(index);
            },
            queryBannerList() {
                this.$request({page: 1, limit: 10}, "/masters/mapper/select/queryHomeBanner", (data) => {
                    this.bannerList = data.list;
                }, () => {
                });
            },
            queryTopicList() {
                this.$request({}, "/masters/mapper/select/selectTopicList", (data) => {
                    let now = 0;
                    for (let [index, item] of data.list.entries()) {
                        this.$request({specialId: item.specialId}, "/masters/mapper/select/queryCourseList", (res) => {
                            data.list[index].courseList = res.list;
                            now++;
                            if (now === data.list.length) {
                                this.topicList = data.list;
                            }
                        }, () => {
                            now++;
                        });
                    }
                }, () => {
                });
            }
        }
    }
</script>

<style lang="less">
    .home {

        .selectList {
            height: 50px;
            line-height: 50px;
            width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;

            .select-subject {
                display: flex;

                .el-tabs__item {
                    font-size: 16px;
                    height: 16px;
                    line-height: 16px;
                    margin-right: 30px;
                }

                .el-tabs__item:hover {
                    color: #5D2283;
                }

                .el-tabs__active-bar {
                    height: 4px;
                    border-radius: 2px;
                }

                .el-tabs__nav-wrap::after {
                    background-color: transparent;
                }
            }

            .select-grade {

            }
        }

        .carousel-box {
            height: 500px;
            position: relative;

            .carousel {
                position: absolute;
                height: 100%;
                width: 100%;
                top: 0;
                left: 0;

                .el-carousel__container {
                    height: 100%;
                    width: 100%;
                }
            }

            .title-box {
                position: absolute;
                right: 15%;
                top: 50%;
                transform: translateY(-50%);
                z-index: 10;
                padding: 20px 20px 20px 5px;
                background-color: rgba(0, 0, 0, 0.6);

                .title-item {
                    color: #fff;
                    height: 36px;
                    line-height: 36px;
                    display: flex;

                    .title-index-icon {
                        width: 20px;
                        height: 20px;
                        position: relative;
                        top: 5px;
                    }

                    .title-name {
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        width: 230px;
                    }
                }

                .title-item-active {
                    color: #3FD987;
                }
            }
        }

        .carousel-box:hover {
            cursor: pointer;
        }

        .topic-list {
            width: 1200px;
            margin: 0px auto;
            padding-top: 30px;

            .no-class {
                text-align: center;
                height: 368px;
                line-height: 368px;
                color: #555;
            }

            .topic-title {
                display: flex;
                justify-content: space-between;
                height: 31px;
                line-height: 31px;

                .course-topic {
                    font-size: 24px;
                    display: flex;

                    .topic-hot {
                        width: 31px;
                        height: 31px;
                    }
                }

                .course-more {
                    color: #333333;
                }

                .course-more:hover {
                    cursor: pointer;
                    color: #5D2283;
                }
            }

            .course-list {
                .course-info {
                    width: 368px;
                    height: 360px;
                    margin: 17px 48px 40px 0px;
                    background-color: #fff;
                    font-size: 14px;
                    border-radius: 10px;
                    cursor: pointer;

                    .course-image-font {
                        position: relative;
                        height: 207px;

                        .course-image {
                            width: 368px;
                            height: 207px;
                            position: absolute;
                            left: 0;
                            right: 0;
                        }

                        .course-state {
                            width: 348px;
                            height: 40px;
                            line-height: 40px;
                            background-color: rgba(0, 0, 0, 0.4);
                            display: flex;
                            justify-content: space-between;
                            padding: 0px 10px;
                            position: absolute;
                            bottom: 0;

                            .course-remain {
                                color: #fff;
                                font-size: 14px;
                            }

                            .course-price {
                                color: #FD4D4D;
                                font-weight: 600;
                                font-size: 18px;
                            }
                        }
                    }

                    .course-details {

                        .course-detail-title {
                            margin: 8px 10px;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }

                        .course-detail {

                            .detail-one {
                                display: flex;
                                color: #8F8E94;
                                margin: 5px 10px;


                                .course-difficult {
                                    .el-rate__icon {
                                        margin-right: 0;
                                    }
                                }
                            }

                            .detail-two {
                                color: #808080;
                                padding: 5px 10px;
                            }

                            .detail-three {
                                display: flex;
                                margin: 5px 10px;

                                .course-teachers {
                                    display: flex;
                                    padding: 5px 25px 10px 0;

                                    .course-teacher-image {
                                        width: 50px;
                                        height: 40px;
                                    }

                                    .course-teacher {
                                        line-height: 20px;

                                        .course-teacher-name {

                                        }

                                        .course-teacher-type {
                                            color: #A8A8A8;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
</style>