<template>
    <div class="bodyContent">
        <div class="content">
            <div class="title">
                <el-breadcrumb separator-class="el-icon-arrow-right">
                    <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/class-select-topic', query:{specialId:courseInformationlist.specialId, specialName:courseInformationlist.specialName}}">{{courseInformationlist.specialName}}</el-breadcrumb-item>
                    <el-breadcrumb-item>{{courseInformationlist.courseName}} ({{courseInformationlist.courseStart}})
                    </el-breadcrumb-item>
                </el-breadcrumb>
            </div>
            <div class="course-information">
                <div class="courseIformationLeft">
                    <el-image v-if="courseInformationlist.courseCover !== undefined" :src="$getFileUrl+courseInformationlist.courseCover" style="height: 100%; width: 100%" lazy/>
                </div>
                <div class="courseIformationRight">
                    <ul class="courseIformationRightUl">
                        <li>
                            【{{courseInformationlist.courseName}}{{courseInformationlist.specialName}}】{{courseInformationlist.gradeName}}{{
                            courseInformationlist.subjectName}}{{courseInformationlist.specialName}}
                            ({{courseInformationlist.courseStart}})
                        </li>

                        <li>
                            <p class="RightUlP">
<!--                                <span>{{courseInformationlist.applyAmount}} 学过</span>-->
                                <span class="difficulty">
                                    <span>难度</span>
                                <span class="dificlty-img">
                                 <el-rate v-model="courseInformationlist.hardLevel" disabled  > </el-rate>
                                </span>
                             </span>
                                <span class="teacher"> 授课老师：{{courseInformationlist.lecturerName}}</span>
                                <span>班主任老师: {{courseInformationlist.managerTeacherName}}</span>
                            </p>

                        </li>
                        <li class="money"><span>￥ {{(courseInformationlist.coursePrice/100).toFixed(2)}} </span></li>
                    </ul>
                    <div class="courseIformationBottom">
                        <div v-if="new Date() <= new Date(courseInformationlist.courseStart)  &&  courseInformationlist.maxAmount>courseInformationlist.applyAmount" class="courseIformationBottomLeft manFullStyle "  @click="signUpNow(courseInformationlist)">立即报名</div>
                        <div   class="courseIformationBottomLeft manNotFullStyle " v-else-if="courseInformationlist.maxAmount<=courseInformationlist.applyAmount" >名额已满 </div>
                        <div  v-else  class="courseIformationBottomLeft manNotFullStyle " >报名结束 </div>
                        <div class="courseIformatinBottomRight ">
                            <ul style="cursor: pointer">
                                <li @click="addCart(courseInformationlist)"><img src="../assets/img/car.png"><span>{{courseInformationlist.isAddCart===1?'已加入选课单':(courseInformationlist.maxAmount-courseInformationlist.applyAmount>0?'加入选课单':'暂无剩余名额')}}</span></li>
                                <li><img src="../assets/img/play.png"><span>免费试听</span></li>
                                <li @click="abilityTest"><img src="../assets/img/edit.png"><span>能力测试</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-card">
                <div class="border-card-left">
                    <el-tabs type="border-card">
                        <el-tab-pane label="介绍">
                            <div class="border-card-content">
                                <el-scrollbar style="height: 100%">
                                    <div  v-html="courseInformationlist.courseIntroduce" class="ql-editor">  </div>
                                </el-scrollbar>
                            </div>

                        </el-tab-pane>
                        <el-tab-pane label="课程大纲">
                            <div class="border-card-content">
                                <el-scrollbar style="height: 100%">
                                    <div  v-html="courseInformationlist.courseOutline" class="ql-editor">  </div>
                                </el-scrollbar>
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="常见问题">
                            <div class="border-card-content">
                                <el-scrollbar style="height: 100%">
                                    <div  v-html="courseInformationlist.commonProblem" class="ql-editor">  </div>
                                </el-scrollbar>
                            </div>
                        </el-tab-pane>
                    </el-tabs>
                </div>
                <div class="border-card-right">
                    <div class="border-card-right-logo">
                        <div class="background-logo">
                            <img src="../assets/img/backg.png">
                            <div class="LogoTop">
                                <div class="Logo"><el-image  v-if="teacherInformationlist.avatar !== undefined" :src="$getFileUrl+teacherInformationlist.avatar"  @click="teacherdetails(teacherId)" ></el-image></div>
                                <span>授课老师: {{teacherInformationlist.realName}}</span>
                            </div>
                        </div>
                        <div class="logo-bottom" v-if="!this.$util.isEmpty(teacherInformationlist.briefIntroduction)" >
                            <el-scrollbar style="height: 100%">
                                <div v-html="teacherInformationlist.briefIntroduction" class="ql-editor"></div>
                            </el-scrollbar>
                        </div>
                        <div class="no-logo-bottom" v-else> 暂无介绍</div>

                    </div>
                    <div class="borderCardRightEvaluate">
                        <span class="evalu">评论</span>
                        <div class="evalucenter" v-if="courseEvaluatelist.length>0">
                            <el-scrollbar style="height:100%">
                                <div  style="margin-right: 5px"  v-for="(item,indexId) in courseEvaluatelist" :key="indexId" >
                                    <div   class=" Evaluate " >
                                        <div class="evaluateLogin">
                                            <el-avatar icon="el-icon-user-solid" :src="$getFileUrl+item.avatar"></el-avatar>
                                        </div>
                                        <div class="evaluateDetial" >
                                            <ul>
                                                <li><span class="evaluateName">{{item.nickName}}</span><span>{{item.operateTime}}</span></li>
                                                <li>
                                                    <span>学习{{item.finishedCourseHour}}个课时评价</span>
                                                    <span class="evaluatedificltyImg">
                                                   <el-rate v-model="item.evaluateNumber" disabled  > </el-rate>
                                                     </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="detial">
                                        <div>{{item.evaluateContent}} </div>
                                    </div>
                                </div>
                            </el-scrollbar>
                        </div>
                        <div class="noEvaluate" v-else >
                            暂无评论
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 能力测验弹框-->
        <el-dialog
                :title="courseInformationlist.courseName+'能力测验'"
                :visible.sync="status.abilityTestDialog"
                width="30%"
                @closed="abilityTestDialoghandleClose"
        >
            <ul class="abilityTestRule">
                <li class="abilityTestOne">1、只有一次机会，请认真答题</li>
                <li>2、测试时长为60分钟,请准备好纸笔和安静的环境</li>
                <li>3、系统将根据测试结果给出报名建议</li>
                <li>4、选择合适自己的班型才能有最好的辅导效果.请独立作答</li>
            </ul>
            <span slot="footer" class="dialog-footer dialog-footerr" center>
               <el-button type="primary" @click="answerSheetDialogMethod" :loading="status.ubmitSompetencyTestRequest">开始答题</el-button>
            </span>
        </el-dialog>
        <!-- 答题卡弹框-->
        <el-dialog custom-class="dialogClass"
                   :title="testPaperList.testPaperName"
                   :visible.sync="status.answerSheetDialog"
                   :before-close="answerSheetDialoghandleClose"
                   width="1000px">
            <div class="conten">
                <div class="homeword-img">
                    <el-scrollbar style="height:100%">
                        <div class="fileimg" v-for="(item,indexId) in  testPaperFileList" :key="indexId">
                            <img v-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.jpg' ||  item.file_url.substring(item.file_url.lastIndexOf('.'))=='.png' || item.file_url.substring(item.file_url.lastIndexOf('.'))==='.jpeg' " :src="$getFileUrl+item.file_url">
                            <div class="pdf" v-else-if="item.file_url.substring(item.file_url.lastIndexOf('.')) ==='.pdf'">
                                <div  style="width:200px;margin-top: 80px;margin-left: 20px">
                                    <!--    上一页-->
                                    <span @click="changePdfPage(0)" >上一页</span>
                                    {{currentPage}} / {{pageCount}}
                                    <!--下一页-->
                                    <span  @click="changePdfPage(1)">下一页</span>
                                </div>
                                <pdf ref="myPDF"
                                     :src="$getFileUrl+item.file_url"
                                     :page="currentPage"
                                     @num-pages="pageCount=$event"
                                     @page-loaded="currentPage=$event"
                                     @loaded="loadPdfHandler"
                                >
                                </pdf>
                            </div>
                            <div v-else style="height:700px;width: 99%;position: relative">
                                <div style="position: absolute;width: 100%;height: 47px;background-color: #ffffff;margin-top: 48px;margin-left: 2px"></div>
                                <iframe  style="height:650px;min-width: 100%" :src="'https://view.officeapps.live.com/op/view.aspx?src=https://mshjy-1301481450.cos.ap-chengdu.myqcloud.com'+item.file_url" ></iframe>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>

                <div class="homeword-conten">
                    <el-scrollbar style="height:100%">
                        <p class="bigTitle" v-if="answerRes.length>0">答题卡</p>
                        <p v-else style="height: 100px;margin:auto;line-height: 100px;color: #ccc;text-align: center">暂无题目</p>
                        <template v-for="(subject,index) in answerRes">
                            <!-- 选择题-->
                            <div v-if="subject.topic_type === 1" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span class="titlepadding">选择题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                        <ol class="choice-ol">
                                            <li v-for="(item,indexId) in subject.themeList" :key="indexId">
                                                <span class="theme-class">{{item.theme_number}}.</span>
                                                <span v-if="item.chose_type===1"
                                                      style="font-size: 12px;color: #CCCCCC;margin-right: 10px">(单选)</span>
                                                <span v-else style="font-size: 12px;color: #CCCCCC;margin-right: 10px">(多选)</span>
                                                <el-radio-group v-model="item.studentAnswer" v-if="item.chose_type===1">
                                                    <el-radio-button  v-for="choseitem in item.option" :label="choseitem"  :key="choseitem">{{choseitem}}</el-radio-button>
                                                </el-radio-group>
                                                <el-checkbox-group v-model="item.studentAnswer" v-else>
                                                    <el-checkbox-button v-for="choseitem in item.option" :label="choseitem"  :key="choseitem"> {{choseitem}} </el-checkbox-button>
                                                </el-checkbox-group>
                                            </li>
                                        </ol>
                                </div>
                            </div>
                            <!-- 判断题-->
                            <div v-if="subject.topic_type === 3" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span class="titlepadding">判断题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                    <el-form>
                                        <ol type="1" class="choice-ol">
                                            <li v-for="(item,indexId) in subject.themeList" :key="indexId">
                                                <span class="theme-class">{{item.theme_number}}.</span>
                                                <span class="judge">
                                                <template>
                                                  <el-radio-group v-model="item.studentAnswer">
                                                    <el-radio label="YES">对</el-radio>
                                                    <el-radio label="NO">错</el-radio>
                                                  </el-radio-group>
                                                </template>
                                            </span>
                                            </li>
                                        </ol>
                                    </el-form>
                                </div>
                            </div>
                            <div v-if="subject.topic_type === 5" class="question-type" :key="index">
                                <div class="title" v-if="!$util.isEmpty(subject.themeList)"><span>{{subject.topic_index}},<span class="titlepadding">连线题</span></span><span></span>
                                </div>
                                <div class="ability-test-content">
                                    <el-form :model="subject" ref="connectionForm" >
                                        <el-form-item v-for="(item,indexId) in subject.themeList" :label="`${item.theme_number}`" :key="indexId" >
                                            <el-input style="width:220px" v-model="item.studentAnswer" @blur.prevent="AnswerRules(item.studentAnswer)"  placeholder=" 例如：1-2,2-3"></el-input>
                                        </el-form-item>
                                    </el-form>
                                </div>
                            </div>
                        </template>
                        <!--  提交-->
                        <div class="question-type">
                            <div style="padding-left: 220px">
                                <el-button type="primary" @click="submitTestPaper" :loading="status.ubmitSompetencyTestRequest" v-if="answerRes.length>0">提交</el-button>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
            </div>
        </el-dialog>

    </div>

</template>


<script>
    import 'quill/dist/quill.core.css';
    import 'quill/dist/quill.snow.css';
    import 'quill/dist/quill.bubble.css';
    import pdf from 'vue-pdf'
    export default {
        name: "course-details",
        components: {
            pdf
        },
        data() {
            return {
                //pdf  在线预览  翻页
                currentPage: 0, // pdf文件页码
                pageCount: 0, // pdf文件总页数
                status: {
                    abilityTestDialog: false,
                    answerSheetDialog: false,
                    ubmitSompetencyTestRequest:false,
                },
                teacherId: "",
                answerRes: [],
                testPaperFileList:[],
                testPaperList:[],
                courseInformationlist: {},
                teacherInformationlist: {},
                courseEvaluatelist: [],
                form: {
                    checkboxGroup1: [],
                    completionValue: '',
                    radio: '',
                    matching: '',
                    answerQuestions: ''
                },

                answerQuestionsSubmit: {
                    answerCardId: "",
                    testPaperId: "",
                    studentId: "",
                    ability: 1,
                    //填空题
                    list: [],
                },
            //能力测验
                abilityTestRequest:{
                studentId: "",
                courseId: "",
                teacherId: "",
                teacherName: "",
                ability: "1"
            },
            }
        },
        created() {
            let courseId = this.$route.query.courseId;
            this.coursedetails(courseId)
        },
        methods: {
            // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
            changePdfPage (val) {
                // console.log(val)
                if (val === 0 && this.currentPage > 1) {
                    this.currentPage--
                    // console.log(this.currentPage)
                }
                if (val === 1 && this.currentPage < this.pageCount) {
                    this.currentPage++
                    // console.log(this.currentPage)
                }
            },
            // pdf加载时
            loadPdfHandler (e) {
                console.log(e)
                this.currentPage = 1 // 加载的时候先加载第一页
            },
            coursedetails(courseId) {
                let user = this.$util.getUser();
                let studentId = '';
                if (!this.$util.isEmpty(user)){
                    studentId = user.studentId
                }
                //课程信息
                this.$request({courseId: courseId,studentId:studentId}, "/masters/courseInformation", res => {
                    res.list[0].hardLevel=(res.list[0].hardLevel)/2
                    this.abilityTestRequest.teacherName=res.list[0].lecturerName
                    this.abilityTestRequest.teacherId=res.list[0].lecturerId
                    this.abilityTestRequest.courseId=res.list[0].courseId
                    this.courseInformationlist = res.list[0]
                    // 老师的介绍
                    this.$request({teacherId:this.abilityTestRequest.teacherId}, "/masters/teacherInformation", res => {
                        this.teacherId = res.list[0].teacherId
                        this.teacherInformationlist = res.list[0]
                    })
                })
                //  课程的评价
                this.$request({courseId:courseId}, "/masters/courseEvaluate", res => {
                    this.courseEvaluatelist = res.list
                })



            },
            // 能力测验弹框
            abilityTest() {

                this.status.abilityTestDialog = true
            },
            //能力测验答题卡弹框
            answerSheetDialogMethod() {
            this.status.ubmitSompetencyTestRequest=true;
                this.abilityTestRequest.studentId = this.$util.getUser().studentId;
                let params={...this.abilityTestRequest}
                this.$request(params, "/masters/course/queryCourseAbiTestPaper", res => {
                    this.status.abilityTestDialog = false;
                    this.status.answerSheetDialog = true;
                    this.status.ubmitSompetencyTestRequest=false;
                    let answerRes=res.list[0].list
                    this.testPaperFileList=res.list[0].fileList
                        this.testPaperList= res.list[0].testPaper
                    answerRes.map(item=>{
                        if(item.topic_type=== 1){
                            item.themeList.map(item=>{
                                item.studentAnswer=[]
                                if (!this.$util.isEmpty(item.option)) {
                                    item.option = item.option.replace(/；/ig, ';')
                                    item.option = item.option.split(';')
                                    for (let i = 0; i < item.option.length; i++) {
                                        item.option[i] = item.option[i].split(':')[0]
                                    }
                                }
                            })
                        }

                    })
                    this.answerRes=answerRes
                    this.answerQuestionsSubmit.answerCardId = res.list[0].testPaper.answer_card_id
                    this.answerQuestionsSubmit.testPaperId = res.list[0].testPaper.testPaperId
                    this.answerQuestionsSubmit.studentId = res.list[0].testPaper.student_id
                },()=>{
                    this.status.ubmitSompetencyTestRequest=false;
                    this.status.abilityTestDialog=false
                })
            },
            //连线题  验证规则
            AnswerRules(itemAnswer){
                if(!this.$util.isEmpty(itemAnswer)){
                    itemAnswer = itemAnswer + ",";
                    let answerReg = /^(([1-9]?\d|100)[-]([1-9]?\d|100)+[,|\uff0c])+$/;
                    console.log(itemAnswer)
                    if (!answerReg.test(itemAnswer)) {
                        this.$message.warning('匹配之间以短横线分隔,每个答案以逗号分隔,例如:1-2,2-1');
                    }
                }

            },
            //提交试卷答题卡
            submitTestPaper() {
                this.answerQuestionsSubmit.list=[];
                this.status.ubmitSompetencyTestRequest=true;
                let parmse = {...this.answerQuestionsSubmit};
                let answer=this.answerRes
                // 选择题
                answer.map(item=> {
                    if (item.topic_type === 1) {
                        item.themeList.map(item => {
                            if (item.studentAnswer.constructor === Array) {
                                if (item.studentAnswer.length > 1) {
                                    item.studentAnswer = item.studentAnswer.join(',')
                                } else if (item.studentAnswer.length === 1) {
                                    item.studentAnswer = item.studentAnswer.toString()
                                } else {
                                    item.studentAnswer = " ";
                                }
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            // console.log( obj.studentAnswer)
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                })
                answer.map(item=> {
                    if (item.topic_type === 2) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                })
                answer.map(item=> {
                    if (item.topic_type === 3) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer =  " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer;
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                })
                answer.map(item=> {
                    if (item.topic_type === 4) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = " ";
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = (item.studentAnswer).replace(/，/ig,',');
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                })
                answer.map(item=> {
                    if (item.topic_type === 5) {
                        item.themeList.map(item => {
                            if (this.$util.isEmpty(item.studentAnswer)) {
                                item.studentAnswer = '';
                            }
                            let obj = {};
                            obj.cardThemeId = item.card_theme_id;
                            obj.studentAnswer = item.studentAnswer.replace(/，/ig,',');
                            this.answerQuestionsSubmit.list.push(obj);
                        })
                    }
                })

                this.$request(parmse, "/masters/course/automaticScoring", res => {
                    this.status.answerSheetDialog = false;
                    this.$message.success( res.message);
                    this.status.ubmitSompetencyTestRequest=false;
                }, (res) => {
                    this.$message.error(res)
                    this.status.answerSheetDialog = false
                    this.status.ubmitSompetencyTestRequest=false;
                })

            },
            //答题卡确认关闭
            abilityTestDialoghandleClose() {
                this.status.ubmitSompetencyTestRequest=false

            },
            answerSheetDialoghandleClose(done) {
                this.$confirm('确认关闭？')
                    .then(() => {
                        done();
                    })
                    .catch(() => {
                    });
            },
            //立即支付
            signUpNow(courseInformationlist){
                if(this.$util.isEmpty(this.$util.getUser())){
                    console.log("请登录")
                    this.$util.openLogin();

                }else{
                    let isAddCart = courseInformationlist.isAddCart;
                    let maxAmount = courseInformationlist.maxAmount;
                    let applyAmount = courseInformationlist.applyAmount;
                    let courseEnd = courseInformationlist.courseEnd
                    let courseStart = courseInformationlist.courseStart
                    let now = this.$util.getNowDate()
                    if (maxAmount-applyAmount<=0&&isAddCart===2){
                        this.$message.warning("该课程暂无剩余名额");
                        return;
                    }
                    if (courseStart <= now && now <= courseEnd){
                        this.$message.warning('课程已开始');
                        return;
                    }
                    if (courseEnd < now) {
                        this.$message.warning('课程已结束');
                        return;
                    }
                    this.$request({courseId:courseInformationlist.courseId}, "/masters/SignUpNow", res => {
                        if (res.flag===200){
                            sessionStorage.setItem('course', JSON.stringify(this.courseInformationlist));
                            sessionStorage.removeItem('order');
                            sessionStorage.removeItem('courseList');
                            this.$router.push("pay");
                        }
                    })

                }

            },
            //    跳转到老师详情页面
            teacherdetails(teacherId) {
                this.$router.push({
                    name: 'teacher-info',
                    query: {"teacherId": teacherId}
                })
            },
            //添加购物车
            addCart(courseInformationlist){
                if(new Date() >= new Date(courseInformationlist.courseStart)){
                    this.$message.info("报名已结束")
                }
                let isAddCart = courseInformationlist.isAddCart;
                let maxAmount = courseInformationlist.maxAmount;
                let applyAmount = courseInformationlist.applyAmount;
                let courseId = this.$route.query.courseId;
                let user = this.$util.getUser();
                let studentId = user.studentId;
                if (maxAmount-applyAmount<=0&&isAddCart===2){
                    this.$message.warning("该课程暂无剩余名额");
                    return;
                }
              if (isAddCart===1){
                //删除购物车
                this.$request({courseId:courseId,studentId:studentId}, "/masters/mapper/select/deleteStudentCart", () => {
                  this.$message.success("取消成功");
                  this.courseInformationlist.isAddCart = 2;
                })
              }else {
                //添加购物车
                this.$request({courseId:courseId}, "/studentCart/insertStudentCart", () => {
                  this.$message.success("添加成功");
                  this.courseInformationlist.isAddCart = 1;
                })
              }
            }
        }
    }
</script>
<style lang="less" scoped>
    .border-card-left{
    .el-tabs--border-card>.el-tabs__header .el-tabs__item{
        border: none;
    }
    .el-tabs--border-card>.el-tabs__header .el-tabs__item{
        border: none;
        background: #F6F2F7;
    }
    .el-tabs--border-card{
        border: none;
        box-shadow:none;
    }
    }

</style>

<style lang="less" >
    ul {
        list-style: none;
    }


    .bodyContent {
        width: 100%;
        background: #F6F2F7;


        .content {
            width: 1200px;
            padding: 0 0 100px 0;
            margin: auto;

            .el-breadcrumb__item {
                font-size: 16px;
                line-height: 76px;
            }

            .border-card {
                display: flex;
                justify-content: space-between;
                margin-top: 33px;
                .el-tabs__nav-scroll {
                    background: #F6F2F7;
                }

                .el-tabs__item {
                    height: 40px;
                    line-height: 40px;
                }

                .border-card-left {
                    width: 800px;
                    background: #ffffff;
                    font-size: 16px;
                    color: #333333;
                    .border-card-content {
                        height: 500px;
                        .el-scrollbar__thumb {
                            display: none;
                        }

                        .el-scrollbar__wrap {
                            overflow-x: hidden;
                            overflow-y: auto;
                        }
                    }
                }

                .border-card-right {
                    width: 380px;
                    margin-top: 40px;

                    .borderCardRightEvaluate {
                        margin-top: 15px;
                        background: #ffffff;
                        overflow: hidden;
                        padding-bottom: 20px;
                        .noEvaluate{
                            height: 100px;
                            text-align: center;
                            line-height: 100px;
                            color: #CCCCCC;
                        }

                        .detial {
                            width: 88%;
                            margin:8px auto;
                            height: 93px;
                            background: #F5F5F5;
                            border-radius: 6px;

                            div {

                                padding: 20px;
                                font-size: 14px;
                                color: #666666;
                            }
                        }

                        .evalu {
                            padding: 10px 15px;
                            display: block;
                            font-size: 16px;
                            color: #333333;
                            border: solid 1px #F5F5F5;
                        }

                        .evalucenter {
                            height: 250px;
                            margin-top: 5px;
                            /*查看更多评价 滚动条样式*/
                            .el-scrollbar__thumb {
                                display: none;
                            }

                            .el-scrollbar__wrap {
                                overflow-x: hidden;
                                overflow-y: auto;
                            }
                            .Evaluate-border{
                                border-bottom: solid 1px #F5F5F5;
                            }
                            .Evaluate {
                                height: 50px;
                                padding: 8px 0;
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                width: 85%;
                                margin: auto;
                                .evaluateLogin {
                                    width: 50px;
                                    height: 50px;
                                    overflow: hidden;
                                    border-radius: 50%;
                                    .el-avatar {
                                        width: 100%;
                                        height: 100%;
                                        font-size: 24px;
                                        line-height: 50px;

                                    }
                                }

                                .evaluateDetial {
                                    width: 85%;
                                    height: 40px;
                                    margin-left: 8px;
                                    ul {
                                        width: 100%;
                                        height: 100%;
                                        display: flex;
                                        flex-flow: column;
                                        justify-content: space-around;

                                        li {
                                            display: flex;
                                            justify-content: flex-start;
                                            align-items: center;

                                            .evaluateName {
                                                font-size: 16px;
                                                color: #333333;
                                                padding-right: 5px;
                                            }

                                            span {
                                                padding: 0;
                                                font-size: 12px;
                                                color: #808080;
                                            }

                                            .evaluatedificltyImg {
                                                margin-left: 5px;

                                                .el-rate {

                                                    display: flex;
                                                    justify-content: flex-start;

                                                    span {
                                                        width: 15px;
                                                    }
                                                }
                                            }

                                        }
                                    }


                                }
                            }
                        }


                    }

                    .border-card-right-logo {
                        width: 100%;
                        background: #FFFFFF;

                        .background-logo {
                            width: 100%;
                            height: 214px;
                        }

                        .LogoTop {
                            margin-top: -200px;
                            display: flex;
                            flex-flow: column;
                            align-items: center;
                            text-align: center;

                            .Logo {
                                width: 108px;
                                height: 108px;
                                overflow: hidden;
                                margin: 20px 0 10px 0;
                                border-radius: 50%;

                                .el-image {
                                    width: 100%;
                                    height: 100%;
                                }
                            }
                        }

                        .logo-bottom {
                            height: 105px;
                            padding: 15px 17px;
                            font-size: 14px;
                            color: #333333;
                            margin: auto;
                            img{
                                width: 50px;
                                height: 50px;
                            }

                            .el-scrollbar__thumb {
                                display: none;
                            }

                            .el-scrollbar__wrap {
                                overflow-x: hidden;
                                overflow-y: auto;
                            }
                        }
                        .no-logo-bottom{
                            height: 105px;
                            padding: 15px 17px;
                            font-size: 14px;
                            line-height: 89px;
                            color: #CCCCCC;
                            text-align: center;

                        }
                    }
                }
            }

            .title {
                width: 60%;
                height: 76px;
                display: flex;
                align-items: center;
                color: #212121;
            }

            .course-information {
                width: 100%;
                height: 196px;
                background: #FFFFFF;
                display: flex;
                justify-content: flex-start;
                align-items: center;

                .courseIformationLeft {
                    width: 270px;
                    height: 150px;
                    margin: 0 35px;

                    img {
                        width: 100%;
                        height: 100%;
                    }
                }

                .courseIformationRight {
                    width: 50%;
                    height: 150px;
                    display: flex;
                    flex-flow: column;
                    justify-content: space-between;

                    .courseIformationBottom {
                        width: 85%;
                        display: flex;
                        justify-content: space-between;
                        align-items: flex-end;

                        .courseIformationBottomLeft {
                            width: 184px;
                            height: 56px;
                            text-align: center;
                            line-height: 56px;
                            cursor: pointer;
                        }

                        .manFullStyle {
                            font-size: 24px;
                            color: #FEFEFE;
                            background: #FD902D;
                        }

                        .manNotFullStyle {
                            background: #CCCCCC;
                            color: #808080;
                            font-size: 24px;

                        }

                        .courseIformatinBottomRight {
                            display: flex;
                            align-items: flex-end;
                            height: 30px;

                            ul {
                                list-style: none;
                                display: flex;
                                justify-content: space-between;
                                align-items: flex-end;
                                color: #A366CC;
                                font-size: 16px;

                                li {
                                    display: flex;
                                    align-items: center;
                                    padding-left: 10px;

                                    span {
                                        padding-left: 5px;

                                        img {
                                            width: 17px;
                                            height: 17px;
                                        }
                                    }

                                }
                            }

                        }
                    }

                    .courseIformationRightUl {
                        list-style: none;
                        color: #808080;
                        font-size: 14px;

                        .money {
                            padding-left: 5px;
                            font-size: 24px;
                            color: #FD5050;
                        }

                        .RightUlP {
                            padding: 2px 0;
                            display: flex;
                            justify-content: flex-start;
                            align-items: center;

                            .teacher {
                                padding-right: 7px;
                            }

                            span {
                                margin-left: 5px;
                            }

                            .difficulty {
                                display: inline-block;
                                display: flex;
                                justify-content: flex-start;

                                .dificlty-img {
                                    padding-right: 7px;

                                    span {
                                        height: 15px;
                                        width: 15px;
                                        padding: 0;
                                        margin: 0;
                                    }
                                }

                            }
                        }

                    }
                }
            }
        }

        .dialog-footerr {
            display: flex;
            justify-content: center;
        }

        .el-dialog__body {
            padding: 10px 0 20px 0;
        }

        .abilityTestRule {
            padding: 0 38px;

            .abilityTestOne {
                color: #FD4D4D;
            }

            li {
                padding: 3px 0;
            }

        }
    }

    /* ==========答题卡样式==========*/
    .dialogClass {
        border-radius: 10px;
        .el-scrollbar__thumb {
            display: none;
        }

        .el-scrollbar__wrap {
            overflow-x: hidden;
            overflow-y: auto;
        }

        .el-dialog__body {
            padding: 0px 20px 30px;
            color: #606266;
            font-size: 14px;
            word-break: break-all;
        }
    }



    .conten {
        display: flex;
        justify-content: space-between;

        .homeword-img {
            width: 778px;
            height: 606px;
            background-color: #ffffff;
            border-right: solid 1px #e4e7ed;
            box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 12px 0px;
            overflow: hidden;
            cursor: pointer;
            .fileimg {
                width: 650px;
                height: 606px;
                img {
                    max-width: 100%;
                    height: 100%;
                }
            }
        }

        .homeword-conten {
            width: 384px;
            height: 606px;
            background-color: #ffffff;
            border-right: solid 1px #e4e7ed;
            box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 12px 0px;
            padding: 0 0 0 30px;

            .bigTitle {
                padding: 10px 0;
            }

            .question-type {
                width: 100%;
                padding-bottom: 20px;

                .title {
                    color: #333333;
                    font-size: 16px;

                    .titlepadding {
                        padding: 0 8px;
                    }
                }

                .ability-test-content {
                    padding-top: 15px;

                    .choice-ol {
                        list-style: none;

                        li {
                            padding: 0 0 15px 0;
                            display: flex;
                            justify-content: flex-start;
                            align-items: center;

                            .theme-class {
                                display: block;
                                width: 25px;
                                padding-right: 2px;
                            }
                        }
                    }

                    ul {
                        width: 100%;
                        display: flex;
                        justify-content: flex-start;
                        flex-wrap: wrap;
                        align-items: center;

                        li {
                            width: 100%;
                            padding-right: 5px;
                            list-style-type: decimal;
                            list-style-position: inside;
                            padding-bottom: 10px;

                            .judge {
                                padding: 0 90px 0 10px;
                            }

                            .el-checkbox-group {
                                padding-left: 10px;
                                width: 195px;
                                display: inline-block;
                            }

                            .el-radio-group {
                                padding-left: 10px;
                                width: 195px;
                                display: inline-block;
                            }

                            .el-input {
                                padding-left: 5px;
                            }


                        }
                    }
                }
            }
        }
    }


</style>