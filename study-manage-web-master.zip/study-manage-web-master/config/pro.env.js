/**
 * @description
 * @author mgLuoBo
 * @createTime 2019/7/25 0025 9:34
 */
// 生产环境
module.exports = {
    NODE_ENV: '"production"',
    hostUrl: 'http://10.168.1.200:9000'
};