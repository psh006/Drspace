/**
 * @description 全局公用函数
 * @author mgLuoBo
 * @createTime 2019/7/23 0023 22:04
 */


/**
 * 保存用户
 * @param user 用户信息
 */
const saveUser = (user) => {
    localStorage.setItem("user", JSON.stringify(user));
};

/**
 * 移除用户
 */
const removeUser = () => {
    localStorage.removeItem("user");
};

/**
 * 获取用户
 */
const getUser = () => {
    let user = localStorage.getItem("user");
    if (isEmpty(user) || user === 'undefined') {
        return {};
    } else {
        return JSON.parse(user);
    }
};

/**
 * 将一个字符串数组转化为逗号分割的字符串
 * @param arr {Array<string>} 需要被转换的数组
 */
const arrToString = arr => {
    let strings = "";
    for (let string of arr) {
        strings += `${string},`;
    }
    return strings.substring(0, strings.length - 1);
};

/**
 * 获取当前时间
 * @returns {string} yyyy-MM-dd hh:mm:ss 格式的时间字符串
 */
const getNowDateTime = () => {
    let date = new Date();
    let y = date.getFullYear();
    let MM = date.getMonth() + 1;
    MM = MM < 10 ? ('0' + MM) : MM;
    let d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    let h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    let m = date.getMinutes();
    m = m < 10 ? ('0' + m) : m;
    let s = date.getSeconds();
    s = s < 10 ? ('0' + s) : s;
    return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
};
/**
 * 获取当前日期
 * @returns {string} yyyy-MM-dd
 * 正数:未来val天
 * 负数:过去val天
 */
const getNowDate = (val) => {
    var date = new Date();
    if (val !== undefined && val !== 0) {
        var curTime = 0;
        var startDate = 0;
        if (val > 0) {
            curTime = new Date().getTime();
            startDate = curTime + (val * 3600 * 24 * 1000);
            date = new Date(startDate);
        } else if (val < 0) {
            curTime = new Date().getTime();
            startDate = curTime - (Math.abs(val) * 3600 * 24 * 1000);
            date = new Date(startDate);
        }
    }
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    return date.getFullYear() + "-" + month + "-" + strDate;
};
/**
 * 时间格式方法
 *
 * @param {any} timeStamp  时间戳，秒级/毫秒级
 * @param {any} type 格式化时间类型，默认  Y-M-D H:I:S
 * @returns {string} formatTime 格式化后的时间 例如： 2017-05-05 12:09:22
 */
const formatDate = (nS, str) => {
    if (!nS) {
        return ''
    }
    if (isNaN(parseInt(nS))) {
        return nS
    }
    var date = new Date(nS)
    var year = date.getFullYear()
    var mon = date.getMonth() + 1
    var day = date.getDate()
    var hours = date.getHours()
    var minu = date.getMinutes()
    var sec = date.getSeconds()

    if (str === 'yyyy-MM-dd') {
        return year + '-' + (mon < 10 ? '0' + mon : mon) + '-' + (day < 10 ? '0' + day : day)
    } else if (str === 'hh-mm-ss') {
        return (hours < 10 ? '0' + hours : hours) + ':' + (minu < 10 ? '0' + minu : minu) + ':' + (sec < 10 ? '0' + sec : sec)
    } else if (str === 'yyyy/MM/dd') {
        return year + '/' + (mon < 10 ? '0' + mon : mon) + '/' + (day < 10 ? '0' + day : day)
    } else {
        return year + '-' + (mon < 10 ? '0' + mon : mon) + '-' + (day < 10 ? '0' + day : day) + ' ' + (hours < 10 ? '0' + hours : hours) + ':' + (minu < 10 ? '0' + minu : minu) + ':' + (sec < 10 ? '0' + sec : sec)
    }
}
/**
 * 使用@inpute时提供的校验方法 —— 校验纯数字
 * @param value
 * @returns {*}
 */
const checkNumber = value => {
    return value.replace(/[^\d]/g, '')
};

/**
 * 使用@inpute时提供的校验方法 —— 校验金额，允许两位小数,负数
 * @param value
 */
const checkMoney = value => {
    if (value) {
        value = value.toString();
        value = value.replace(/^\D*(\d*(?:\.\d{0,2})?).*$/g, '$1');
        if (value.length >= 2 && value[0] === '0' && (value[1] === '0' || value[1] !== '.')) {
            return '0';
        }
        return value;
    }
};

/**
 * 判空
 */
const isEmpty = (obj) => {
    if (typeof obj === "number" && !isNaN(obj)) {
        return false;
    }
    if (!obj) {
        return true;
    }
    return Object.keys(obj).length < 1
};

/**
 * 保存用户密码
 */
const saveUserPassword = (userPassword) => {
    localStorage.setItem("userPassword", userPassword);
};

/**
 * 获取用户密码
 */
const getUserPassword = () => {
    return localStorage.getItem("userPassword");
};

/**
 * 获取用户密码
 */
const removeUserPassword = () => {
    localStorage.removeItem("userPassword");
};

/**
 * 身份证判断
 */
const isCardId = (card) => {
    let reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
    return reg.test(card);
};

/**
 * 手机号码判断
 * @param number
 * @returns {boolean}
 */
const isPhoneNumber = (number) => {
    let reg = /^(\+86)?1[3456789]\d{9}$/;
    return reg.test(number);
};

export default {
    getUser,
    saveUser,
    removeUser,
    isEmpty,
    checkMoney,
    checkNumber,
    getNowDateTime,
    getNowDate,
    formatDate,
    arrToString,
    saveUserPassword,
    getUserPassword,
    removeUserPassword,
    isCardId,
    isPhoneNumber,
}
