/**
 * 是否
 */
const filter_grade = value => {
    let code = {1: '1年级', 2: '2年级',3:'3年级'};
    return code[value];
};

const filters = {
    filter_grade
};

const install = function (Vue) {
    Object.keys(filters).forEach(key => {
        Vue.filter(key, filters[key])
    })
};

export default install
