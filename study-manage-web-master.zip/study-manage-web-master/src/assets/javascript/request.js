/**
 * @description
 * @author mgLuoBo
 * @createTime 2019/8/19 0019 10:42
 */
import {Message} from "element-ui"
import axios from 'axios'
import util from './util'
import Router from './../../router/index'
import Store from './../../store/index'

//生产环境
let proEnv = require('./../../../config/pro.env.js');
//开发环境
let devEnv = require('./../../../config/dev.env.js');
//代理地址
let basePath = "/manage";
let baseURL = process.env.NODE_ENV === 'production' ? proEnv.hostUrl + basePath : devEnv.hostUrl + basePath;
//文件上传与获取文件
let UPLOAD_FILE_URL = baseURL + "/file/uploadFile";//上传文件接口
let GET_FILE_URL = baseURL + "/file/getFile";//获取文件接口，后面拼接相对路径
let REMOVE_FILE_URL = "/file/removeFile";//获取文件接口，后面拼接相对路径

export const fileUrl = (success_callback) => {
    let file = {
        'BASE_URL': baseURL,
        'UPLOAD_FILE_URL': UPLOAD_FILE_URL,
        'GET_FILE_URL': GET_FILE_URL,
        'REMOVE_FILE_URL': REMOVE_FILE_URL
    };
    success_callback(file);
};

/**
 * 请求API公用函数
 * @param httpMethod 请求方法（GET POST PUT PATCH DELETE） 如果是GET请求并且没有参数 请传空对象{}
 * @param path api路径
 * @param params 请求参数
 * @param success_callback
 * @param fail_callback
 */
export const requestData = function (params, path, success_callback, fail_callback) {
    let loginToken = util.isEmpty(util.getUser()) ? '' : util.getUser().loginToken;

    let method = params.method == "GET" ? "GET" : "POST";

    var request = {
        url: baseURL + path,
        method: method,
        withCredentials: true,
        headers: {
            loginToken: loginToken,
        },
        data: params
    };

    axios(request).then(res => {
        switch (res.data.flag) {
            case 200:
                success_callback && success_callback(res.data);
                break;
            case 401:
                Message.error("无访问权限");
                break;
            case 5002:
                Message.error("系统服务无法连接");
                break;
            case 5003:
                Message.error("登录失效，请重新登录");
                util.removeUser();
                Store.commit("clearTab");
                Router.push({path: "/login"});
                break;
            default:
                Message.error(res.data.message);
                if (fail_callback) {
                    fail_callback && fail_callback(res.data);
                }
        }
    }).catch(function (err) {
        if (err.response) {
            if (err.response.data && err.response.data.code === 401) {
                Message.error(err.response.data.message);
                util.removeUser();
                Store.commit("clearTab");
                Router.push({path: "/login"});
            } else {
                Message.error('服务器异常');
                console.log('------响应错误------');
            }
        } else if (err.request) {
            Message.error('服务器未响应');
            console.log('------没有响应返回------');
        } else {
            console.log('------其他错误------');
        }
        if (fail_callback) {
            fail_callback && fail_callback(err);
        }
    });
};

export default {
    requestData
}