import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
    {
        path: '/home',
        name: 'home',
        component: () => import(/* webpackChunkName: "about" */ '../views/home.vue'),
        children:[
            {
                path: '/page1',
                name: 'page1',
                component: () => import(/* webpackChunkName: "about" */ '../views/page/page1.vue'),
            },
            {
                path: '/page2',
                name: 'page2',
                component: () => import(/* webpackChunkName: "about" */ '../views/page/page2.vue'),
            }
        ]
    },
    {
        path: '/',
        redirect: '/home'
    }
];

const router = new VueRouter({
    routes
})

export default router
