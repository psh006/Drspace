import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import util from './assets/javascript/util.js'
import dict from './assets/javascript/dict.js'
import {
    requestData,
    fileUrl
} from './assets/javascript/request.js'
import Filter from './assets/javascript/filter'

// //引入axios
// import axios from 'axios';
// //注册
// Vue.prototype.axios = axios;
// //全局路径
// Vue.prototype.baseUrl = 'http://localhost:9000'

Vue.config.productionTip = false;
Vue.use(ElementUI, {
    size: 'small'
});
Vue.use(Filter);
Vue.prototype.$util = util;
Vue.prototype.$dict = dict;
Vue.prototype.$request = requestData;

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')

fileUrl((data) => {
    Vue.prototype.$baseUrl = data.BASE_URL;
    Vue.prototype.$uploadFileUrl = data.UPLOAD_FILE_URL;
    Vue.prototype.$getFileUrl = data.GET_FILE_URL;
    Vue.prototype.$removeFileUrl = data.REMOVE_FILE_URL;
});