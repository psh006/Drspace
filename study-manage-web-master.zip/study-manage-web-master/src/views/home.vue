<template>
    <div class="home">
        <el-container class="home-container">
            <el-header class="home-header">
                成都耘云科技
            </el-header>
            <el-container>
                <el-aside width="200px">
                    <el-menu router>
                        <el-menu-item index="/page1">页面一</el-menu-item>
                        <el-menu-item index="/page2">页面二</el-menu-item>
                    </el-menu>
                </el-aside>
                <el-main>
                    <router-view class="router-view-content"/>
                </el-main>
            </el-container>
        </el-container>
    </div>
</template>

<script>
    // @ is an alias to /src

    export default {
        name: 'Home'
    }
</script>

<style lang="less" scoped>
    .home {
        height: 100%;
        .home-container {
            height: 100%;
            .home-header{
                display: flex;
                align-items: center;
                background-color: #409EFF;
                color: white;
            }
        }
    }
</style>
