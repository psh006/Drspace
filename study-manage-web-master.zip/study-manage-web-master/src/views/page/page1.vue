<template>
    <!--该页面展示一个简单的常用后台管理页面-->
    <div class="page1">
        <!--利用element表单自身的样式布局-->
        <el-form inline>
            <el-form-item label="姓名">
                <el-input v-model="searchParams.name" placeholder="请输入姓名"></el-input>
            </el-form-item>
            <el-form-item label="年级">
                <el-select v-model="searchParams.grade">
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in gradeList" :key="item.id" :label="item.label" :value="item.value"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="入学日期">
                <el-date-picker v-model="searchParams.createTime"
                                type="daterange"
                                value-format="yyyy-MM-dd"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"/>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" :loading="status.getDataLoading" @click="handleCurrentChange(1)">搜索</el-button>
            </el-form-item>
        </el-form>
        <div style="padding: 20px 0">
            <el-button type="primary" @click="addStudent">添加</el-button>
        </div>
        <!--这里放一个表格-->
        <el-table :data="studentList" border v-loading="status.getDataLoading">
            <el-table-column label="姓名" prop="name"></el-table-column>
            <el-table-column label="年级" prop="grade">
                <!--自定义+管道过滤-->
                <template slot-scope="scope">{{scope.row.grade | filter_grade}}</template>
            </el-table-column>
            <el-table-column label="入学日期" prop="createTime"></el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button type="text" @click="updateStudent(scope.row)">编辑</el-button>
                    <el-button type="text" @click="deleteStudent(scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <el-pagination
                layout="total, sizes, prev, pager, next, jumper"
                :current-page="searchParams.currentPage"
                :page-sizes="[5, 10, 20, 50]"
                :page-size="searchParams.pageSize"
                :total="studentListTotal"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
        </el-pagination>
        <!--添加或编辑学生的弹窗-->
        <el-dialog :title="studentDialogTitle" :visible.sync="status.studentDialogOpen" @closed="studentDialogClosed" width="30%">
            <el-form :model="studentFormData" ref="studentForm" :rules="studentFormRules" label-width="110px">
                <el-form-item label="姓名" v-model="studentFormData.name" prop="name">
                    <el-input v-model="studentFormData.name" placeholder="请输入姓名" style="width: 200px"></el-input>
                </el-form-item>
                <el-form-item label="年级" prop="grade">
                    <el-select v-model="studentFormData.grade" style="width: 200px">
                        <el-option v-for="item in gradeList" :key="item.id" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="入学日期" prop="createTime">
                    <el-date-picker v-model="studentFormData.createTime"
                                    style="width: 200px"
                                    type="date"
                                    value-format="yyyy-MM-dd"
                                    placeholder="选择入学日期"/>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                    <el-button type="primary" plain @click="status.studentDialogOpen = false">取消</el-button>
                    <el-button type="primary" @click="submitStudent">确定</el-button>
                </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "page1",

        data() {
            // 这里是数据中心 这里面的值会驱动页面渲染
            return {
                searchParams: {
                    name: "",
                    grade: "",
                    createTime: [],
                    currentPage: 1,
                    pageSize: 10
                },
                status: {
                    getDataLoading: false,
                    studentDialogOpen: false
                },
                gradeList: [
                    {
                        id: "1",
                        label: "1年级",
                        value: "1"
                    },
                    {
                        id: "2",
                        label: "2年级",
                        value: "2"
                    },
                    {
                        id: "3",
                        label: "3年级",
                        value: "3"
                    }
                ],
                studentFormData: {
                    name: "",
                    grade: "",
                    createTime: "",
                },
                studentFormRules: {
                    name: [
                        {required: true, message: '请输入姓名', trigger: 'blur'}
                    ],
                    grade: [
                        {required: true, message: '请选择年级', trigger: 'blur'}
                    ],
                    createTime: [
                        {required: true, message: '请选择开学时间', trigger: 'blur'}
                    ]
                },
                studentList: [],
                studentListTotal: [],
                studentDialogTitle: "添加学生"
            }
        },
        // created函数会在页面渲染完成之前加载，一般在这里面请求数据
        created() {
            this.getData();
        },
        // 在这里面定义页面所需函数
        methods: {
            // 请求列表数据
            getData() {
                let params = {...this.searchParams};
                if (params.createTime && params.createTime.length >= 2) {
                    params.startDate = params.createTime[0];
                    params.endDate = params.createTime[1];
                }
                console.log("请求时带给后台的参数:", params);
                this.status.getDataLoading = true;
                // 这里模拟一下请求数据
                let request = setTimeout(() => {
                    this.studentList = [
                        {
                            id: "1",
                            name: "小明",
                            grade: "1",
                            createTime: "2020-9-1",
                        },
                        {
                            id: "2",
                            name: "小红",
                            grade: "2",
                            createTime: "2019-9-1",
                        },
                        {
                            id: "3",
                            name: "小刚",
                            grade: "3",
                            createTime: "2018-9-1",
                        }
                    ];
                    this.studentListTotal = this.studentList.length;
                    this.status.getDataLoading = false;
                    clearTimeout(request);
                }, 1000)
            },
            // 每页几条
            handleSizeChange(pageSize) {
                this.searchParams.pageSize = pageSize;
                this.getData();
            },
            // 当前第几页
            handleCurrentChange(CurrentPage) {
                this.searchParams.currentPage = CurrentPage;
                this.getData();
            },
            // 添加学生
            addStudent() {
                this.status.studentDialogOpen = true;
            },
            // 编辑学生
            updateStudent(student) {
                this.status.studentDialogOpen = true;
                this.$nextTick(() => {
                    this.studentFormData = {...student};
                });
            },
            // 删除学生
            deleteStudent(student) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    // ... (这里进行接口请求)
                    this.$message.success(`删除了学生${student.name}`);
                    this.getData();
                }).catch(() => {
                });
            },
            // 当弹窗关闭时情况表单状态
            studentDialogClosed() {
                this.$refs.studentForm.resetFields();
            },
            // 提交学生信息
            submitStudent() {
                this.$refs.studentForm.validate((valid) => {
                    if (valid) {
                        // ... (这里进行接口请求)
                        this.status.studentDialogOpen = false;
                        this.$message.success("编辑成功");
                        this.getData();
                    }
                });
            }
        }
    }
</script>


<style lang="less" scoped>
    /*less 是css预编译语言，比css更好用*/
    /*scoped 是限制样式只在本组件使用*/

</style>