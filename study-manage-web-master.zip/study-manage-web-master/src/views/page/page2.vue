<template>
    <div class="page2">
        第二个页面
    </div>
</template>

<script>
    export default {
        name: "page2"
    }
</script>

<style scoped>

</style>