<template>
	<view class="shopping-mall">
		商城
	</view>
</template>

<script>
export default {
	name: 'shopping-mall',
	data() {
		return {};
	},
	onLoad() {},
	onShow() {},
	methods: {}
};
</script>

<style></style>
