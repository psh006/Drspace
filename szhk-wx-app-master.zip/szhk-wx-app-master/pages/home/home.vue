<template>
	<view class="home">
		首页
	</view>
</template>

<script>
export default {
	name: 'home',
	data() {
		return {};
	},
	onLoad() {},
	onShow() {},
	methods: {}
};
</script>

<style></style>
