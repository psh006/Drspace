<template>
	<view class="customer">
		会员
	</view>
</template>

<script>
export default {
	name: 'customer',
	data() {
		return {};
	},
	onLoad() {},
	onShow() {},
	methods: {}
};
</script>

<style></style>
