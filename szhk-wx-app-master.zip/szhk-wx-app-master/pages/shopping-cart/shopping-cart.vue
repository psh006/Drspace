<template>
	<view class="education">
		购物车
	</view>
</template>

<script>
export default {
	name: 'education',
	data() {
		return {};
	},
	onLoad() {},
	onShow() {},
	methods: {}
};
</script>

<style></style>
