<template>
	<view class="index">
		<view class="index-content">
			<home class="index-content-item" v-if="active === 0"></home>
			<shoppingMall class="index-content-item"  v-else-if="active === 1"></shoppingMall>
			<education class="index-content-item" v-else-if="active === 2"></education>
			<shoppingCart class="index-content-item" v-else-if="active === 3"></shoppingCart>
			<customer class="index-content-item" v-else></customer>
		</view>
		<van-tabbar class="index-tabbar" :active="active" @change="tabbarChange" :safe-area-inset-bottom="false">
			<van-tabbar-item v-for="(item, index) in icon" :key="index">
				<image slot="icon" :src="item.normal" mode="aspectFit" class="tabbar-icon" />
				<image slot="icon-active" :src="item.active" mode="aspectFit" class="tabbar-icon" />
				{{ item.name }}
			</van-tabbar-item>
		</van-tabbar>
	</view>
</template>

<script>
import home from './../home/home.vue';
import customer from './../customer/customer.vue';
import education from './../education/education.vue';
import shoppingCart from './../shopping-cart/shopping-cart.vue';
import shoppingMall from './../shopping-mall/shopping-mall.vue';

export default {
	name: 'index',
	components: {
		home,
		customer,
		education,
		shoppingCart,
		shoppingMall
	},
	data() {
		return {
			icon: [
				{
					normal: require('./../../static/image/tabbar-home.png'),
					active: require('./../../static/image/tabbar-home-active.png'),
					name: '首页'
				},
				{
					normal: require('./../../static/image/tabbar-shopping-mall.png'),
					active: require('./../../static/image/tabbar-shopping-mall-active.png'),
					name: '商城'
				},
				{
					normal: require('./../../static/image/tabbar-education.png'),
					active: require('./../../static/image/tabbar-education-active.png'),
					name: '教育'
				},
				{
					normal: require('./../../static/image/tabbar-shopping-cart.png'),
					active: require('./../../static/image/tabbar-shopping-cart-active.png'),
					name: '购物车'
				},
				{
					normal: require('./../../static/image/tabbar-customer.png'),
					active: require('./../../static/image/tabbar-customer-active.png'),
					name: '会员'
				}
			],
			active: 0
		};
	},
	onLoad() {},
	methods: {
		tabbarChange(event) {
			this.active = event.detail;
			uni.setNavigationBarTitle({
				title: this.icon[event.detail].name
			});
		}
	}
};
</script>

<style lang="less">
.index {
	height: 100%;
	.index-content{
		height: calc(100% - 100rpx);
		.index-content-item{
			height: 100%;
		}
	}
	.index-tabbar {
		.tabbar-icon {
			width: 50rpx;
			height: 50rpx;
		}
	}
}
</style>
