import mineApi from "./api/mineApi.js"

/**
 * 保存用户
 * @param user 用户信息
 */
const saveUser = (user) => {
	uni.setStorageSync("user", JSON.stringify(user));
};

/**
 * 移除用户
 */
const removeUser = () => {
	uni.removeStorageSync("user")
};

/**
 * 获取用户
 */
const getUser = () => {
	let user = uni.getStorageSync("user");
	if (isEmpty(user) || user === 'undefined') {
		return {};
	} else {
		return JSON.parse(user);
	}
};

/**
 * 判空
 */
const isEmpty = (obj) => {
	if (typeof obj === "number" && !isNaN(obj)) {
		return false;
	}
	if (!obj) {
		return true;
	}
	return Object.keys(obj).length < 1
};

/**
 * 检查用户是否授权(默认检查userInfo)
 * @param {Funtion} yes_callback 已经授权的回调
 * @param {Funtion} no_callback 没有授权的回调
 * @param {String} setting 要检查的授权类型  所有类型见 https://uniapp.dcloud.io/api/other/authorize?id=scope-%e5%88%97%e8%a1%a8
 */
const checkSetting = (yes_callback, no_callback, setting) => {
	uni.getSetting({
		success: res => {
			let flag = res.authSetting[setting || 'scope.userInfo'];
			if (flag) {
				yes_callback && yes_callback(flag, res)
			} else {
				no_callback && no_callback(flag, res)
			}
		},
		fail: err => {
			console.log("检查接口调用失败:", err);
		}
	});
}

/**
 * 输入的数字转换为金额（用于限制输入金额）
 */
const numberToMoney = (val) => {
	// 	  if (this.integer != undefined) {
	val = val + "";
	val = val.replace(/[^\d]/g, ''); //保留数字
	if (val.length > 1) {
		val = val.replace(/\b(0+)/gi, ""); //取最前面的0

	}
	//                 } else {
	val = val + "";
	val = val.replace(/[^\d.]/g, ""); //清除“数字”和“.”以外的字符
	val = val.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的
	val = val.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
	val = val.replace(/^()*(\d+)\.(\d\d).*$/, '$1$2.$3'); //只能输入两个小数
	if (val.indexOf(".") < 0 && val != "") { //以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
		val = parseFloat(val);
	}
	// }
	return val;
};

/**
 * 身份证判断
 */
const isCardId = (card) => {
	let reg =
		/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
	return reg.test(card);
};

/**
 * Email判断
 */
const isEmail = (val) => {
	let reg =
		/^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
	return reg.test(val);
};

/**
 * 手机号判断
 */
const isPhoneNumber = (val) => {
	let reg =
		/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
	return reg.test(val);
}


const isQQ = (val) => {
	let reg =
		/^[1-9][0-9]{5,10}/;
	return reg.test(val);
}

const calculationTime = (startDateTime, endDateTime, calculationType) => {
	startDateTime = startDateTime.replace(/-/g,"/");
	endDateTime = endDateTime.replace(/-/g,"/");
	let startTime = new Date(startDateTime);
	let endTime = new Date(endDateTime);
	switch (calculationType) {
		case "second":
			return Math.floor((endTime - startTime) / 1000);
		case "minutes":
			return Math.floor((endTime - startTime) / 1000 / 60);
		case "hour":
			return Math.floor((endTime - startTime) / 1000 / 60 / 60);
		case "day":
			return Math.floor((endTime - startTime) / 1000 / 60 / 60 / 24);
	}
}

/**
 * 获取当前时间
 * @returns {string} yyyy-MM-dd hh:mm:ss 格式的时间字符串
 */
const getNowDateTime = () => {
    let date = new Date();
    let y = date.getFullYear();
    let MM = date.getMonth() + 1;
    MM = MM < 10 ? ('0' + MM) : MM;
    let d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    let h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    let m = date.getMinutes();
    m = m < 10 ? ('0' + m) : m;
    let s = date.getSeconds();
    s = s < 10 ? ('0' + s) : s;
    return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
};

/**
 * 更新用户信息
 * @return 
 * true:"更新成功"
 * false:"更新失败(无实名)"
 */
const updateCustomerMap = () => {
	let p = new Promise((resolve, reject) => {
		if (isEmpty(getUser().customerMap)) {
			resolve(false);
			return;
		}
		mineApi.queryCustomerInfoWx({
			customerId: getUser().customerMap.customerId
		}, (data) => {
			let user = getUser();
			user.customerMap = data.data[0];
			saveUser(user);
			resolve(true);
		}, () => {
			resolve(false);
		});
	})
	return p;
};

export default {
	saveUser,
	removeUser,
	getUser,
	isEmpty,
	numberToMoney,
	checkSetting,
	isCardId,
	updateCustomerMap,
	isEmail,
	isPhoneNumber,
	isQQ,
	calculationTime,
	getNowDateTime
}
