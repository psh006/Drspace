import Util from "./util.js";

let apiBaseUrl;
let imgBaseUrl;

if (process.env.NODE_ENV === 'development') {
	apiBaseUrl = "http://10.168.1.200:9000";
	imgBaseUrl = "http://10.168.1.200:8080/kiegameImg";
	// apiBaseUrl = "https://kienewdemo.kiegame.com/api";
	// imgBaseUrl = "https://kienewdemo.kiegame.com/kiegameImg";
} else {
	apiBaseUrl = "http://10.168.1.200:9000";
	imgBaseUrl = "http://10.168.1.200:8080/kiegameImg";
	// apiBaseUrl = "https://kienewdemo.kiegame.com/api";
	// imgBaseUrl = "https://kienewdemo.kiegame.com/kiegameImg";
}

export const getImgBaseUrl = function() {
	return imgBaseUrl;
};

export const getImageUploadUrl = function() {
	return apiBaseUrl + "/manage/service/imageUpload";
};

export const request = function(params, httpMethod, model, path, success_callback, fail_callback) {
	uni.request({
		url: apiBaseUrl + model + path,
		method: httpMethod,
		header: {
			'content-type': 'application/json',
			'loginToken': Util.getUser().loginToken
		},
		data: params,
		success: function(res) {
			switch (res.data.code) {
				case 200:
					success_callback && success_callback(res.data);
					break;
				case 401:
					console.log('无访问权限');
					break;
				case 5002:
				case 5003:
					console.log('登录失效，请重新登录');
					break;
				default:
					console.error(res.data.message);
					if (fail_callback) {
						fail_callback && fail_callback(res.data);
					}
			}
		},
		fail: function(error) {
			if (err.response) {
				if (err.response.data && err.response.data.code === 401) {

				} else {
					console.log('------响应错误------');
				}
			} else if (err.request) {
				console.log('------没有响应返回------');
			} else {
				console.log('------其他错误------');
			}
			if (fail_callback) {
				fail_callback && fail_callback(err.data);
			}
		}
	})
}


export const deleteImage = function(imageUrl, success_callback, fail_callback) {
	uni.request({
		url: apiBaseUrl + "/manage/service/deleteImage",
		method: "GET",
		header: {
			'loginToken': Util.getUser().loginToken
		},
		data: {
			imageUrl: imageUrl
		},
		success: function(res) {
			switch (res.data.code) {
				case 200:
					success_callback && success_callback(res.data);
					break;
				case 401:
					console.log('无访问权限');
					break;
				case 5002:
				case 5003:
					console.log('登录失效，请重新登录');
					break;
				default:
					console.error(res.data.message);
					if (fail_callback) {
						fail_callback && fail_callback(res.data);
					}
			}
		},
		fail: function(error) {
			if (err.response) {
				if (err.response.data && err.response.data.code === 401) {

				} else {
					console.log('------响应错误------');
				}
			} else if (err.request) {
				console.log('------没有响应返回------');
			} else {
				console.log('------其他错误------');
			}
			if (fail_callback) {
				fail_callback && fail_callback(err.data);
			}
		}
	})
}
